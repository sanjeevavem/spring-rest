package ae.etisalat.cw.restws.dao.generic;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

@Repository
public class GenericOrderCreationDAOImpl implements GenericOrderCreationDAO {

	
    private static final Logger logger = LogManager.getLogger(GenericOrderCreationDAOImpl.class);
    
    @Autowired
    @Qualifier("crmJdbcTemplate")
	private NamedParameterJdbcTemplate crmJdbcTemplate;
    
//    @Autowired
//    @Qualifier("simpleJdbcCallTemplate")
    private SimpleJdbcCall simpleJdbcCall;
    
    @Autowired
    @Qualifier("crmDataSource")
    private DataSource cDataSource;
    
//    @Autowired
//    @Qualifier("simpleJdbcInsertTemplate")
//    private SimpleJdbcInsert simpleJdbcInsert;

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Map<String, Object> query(DataSourceType dataSourceType, String sql, Map<String, Object> args)
			throws DataAccessException {
        logger.info("Executing the query[{}], with params[{}] for a single record", Objects.toString(sql), Objects.toString(args));
        Map<String, Object> result = null;

        try {
            result = jdbcTemplate(dataSourceType).queryForMap(sql, args);
        }
        catch (DataAccessException e) {
            if (e instanceof EmptyResultDataAccessException) {
                logger.warn("No results found for the given query");
            }
            else {
                logger.error("Error in executing the query", e);
                throw e;
            }
        }
        return result;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<Map<String, Object>> queryList(DataSourceType dataSourceType, String sql, Map<String, Object> args)	throws DataAccessException {
		
        logger.info("Executing the query[{}], with params[{}] for a list", Objects.toString(sql), Objects.toString(args));
        List<Map<String, Object>> result = null;
        try {
            result = jdbcTemplate(dataSourceType).queryForList(sql, args);
        }
        catch (DataAccessException e) {
            if (e instanceof EmptyResultDataAccessException) {
                logger.warn("No results found for the given query");
            }
            else {
                logger.error("Error in executing the query", e);
                throw e;
            }
        }
        return result;
	}
	

    @Override
	public int insert(DataSourceType dataSourceType, String sql, Map<String, Object> args)	throws DataAccessException {
		
        logger.info("Executing the query[{}], with params[{}] for a list", Objects.toString(sql), Objects.toString(args));
        int result = 0;
        try {
            result = jdbcTemplate(dataSourceType).update(sql, args);
        }
        catch (DataAccessException e) {
            if (e instanceof EmptyResultDataAccessException) {
                logger.warn("No results found for the given query");
            }
            else {
                logger.error("Error in executing the query", e);
                throw e;
            }
        }
        return result;
	}
	
    private NamedParameterJdbcTemplate jdbcTemplate(DataSourceType dataSourceType) {
        if (DataSourceType.cbcm_cw_datasource.equals(dataSourceType)) {
            return crmJdbcTemplate;
        }else{
           return null;
        }
    }
    
//    private SimpleJdbcInsert jdbcInsertTemplate(DataSourceType dataSourceType) {
//        if (DataSourceType.cbcm_cw_datasource.equals(dataSourceType)) {
//            return simpleJdbcInsert;
//        }else{
//           return null;
//        }
//    }
    
    public Map<String, Object> executeProcedure(String procName, HashMap< String, Object> args) throws DataAccessException{
      logger.info("Executing the executeProcedure[{}], with params[{}] for ", procName, Objects.toString(args));
    	Map<String, Object> out = null;
    	try
    	 {
    		simpleJdbcCall = new SimpleJdbcCall(cDataSource);
    		out =simpleJdbcCall.withProcedureName(procName).execute(args);
    	 }catch(DataAccessException e){
    		if (e instanceof EmptyResultDataAccessException) {
              logger.warn("No results found for the given query");
    		}
    		else {
              logger.error("Error in executing the query", e);
              throw e;
    		}
        }
      return out;
    }
}
