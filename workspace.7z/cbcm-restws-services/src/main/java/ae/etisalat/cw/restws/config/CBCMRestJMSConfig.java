package ae.etisalat.cw.restws.config;

//@Configuration
//@EnableJms
//@ComponentScan(basePackages={"ae.etisalat.cbcm.restws"})
public class CBCMRestJMSConfig {

//
//	 // Defines the JNDI context factory.
//	 public final static String JNDI_FACTORY="weblogic.jndi.WLInitialContextFactory"; // need to be changed 
//
//	 // Defines the JMS context factory.
//	 public final static String JMS_FACTORY="jms/TestConnectionFactory"; // need to be changed 
//
//	 // Defines the queue.
//	 public final static String QUEUE="jms/TestJMSQueue";  // need to be changed 
//	 String url ="t3://localhost:7001";
//	 
//	@Bean 
//	public QueueConnectionFactory connectionFactory() throws Exception
//	{ 
//	 Hashtable<String,String> env = new Hashtable<String,String>();
//     env.put(Context.INITIAL_CONTEXT_FACTORY, JNDI_FACTORY);
//     env.put(Context.PROVIDER_URL, url);
//     InitialContext ctx =new InitialContext(env);
//     QueueConnectionFactory qconFactory = (QueueConnectionFactory) ctx.lookup(JMS_FACTORY);
//	 return qconFactory; 
//	 }
//	
//	@Bean 
//	public JmsTemplate jmsTemplate() throws Exception
//	{ 
//	  JmsTemplate template = new JmsTemplate();
//	  template.setConnectionFactory(connectionFactory());
//	 return template;
//	}	
//	
//	@Bean 
//	public DefaultJmsListenerContainerFactory jmsListenerContainerFactory() throws Exception 
//	{ 
//	 DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory(); 
//	 factory.setConnectionFactory(connectionFactory()); factory.setConcurrency("1-1");
//	 return factory; 
//	 }
}
