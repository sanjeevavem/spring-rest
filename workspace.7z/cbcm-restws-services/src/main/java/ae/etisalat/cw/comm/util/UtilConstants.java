package ae.etisalat.cw.comm.util;

public class UtilConstants {

	public static final String HIBERNATE_DIALECT_PROPERTY = "hibernate.dialect";
	public static final String HIBERNATE_DIALECT = "${" + HIBERNATE_DIALECT_PROPERTY + "}";
	public static final String HIBERNATE_SHOW_SQL_PROPERTY = "hibernate.show_sql";
	public static final String HIBERNATE_CURRENT_SESSION_CONTEXT_CLASS_PROPERTY = "current_session_context_class";
	public static final String HIBERNATE_CONNECTION_DATASOURCE = "hibernate.connection.datasource";

  public static final String API="API";
  public static final String LOG_TYPE="LOG_TYPE";
  public static final String LOG_TYPE_REQUEST="REQUEST";
  public static final String UID = "TXN_ID";
  public static final String CHANNEL="CHANNEL";
  public static final String SUB_CHANNEL="SUB_CHANNEL";
  public static final String OPERATION="OPERATION";
  public static final String JSON_REQUEST="JSON_REQUEST";
  public static final String JSON_RESPONSE="JSON_RESPONSE";
  
  // Offers
  public static final String OFFER_TYPE_RATEPLAN="R";
}
