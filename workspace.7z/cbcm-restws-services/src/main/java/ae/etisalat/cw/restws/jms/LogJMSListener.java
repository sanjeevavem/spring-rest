package ae.etisalat.cw.restws.jms;

import javax.annotation.PostConstruct;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.springframework.stereotype.Component;

/**
 * @author svem
 *
 */
//@Component
public class LogJMSListener /*implements MessageListener*/ {

	@PostConstruct
	public void message(){
		System.out.println("LogJMSListener");
	}
	
//	@JmsListener(destination="jms/TestJMSQueue")
//	public void logRESTMessages(Message message) throws JMSException{
//		String messageData = null;
//		System.out.println("Received message " + message); 
//		if(message instanceof TextMessage) 
//		 { 
//			TextMessage textMessage = (TextMessage)message; 
//			 messageData = textMessage.getText(); 
//		 } 
//		System.out.println(messageData);
//	}

//	@Override
//	public void onMessage(Message message) {
//		// TODO Auto-generated method stub
//		String messageData = null;
//		System.out.println("Received message " + message); 
//		if(message instanceof TextMessage) 
//		 { 
//			TextMessage textMessage = (TextMessage)message; 
//			 try {
//				messageData = textMessage.getText();
//			} catch (JMSException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			} 
//		 } 
//		System.out.println("LogJMSListener"+messageData);
//		
//	}
}
