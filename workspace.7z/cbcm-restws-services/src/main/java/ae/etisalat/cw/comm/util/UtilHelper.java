package  ae.etisalat.cw.comm.util;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.UUID;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;

public class UtilHelper {

	private static final Logger logger = LogManager.getLogger(UtilHelper.class);
	  
	public  Object evalExpr(String fieldName, Expression expVariable, DelegateExecution delegateExecution) {
		Object returnValue = expVariable == null ? null : expVariable.getValue(delegateExecution);
		if (logger.isDebugEnabled()) {
			Throwable t = new Throwable();
			StackTraceElement[] elements = t.getStackTrace();
			String callerClassName = elements[1].getClassName();
			LogManager.getLogger(callerClassName).debug("fieldName:[{}], value:[{}]", fieldName, returnValue);
		}
		return returnValue;
	}
	
	public HashMap<String, Object> convertJSONToMap(JsonObject json){
		Type type = new TypeToken<HashMap<String, Object>>(){}.getType();
		HashMap<String, Object> map= new Gson().fromJson(json, type);
	 return map;
	}
	
	public HashMap<String, Object> convertJSONStringToMap(String jsonStr){
		JsonObject json = new Gson().fromJson(jsonStr, JsonObject.class);
		Type type = new TypeToken<HashMap<String, Object>>(){}.getType();
	 return new Gson().fromJson(json, type);
	}
	
	public String getUUID(){
		ThreadContext.put(UtilConstants.UID, UUID.randomUUID().toString());
		String txnId = org.apache.logging.log4j.ThreadContext.get(UtilConstants.UID);
		logger.debug("TXN_ID from thread context: " + txnId);
        if (StringUtils.isBlank(txnId)) {
            txnId = UUID.randomUUID().toString();
        }
        ThreadContext.put(UtilConstants.UID, txnId);
      return txnId;
	}
	
	public void populateThreadContext(String channel, String sub_channel, String transaction_id,String operation) {
		if (StringUtils.isNotBlank(channel)) {
			ThreadContext.put(UtilConstants.CHANNEL, channel);
		}
		if (StringUtils.isNotBlank(sub_channel)) {
			ThreadContext.put(UtilConstants.SUB_CHANNEL, sub_channel);
		}
		if (StringUtils.isNotBlank(transaction_id)) {
			ThreadContext.put(UtilConstants.UID, transaction_id);
		} else {
			ThreadContext.put(UtilConstants.UID, UUID.randomUUID().toString());
		}
		if (StringUtils.isNotBlank(operation)) {
			ThreadContext.put(UtilConstants.OPERATION, operation);
		} 
	}
}
