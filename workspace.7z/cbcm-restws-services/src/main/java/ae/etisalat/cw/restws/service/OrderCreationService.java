package ae.etisalat.cw.restws.service;

import com.google.gson.JsonObject;

import ae.etisalat.cw.restws.controllers.OrderResponseWrapper;

public interface OrderCreationService {
	public OrderResponseWrapper createOrder(JsonObject orderRequest) throws Exception;
}
