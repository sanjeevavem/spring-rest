package ae.etisalat.cw.restws.dao.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="CW_MST_SQL_CONFIG")
public class SQLConfig implements Serializable {

    private static final long serialVersionUID = -4514072080372276139L;
    
    @Column(name="config_code")
	private String configCode;
    
    @Column(name="operation")
	private String opration;
    
    @Column(name="API")
	private String api;
    
    @Column(name="description")
	private String description;
    
	@Column(name="CREATED_USER_ID")
	private String createdUserId;
	
	@Column(name="CREATED_DATE")
	private Timestamp createdDate;
	
	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;
	
	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	public String getConfigCode() {
		return configCode;
	}

	public void setConfigCode(String configCode) {
		this.configCode = configCode;
	}

	public String getOpration() {
		return opration;
	}

	public void setOpration(String opration) {
		this.opration = opration;
	}

	public String getApi() {
		return api;
	}

	public void setApi(String api) {
		this.api = api;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCreatedUserId() {
		return createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedUserId() {
		return modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public Timestamp getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	@Override
	public String toString() {
		return "SQLConfig [configCode=" + configCode + ", opration=" + opration + ", api=" + api + ", description="
				+ description + ", createdUserId=" + createdUserId + ", createdDate=" + createdDate
				+ ", modifiedUserId=" + modifiedUserId + ", modifiedDate=" + modifiedDate + "]";
	}
}
