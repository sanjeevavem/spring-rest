package ae.etisalat.cw.restws.util;

import java.util.HashMap;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.google.gson.JsonObject;

@Component
public class JSONUtil {
	
	  private static final Logger logger = LogManager.getLogger(JSONUtil.class);
	  
	public HashMap<String, Object> getMapFromJson(JsonObject jsonObject){
		
		HashMap<String, Object> map = new HashMap<String, Object>();
		  //   "productGroup": "BL","Account_Number":"0503264246","Product":"BFXI","ordertype":"NEW","OFFERTYPE":"RATEPLAN","OFFERCODE":"RP1001"
		map.put("ProductGroup", jsonObject.get("ProductGroup").getAsString());
		map.put("Account_Number", jsonObject.get("Account_Number").getAsString());
		map.put("Product", jsonObject.get("Product").getAsString());
		map.put("Ordertype", jsonObject.get("Ordertype").getAsString());
		map.put("OfferType", jsonObject.get("OfferType").getAsString());
		map.put("OfferCode", jsonObject.get("OfferCode").getAsString());
		
	 return map;
	}
	
	public static Object evalExpr(String fieldName, Expression expVariable, DelegateExecution delegateExecution) {
		Object returnValue = expVariable == null ? null : expVariable.getValue(delegateExecution);
		if (logger.isDebugEnabled()) {
			Throwable t = new Throwable();
			StackTraceElement[] elements = t.getStackTrace();
			String callerClassName = elements[1].getClassName();
			LogManager.getLogger(callerClassName).debug("fieldName:[{}], value:[{}]", fieldName, returnValue);
		}
		return returnValue;
	}
	

}
