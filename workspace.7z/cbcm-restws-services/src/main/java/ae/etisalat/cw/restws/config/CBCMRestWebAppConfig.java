package ae.etisalat.cw.restws.config;

import java.util.List;
import java.util.Properties;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.activiti.engine.ProcessEngineConfiguration;
import org.activiti.engine.impl.asyncexecutor.DefaultAsyncJobExecutor;
import org.activiti.engine.impl.history.HistoryLevel;
import org.activiti.spring.ProcessEngineFactoryBean;
import org.activiti.spring.SpringProcessEngineConfiguration;
import org.hibernate.ejb.HibernatePersistence;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.CommonAnnotationBeanPostProcessor;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
//import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.GsonHttpMessageConverter;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import ae.etisalat.cw.comm.util.UtilConstants;

@Configuration
@EnableWebMvc
//@EnableJms
@EnableTransactionManagement
@PropertySource("classpath:sql-queries.properties")
@ComponentScan(basePackages = { "ae.etisalat.cbcm.restws", "ae.etisalat.activiti" })
//@EnableJpaRepositories("ae.etisalat.cw.restws.dao.repository")
public class CBCMRestWebAppConfig extends WebMvcConfigurerAdapter /* WebMvcConfigurationSupport */ {

	// @Override
	// protected void configureContentNegotiation(ContentNegotiationConfigurer
	// configurer) {
	// configurer.favorPathExtension(false).favorParameter(true).parameterName("mediaType").ignoreAcceptHeader(true).useJaf(false)
	// .defaultContentType(MediaType.APPLICATION_JSON).mediaType("xml",
	// MediaType.APPLICATION_XML)
	// .mediaType("json", MediaType.APPLICATION_JSON);
	// }

	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	@Bean
	public CommonAnnotationBeanPostProcessor commonAnnotationBeanPostProcessor() {
		CommonAnnotationBeanPostProcessor processor = new CommonAnnotationBeanPostProcessor();
		processor.setAlwaysUseJndiLookup(true);
		return processor;
	}

	@Override
	public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
		GsonHttpMessageConverter msgConverter = new GsonHttpMessageConverter();
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		msgConverter.setGson(gson);
		converters.add(msgConverter);
		super.configureMessageConverters(converters);
	}

//	@Bean
//	public DataSource crmDataSource() throws NamingException {
//
//		DataSource crmDataSource = (DataSource) new InitialContext().lookup("cbcm_cw_datasource");
//		return crmDataSource;
//	}
//	
	@Bean
	public DataSource crmDataSource() {
		DriverManagerDataSource ds = new DriverManagerDataSource();
		ds.setDriverClassName("oracle.jdbc.driver.OracleDriver");
		ds.setUrl("jdbc:oracle:thin:@au170.etisalat.corp.ae:1521:CUSTDEV");
		ds.setUsername("cust_dev");
		ds.setPassword("cust_dev");
		return ds;
	}

	@Bean
	public NamedParameterJdbcTemplate crmJdbcTemplate() throws NamingException {

		return new NamedParameterJdbcTemplate(crmDataSource());
	}

//	@Bean
//	public SimpleJdbcCall simpleJdbcCallTemplate() throws NamingException {
//		return new SimpleJdbcCall(crmDataSource());
//	}
//	
//	@Bean
//	public SimpleJdbcInsert simpleJdbcInsertTemplate() throws NamingException{
//		return new SimpleJdbcInsert(crmDataSource());
//	}

	/* JMS Related Configuration need to move to another configuration class */

	// // Defines the JNDI context factory.
	// public final static String
	// JNDI_FACTORY="weblogic.jndi.WLInitialContextFactory"; // need to be
	// changed
	//
	// // Defines the JMS context factory.
	// public final static String JMS_FACTORY="jms/TestConnectionFactory"; //
	// need to be changed
	//
	// // Defines the queue.
	// public final static String QUEUE="jms/TestJMSQueue"; // need to be
	// changed
	// String url ="t3://DXB00070315:7001";
	//
	// @Bean
	// public QueueConnectionFactory connectionFactory() throws Exception
	// {
	// Hashtable<String,String> env = new Hashtable<String,String>();
	// env.put(Context.INITIAL_CONTEXT_FACTORY, JNDI_FACTORY);
	// env.put(Context.PROVIDER_URL, url);
	// env.put("java.naming.security.principal", "weblogic");
	// env.put("java.naming.security.credentials", "etisalat1");
	// InitialContext ctx =new InitialContext(env);
	// QueueConnectionFactory qconFactory = (QueueConnectionFactory)
	// ctx.lookup("weblogic.jms.XAConnectionFactory");
	// return qconFactory;
	// }
	//
	// @Bean
	// public JmsTemplate jmsTemplate() throws Exception
	// {
	// JmsTemplate template = new JmsTemplate();
	// template.setConnectionFactory(connectionFactory());
	// template.setDefaultDestinationName("TestJMSQueue");
	// JndiObjectFactoryBean jndiObjectFactoryBean = new
	// JndiObjectFactoryBean();
	// jndiObjectFactoryBean.setJndiName("jms/TestJMSQueue");
	// DestinationImpl destination = new DestinationImpl();
	// destination.setPort(7001);
	// destination.setReferenceName("TestJMSQueue");
	// template.setDefaultDestination(destination);
	// return template;
	// }
	//
	// @Bean
	// public DefaultJmsListenerContainerFactory jmsListenerContainerFactory()
	// throws Exception
	// {
	// DefaultJmsListenerContainerFactory factory = new
	// DefaultJmsListenerContainerFactory();
	// factory.setConnectionFactory(connectionFactory());
	// factory.setConcurrency("1-1");
	// return factory;
	// }
	//
	// @Bean
	// public DefaultMessageListenerContainer listenerContainer() throws
	// Exception {
	// DefaultMessageListenerContainer container = new
	// DefaultMessageListenerContainer();
	// container.setConnectionFactory(connectionFactory());
	// container.setDestinationName(QUEUE);
	// container.setMessageListener(new LogJMSListener());
	// return container;
	// }

	/* Activiti spring */

	@Bean
	public ProcessEngineFactoryBean processEngine() throws NamingException {
		ProcessEngineFactoryBean processEngineFactoryBean = new ProcessEngineFactoryBean();

		SpringProcessEngineConfiguration configuration = new SpringProcessEngineConfiguration();
		configuration.setTransactionManager(this.dataSourceTransactionManager());
		// configuration.setDatabaseType("oracle");
		configuration.setAsyncExecutorActivate(true);
		configuration.setEnableProcessDefinitionInfoCache(true);
		configuration.setHistoryLevel(HistoryLevel.FULL);
		configuration.setDataSource(crmDataSource());
		configuration.setDatabaseSchemaUpdate(ProcessEngineConfiguration.DB_SCHEMA_UPDATE_FALSE);

		DefaultAsyncJobExecutor asyncExecutor = new DefaultAsyncJobExecutor();
		asyncExecutor.setCorePoolSize(50);
		asyncExecutor.setMaxPoolSize(100);
		asyncExecutor.setAsyncJobLockTimeInMillis(60000);
		asyncExecutor.setDefaultTimerJobAcquireWaitTimeInMillis(1);
		asyncExecutor.setMaxAsyncJobsDuePerAcquisition(100);
		asyncExecutor.setDefaultAsyncJobAcquireWaitTimeInMillis(1);
		asyncExecutor.setRetryWaitTimeInMillis(1000);
		asyncExecutor.setMaxTimerJobsPerAcquisition(50);
		asyncExecutor.setQueueSize(500);

		configuration.setAsyncExecutor(asyncExecutor);
		processEngineFactoryBean.setProcessEngineConfiguration(configuration);
		return processEngineFactoryBean;
	}

	@Bean
	public DataSourceTransactionManager dataSourceTransactionManager() throws NamingException {
		DataSourceTransactionManager dataSourceTransactionManager = new DataSourceTransactionManager();
		dataSourceTransactionManager.setDataSource(crmDataSource());
		return dataSourceTransactionManager;
	}
	
	/**
	 * Hibernate JPA related configruation
	 */
	  @Bean
	    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
	        LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();
	        entityManagerFactoryBean.setDataSource(crmDataSource());
	        entityManagerFactoryBean.setPersistenceProviderClass(HibernatePersistence.class);
	        entityManagerFactoryBean.setPackagesToScan("ae.etisalat.cw.restws.dao.entities");
	        entityManagerFactoryBean.setJpaProperties(hibProperties());
	      return entityManagerFactoryBean;
	    }

	    private Properties hibProperties() {
	      Properties properties = new Properties();
	      properties.put(UtilConstants.HIBERNATE_DIALECT_PROPERTY, "hibernate.dialect=org.hibernate.dialect.OracleDialect"); // need to move to properties files
	      properties.put(UtilConstants.HIBERNATE_SHOW_SQL_PROPERTY, true);// need to move to properties files
	     return properties;
	    }

	    @Bean
	    public JpaTransactionManager transactionManager() {
	        JpaTransactionManager transactionManager = new JpaTransactionManager();
	        transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
	       return transactionManager;
		  }	
	
}
