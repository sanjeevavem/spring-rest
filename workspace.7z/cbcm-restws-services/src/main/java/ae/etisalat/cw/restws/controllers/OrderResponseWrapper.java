package ae.etisalat.cw.restws.controllers;

import com.google.gson.JsonObject;

public class OrderResponseWrapper {

   private String errorCode;
   private String errorResponse;
   private JsonObject orderResponse;
  
   public String getErrorCode() {
		return errorCode;
	}
   
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	
	public String getErrorResponse() {
		return errorResponse;
	}
	
	public void setErrorResponse(String errorResponse) {
		this.errorResponse = errorResponse;
	}
	
	public JsonObject getOrderResponse() {
		return orderResponse;
	}
	
	public void setOrderResponse(JsonObject orderResponse) {
		this.orderResponse = orderResponse;
	}
	 

}
