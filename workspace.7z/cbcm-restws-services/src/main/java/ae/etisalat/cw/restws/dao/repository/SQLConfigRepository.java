package ae.etisalat.cw.restws.dao.repository;

public interface SQLConfigRepository /*extends JpaRepository<SQLConfig, String> */ {

}
