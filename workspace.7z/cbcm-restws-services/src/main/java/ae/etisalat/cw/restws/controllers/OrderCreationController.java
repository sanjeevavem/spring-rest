package ae.etisalat.cw.restws.controllers;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;

import ae.etisalat.cw.restws.jms.LogJMSProvider;
import ae.etisalat.cw.restws.service.OrderCreationService;
import ae.etisalat.cw.restws.service.OrderCreationServiceImpl;
import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.UtilHelper;

@RestController
@RequestMapping("/")
public class OrderCreationController {

	private static final Logger logger = LogManager.getLogger(OrderCreationServiceImpl.class);
	
	@Autowired
	private OrderCreationService orderCreationService;
	
	@Autowired
	private LogJMSProvider logJMSProvider;

	UtilHelper util = new UtilHelper();

	@RequestMapping(value = "/createorder", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public JsonObject createOrder(@RequestBody JsonObject orderDetails) throws Exception {
	   logger.info("createOrder Start : ",orderDetails);
	   String UID = util.getUUID();
		log(orderDetails,UID);
		String refNo = orderDetails.get("RefernceNumber").getAsString();
		JsonObject orderResponse = orderCreationService.createOrder(orderDetails).getOrderResponse();
		if(orderResponse!=null){
			orderResponse.addProperty("RefernceNumber", refNo);
		}
		
		log(orderResponse,UID);
	   logger.info("createOrder End : ",orderDetails);
	  return orderResponse;
	}

	@RequestMapping(value = "/test", method = RequestMethod.GET, produces = MediaType.TEXT_PLAIN_VALUE)
	public String testService() {
		return "success";
	}
	
	private void log(JsonObject orderDetails,String UID) throws Exception{
		orderDetails.addProperty(UtilConstants.API, ""+this.getClass());
		orderDetails.addProperty(UtilConstants.UID, util.getUUID());
		orderDetails.addProperty(UtilConstants.LOG_TYPE, UtilConstants.LOG_TYPE_REQUEST);
	  logJMSProvider.sendMsg(orderDetails);	
	}

}
