package ae.etisalat.cw.restws.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;

import ae.etisalat.activiti.core.ActivitiEngine;
import ae.etisalat.activiti.core.ActivitiUtil;
import ae.etisalat.activiti.core.GenericDBQueryAPI;
import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.restws.controllers.OrderResponseWrapper;
import ae.etisalat.cw.restws.dao.generic.DataSourceType;
import ae.etisalat.cw.restws.dao.generic.GenericOrderCreationDAO;
import ae.etisalat.cw.restws.util.JSONUtil;

@Service
public class OrderCreationServiceImpl implements OrderCreationService {

	private static final Logger logger = LogManager.getLogger(OrderCreationServiceImpl.class);
	
	@Value("${cbcmcw.config.masterflow.select}")
	private String masterflow;
	
	@Value("${cbcm.soh.insert.CW_ORDER_AUDIT}")
	private String cwOrderAudit;
	
	@Autowired
	private JSONUtil util;
	
	@Autowired
	private ActivitiUtil activitiUtil;
	
	@Autowired
	private GenericDBQueryAPI genericDBQueryAPI;
	   
//    @EJB(mappedName="java:global.cbcmrestws.ActivitiEngine!ae.etisalat.activiti.core.ActivitiEngine")
//    private ActivitiEngine activitiEngine;
	
	@Autowired
	private ActivitiEngine activitiEngine;
    
    @Autowired
    private GenericOrderCreationDAO genericOrderCreationDAO;
    
	public OrderResponseWrapper createOrder(JsonObject orderRequest) throws Exception {
	  logger.info(""+ this.getClass(), "createOrder Start"+orderRequest.toString());		
	  
	  JsonObject  criteria = orderRequest.getAsJsonObject("criteria");
      String refernceNumber = orderRequest.get("RefernceNumber")!=null?orderRequest.get("RefernceNumber").getAsString():" ";
      if(refernceNumber  == null || (refernceNumber.length()<8 || refernceNumber.length()>20)){
    	  return errorRespone("01","Refernce Number is missing in request");  // NEED TO CHANGE TO Util class  
      }
      
      if(criteria==null){
    	  return errorRespone("01","Order Criteria is missing in request");  // NEED TO CHANGE TO Util class  
      }

      HashMap<String, Object> map = util.getMapFromJson(criteria);
      map.put(UtilConstants.JSON_REQUEST, orderRequest.toString());
      Map<String, Object> flowMap = activitiUtil.findProductFlow(map);
      
      if(flowMap== null || flowMap.size()==0){
    	  return errorRespone("99","Application Error");  // NEED TO CHANGE TO Util class
      }
      
      /*
       * Generic API testing
       */
      genericDBQueryAPI.execute(map, map);
      logger.info("genericDBQueryAPI");
      
      Map<String, Object> outputVaribales = activitiEngine.executeWorkflow(flowMap.get("FLOW_CODE").toString(), map);
      logger.info("outputVaribales",outputVaribales);
      logger.debug("outputVaribales",outputVaribales);
	  
		 // response
	  OrderResponseWrapper orderResponseWrapper = new OrderResponseWrapper();
	  orderResponseWrapper.setErrorCode("00");
	  orderResponseWrapper.setErrorResponse("Success");
	  JsonObject jsonObject = new JsonObject();
	  if(outputVaribales!=null && outputVaribales.get("output_RequestId")!=null){
		  jsonObject.addProperty("orderNumber", outputVaribales.get("output_RequestId").toString());  
	  }
	  orderResponseWrapper.setOrderResponse(jsonObject);
	  
       Map<String, Object> parameters = new HashMap<>();
       parameters.put("REFERENCE_NO", refernceNumber);
       parameters.put("REQUEST_ID",outputVaribales.get("output_RequestId"));
       parameters.put("SUBREQUEST_ID",outputVaribales.get("output_SubRequestId"));
       parameters.put("NOTES", "CBCM CW Order");
       parameters.put("CREATED_USER_ID", "CBCM_CW");
       parameters.put("MODIFIED_USER_ID", "CBCM_CW");
      
      
	  genericOrderCreationDAO.insert(DataSourceType.cbcm_cw_datasource, cwOrderAudit, parameters);
	  
	 return orderResponseWrapper;
	}
	


	private OrderResponseWrapper errorRespone(String errorCode,String errorDesc) {
	 OrderResponseWrapper orderResponseWrapper = new OrderResponseWrapper();
	  JsonObject jsonObject = new JsonObject();
	  jsonObject.addProperty("errorCode", errorCode);
	  jsonObject.addProperty("errorDesc", errorDesc);
	  orderResponseWrapper.setOrderResponse(jsonObject);
	 return orderResponseWrapper;
	}

}
