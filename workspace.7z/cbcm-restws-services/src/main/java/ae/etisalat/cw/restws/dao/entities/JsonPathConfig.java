package ae.etisalat.cw.restws.dao.entities;

import java.io.Serializable;
import java.sql.Timestamp;

public class JsonPathConfig implements Serializable {

	private static final long serialVersionUID = 381701751906222166L;
	
	private String jSONPath;
	private String versionId;
	private String createdUserId;
	private Timestamp createdDate;
	private String modifiedUserId;
	private Timestamp modifiedDate;
	
	public String getjSONPath() {
		return jSONPath;
	}
	public void setjSONPath(String jSONPath) {
		this.jSONPath = jSONPath;
	}
	public String getVersionId() {
		return versionId;
	}
	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}
	public String getCreatedUserId() {
		return createdUserId;
	}
	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getModifiedUserId() {
		return modifiedUserId;
	}
	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}
	public Timestamp getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

}
