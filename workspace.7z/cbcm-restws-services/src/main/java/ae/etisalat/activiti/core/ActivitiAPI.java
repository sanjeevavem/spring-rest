package ae.etisalat.activiti.core;

import java.util.Map.Entry;
import java.util.UUID;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.stereotype.Service;

import ae.etisalat.cw.restws.context.SpringApplicationContext;
import ae.etisalat.cw.restws.dao.generic.GenericOrderCreationDAO;

@Service
public abstract class ActivitiAPI implements JavaDelegate {
	
	public abstract void init(DelegateExecution execution) throws Exception;

	public abstract void run(DelegateExecution execution) throws Exception;
	
	protected GenericOrderCreationDAO genericOrderCreationDAO;
	
	protected ActivitiEngine activitiEngine;
	
	protected ActivitiUtil activitiUtil;
	
    public static final String default_user_id ="CBCMCW_FIXED";

	/**
	 * The original execution method, this method is calling internally another
	 * method that should be implemented in the child classes
	 */
	@SuppressWarnings("resource")
	@Override
	public void execute(DelegateExecution execution) {

		Object uuid = execution.getVariable("UUID");
		if (uuid == null) {
			uuid = UUID.randomUUID();
		}
		ThreadContext.put("TXN_ID", uuid.toString());
		ThreadContext.put("processId", execution.getProcessInstanceId());

		Logger logger = LogManager.getLogger(this.getClass().getName());

		if (execution.hasVariable("skip#" + execution.getCurrentActivityId())) {
			logger.info("API [{}] execution skipped", execution.getCurrentActivityId());
			return;
		}

		long before = System.currentTimeMillis();
		logger.info("API [{}] execution started", execution.getCurrentActivityId());
		if (logger.isDebugEnabled()) {
			printExecutionVariables(execution);
		}
		try {
			genericOrderCreationDAO = SpringApplicationContext.getApplicationContext().getBean(GenericOrderCreationDAO.class);
			activitiEngine = SpringApplicationContext.getApplicationContext().getBean(ActivitiEngine.class);
			activitiUtil = SpringApplicationContext.getApplicationContext().getBean(ActivitiUtil.class);
			
			init(execution);
			run(execution);
		} catch (Throwable e) {
			logger.error("API Execution failed", e);
			throw new RuntimeException(e);
		} finally {
			if (logger.isDebugEnabled())
				printExecutionVariables(execution);
			logger.info("API [{}] execution finished, time = {} ms", execution.getCurrentActivityId(),
					(System.currentTimeMillis() - before));
		}
	}

	/**
	 * This method is used to print all the variables stored currently in the
	 * context, used for debugging only
	 * 
	 * @param execution
	 */
	private void printExecutionVariables(DelegateExecution execution) {
		StringBuilder sb = new StringBuilder();
		for (Entry<String, Object> entry : execution.getVariables().entrySet()) {
			if (sb.length() > 0)
				sb.append(", ");
			sb.append(entry.getKey()).append("=[").append(entry.getValue()).append("]");
		}
		LogManager.getLogger(this.getClass().getName()).debug("Execution Variables: {}", sb);
	}
}