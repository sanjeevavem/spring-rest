package ae.etisalat.activiti.core;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.logger.Log;
import ae.etisalat.cw.restws.dao.entities.SQLConfig;
import ae.etisalat.cw.restws.dao.repository.SQLConfigRepository;
import net.minidev.json.JSONObject;

@Component
public class GenericDBQueryAPI implements Serializable {


	private static final long serialVersionUID = 1750067248214560916L;
	
	@Autowired
	private SQLConfigRepository sqlConfigRepository;

	public HashMap<String, Object> execute (HashMap<String, Object> orderInfo,HashMap<String,Object> inputParam) {
		Log.logMessage(Level.INFO,"init(executeWorkflow for processDefinitionKey {}) - start",orderInfo.toString());
		HashMap<String, Object> map = new HashMap<String, Object>();
		JSONObject restReqeust =(JSONObject)orderInfo.get(UtilConstants.JSON_REQUEST);
		
//		 List<SQLConfig> listSQLConfigs =sqlConfigRepository.findAll();
//		 listSQLConfigs.forEach(System.out::println);
		 
		/*
		 * 1. fetech the configuration
		 * 2. fetech config parameters
		 * 3. check json path
		 */
		
		
		Log.logMessage(Level.INFO,"init(executeWorkflow for processDefinitionKey {}) - end",orderInfo.toString());
	    return map;
	   }
	


}
