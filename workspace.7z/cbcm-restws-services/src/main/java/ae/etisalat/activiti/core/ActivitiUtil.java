package ae.etisalat.activiti.core;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import ae.etisalat.cw.restws.dao.generic.DataSourceType;
import ae.etisalat.cw.restws.dao.generic.GenericOrderCreationDAO;

@Component
public class ActivitiUtil {
	
	@Value("${cbcmcw.config.masterflow.select}")
	private String masterFlow;
	
	@Value("${cbcmcw.config.subflow.select}")
	private String subFlow;
	
	@Autowired
	private GenericOrderCreationDAO genericOrderCreationDAO;

	public Map<String, Object> findProductFlow(Map<String, Object> request) throws Exception {
	   Map<String, Object> parameters = new HashMap<String, Object>();
	   parameters.put("PRODUCT_GROUP", request.get("ProductGroup"));
	   parameters.put("PRODUCT", request.get("Product"));
	   parameters.put("ORDER_TYPE", request.get("Ordertype"));
	   parameters.put("FLOW_TYPE", "MAIN"); 
	 return genericOrderCreationDAO.query(DataSourceType.cbcm_cw_datasource, masterFlow, parameters);
	}
	
	public Map<String, Object> findProductSubFlow(Map<String, Object> request) throws Exception {
	   Map<String, Object> parameters = new HashMap<String, Object>();
	   parameters.put("PRODUCT_GROUP", request.get("ProductGroup"));
	   parameters.put("PRODUCT", request.get("Product"));
	   parameters.put("ORDER_TYPE", request.get("Ordertype"));
	   parameters.put("FLOW_TYPE", "DEPENDENT");
	   parameters.put("OFFER_CODES", request.get("OFFER_CODES"));
	   parameters.put("OFFER_TYPE", request.get("OFFER_TYPE"));
	 return genericOrderCreationDAO.query(DataSourceType.cbcm_cw_datasource, subFlow, parameters);
	}
	
	
}
