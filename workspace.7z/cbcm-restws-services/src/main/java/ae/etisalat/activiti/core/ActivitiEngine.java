package ae.etisalat.activiti.core;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.activiti.engine.HistoryService;
import org.activiti.engine.ManagementService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.history.HistoricVariableInstance;
import org.activiti.engine.runtime.ProcessInstance;
import org.apache.logging.log4j.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ae.etisalat.cw.comm.util.logger.Log;

//@Singleton
//@TransactionManagement(TransactionManagementType.BEAN)
@Service
@Transactional
public class ActivitiEngine {
//	private static final Logger logger = LogManager.getLogger(ActivitiEngine.class);

	@Autowired
	private ProcessEngine processEngine;
	
	private RuntimeService runtimeService;
	private HistoryService historyService;
	private ManagementService managementService;

	@PostConstruct
	public void init() {
		try {
			/*DataSource dataSource = getDataSource();

			DefaultAsyncJobExecutor asyncExecutor = new DefaultAsyncJobExecutor();
			asyncExecutor.setCorePoolSize(50);
			asyncExecutor.setMaxPoolSize(100);
			asyncExecutor.setAsyncJobLockTimeInMillis(60000);
			asyncExecutor.setDefaultTimerJobAcquireWaitTimeInMillis(1);
			asyncExecutor.setMaxAsyncJobsDuePerAcquisition(100);
			asyncExecutor.setDefaultAsyncJobAcquireWaitTimeInMillis(1);
			asyncExecutor.setRetryWaitTimeInMillis(1000);
			asyncExecutor.setMaxTimerJobsPerAcquisition(50);
			asyncExecutor.setQueueSize(500);

			ProcessEngineConfiguration cfg = new StandaloneProcessEngineConfiguration().setDataSource(dataSource)
					.setEnableProcessDefinitionInfoCache(true)
					.setDatabaseSchemaUpdate(ProcessEngineConfiguration.DB_SCHEMA_UPDATE_FALSE)
					.setHistoryLevel(HistoryLevel.FULL).setAsyncExecutorActivate(true).setAsyncExecutor(asyncExecutor);

			processEngine = cfg.buildProcessEngine();*/
			runtimeService = processEngine.getRuntimeService();
			RepositoryService repositoryService = processEngine.getRepositoryService();

			repositoryService.createDeployment().addClasspathResource("BQS_AddServiceProcess.bpmn").addClasspathResource("Generic_Service_specific_attribute_order.bpmn").deploy();
			historyService = processEngine.getHistoryService();

			managementService = processEngine.getManagementService();

		} catch (Exception e) {
			Log.logMessage(e,"Failed to initiate ACTIVITI Engine");
		} finally {
			Log.logMessage(Level.INFO,"init() - finished");
		}
	}

//	private DataSource getDataSource() throws NamingException {
//		Context context = new InitialContext();
//		DataSource dataSource = (javax.sql.DataSource) context.lookup("cbcm_cw_datasource");
//		return dataSource;
//	}

	// @TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Map<String, Object> executeWorkflow(String workflow, Map<String, Object> variables) throws Exception {
		Log.logMessage(Level.INFO,"init(executeWorkflow for processDefinitionKey {}) - start",workflow);
		long beforeCall = System.nanoTime();
		Map<String, Object> outputVariables = new HashMap<String, Object>();
		try {
			ProcessInstance processInstance = runtimeService.startProcessInstanceByKey(workflow, variables);
			outputVariables = populateOutputVariables(processInstance);
			System.out.println("outputVariables" + outputVariables);
			Log.logMessage(Level.INFO,"[{}] - Done: {} MillSeconds ",""+processInstance.getId(),""+ ((System.nanoTime() - beforeCall) / 1000000.0));
			return outputVariables;
		} catch (Exception e) {
			Log.logMessage(e,"Error occured during executeWorkflow ");
			throw e;
		} finally {
			Log.logMessage(Level.INFO,"init(workflow={}) - finished", workflow);
		}
	}

	private Map<String, Object> populateOutputVariables(ProcessInstance processInstance) {
		Map<String, Object> outputVariables = new HashMap<String, Object>();
		outputVariables.put("processInstanceId", processInstance.getProcessInstanceId());
		for (HistoricVariableInstance variableInstance : processEngine.getHistoryService()
				.createHistoricVariableInstanceQuery().processInstanceId(processInstance.getId()).list()) {
			outputVariables.put(variableInstance.getVariableName(), variableInstance.getValue());
		}
		return outputVariables;
	}

	public ProcessEngine getProcessEngine() {
		return processEngine;
	}

	public void setProcessEngine(ProcessEngine processEngine) {
		this.processEngine = processEngine;
	}

	public RuntimeService getRuntimeService() {
		return runtimeService;
	}

	public void setRuntimeService(RuntimeService runtimeService) {
		this.runtimeService = runtimeService;
	}

	public HistoryService getHistoryService() {
		return historyService;
	}

	public void setHistoryService(HistoryService historyService) {
		this.historyService = historyService;
	}

}
