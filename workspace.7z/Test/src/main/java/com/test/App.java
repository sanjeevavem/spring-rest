package com.test;

import org.apache.commons.lang3.StringUtils;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	String query = "SELECT ID,DESCRIPTION,ORDER_TYPE,OFFER_TYPE,OFFER_CODE,FLOW_CODE,FLOW_SEQUENCE,PRODUCT_GROUP,PRODUCT,REGION,FLOW_TYPE,CREATED_DATE,MODIFIED_DATE,CREATED_USER_ID,MODIFIED_USER_ID,DELETION_STATUS FROM CW_MST_FLOW_MAP WHERE PRODUCT_GROUP=:PRODUCT_GROUP and PRODUCT=:PRODUCT and ORDER_TYPE=:ORDER_TYPE and FLOW_TYPE=:FLOW_TYPE and DELETION_STATUS='N' and OFFER_TYPE=:OFFER_TYPE and OFFER_CODE in (:OFFER_CODES) order by FLOW_SEQUENCE asc";
    	String result = StringUtils.replacePattern(query, ":\\w+", "?");
        System.out.println( "query" +result);
    }
}
