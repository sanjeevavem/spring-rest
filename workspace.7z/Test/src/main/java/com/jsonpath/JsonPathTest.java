package com.jsonpath;

import java.util.EnumSet;
import java.util.Map;
import java.util.Set;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;
import com.jayway.jsonpath.spi.json.GsonJsonProvider;
import com.jayway.jsonpath.spi.json.JsonProvider;
import com.jayway.jsonpath.spi.mapper.GsonMappingProvider;
import com.jayway.jsonpath.spi.mapper.MappingProvider;

public class JsonPathTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration.setDefaults(new Configuration.Defaults() {
		    private final JsonProvider jsonProvider = new GsonJsonProvider();
		    private final MappingProvider mappingProvider = new GsonMappingProvider();

		    @Override
		    public JsonProvider jsonProvider() {
		        return jsonProvider;
		    }

		    @Override
		    public MappingProvider mappingProvider() {
		        return mappingProvider;
		    }

		    @Override
		    public Set<Option> options() {
		        return EnumSet.noneOf(Option.class);
		    }
		});
		
       String json ="{  \"requestDetails\": {    \"ReferenceNumber\": \"19840001\",    \"accountNumber\": \"024478352\",    \"channel\": \"CIM\",    \"subChannel\": \"CIM\",    \"productCode\": \"BFXI\",    \"productGroupCode\": \"BL\",    \"userId\": \"CIM\",    \"systemName\": \"CL\",    \"msoFlag\": \"N\",    \"subRequestType\": \"NEW\",    \"regionName\": null,    \"bitStreamFlag\": \"N\",    \"serviceRequiredDate\": \"27/12/2017\",    \"additionalInfoList\": null  },  \"customerDetails\": { },  \"orderDetails\": {    \"offeringDetailsList\": [      {        \"offerType\": \"RATEPLAN\",        \"actionChargeTypeCode\": null,        \"offerCode\": \"RP15003\",        \"oldOfferCode\": null,        \"offerAction\": \"ADD\",        \"numberOfInstances\": \"1\",        \"quantity\": \"1\",        \"deleteAccInsID\": null,        \"additionalInfoList\": [          {            \"additonalInfoDtlList\": [              {                \"infoKey\": \"QUANTITY\",                \"infoValue\": \"2\"              },              {                \"infoKey\": \"USER_NAME\",                \"infoValue\": \"coms\"              }            ],            \"type\": \"PRICE_OPTION\"          }        ]      },      {        \"offerType\": \"RATEPLAN\",        \"actionChargeTypeCode\": null,        \"offerCode\": \"RP15004\",        \"oldOfferCode\": null,        \"offerAction\": \"ADD\",        \"numberOfInstances\": \"1\",        \"quantity\": \"1\",        \"deleteAccInsID\": null,        \"additionalInfoList\": [          {            \"additonalInfoDtlList\": [              {                \"infoKey\": \"USER_NAME\",                \"infoValue\": \"SVEM\"              }            ],            \"type\": \"PRICE_OPTION\"          }        ]      }    ],    \"additionalInfoList\": null  }}";
       JsonElement book = JsonPath.read(json, "$.orderDetails.offeringDetailsList[0].additionalInfoList[0].additonalInfoDtlList[0]");
       System.out.println(book);  // prints {category=reference, author=Nigel Rees, title=Sayings of the Century, price=8.95}
       JsonElement book1 = JsonPath.read(json, "$.orderDetails.offeringDetailsList[*].additionalInfoList[*].additonalInfoDtlList[?(@.infoKey=='USER_NAME')].infoValue");
       System.out.println(book1);
       JsonElement book2 = JsonPath.read(json, "$.orderDetails.offeringDetailsList[?(@.offerCode=='RP15003')].additionalInfoList[*].additonalInfoDtlList[?(@.infoKey=='USER_NAME')].infoValue");
       System.out.println(book2);

//       Double price = JsonPath.read(json, "$.store.bicycle.price");
//       System.out.println(price); 
	
	}

}
