package ae.etisalat.cbcm.cw.util;

public class CWConstants {
	
	/*
	 * Application Constants
	 */
    public static final String HIBERNATE_DIALECT_PROPERTY = "hibernate.dialect";

    public static final String HIBERNATE_DIALECT = "${" + HIBERNATE_DIALECT_PROPERTY + "}";

    public static final String HIBERNATE_SHOW_SQL_PROPERTY = "hibernate.show_sql";

    public static final String HIBERNATE_CURRENT_SESSION_CONTEXT_CLASS_PROPERTY = "current_session_context_class";

    public static final String HIBERNATE_CONNECTION_DATASOURCE = "hibernate.connection.datasource";

//   public static final String ENTITIES_PACKAGE = "com.zanox.rest.file.upload.entities";

    public static final String TXN_ID="TXN_ID";
    public static final String API="API";
    public static final String LOG_TYPE="LOG_TYPE";
    public static final String LOG_TYPE_REQUEST="REQUEST";
    public static final String REF_NO ="RefernceNumber";
    public static final String USER_ID ="CBCMCW_BFIXED";
}
