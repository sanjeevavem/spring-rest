package ae.etisalat.cbcm.cw.jms.listener;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import ae.etisalat.cbcm.cw.dao.GenericDAO;
import ae.etisalat.cbcm.cw.entities.CWAudit;
import ae.etisalat.cbcm.cw.exception.DataAccessException;
import ae.etisalat.cbcm.cw.util.CWConstants;
import ae.etisalat.cbcm.cw.util.CWUtil;

@Component
public class JMSLogConumser implements MessageListener {

	private static final Logger logger = LogManager.getLogger(JMSLogConumser.class);
	
	@Autowired
	GenericDAO genericDAO;
	
//	@JmsListener(destination="jms/TestJMSQueue")
	public void onMessage(Message message) {
		logger.info("Start onMessage LOG JMS:");
		// TODO Auto-generated method stub
		String messageData = null;
		System.out.println("Received message " + message); 
		if(message instanceof TextMessage) 
		 { 
			TextMessage textMessage = (TextMessage)message; 
			 try {
				messageData = textMessage.getText();
                JsonObject json = new Gson().fromJson(messageData.toString(), JsonObject.class);
				try {
					if(json!=null){
					  CWAudit cwAudit = new CWAudit();
						cwAudit.setLogType(json.get(CWConstants.LOG_TYPE).getAsString());
						cwAudit.setOrderLog(json.toString());
						cwAudit.setReferenceAPI(json.get(CWConstants.API).getAsString());
						cwAudit.setReferenceNo(json.get(CWConstants.REF_NO).getAsString());
						cwAudit.setAppRefNo(json.get(CWConstants.TXN_ID).getAsString());	
						cwAudit.setCreatedUserId(CWConstants.USER_ID);
						cwAudit.setCreatedDate(CWUtil.getSQLTimestamp());
						cwAudit.setModifiedUserId(CWConstants.USER_ID);
						cwAudit.setModifiedDate(CWUtil.getSQLTimestamp());
					  genericDAO.save(cwAudit);		
					}

				} catch (DataAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (JMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		 } 
		System.out.println("LogJMSListener"+messageData);
		logger.info("End onMessage LOG JMS:");
	}
	
	private void logData(){
		
	}
}
