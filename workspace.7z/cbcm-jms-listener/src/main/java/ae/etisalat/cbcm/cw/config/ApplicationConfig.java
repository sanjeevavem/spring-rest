package ae.etisalat.cbcm.cw.config;

import java.util.Properties;

import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
import org.springframework.jms.listener.MessageListenerContainer;
import org.springframework.jndi.JndiObjectFactoryBean;
import org.springframework.jndi.JndiTemplate;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;

import ae.etisalat.cbcm.cw.jms.listener.JMSLogConumser;
import ae.etisalat.cbcm.cw.util.CWConstants;

@Configuration
@ComponentScan(basePackages={"ae.etisalat.cbcm.cw"})
@PropertySource("classpath:app-config.properties")
/*@EnableJms*/
//@EnableJpaRepositories(basePackages={"ae.etisalat.cbcm.cw"})
public class ApplicationConfig {
	
    @Value("${hibernate.dialect}")
    private String hibernateDialect;

    @Bean(name = "appProperty")
    public static PropertySourcesPlaceholderConfigurer appProperty() {
        return new PropertySourcesPlaceholderConfigurer();
}
	
	  @Bean(name="JndiTemplate")
	  public JndiTemplate jndiTemplate()
	  {
		  JndiTemplate jndiJndiTemplate = new JndiTemplate();
		  Properties properties = new Properties();
		  properties.put("java.naming.factory.initial","weblogic.jndi.WLInitialContextFactory");
		  properties.put("java.naming.provider.url", "t3://localhost:7001");
		  properties.put("java.naming.security.principal", "weblogic");
		  properties.put("java.naming.security.credentials", "etisalat1");
		  jndiJndiTemplate.setEnvironment(properties);
		  return jndiJndiTemplate;
	  }
	  
	  @Bean(name = "jmsJndiConnectionFactory")
	  public JndiObjectFactoryBean jndiObjectFactoryBean() 
	  {

	      final JndiObjectFactoryBean jndiObjectFactoryBean = new JndiObjectFactoryBean();
	      jndiObjectFactoryBean.setJndiTemplate(jndiTemplate());   
	      jndiObjectFactoryBean.setJndiName("jms/TestConnectionFactory");
	      return jndiObjectFactoryBean;

	  }
	  
	 @Bean(name = "connectionFactory")
	  public ConnectionFactory connectionFactory()
	  {
	      final ConnectionFactory connectionFactory = (ConnectionFactory) jndiObjectFactoryBean().getObject();
	      System.out.print("ConnectoinFactory is null? {}"+ connectionFactory == null);
	      return connectionFactory;
	  }
	  
	  @Bean(name = "jmsConnectionFactory")
	  @Primary
	  public ConnectionFactory connectionFactoryProxy() {
	      final CachingConnectionFactory jmsConnectionFactory = new CachingConnectionFactory(connectionFactory());
	      jmsConnectionFactory.setCacheProducers(true);
	      jmsConnectionFactory.setSessionCacheSize(20);
	      return jmsConnectionFactory;
	  }
	  
	  @Bean(name="jmsQueueName")
	  public Destination jmsQueueName() {

	      final JndiObjectFactoryBean jndiObjectFactoryBean = new JndiObjectFactoryBean();
	      jndiObjectFactoryBean.setJndiTemplate(jndiTemplate());
	      jndiObjectFactoryBean.setJndiName("jms/TestJMSQueue"); // queue name
	      try {
			jndiObjectFactoryBean.afterPropertiesSet();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     // jndiObjectFactoryBean.set
	      return (Destination) jndiObjectFactoryBean.getObject();
	  }
	  
	  
//	  @Bean(name="jmsQueueName")
//	  public Destination jmsDestinationQueueName() {
//
//	      final JndiObjectFactoryBean jndiObjectFactoryBean = new JndiObjectFactoryBean();
//	      jndiObjectFactoryBean.setJndiTemplate(jndiTemplate());
//	      jndiObjectFactoryBean.setJndiName("jms/jmsDestinationQueue"); // queue name
//	      try {
//			jndiObjectFactoryBean.afterPropertiesSet();
//		} catch (IllegalArgumentException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (NamingException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	     // jndiObjectFactoryBean.set
//	      return (Destination) jndiObjectFactoryBean.getObject();
//	  }
	  
	  /*@Bean
	  public DefaultMessageListenerContainer responder() {
	  	DefaultMessageListenerContainer container = new DefaultMessageListenerContainer();
	  	container.setConnectionFactory(connectionFactory());
	  	container.setDestination(jmsDestinationQueueName());
	   	MessageListenerAdapter adapter = new MessageListenerAdapter(new Object() {

	  		@SuppressWarnings("unused")
	  		public String handleMessage(String in) {
	  			return in.toUpperCase();
	  		}

	  	});
	  	container.setMessageListener(adapter);
	  	return container;
	  }*/
	  
	  @Bean
	  public JMSLogConumser jmsLogConumser() {
		  return new JMSLogConumser();
	  }
	   
	  
	  @Bean
	  public MessageListenerContainer listenerContainer() {
	      DefaultMessageListenerContainer container = new DefaultMessageListenerContainer();
	      container.setConnectionFactory(connectionFactory());
	      container.setDestinationName("test.out");
	      //container.setDestination(jmsDestinationQueueName()); jmsQueueName() 
	      container.setDestination(jmsQueueName());  
	      container.setMessageListener(jmsLogConumser());
	      container.start(); 
	      return container;
	  }
	

//		public DataSource dataSource() throws NamingException {
//			DataSource crmDataSource = (DataSource) new InitialContext().lookup("cbcm_cw_datasource");
//			return crmDataSource;
//		}
	  

		public DataSource dataSource() {
			DriverManagerDataSource ds = new DriverManagerDataSource();
			ds.setDriverClassName("oracle.jdbc.driver.OracleDriver");
			ds.setUrl("jdbc:oracle:thin:@au170.etisalat.corp.ae:1521:CUSTDEV");
			ds.setUsername("cust_dev");
			ds.setPassword("cust_dev");
			return ds;
		}
		
	    @Bean(name = "sessionFactory")
	    public SessionFactory getSessionFactory() throws Exception {
	        Properties properties = new Properties();
	        properties.put(CWConstants.HIBERNATE_DIALECT_PROPERTY, hibernateDialect);
	        properties.put(CWConstants.HIBERNATE_SHOW_SQL_PROPERTY, "true");
	        properties.put(CWConstants.HIBERNATE_CURRENT_SESSION_CONTEXT_CLASS_PROPERTY, "thread");
	        properties.put("dynamic-update", "true");
	        properties.put("shutdown", "false");
	        properties.put("hibernate.hbm2ddl.auto", "update");
	        LocalSessionFactoryBean factory = new LocalSessionFactoryBean();
	        factory.setDataSource(dataSource());
	        factory.setHibernateProperties(properties);
	        factory.setPackagesToScan("ae.etisalat.cbcm.cw.entities");
	        factory.afterPropertiesSet();
	        return factory.getObject();
	    }


	    @Bean(name = "transactionManager")
	    public HibernateTransactionManager getTransactionManager() throws Exception {
	        return new HibernateTransactionManager(getSessionFactory());
	}
}
