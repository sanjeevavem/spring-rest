package ae.etisalat.cbcm.cw.dao;

import java.io.Serializable;
import java.util.List;

import ae.etisalat.cbcm.cw.exception.DataAccessException;

public interface GenericDAO {

    /**
     * <pre>
     * <b>Description : </b>
     * Finds the given entity by given ID.
     * 
     * </pre>
     */
    public <T> T findByPrimaryKey(Class<T> entityClass, Serializable id) throws DataAccessException;

    /**
     * <pre>
     * <b>Description : </b>
     * Saves the given entity.
     * 
     * </pre>
     */
   public boolean save(Object entity) throws DataAccessException;
   

   /**
    * <pre>
    * <b>Description : </b>
    * Finds all the entities of the given type.
    * 
    * </pre>
    */
  public <T> List<T> findAll(Class<T> entityClass) throws DataAccessException;
}
