package ae.etisalat.cbcm.cw.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="CW_AUDIT")
public class CWAudit implements Serializable {

	private static final long serialVersionUID = 5575361037475415152L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="CW_AUDIT_ID")
	private long id;
	
	@Column(name="REFERENCE_API")
	private String referenceAPI;
	
	@Column(name="REFERENCE_N0")
	private String referenceNo;
	
	@Column(name="LOG_TYPE")
	private String logType;
	
	@Column(name="ORDER_LOG")
	private String orderLog;
	
	@Column(name="APP_REF_NO")
	private String appRefNo;
	
	@Column(name="CREATED_USER_ID")
	private String createdUserId;
	
	@Column(name="CREATED_DATE")
	private Timestamp createdDate;
	
	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;
	
	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;
	
	public String getReferenceNo() {
		return referenceNo;
	}
	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}
	
	public String getAppRefNo() {
		return appRefNo;
	}
	public void setAppRefNo(String appRefNo) {
		this.appRefNo = appRefNo;
	}
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	public String getReferenceAPI() {
		return referenceAPI;
	}
	public void setReferenceAPI(String referenceAPI) {
		this.referenceAPI = referenceAPI;
	}

	public String getLogType() {
		return logType;
	}
	public void setLogType(String logType) {
		this.logType = logType;
	}
	
	public String getOrderLog() {
		return orderLog;
	}
	public void setOrderLog(String orderLog) {
		this.orderLog = orderLog;
	}
	public String getCreatedUserId() {
		return createdUserId;
	}
	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getModifiedUserId() {
		return modifiedUserId;
	}
	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}
	public Timestamp getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
