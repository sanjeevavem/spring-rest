package ae.etisalat.cw.activiti.closure.api;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import ae.etisalat.activiti.core.ActivitiAPI;

public class Test1API extends ActivitiAPI {

	private static final Logger logger = LogManager.getLogger(GenericOrderCreationAPI.class);
    
	private Expression JSON_REQUEST;
	 
	@Override
	public void init(DelegateExecution execution) throws Exception {
		
	}

	@Override
	public void run(DelegateExecution execution) throws Exception {

		logger.info("run Start");
		
		logger.info("genericOrderCreationDAO {}", genericOrderCreationDAO);
		
		logger.info("execution {}", execution);

//		UtilHelper util = new UtilHelper();
//		String productGroup = (String) util.evalExpr("ProductGroup", ProductGroup, execution);
//		String accNumber = (String) util.evalExpr("Account_Number", Account_Number, execution);
//		String product = (String) util.evalExpr("Product", Product, execution);
//		String ordertype = (String) util.evalExpr("Ordertype", Ordertype, execution);
//		String offerType = (String) util.evalExpr("OfferType", OfferType, execution);
//		String offerCode = (String) util.evalExpr("OfferCode", OfferCode, execution);
//
//		HashMap<String, Object> procIn = new HashMap<String, Object>();
//		procIn.put("p_accountId", "441285904");
//		procIn.put("p_Offer_type", "R");
//		procIn.put("p_offer_code", "RP541560");
//		procIn.put("p_channel_id", "WEB");
//		procIn.put("p_created_user_id", "CBCM_CW");
//		Map<String, Object> output = genericOrderCreationDAO.executeProcedure(procIn);
//
//		System.out.println(output);
		logger.info("run end");

	}

}
