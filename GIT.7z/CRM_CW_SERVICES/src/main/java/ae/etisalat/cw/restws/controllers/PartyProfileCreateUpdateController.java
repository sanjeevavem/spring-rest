package ae.etisalat.cw.restws.controllers;

import javax.validation.Valid;

import org.apache.logging.log4j.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;

import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.restws.integration.PartyProfileManageRequest;
import ae.etisalat.cw.restws.service.partyProfileManagement.PartyProfileManageService;
import ae.etisalat.cw.restws.util.ServicesUtil;

@RestController
@RequestMapping("/partyProfile")
public class PartyProfileCreateUpdateController {
	
	@Autowired
	private PartyProfileManageService partyProfileManageService;
	
	@Autowired
	private ServicesUtil util;
	
	@RequestMapping(value = "/createUpdatePartyProfile", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public JsonObject createUpdatePartyProfile(@Valid @RequestBody PartyProfileManageRequest partyProfDetails) throws Exception {
	  CWLog.logMessage(Level.INFO, "createUpdatePartyProfile Start :"+partyProfDetails.toString());
	   String UID = util.getUUID();
	   try{
       }
       catch(Exception e){
    	   CWLog.logMessage(e, "Excpetion occured while converting object to JSON");
       }
		JsonObject orderResponse = partyProfileManageService.createUpdatePartyProfile(partyProfDetails);
		if(orderResponse!=null)
			orderResponse.addProperty("InternalRefNumber", UID);
	  CWLog.logMessage(Level.INFO, "createUpdatePartyProfile End :"+orderResponse);
	  return orderResponse;
	}

}
