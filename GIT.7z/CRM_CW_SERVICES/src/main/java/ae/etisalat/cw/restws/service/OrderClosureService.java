package ae.etisalat.cw.restws.service;

import com.google.gson.JsonObject;

public interface OrderClosureService {
	
	public JsonObject initiateOrderClosure(JsonObject orderRequest) throws Exception;

}
