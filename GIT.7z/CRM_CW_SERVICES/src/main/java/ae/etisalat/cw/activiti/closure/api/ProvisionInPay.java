package ae.etisalat.cw.activiti.closure.api;

import java.net.URL;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Level;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import ae.etisalat.activiti.core.ActivitiAPI;
import ae.etisalat.crmgw.util.JsonSearchConstants;
import ae.etisalat.cw.comm.util.JSONUtil;
import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.UtilHelper;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.jpa.soh.entities.TSohAccount;
import ae.etisalat.cw.otherSystem.clients.prePay.Ae_co_etisalat_cbcm_web_pay_webservice_tranferprepmntws_TransferPrePaymentRequest;
import ae.etisalat.cw.otherSystem.clients.prePay.Ae_co_etisalat_cbcm_web_pay_webservice_tranferprepmntws_TransferPrePaymentResponse;
import ae.etisalat.cw.otherSystem.clients.prePay.TransferPayPmntWSLocator;
import ae.etisalat.cw.otherSystem.clients.prePay.TransferPrePaymentControllerBindingStub;
import ae.etisalat.cw.restws.clients.OrderInfo;
import ae.etisalat.cw.restws.context.SpringApplicationContext;
import ae.etisalat.cw.restws.dao.generic.ConfigDao;

public class ProvisionInPay extends ActivitiAPI{
	
	private Expression JSON_REQUEST;
	protected ConfigDao configDao;

	@Override
	public void init(DelegateExecution execution) throws Exception {
		configDao = SpringApplicationContext.getApplicationContext().getBean(ConfigDao.class);		
	}

	@Override
	public void run(DelegateExecution execution) throws Exception {
		CWLog.logMessage(Level.INFO, "run Start");
		UtilHelper util = new UtilHelper();
		String jsonStr = (String) util.evalExpr(UtilConstants.JSON_REQUEST,JSON_REQUEST,execution);
		JsonObject json = new Gson().fromJson(jsonStr, JsonObject.class);
		TSohAccount tSohAccount    =  execution.getVariable(UtilConstants.accountEntity, TSohAccount.class);
		OrderInfo orderInfo = JSONUtil.jsonToObject(jsonStr,JsonSearchConstants.orderInfoQry,OrderInfo.class);
		Long subReqId=null;
		if(orderInfo.getSubRequestId()!=null)
			subReqId=Long.parseLong(orderInfo.getSubRequestId());
		
		String payeUrl =configDao.fetchConfigValue(UtilConstants.WEB_SERVICE, UtilConstants.PREPAYMENT, UtilConstants.URL);
		TransferPayPmntWSLocator locator = new TransferPayPmntWSLocator();
		TransferPrePaymentControllerBindingStub transferPrePaymentControllerBindingStub = (TransferPrePaymentControllerBindingStub) locator.getTransferPrePaymentControllerPort(new URL(payeUrl));		
		String unitTestHeaderValue =configDao.fetchConfigValue(UtilConstants.WEB_SERVICE, UtilConstants.COMMON_ATTRIBUTE, UtilConstants.WS_HEADER_VALUE);
		if (StringUtils.isNotBlank(unitTestHeaderValue)) 
			transferPrePaymentControllerBindingStub.setHeader(configDao.fetchConfigValue(UtilConstants.WEB_SERVICE, UtilConstants.COMMON_ATTRIBUTE, UtilConstants.WS_NAMESPACE)
					,unitTestHeaderValue,unitTestHeaderValue);
		
		Ae_co_etisalat_cbcm_web_pay_webservice_tranferprepmntws_TransferPrePaymentRequest transferPrePaymentRequest = new Ae_co_etisalat_cbcm_web_pay_webservice_tranferprepmntws_TransferPrePaymentRequest();
		transferPrePaymentRequest.setAccountId(tSohAccount.getAccountId());
		transferPrePaymentRequest.setPartyId(tSohAccount.getPartyId().longValue());
		transferPrePaymentRequest.setSubReuestId(subReqId);
		CWLog.logMessage(Level.INFO, " with Params sub_request_id["+subReqId+"] accountId["+tSohAccount.getAccountId()+"] partyId["+tSohAccount.getPartyId()+"]");
		Ae_co_etisalat_cbcm_web_pay_webservice_tranferprepmntws_TransferPrePaymentResponse prePaymentResponse = null;
		try {
			prePaymentResponse = transferPrePaymentControllerBindingStub.performTransferPrePaymentResponse(transferPrePaymentRequest);
		} catch (Exception e) {
			// exception while calling pay web service
			CWLog.logMessage(Level.INFO, " Exception: ",e);
			if (prePaymentResponse == null) {
				String responseDesc = StringUtils.join("Error while getting response from webservice",e.getMessage());
				execution.setVariable(UtilConstants.RESPONSE_CODE, "Failed");
				execution.setVariable(UtilConstants.RESPONSE_DESC, responseDesc);
				json.addProperty(UtilConstants.RESPONSE_CODE, "Failed");
				json.addProperty(UtilConstants.RESPONSE_DESC, responseDesc);
			}
			CWLog.logMessage(Level.INFO," Failed to provision in pay with exception:" + e);
			String responseDesc = StringUtils.join("Failed to provision in pay with exception:",e.getMessage());
			execution.setVariable(UtilConstants.RESPONSE_CODE, "Failed");
			execution.setVariable(UtilConstants.RESPONSE_DESC, responseDesc);
			json.addProperty(UtilConstants.RESPONSE_CODE, "Failed");
			json.addProperty(UtilConstants.RESPONSE_DESC, responseDesc);
		}

		if (null != prePaymentResponse) {
			CWLog.logMessage(Level.INFO,"Got Response from pay service: Status["+prePaymentResponse.getStatus()+"] TransactionId["+prePaymentResponse.getTransactionId()+"]");
			if (prePaymentResponse.getStatus().equalsIgnoreCase("00")) {
				CWLog.logMessage(Level.INFO,"Got SUCCESS from pay service: Status["+prePaymentResponse.getStatus()+"] prePaymentResponse.["+prePaymentResponse.getTransactionId()+"]");
				execution.setVariable(UtilConstants.RESPONSE_CODE, "Done");
				execution.setVariable(UtilConstants.RESPONSE_DESC, "Got response SUCCESS from pay service: Status" + prePaymentResponse.getStatus() );
				json.addProperty(UtilConstants.RESPONSE_CODE, "Done");
				json.addProperty(UtilConstants.RESPONSE_DESC,"Got response SUCCESS from pay service: Status" + prePaymentResponse.getStatus() );
			} else {
				CWLog.logMessage(Level.INFO," Got reponse code " + prePaymentResponse.getStatus() + " from pay service");
				CWLog.logMessage(Level.INFO," Failure Response description got from pay : " + prePaymentResponse.getStatus() + " Reason :"+prePaymentResponse.getReason());
				execution.setVariable(UtilConstants.RESPONSE_CODE, "Failed");
				execution.setVariable(UtilConstants.RESPONSE_DESC, "Failure Response description got from pay: " 
						+ prePaymentResponse.getStatus()+" Reason :"+prePaymentResponse.getReason());
				json.addProperty(UtilConstants.RESPONSE_CODE, "Failed");
				json.addProperty(UtilConstants.RESPONSE_DESC,"Failure Response description got from pay: " 
						+ prePaymentResponse.getStatus()+" Reason :"+prePaymentResponse.getReason());
			}
		} else {
			CWLog.logMessage(Level.INFO," No response got from pay system");
			execution.setVariable(UtilConstants.RESPONSE_CODE, "Failed");
			execution.setVariable(UtilConstants.RESPONSE_DESC, "No response got from pay service");
			json.addProperty(UtilConstants.RESPONSE_CODE, "Failed");
			json.addProperty(UtilConstants.RESPONSE_DESC, "No response got from pay service");
		}
		
		 execution.setVariable(UtilConstants.ACTIVITI_API_CTX, json.toString());
		 CWLog.logMessage(Level.INFO,"" + this.getClass() + "run end, output {}", "");
		
	}

}
