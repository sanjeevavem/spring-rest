
package ae.etisalat.cw.restws.integration;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "additionalParameters", "action", "visaId", "active", "createdDate", "createdUserId", "deletionStatus", "documentId",
        "expiryDate", "issueDate", "issuingAuthority", "modifiedDate", "modifiedUserId", "residentialFileNo", "visaNumber", "visaType",
        "entryPermitNo", "partyNationality", "identityId" })
public class VisaDetails {

    @JsonProperty("additionalParameters")
    private List<AdditionalParameter> additionalParameters = new ArrayList<AdditionalParameter>();
    @JsonProperty("action")
    private String action;
    @JsonProperty("visaId")
    private Long visaId;
    @JsonProperty("active")
    private String active;
    @JsonProperty("createdDate")
    private Date createdDate;
    @JsonProperty("createdUserId")
    private String createdUserId;
    @JsonProperty("deletionStatus")
    private String deletionStatus;
    @JsonProperty("documentId")
    private Long documentId;
    @JsonProperty("expiryDate")
    private Date expiryDate;
    @JsonProperty("issueDate")
    private Date issueDate;
    @JsonProperty("issuingAuthority")
    private String issuingAuthority;
    @JsonProperty("modifiedDate")
    private Date modifiedDate;
    @JsonProperty("modifiedUserId")
    private String modifiedUserId;
    @JsonProperty("residentialFileNo")
    private Long residentialFileNo;
    @JsonProperty("visaNumber")
    private String visaNumber;
    @JsonProperty("visaType")
    private String visaType;
    @JsonProperty("entryPermitNo")
    private String entryPermitNo;
    @JsonProperty("partyNationality")
    private Segment partyNationality ;
    @JsonProperty("identityId")
    private Long identityId;

    @JsonProperty("additionalParameters")
    public List<AdditionalParameter> getAdditionalParameters() {
        return additionalParameters;
    }

    @JsonProperty("additionalParameters")
    public void setAdditionalParameters(List<AdditionalParameter> additionalParameters) {
        this.additionalParameters = additionalParameters;
    }

    public VisaDetails withAdditionalParameters(List<AdditionalParameter> additionalParameters) {
        this.additionalParameters = additionalParameters;
        return this;
    }

    @JsonProperty("action")
    public String getAction() {
        return action;
    }

    @JsonProperty("action")
    public void setAction(String action) {
        this.action = action;
    }

    public VisaDetails withAction(String action) {
        this.action = action;
        return this;
    }

    @JsonProperty("visaId")
    public Long getVisaId() {
        return visaId;
    }

    @JsonProperty("visaId")
    public void setVisaId(Long visaId) {
        this.visaId = visaId;
    }

    public VisaDetails withVisaId(Long visaId) {
        this.visaId = visaId;
        return this;
    }

    @JsonProperty("active")
    public String getActive() {
        return active;
    }

    @JsonProperty("active")
    public void setActive(String active) {
        this.active = active;
    }

    public VisaDetails withActive(String active) {
        this.active = active;
        return this;
    }

    @JsonProperty("createdDate")
    public Date getCreatedDate() {
        return createdDate;
    }

    @JsonProperty("createdDate")
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public VisaDetails withCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
        return this;
    }

    @JsonProperty("createdUserId")
    public String getCreatedUserId() {
        return createdUserId;
    }

    @JsonProperty("createdUserId")
    public void setCreatedUserId(String createdUserId) {
        this.createdUserId = createdUserId;
    }

    public VisaDetails withCreatedUserId(String createdUserId) {
        this.createdUserId = createdUserId;
        return this;
    }

    @JsonProperty("deletionStatus")
    public String getDeletionStatus() {
        return deletionStatus;
    }

    @JsonProperty("deletionStatus")
    public void setDeletionStatus(String deletionStatus) {
        this.deletionStatus = deletionStatus;
    }

    public VisaDetails withDeletionStatus(String deletionStatus) {
        this.deletionStatus = deletionStatus;
        return this;
    }

    @JsonProperty("documentId")
    public Long getDocumentId() {
        return documentId;
    }

    @JsonProperty("documentId")
    public void setDocumentId(Long documentId) {
        this.documentId = documentId;
    }

    public VisaDetails withDocumentId(Long documentId) {
        this.documentId = documentId;
        return this;
    }

    @JsonProperty("expiryDate")
    public Date getExpiryDate() {
        return expiryDate;
    }

    @JsonProperty("expiryDate")
    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }

    public VisaDetails withExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
        return this;
    }

    @JsonProperty("issueDate")
    public Date getIssueDate() {
        return issueDate;
    }

    @JsonProperty("issueDate")
    public void setIssueDate(Date issueDate) {
        this.issueDate = issueDate;
    }

    public VisaDetails withIssueDate(Date issueDate) {
        this.issueDate = issueDate;
        return this;
    }

    @JsonProperty("issuingAuthority")
    public String getIssuingAuthority() {
        return issuingAuthority;
    }

    @JsonProperty("issuingAuthority")
    public void setIssuingAuthority(String issuingAuthority) {
        this.issuingAuthority = issuingAuthority;
    }

    public VisaDetails withIssuingAuthority(String issuingAuthority) {
        this.issuingAuthority = issuingAuthority;
        return this;
    }

    @JsonProperty("modifiedDate")
    public Date getModifiedDate() {
        return modifiedDate;
    }

    @JsonProperty("modifiedDate")
    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public VisaDetails withModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
        return this;
    }

    @JsonProperty("modifiedUserId")
    public String getModifiedUserId() {
        return modifiedUserId;
    }

    @JsonProperty("modifiedUserId")
    public void setModifiedUserId(String modifiedUserId) {
        this.modifiedUserId = modifiedUserId;
    }

    public VisaDetails withModifiedUserId(String modifiedUserId) {
        this.modifiedUserId = modifiedUserId;
        return this;
    }

    @JsonProperty("residentialFileNo")
    public Long getResidentialFileNo() {
        return residentialFileNo;
    }

    @JsonProperty("residentialFileNo")
    public void setResidentialFileNo(Long residentialFileNo) {
        this.residentialFileNo = residentialFileNo;
    }

    public VisaDetails withResidentialFileNo(Long residentialFileNo) {
        this.residentialFileNo = residentialFileNo;
        return this;
    }

    @JsonProperty("visaNumber")
    public String getVisaNumber() {
        return visaNumber;
    }

    @JsonProperty("visaNumber")
    public void setVisaNumber(String visaNumber) {
        this.visaNumber = visaNumber;
    }

    public VisaDetails withVisaNumber(String visaNumber) {
        this.visaNumber = visaNumber;
        return this;
    }

    @JsonProperty("visaType")
    public String getVisaType() {
        return visaType;
    }

    @JsonProperty("visaType")
    public void setVisaType(String visaType) {
        this.visaType = visaType;
    }

    public VisaDetails withVisaType(String visaType) {
        this.visaType = visaType;
        return this;
    }

    @JsonProperty("entryPermitNo")
    public String getEntryPermitNo() {
        return entryPermitNo;
    }

    @JsonProperty("entryPermitNo")
    public void setEntryPermitNo(String entryPermitNo) {
        this.entryPermitNo = entryPermitNo;
    }

    public VisaDetails withEntryPermitNo(String entryPermitNo) {
        this.entryPermitNo = entryPermitNo;
        return this;
    }

    @JsonProperty("identityId")
    public Long getIdentityId() {
        return identityId;
    }

    @JsonProperty("identityId")
    public void setIdentityId(Long identityId) {
        this.identityId = identityId;
    }

    public VisaDetails withIdentityId(Long identityId) {
        this.identityId = identityId;
        return this;
    }

	public Segment getPartyNationality() {
		return partyNationality;
	}

	public void setPartyNationality(Segment partyNationality) {
		this.partyNationality = partyNationality;
	}

    public VisaDetails withPartyNationality(Segment partyNationality) {
        this.partyNationality = partyNationality;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(additionalParameters).append(action).append(visaId).append(active).append(createdDate)
            .append(createdUserId).append(deletionStatus).append(documentId).append(expiryDate).append(issueDate).append(issuingAuthority)
            .append(modifiedDate).append(modifiedUserId).append(residentialFileNo).append(visaNumber).append(visaType).append(entryPermitNo)
            .append(partyNationality).append(identityId).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof VisaDetails) == false) {
            return false;
        }
        VisaDetails rhs = ((VisaDetails) other);
        return new EqualsBuilder().append(additionalParameters, rhs.additionalParameters).append(action, rhs.action)
            .append(visaId, rhs.visaId).append(active, rhs.active).append(createdDate, rhs.createdDate)
            .append(createdUserId, rhs.createdUserId).append(deletionStatus, rhs.deletionStatus).append(documentId, rhs.documentId)
            .append(expiryDate, rhs.expiryDate).append(issueDate, rhs.issueDate).append(issuingAuthority, rhs.issuingAuthority)
            .append(modifiedDate, rhs.modifiedDate).append(modifiedUserId, rhs.modifiedUserId)
            .append(residentialFileNo, rhs.residentialFileNo).append(visaNumber, rhs.visaNumber).append(visaType, rhs.visaType)
            .append(entryPermitNo, rhs.entryPermitNo).append(partyNationality, rhs.partyNationality).append(identityId, rhs.identityId).isEquals();
    }

}
