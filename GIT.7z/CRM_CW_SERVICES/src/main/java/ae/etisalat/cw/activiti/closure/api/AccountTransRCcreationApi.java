package ae.etisalat.cw.activiti.closure.api;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.apache.logging.log4j.Level;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import ae.etisalat.activiti.core.ActivitiAPI;
import ae.etisalat.crmgw.util.JsonSearchConstants;
import ae.etisalat.cw.comm.util.JSONUtil;
import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.UtilHelper;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.jpa.psm.entities.TPsmRpRecurringMap;
import ae.etisalat.cw.jpa.soh.daos.AccountTransCreationDao;
import ae.etisalat.cw.jpa.soh.daos.PkgRpAcctSrvcInstMapping;
import ae.etisalat.cw.jpa.soh.entities.TSohAccount;
import ae.etisalat.cw.restws.clients.OrderInfo;
import ae.etisalat.cw.restws.context.SpringApplicationContext;

@Service
public class AccountTransRCcreationApi extends ActivitiAPI{
	
	private Expression JSON_REQUEST;
	
	protected AccountTransCreationDao accountTransCreationDao;

	@Override
	public void init(DelegateExecution execution) throws Exception {
		accountTransCreationDao = SpringApplicationContext.getApplicationContext().getBean(AccountTransCreationDao.class);
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public void run(DelegateExecution execution) throws Exception {
		CWLog.logMessage(Level.INFO, "run Start");
		UtilHelper util = new UtilHelper();
		String jsonStr = (String) util.evalExpr(UtilConstants.JSON_REQUEST,JSON_REQUEST,execution);
		JsonObject json = new Gson().fromJson(jsonStr, JsonObject.class);
		OrderInfo orderInfo = JSONUtil.jsonToObject(jsonStr,JsonSearchConstants.orderInfoQry,OrderInfo.class);
		List<PkgRpAcctSrvcInstMapping> pkgRpAcctSrvcInstMapList = (List<PkgRpAcctSrvcInstMapping>) execution.getVariable(UtilConstants.accSrvInstDtl);
		TSohAccount tSohAccount    =  execution.getVariable(UtilConstants.accountEntity, TSohAccount.class);
		if(pkgRpAcctSrvcInstMapList!=null && pkgRpAcctSrvcInstMapList.size()>0){
			for(PkgRpAcctSrvcInstMapping acctSrvcInstDtl:pkgRpAcctSrvcInstMapList){	
				Date billCycleStartDate = startDateOfCurrentMonth();
				Date billCyleEndDate = lastDateOfCurrentMonth();
				System.out.println("Current rate plan id: " + acctSrvcInstDtl.getRatePlanId());
				TPsmRpRecurringMap recurringCharges = accountTransCreationDao.getRecurringCharges(acctSrvcInstDtl.getRatePlanId());
				if (recurringCharges != null) {				   
					Long chargeTypeId = recurringCharges.getTPsmMstRecurrChrgType().getId().getRecurrChargeTypeId();					
					double rateInfluence = 0;
					/*if (null != tPsmDtlRecurrInflRate && ! tPsmDtlRecurrInflRate.isEmpty() && tPsmDtlRecurrInflRate.size() > 0) {
						for(TPsmDtlRecurrInflRate psmDtlRecurrInflRate : tPsmDtlRecurrInflRate) {	
							if (psmDtlRecurrInflRate != null) {
								rateInfluence = (psmDtlRecurrInflRate.getRate() != null ? psmDtlRecurrInflRate.getRate().doubleValue() : 0);
								ComsLoggingUtil.logMessage(Level.INFO, sub_request_id, account_number, " the Influence Rate for the rateplan:" + ratePlanId + " is " + rateInfluence);
							}
						}
					}*/			
					BigDecimal transactionAmount = recurringCharges.getTPsmMstRecurrChrgType().getRate();
					transactionAmount = (rateInfluence > 0) ? BigDecimal.valueOf(rateInfluence) : transactionAmount ;					
					transactionAmount = transactionAmount.multiply(new BigDecimal(acctSrvcInstDtl.getQuantity()));					 
					/*if(isMassarrahCustomer!=null && isMassarrahCustomer.equals("true")){
                	String discountMultiplierVal = (String) Config.settings.get("MassarrahDiscountMultiplier");
                	if(discountMultiplierVal != null){
                    	 transactionAmount = transactionAmount.multiply(new BigDecimal(discountMultiplierVal));
                	}
                	}
                	transactionAmount = (rateInfluence > 0) ? BigDecimal.valueOf(rateInfluence) : transactionAmount ;*/		
					transactionAmount = transactionAmount.multiply(new BigDecimal(acctSrvcInstDtl.getQuantity()));				
					boolean persistAcctChargeDtls = true;
					boolean zeroCharges = transactionAmount.doubleValue() == 0;
                    if (!zeroCharges) {
                    	 accountTransCreationDao.addBillTransaction(tSohAccount, acctSrvcInstDtl.getAcctSrvcId(),
                    			tSohAccount.getBillCycleId().longValue(), billCycleStartDate, chargeTypeId, tSohAccount.getCreatedUserId(), null, acctSrvcInstDtl.getRatePlanId(),
                    			orderInfo.getSubRequestId(), transactionAmount, "Recurring", billCycleStartDate, billCyleEndDate,
								persistAcctChargeDtls, null);
                    }
			}
		}
		}
	  execution.setVariable(UtilConstants.ACTIVITI_API_CTX, json.toString());
	  CWLog.logMessage(Level.INFO,"" + this.getClass() + "run end, output {}", "");
	}
	
	public Date startDateOfCurrentMonth() {    
		 java.sql.Date today = new java.sql.Date(new Date().getTime());
	      Calendar calendar = Calendar.getInstance();
	      calendar.setTime(today);	      
	      calendar.set(Calendar.DAY_OF_MONTH,1);
	      java.sql.Date firstDay = new java.sql.Date(calendar.getTime().getTime());
	      
	      return firstDay;
	}
	
	public Date lastDateOfCurrentMonth() { 		
		 Calendar calendar = Calendar.getInstance();
	     calendar.set(Calendar.DATE, calendar.getActualMaximum(Calendar.DATE));			
	     java.sql.Date lastDay = new java.sql.Date(calendar.getTime().getTime());	      
	     return lastDay;
	}

}
