package ae.etisalat.cw.activiti.closure.api.subtoss;

import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.apache.logging.log4j.Level;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import ae.etisalat.activiti.core.ActivitiAPI;
import ae.etisalat.cw.comm.util.JSONUtil;
import ae.etisalat.cw.comm.util.Util;
import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.UtilHelper;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.jpa.soh.daos.AccountDao;
import ae.etisalat.cw.jpa.soh.entities.TSohAccAccountNumber;
import ae.etisalat.cw.jpa.soh.entities.TSohAccount;
import ae.etisalat.cw.jpa.soh.entities.TSohHstAccountStatus;
import ae.etisalat.cw.restws.clients.OrderInfo;
import ae.etisalat.cw.restws.clients.ServiceRegistry;
import ae.etisalat.cw.restws.context.SpringApplicationContext;

@Service
public class UpdateAccountStatusAPI  extends ActivitiAPI {

	private Expression JSON_REQUEST;
	protected AccountDao accDao;

	@Override
	public void init(DelegateExecution execution) throws Exception {
		
		accDao = SpringApplicationContext.getApplicationContext().getBean(AccountDao.class);

	}

	@Override
	public void run(DelegateExecution execution) throws Exception {
		CWLog.logMessage(Level.INFO, "run Start");
		UtilHelper util = new UtilHelper();
		boolean statusUpdated=false;
		String jsonStr = (String) util.evalExpr(UtilConstants.JSON_REQUEST,JSON_REQUEST,execution);
		JsonObject json = new Gson().fromJson(jsonStr, JsonObject.class);
		ServiceRegistry srRegistry = JSONUtil.jsonToObject(jsonStr,"serviceRegistry",ServiceRegistry.class);
		OrderInfo orderInfo = JSONUtil.jsonToObject(jsonStr,"orderInfo",OrderInfo.class);
		
		TSohAccAccountNumber accAccountNumber = accDao.getAccountIdFromAccnum(srRegistry.getAccountInfo().getAccountNumber());
		 if (null != accAccountNumber) {
	            TSohAccount account = accAccountNumber.getTSohAccount();
	            if (null != account) {
	            	String statusToBeUpdated=(String)execution.getVariable("statusToBeUpdated");
	                //Update the Latest history status - with effective till date
	                TSohHstAccountStatus latestHstAccountStatus = accDao.getLatestTSohHstAccountStatusByAccId(account.getAccountId());
	                if(Util.isValidObject(latestHstAccountStatus)){
	                	accDao.deleteTSohHstAccountStatus(latestHstAccountStatus, orderInfo.getUserId());
	                	CWLog.logMessage(Level.INFO,"Latest HST account["+ account.getAccountId() +"]status["+ latestHstAccountStatus.getAccStsId(), "]", ", Updated with effective till date");
	                }
	                // Creating new Account Status 
	                TSohHstAccountStatus newHstAccountStatus = accDao.newHstAccountStatus(orderInfo.getUserId(), latestHstAccountStatus, account,  statusToBeUpdated);                
	                List<TSohHstAccountStatus> hstAccountStatuses = account.getTSohHstAccountStatuses();
	                if (Util.isValidObject(newHstAccountStatus)) {
	                	CWLog.logMessage(Level.INFO,"Latest HST account[",account.getAccountId() +"]status[", newHstAccountStatus.getAccStsId()+ "] Created");
	                	hstAccountStatuses.add(newHstAccountStatus);
	                	account.setTSohHstAccountStatuses(hstAccountStatuses);
	                }
	                statusUpdated = accDao.updateAccountStatus(orderInfo.getUserId(), account, statusToBeUpdated);
	                execution.setVariable(UtilConstants.accountEntity, account);
	            }
	        }
	        if (statusUpdated) {
	        	execution.setVariable(UtilConstants.RESPONSE_CODE, "Done");	        	
				execution.setVariable(UtilConstants.RESPONSE_DESC, "Updated account status successfully");
	        }else {
	        	execution.setVariable(UtilConstants.RESPONSE_CODE, "Failed");
				execution.setVariable(UtilConstants.RESPONSE_DESC, "Unable to update account status");
	        }
	        execution.setVariable(UtilConstants.ACTIVITI_API_CTX, json.toString());
	        CWLog.logMessage(Level.INFO,"" + this.getClass() + "run end, output {}", "");
	}

}
