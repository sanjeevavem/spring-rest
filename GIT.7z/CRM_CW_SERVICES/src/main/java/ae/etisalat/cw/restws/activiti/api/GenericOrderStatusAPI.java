package ae.etisalat.cw.restws.activiti.api;

import java.util.HashMap;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.logging.log4j.Level;

import ae.etisalat.activiti.core.ActivitiAPI;
import ae.etisalat.cw.comm.util.logger.CWLog;

public class GenericOrderStatusAPI extends ActivitiAPI {

//	private static final Logger logger = LogManager.getLogger(GenericOrderCreationAPI.class);
    
	private String procedureName="updatesubreqstatus";
	private String output_SubRequestId;
	private String output_RequestId;
	
	@Override
	public void init(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
	}

	@Override
	public void run(DelegateExecution execution) throws Exception {
		CWLog.logMessage(Level.INFO, "run Start");
	
		if(execution!=null && execution.getVariable("output_SubRequestId")!=null){
			  output_SubRequestId = execution.getVariable("output_SubRequestId").toString();
		}
		if(execution!=null && execution.getVariable("output_RequestId")!=null){
			  output_RequestId = execution.getVariable("output_RequestId").toString();
		}

		HashMap<String, Object> procIn = new HashMap<String, Object>();
		procIn.put("REQUEST", output_RequestId);
		procIn.put("SUBREQUEST", output_SubRequestId);
		procIn.put("p_created_user_id", default_user_id);
		Map<String, Object> output = null;//genericOrderCreationDAO.executeProcedure(procedureName,procIn);
	
		CWLog.logMessage(Level.INFO, "run() end"+output);
	}

}
