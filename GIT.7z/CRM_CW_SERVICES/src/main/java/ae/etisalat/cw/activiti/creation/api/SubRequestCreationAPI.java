package ae.etisalat.cw.activiti.creation.api;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.apache.logging.log4j.Level;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import ae.etisalat.activiti.core.ActivitiAPI;
import ae.etisalat.crmgw.util.JsonSearchConstants;
import ae.etisalat.cw.comm.util.JSONUtil;
import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.UtilHelper;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.jpa.soh.daos.SubReqCreationDao;
import ae.etisalat.cw.jpa.soh.entities.TSohRequest;
import ae.etisalat.cw.jpa.soh.entities.TSohRequirement;
import ae.etisalat.cw.jpa.soh.entities.TSohSubrequest;
import ae.etisalat.cw.restws.clients.OrderInfo;
import ae.etisalat.cw.restws.clients.ServiceRegistry;
import ae.etisalat.cw.restws.context.SpringApplicationContext;

public class SubRequestCreationAPI    extends ActivitiAPI{
	
	private Expression JSON_REQUEST;
	protected SubReqCreationDao subReqCreation;

	@Override
	public void init(DelegateExecution execution) throws Exception {
		subReqCreation = SpringApplicationContext.getApplicationContext().getBean(SubReqCreationDao.class);
	}

	@Override
	public void run(DelegateExecution execution) throws Exception {
		CWLog.logMessage(Level.INFO, "run Start");
		UtilHelper util = new UtilHelper();
		String jsonStr = (String) util.evalExpr(UtilConstants.JSON_REQUEST,JSON_REQUEST,execution);
		JsonObject json = new Gson().fromJson(jsonStr, JsonObject.class);
		OrderInfo orderInfo = JSONUtil.jsonToObject(jsonStr,"orderInfo",OrderInfo.class);
		ServiceRegistry srvRegistry = JSONUtil.jsonToObject(jsonStr,JsonSearchConstants.srvRegistryQry,ServiceRegistry.class);
		TSohRequest request=subReqCreation.createRequest(orderInfo, srvRegistry.getAccountInfo());
		TSohRequirement requirement=subReqCreation.createRequirement(request,orderInfo);
		TSohSubrequest subRequest=subReqCreation.createSubRequest(request, requirement, orderInfo,srvRegistry.getAccountInfo());
		subReqCreation.createAccountInfo(orderInfo,srvRegistry.getAccountInfo(),request,subRequest);
		execution.setVariable(UtilConstants.subRequestEntity, subRequest);
		execution.setVariable(UtilConstants.requestEntity, request);
		execution.setVariable(UtilConstants.requirementEntity, requirement);
		execution.setVariable(UtilConstants.ACTIVITI_API_CTX, json.toString());
		CWLog.logMessage(Level.INFO,"" + this.getClass() + "run end, output {}", "");
	}

}
