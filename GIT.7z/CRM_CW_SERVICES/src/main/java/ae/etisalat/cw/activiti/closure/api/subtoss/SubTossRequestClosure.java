package ae.etisalat.cw.activiti.closure.api.subtoss;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.apache.logging.log4j.Level;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import ae.etisalat.activiti.core.ActivitiAPI;
import ae.etisalat.cw.comm.util.JSONUtil;
import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.UtilHelper;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.jpa.soh.daos.AccountDao;
import ae.etisalat.cw.jpa.soh.entities.TSohAccount;
import ae.etisalat.cw.jpa.soh.entities.TSohAccountServiceDetail;
import ae.etisalat.cw.jpa.soh.entities.TSohHstAccountStatus;
import ae.etisalat.cw.jpa.soh.entities.TSohSubrequest;
import ae.etisalat.cw.restws.clients.OrderInfo;
import ae.etisalat.cw.restws.context.SpringApplicationContext;

@Service
public class SubTossRequestClosure   extends ActivitiAPI {
	
	private Expression JSON_REQUEST;
	protected AccountDao accDao;

	@Override
	public void init(DelegateExecution execution) throws Exception {
		
		accDao = SpringApplicationContext.getApplicationContext().getBean(AccountDao.class);

	}
	@Override
	public void run(DelegateExecution execution) throws Exception {
		CWLog.logMessage(Level.INFO, "run Start");
		UtilHelper util = new UtilHelper();
		boolean statusUpdated=false;
		String jsonStr = (String) util.evalExpr(UtilConstants.JSON_REQUEST,JSON_REQUEST,execution);
		JsonObject json = new Gson().fromJson(jsonStr, JsonObject.class);
		OrderInfo orderInfo = JSONUtil.jsonToObject(jsonStr,"orderInfo",OrderInfo.class);
		Long subReqId=null;TSohSubrequest currentSubrequestEntity=null;
		if(orderInfo.getSubRequestId()!=null){
			subReqId=Long.parseLong(orderInfo.getSubRequestId());
			currentSubrequestEntity = accDao.getsubRequestBySubrequestId(subReqId);
		}		
		TSohAccount tSohAccount = execution.getVariable(UtilConstants.accountEntity, TSohAccount.class);			
		if(null != tSohAccount){
			String statusToBeUpdated=(String)execution.getVariable("statusToBeUpdated");
            boolean isUpdated = updateTSohAccountDetails(orderInfo.getUserId(), tSohAccount, currentSubrequestEntity);
			if(isUpdated)
				CWLog.logMessage(Level.INFO, " Port Out TSohAccount succesfully updated");
			else{
				CWLog.logMessage(Level.INFO, " Exiting PortOut Operation. Unable to update TSohAccount in CRM");
				execution.setVariable(UtilConstants.RESPONSE_CODE, "Failed");
				execution.setVariable(UtilConstants.RESPONSE_DESC, " Exiting PortOut Operation. Unable to update TSohAccount in CRM");
				json.addProperty(UtilConstants.RESPONSE_CODE, "Failed");
				json.addProperty(UtilConstants.RESPONSE_DESC, " Exiting PortOut Operation. Unable to update TSohAccount in CRM");
			}
			isUpdated = portOutAccountServiceDetails(tSohAccount, orderInfo.getUserId());
			if(isUpdated)
				CWLog.logMessage(Level.INFO," Port Out TSohAccountServiceDetails succesfully updated");
			else{
				CWLog.logMessage(Level.INFO, " Exiting PortOut Operation. Unable to update TSohAccountServiceDetails in CRM");
				execution.setVariable(UtilConstants.RESPONSE_CODE, "Failed");
				execution.setVariable(UtilConstants.RESPONSE_DESC, "Port Out failed at TSohAccountServiceDetails update");
				json.addProperty(UtilConstants.RESPONSE_CODE, "Failed");
				json.addProperty(UtilConstants.RESPONSE_DESC, "Port Out failed at TSohAccountServiceDetails update");
			}
			
			TSohHstAccountStatus latestHstAccountStatus = accDao.getLatestTSohHstAccountStatusByAccId(tSohAccount.getAccountId());
			isUpdated = accDao.deleteTSohHstAccountStatus(latestHstAccountStatus,orderInfo.getUserId());
			if(isUpdated)
				CWLog.logMessage(Level.INFO, " Port Out TSohHstAccountStatus succesfully updated");
			else{
				CWLog.logMessage(Level.INFO," Exiting PortOut Operation. Unable to update TSohHstAccountStatus in CRM");
				execution.setVariable(UtilConstants.RESPONSE_CODE, "Failed");
				execution.setVariable(UtilConstants.RESPONSE_DESC, "Port Out failed at TSohHstAccountStatus update");
				json.addProperty(UtilConstants.RESPONSE_CODE, "Failed");
				json.addProperty(UtilConstants.RESPONSE_DESC, "Port Out failed at TSohHstAccountStatus update");
			}
			TSohHstAccountStatus newHstAccountStatus = accDao.newHstAccountStatus(orderInfo.getUserId(), latestHstAccountStatus,tSohAccount, statusToBeUpdated);
			if(newHstAccountStatus!=null)
				CWLog.logMessage(Level.INFO, " Port Out TSohHstAccountStatus succesfully Inserted");
			else{
				execution.setVariable(UtilConstants.RESPONSE_CODE, "Failed");
				execution.setVariable(UtilConstants.RESPONSE_DESC, "Port Out TSohHstAccountStatus failed to Insert");
				json.addProperty(UtilConstants.RESPONSE_CODE, "Failed");
				json.addProperty(UtilConstants.RESPONSE_DESC, "Port Out TSohHstAccountStatus failed to Insert");
			}
		}		
		if (statusUpdated) {
        	execution.setVariable(UtilConstants.RESPONSE_CODE, "Done");
			execution.setVariable(UtilConstants.RESPONSE_DESC, "Updated account status successfully");
        }else {
        	execution.setVariable(UtilConstants.RESPONSE_CODE, "Failed");
			execution.setVariable(UtilConstants.RESPONSE_DESC, "Unable to update account status");
        }
        execution.setVariable(UtilConstants.ACTIVITI_API_CTX, json.toString());
        CWLog.logMessage(Level.INFO,"" + this.getClass() + "run end, output {}", "");
		
	}
	
	private Boolean updateTSohAccountDetails(String userId, TSohAccount tSohAccount,
	        TSohSubrequest currentSubrequestEntity) throws DataAccessException {
			tSohAccount.setModifiedUserId(userId);
			tSohAccount.setModifiedDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
			tSohAccount.setCessationDate(null);
			tSohAccount.setDateAcctStat(new Timestamp(Calendar.getInstance().getTimeInMillis()));
			tSohAccount.setDeletionStatus("N");
			if(currentSubrequestEntity != null && null != currentSubrequestEntity.getTSohDtlSystemCodeValue3() && 
					currentSubrequestEntity.getTSohDtlSystemCodeValue3().getSystemCodeValueId() > 0 ){
				CWLog.logMessage(Level.INFO, " Port Out reason id tSohAccount:- "+ currentSubrequestEntity.getTSohDtlSystemCodeValue3().getSystemCodeValueId());
				tSohAccount.setReasonId(new BigDecimal(currentSubrequestEntity.getTSohDtlSystemCodeValue3().getSystemCodeValueId()));
			}else{
				CWLog.logMessage(Level.INFO, " Port Out reason id tSohAccount is not available");
				tSohAccount.setReasonId(new BigDecimal("57"));
			}
			tSohAccount.setCreditReasonId(new BigDecimal(102));
			tSohAccount.setAccountStatusId(new BigDecimal("3"));
			accDao.merge(tSohAccount);
			return Boolean.TRUE;
		}
	
	public boolean portOutAccountServiceDetails(TSohAccount account, String userId) throws Exception {
		boolean operation = false;	
		CWLog.logMessage(Level.INFO," portOutAccountServiceDetails() - AccountId " + account.getAccountId());		
		List<TSohAccountServiceDetail> tSohAccountServiceDetails = null;
		try {
			if (null != account) {
				tSohAccountServiceDetails = accDao.fetchServiceDtlbyAcctId(account.getAccountId());
				if(null!=tSohAccountServiceDetails) {
					for (TSohAccountServiceDetail serviceDetail:tSohAccountServiceDetails) {
						serviceDetail.setServiceStatusId(new BigDecimal("561"));
						serviceDetail.setCreditStatusId(new BigDecimal(67));
						serviceDetail.setDateAcctStat(new Date());
						serviceDetail.setReasonId(new BigDecimal("63"));
						serviceDetail.setCreditReasonId(new BigDecimal(102));
						serviceDetail.setModifiedUserId(userId);
						accDao.merge(serviceDetail);
						operation=true;						
					}
				}
			}
		} catch (Exception e) {
			CWLog.logMessage(Level.INFO,"Exception AccountServiceDetails_DAO.portOutAccountServiceDetails() ", e);
			operation=false;
		} 
		return operation;
	}

}
