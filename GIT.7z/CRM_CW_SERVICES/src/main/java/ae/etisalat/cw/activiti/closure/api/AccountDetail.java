package ae.etisalat.cw.activiti.closure.api;

import java.util.List;

import ae.etisalat.cw.jpa.soh.entities.TSohAccAccountNumber;
import ae.etisalat.cw.jpa.soh.entities.TSohAccount;
import ae.etisalat.cw.jpa.soh.entities.TSohAccountServiceDetail;
import ae.etisalat.cw.jpa.soh.entities.TSohSubscriptionPackageDtl;
import ae.etisalat.cw.jpa.soh.entities.TSohSubscriptionRateplnDtl;

public class AccountDetail {
	private Long accountNumber;
	private Long accountId;
	private TSohAccAccountNumber accAccountNumber;
	private TSohAccount account;
	
	public Long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Long getAccountId() {
		return accountId;
	}
	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}
	public TSohAccAccountNumber getAccAccountNumber() {
		return accAccountNumber;
	}
	public void setAccAccountNumber(TSohAccAccountNumber accAccountNumber) {
		this.accAccountNumber = accAccountNumber;
	}
	public TSohAccount getAccount() {
		return account;
	}
	public void setAccount(TSohAccount account) {
		this.account = account;
	}
	public List<TSohAccountServiceDetail> getAccServiceDetails() {
		return accServiceDetails;
	}
	public void setAccServiceDetails(List<TSohAccountServiceDetail> accServiceDetails) {
		this.accServiceDetails = accServiceDetails;
	}
	public List<TSohSubscriptionPackageDtl> getAccSubscriptionPackageDtls() {
		return accSubscriptionPackageDtls;
	}
	public void setAccSubscriptionPackageDtls(List<TSohSubscriptionPackageDtl> accSubscriptionPackageDtls) {
		this.accSubscriptionPackageDtls = accSubscriptionPackageDtls;
	}
	public List<TSohSubscriptionRateplnDtl> getAccSubscriptionRateplnDtls() {
		return accSubscriptionRateplnDtls;
	}
	public void setAccSubscriptionRateplnDtls(List<TSohSubscriptionRateplnDtl> accSubscriptionRateplnDtls) {
		this.accSubscriptionRateplnDtls = accSubscriptionRateplnDtls;
	}
	private List<TSohAccountServiceDetail> accServiceDetails;
	private List<TSohSubscriptionPackageDtl> accSubscriptionPackageDtls;
	private List<TSohSubscriptionRateplnDtl> accSubscriptionRateplnDtls;
	
	

}
