package ae.etisalat.cw.restws.service;

import com.google.gson.JsonObject;

public interface OrderCreationService {
	public JsonObject createOrder(JsonObject orderRequest) throws Exception;
	public JsonObject loadDefaultConfiguration(JsonObject orderRequest) throws Exception;
}
