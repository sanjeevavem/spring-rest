package ae.etisalat.cw.restws.integration;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "additionalParameters", "action", "visaDetails", "identityId", "identitySeqId", "cdmsReference", "createdDate", "createdUserId",
        "deletionStatus", "documentDate", "effectiveFrom", "effectiveTill", "establishmentName", "identityCode", "identityTypeId",
        "identityTypeCode", "identityValNo", "identityValue", "issuingAuthority", "messageId", "modifiedDate", "modifiedUserId", "partyId",
        "profileId", "scannedFromReader", "tradeName", "unifiedNumber", "universityName", "documentScannedManually",
        "documentAuditInformation","partyNationality" })
public class Document {

    @JsonProperty("additionalParameters")
    private List<AdditionalParameter> additionalParameters = new ArrayList<AdditionalParameter>();
    @JsonProperty("action")
    private String action;
    @JsonProperty("visaDetails")
    private VisaDetails visaDetails;
    @JsonProperty("identityId")
    private Long identityId;
    @JsonProperty("identitySeqId")
	protected Long identitySeqId;
    @JsonProperty("cdmsReference")
    private Long cdmsReference;
    @JsonProperty("createdDate")
    private Date createdDate;
    @JsonProperty("createdUserId")
    private String createdUserId;
    @JsonProperty("deletionStatus")
    private String deletionStatus;
    @JsonProperty("documentDate")
    private Date documentDate;
    @JsonProperty("effectiveFrom")
    private Date effectiveFrom;
    @JsonProperty("effectiveTill")
    private Date effectiveTill;
    @JsonProperty("establishmentName")
    private String establishmentName;
    @JsonProperty("identityCode")
    private String identityCode;
    @JsonProperty("identityTypeId")
    private Long identityTypeId;
    @JsonProperty("identityTypeCode")
    private String identityTypeCode;
    @JsonProperty("identityValNo")
    private Long identityValNo;
    @JsonProperty("identityValue")
    private String identityValue;
    @JsonProperty("issuingAuthority")
    private String issuingAuthority;
    @JsonProperty("messageId")
    private Long messageId;
    @JsonProperty("modifiedDate")
    private Date modifiedDate;
    @JsonProperty("modifiedUserId")
    private String modifiedUserId;
    @JsonProperty("partyId")
    private Long partyId;
    @JsonProperty("profileId")
    private Long profileId;
    @JsonProperty("scannedFromReader")
    private String scannedFromReader;
    @JsonProperty("tradeName")
    private String tradeName;
    @JsonProperty("unifiedNumber")
    private Long unifiedNumber;
    @JsonProperty("universityName")
    private String universityName;
    @JsonProperty("documentScannedManually")
    private boolean documentScannedManually;
    @JsonProperty("documentAuditInformation")
    private DocumentAuditInformation documentAuditInformation;
    @JsonProperty("partyNationality")
    private Segment partyNationality ;

    @JsonProperty("additionalParameters")
    public List<AdditionalParameter> getAdditionalParameters() {
        return additionalParameters;
    }

    @JsonProperty("additionalParameters")
    public void setAdditionalParameters(List<AdditionalParameter> additionalParameters) {
        this.additionalParameters = additionalParameters;
    }

    public Document withAdditionalParameters(List<AdditionalParameter> additionalParameters) {
        this.additionalParameters = additionalParameters;
        return this;
    }

    @JsonProperty("action")
    public String getAction() {
        return action;
    }

    @JsonProperty("action")
    public void setAction(String action) {
        this.action = action;
    }

    public Document withAction(String action) {
        this.action = action;
        return this;
    }

    @JsonProperty("visaDetails")
    public VisaDetails getVisaDetails() {
        return visaDetails;
    }

    @JsonProperty("visaDetails")
    public void setVisaDetails(VisaDetails visaDetails) {
        this.visaDetails = visaDetails;
    }

    public Document withVisaDetails(VisaDetails visaDetails) {
        this.visaDetails = visaDetails;
        return this;
    }

    @JsonProperty("identityId")
    public Long getIdentityId() {
        return identityId;
    }

    @JsonProperty("identityId")
    public void setIdentityId(Long identityId) {
        this.identityId = identityId;
    }

    public Document withIdentityId(Long identityId) {
        this.identityId = identityId;
        return this;
    }

    @JsonProperty("cdmsReference")
    public Long getCdmsReference() {
        return cdmsReference;
    }

    @JsonProperty("cdmsReference")
    public void setCdmsReference(Long cdmsReference) {
        this.cdmsReference = cdmsReference;
    }

    public Document withCdmsReference(Long cdmsReference) {
        this.cdmsReference = cdmsReference;
        return this;
    }

    @JsonProperty("createdDate")
    public Date getCreatedDate() {
        return createdDate;
    }

    @JsonProperty("createdDate")
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Document withCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
        return this;
    }

    @JsonProperty("createdUserId")
    public String getCreatedUserId() {
        return createdUserId;
    }

    @JsonProperty("createdUserId")
    public void setCreatedUserId(String createdUserId) {
        this.createdUserId = createdUserId;
    }

    public Document withCreatedUserId(String createdUserId) {
        this.createdUserId = createdUserId;
        return this;
    }

    @JsonProperty("deletionStatus")
    public String getDeletionStatus() {
        return deletionStatus;
    }

    @JsonProperty("deletionStatus")
    public void setDeletionStatus(String deletionStatus) {
        this.deletionStatus = deletionStatus;
    }

    public Document withDeletionStatus(String deletionStatus) {
        this.deletionStatus = deletionStatus;
        return this;
    }

    @JsonProperty("documentDate")
    public Date getDocumentDate() {
        return documentDate;
    }

    @JsonProperty("documentDate")
    public void setDocumentDate(Date documentDate) {
        this.documentDate = documentDate;
    }

    public Document withDocumentDate(Date documentDate) {
        this.documentDate = documentDate;
        return this;
    }

    @JsonProperty("effectiveFrom")
    public Date getEffectiveFrom() {
        return effectiveFrom;
    }

    @JsonProperty("effectiveFrom")
    public void setEffectiveFrom(Date effectiveFrom) {
        this.effectiveFrom = effectiveFrom;
    }

    public Document withEffectiveFrom(Date effectiveFrom) {
        this.effectiveFrom = effectiveFrom;
        return this;
    }

    @JsonProperty("effectiveTill")
    public Date getEffectiveTill() {
        return effectiveTill;
    }

    @JsonProperty("effectiveTill")
    public void setEffectiveTill(Date effectiveTill) {
        this.effectiveTill = effectiveTill;
    }

    public Document withEffectiveTill(Date effectiveTill) {
        this.effectiveTill = effectiveTill;
        return this;
    }

    @JsonProperty("establishmentName")
    public String getEstablishmentName() {
        return establishmentName;
    }

    @JsonProperty("establishmentName")
    public void setEstablishmentName(String establishmentName) {
        this.establishmentName = establishmentName;
    }

    public Document withEstablishmentName(String establishmentName) {
        this.establishmentName = establishmentName;
        return this;
    }

    @JsonProperty("identityCode")
    public String getIdentityCode() {
        return identityCode;
    }

    @JsonProperty("identityCode")
    public void setIdentityCode(String identityCode) {
        this.identityCode = identityCode;
    }

    public Document withIdentityCode(String identityCode) {
        this.identityCode = identityCode;
        return this;
    }

    @JsonProperty("identityTypeId")
    public Long getIdentityTypeId() {
        return identityTypeId;
    }

    @JsonProperty("identityTypeId")
    public void setIdentityTypeId(Long identityTypeId) {
        this.identityTypeId = identityTypeId;
    }

    public Document withIdentityTypeId(Long identityTypeId) {
        this.identityTypeId = identityTypeId;
        return this;
    }

    @JsonProperty("identityTypeCode")
    public String getIdentityTypeCode() {
        return identityTypeCode;
    }

    @JsonProperty("identityTypeCode")
    public void setIdentityTypeCode(String identityTypeCode) {
        this.identityTypeCode = identityTypeCode;
    }

    public Document withIdentityTypeCode(String identityTypeCode) {
        this.identityTypeCode = identityTypeCode;
        return this;
    }

    @JsonProperty("identityValNo")
    public Long getIdentityValNo() {
        return identityValNo;
    }

    @JsonProperty("identityValNo")
    public void setIdentityValNo(Long identityValNo) {
        this.identityValNo = identityValNo;
    }

    public Document withIdentityValNo(Long identityValNo) {
        this.identityValNo = identityValNo;
        return this;
    }

    @JsonProperty("identityValue")
    public String getIdentityValue() {
        return identityValue;
    }

    @JsonProperty("identityValue")
    public void setIdentityValue(String identityValue) {
        this.identityValue = identityValue;
    }

    public Document withIdentityValue(String identityValue) {
        this.identityValue = identityValue;
        return this;
    }

    @JsonProperty("issuingAuthority")
    public String getIssuingAuthority() {
        return issuingAuthority;
    }

    @JsonProperty("issuingAuthority")
    public void setIssuingAuthority(String issuingAuthority) {
        this.issuingAuthority = issuingAuthority;
    }

    public Document withIssuingAuthority(String issuingAuthority) {
        this.issuingAuthority = issuingAuthority;
        return this;
    }

    @JsonProperty("messageId")
    public Long getMessageId() {
        return messageId;
    }

    @JsonProperty("messageId")
    public void setMessageId(Long messageId) {
        this.messageId = messageId;
    }

    public Document withMessageId(Long messageId) {
        this.messageId = messageId;
        return this;
    }

    @JsonProperty("modifiedDate")
    public Date getModifiedDate() {
        return modifiedDate;
    }

    @JsonProperty("modifiedDate")
    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Document withModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
        return this;
    }

    @JsonProperty("modifiedUserId")
    public String getModifiedUserId() {
        return modifiedUserId;
    }

    @JsonProperty("modifiedUserId")
    public void setModifiedUserId(String modifiedUserId) {
        this.modifiedUserId = modifiedUserId;
    }

    public Document withModifiedUserId(String modifiedUserId) {
        this.modifiedUserId = modifiedUserId;
        return this;
    }

    @JsonProperty("partyId")
    public Long getPartyId() {
        return partyId;
    }

    @JsonProperty("partyId")
    public void setPartyId(Long partyId) {
        this.partyId = partyId;
    }

    public Document withPartyId(Long partyId) {
        this.partyId = partyId;
        return this;
    }

    @JsonProperty("profileId")
    public Long getProfileId() {
        return profileId;
    }

    @JsonProperty("profileId")
    public void setProfileId(Long profileId) {
        this.profileId = profileId;
    }

    public Document withProfileId(Long profileId) {
        this.profileId = profileId;
        return this;
    }

    @JsonProperty("scannedFromReader")
    public String getScannedFromReader() {
        return scannedFromReader;
    }

    @JsonProperty("scannedFromReader")
    public void setScannedFromReader(String scannedFromReader) {
        this.scannedFromReader = scannedFromReader;
    }

    public Document withScannedFromReader(String scannedFromReader) {
        this.scannedFromReader = scannedFromReader;
        return this;
    }

    @JsonProperty("tradeName")
    public String getTradeName() {
        return tradeName;
    }

    @JsonProperty("tradeName")
    public void setTradeName(String tradeName) {
        this.tradeName = tradeName;
    }

    public Document withTradeName(String tradeName) {
        this.tradeName = tradeName;
        return this;
    }

    @JsonProperty("unifiedNumber")
    public Long getUnifiedNumber() {
        return unifiedNumber;
    }

    @JsonProperty("unifiedNumber")
    public void setUnifiedNumber(Long unifiedNumber) {
        this.unifiedNumber = unifiedNumber;
    }

    public Document withUnifiedNumber(Long unifiedNumber) {
        this.unifiedNumber = unifiedNumber;
        return this;
    }

    @JsonProperty("universityName")
    public String getUniversityName() {
        return universityName;
    }

    @JsonProperty("universityName")
    public void setUniversityName(String universityName) {
        this.universityName = universityName;
    }

    public Document withUniversityName(String universityName) {
        this.universityName = universityName;
        return this;
    }

    @JsonProperty("documentScannedManually")
    public boolean getDocumentScannedManually() {
        return documentScannedManually;
    }

    @JsonProperty("documentScannedManually")
    public void setDocumentScannedManually(boolean documentScannedManually) {
        this.documentScannedManually = documentScannedManually;
    }

    public Document withDocumentScannedManually(boolean documentScannedManually) {
        this.documentScannedManually = documentScannedManually;
        return this;
    }

    @JsonProperty("documentAuditInformation")
    public DocumentAuditInformation getDocumentAuditInformation() {
        return documentAuditInformation;
    }

    @JsonProperty("documentAuditInformation")
    public void setDocumentAuditInformation(DocumentAuditInformation documentAuditInformation) {
        this.documentAuditInformation = documentAuditInformation;
    }

    public Document withDocumentAuditInformation(DocumentAuditInformation documentAuditInformation) {
        this.documentAuditInformation = documentAuditInformation;
        return this;
    }

    public Long getIdentitySeqId() {
		return identitySeqId;
	}

	public void setIdentitySeqId(Long identitySeqId) {
		this.identitySeqId = identitySeqId;
	}

    public Document withIdentitySeqId(Long identitySeqId) {
        this.identitySeqId = identitySeqId;
        return this;
    }

	public Segment getPartyNationality() {
		return partyNationality;
	}

	public void setPartyNationality(Segment partyNationality) {
		this.partyNationality = partyNationality;
	}

    public Document withPartyNationality(Segment partyNationality) {
        this.partyNationality = partyNationality;
        return this;
    }

	@Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(additionalParameters).append(action).append(visaDetails).append(identityId).append(identitySeqId)
            .append(cdmsReference).append(createdDate).append(createdUserId).append(deletionStatus).append(documentDate)
            .append(effectiveFrom).append(effectiveTill).append(establishmentName).append(identityCode).append(identityTypeId)
            .append(identityTypeCode).append(identityValNo).append(identityValue).append(issuingAuthority).append(messageId)
            .append(modifiedDate).append(modifiedUserId).append(partyId).append(profileId).append(scannedFromReader).append(tradeName)
            .append(unifiedNumber).append(universityName).append(documentScannedManually).append(partyNationality).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Document) == false) {
            return false;
        }
        Document rhs = ((Document) other);
        return new EqualsBuilder().append(additionalParameters, rhs.additionalParameters).append(action, rhs.action)
            .append(visaDetails, rhs.visaDetails).append(identityId, rhs.identityId).append(identitySeqId, rhs.identitySeqId).append(cdmsReference, rhs.cdmsReference)
            .append(createdDate, rhs.createdDate).append(createdUserId, rhs.createdUserId).append(deletionStatus, rhs.deletionStatus)
            .append(documentDate, rhs.documentDate).append(effectiveFrom, rhs.effectiveFrom).append(effectiveTill, rhs.effectiveTill)
            .append(establishmentName, rhs.establishmentName).append(identityCode, rhs.identityCode)
            .append(identityTypeId, rhs.identityTypeId).append(identityTypeCode, rhs.identityTypeCode)
            .append(identityValNo, rhs.identityValNo).append(identityValue, rhs.identityValue)
            .append(issuingAuthority, rhs.issuingAuthority).append(messageId, rhs.messageId).append(modifiedDate, rhs.modifiedDate)
            .append(modifiedUserId, rhs.modifiedUserId).append(partyId, rhs.partyId).append(profileId, rhs.profileId)
            .append(scannedFromReader, rhs.scannedFromReader).append(tradeName, rhs.tradeName).append(unifiedNumber, rhs.unifiedNumber)
            .append(universityName, rhs.universityName).append(documentScannedManually, rhs.documentScannedManually)
            .append(documentAuditInformation, rhs.documentAuditInformation).append(partyNationality, rhs.partyNationality).isEquals();
    }

}
