package ae.etisalat.cw.activiti.closure.api;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.logging.log4j.Level;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import ae.etisalat.activiti.core.ActivitiAPI;
import ae.etisalat.crmgw.util.JsonSearchConstants;
import ae.etisalat.cw.comm.util.JSONUtil;
import ae.etisalat.cw.comm.util.Util;
import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.UtilHelper;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.jpa.soh.entities.TSohDtlSystemCodeValue;
import ae.etisalat.cw.jpa.soh.entities.TSohRequest;
import ae.etisalat.cw.jpa.soh.entities.TSohSubrequest;

@Service
public class CloseSubRequestAPI extends ActivitiAPI {



	@Override
	public void init(DelegateExecution execution) throws Exception {
	}

	@Override
	public void run(DelegateExecution execution) throws Exception {
	  CWLog.logMessage(Level.INFO, "CloseSubRequestAPI run Start");
		UtilHelper util = new UtilHelper();
		String jsonStr = (String) util.evalExpr(UtilConstants.JSON_REQUEST,JSON_REQUEST,execution);
		JsonObject json = new Gson().fromJson(jsonStr, JsonObject.class);
		HashMap<String, Object> map = JSONUtil.convertJSONToMap(json);
		
		String request = JSONUtil.getJSONValueByKey(jsonStr,JsonSearchConstants.request);
		String subRequest = JSONUtil.getJSONValueByKey(jsonStr,JsonSearchConstants.subRequest);
		  
        List<Long> subRequestStatusList = Arrays.asList(UtilConstants.REQUEST_STATUS_CANCEL_AND_CLOSED);
        TSohDtlSystemCodeValue closeSubRequestSystemCodeValue = genericOrderCreationDAO.findById(TSohDtlSystemCodeValue.class, 90l);
		
		if(Util.isValidObject(request)){
			HashMap<String,Object> queryParamMap = new HashMap<String,Object>();
			queryParamMap.put("REQUEST_ID", new Long(request));
			List<TSohRequest> list =  genericOrderCreationDAO.executeQueryList("TSohRequest.findById",queryParamMap,TSohRequest.class);	
			if(list!=null && list.size()>0){
				TSohRequest tSohRequest =(TSohRequest)list.get(0);	
				queryParamMap.put("SUBREQSTATUSES", subRequestStatusList);
				List<TSohSubrequest>  tSohSubrequestList = genericOrderCreationDAO.executeQueryList("TSohSubrequest.findByRequestIdAndNotInStatus",queryParamMap,TSohSubrequest.class);
				for(TSohSubrequest tSohSubrequest: tSohSubrequestList){
				 tSohSubrequest.setTSohDtlSystemCodeValue1(closeSubRequestSystemCodeValue);
				 genericOrderCreationDAO.update(tSohSubrequest,TSohSubrequest.class);
				}
			} 
		}else if(Util.isValidObject(subRequest)){
			HashMap<String,Object> queryParamMap = new HashMap<String,Object>();
			queryParamMap.put("SUBREQUEST_ID", new Long(subRequest));
			queryParamMap.put("SUBREQSTATUSES", subRequestStatusList);
			List<TSohSubrequest>  tSohSubrequestList = genericOrderCreationDAO.executeQueryList("TSohSubrequest.findByRequestIdAndNotInStatus",queryParamMap,TSohSubrequest.class);
			for(TSohSubrequest tSohSubrequest: tSohSubrequestList){
				 tSohSubrequest.setTSohDtlSystemCodeValue1(closeSubRequestSystemCodeValue);
				 genericOrderCreationDAO.update(tSohSubrequest,TSohSubrequest.class);
				}
		}else {
			throw new Exception("Invalid Input");
		}
		System.out.println(jsonStr);
	  CWLog.logMessage(Level.INFO, "CloseSubRequestAPI run End");
	}
	
	public void updateSubRequestStatus() throws Exception {
	  CWLog.logMessage(Level.INFO, "updateSubRequestStatus Start");
	  
	  CWLog.logMessage(Level.INFO, "updateSubRequestStatus End");
	}
 

}
