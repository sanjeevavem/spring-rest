package ae.etisalat.cw.activiti.closure.api;

import java.util.HashMap;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.apache.logging.log4j.Level;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import ae.etisalat.activiti.core.ActivitiAPI;
import ae.etisalat.crmgw.util.JsonSearchConstants;
import ae.etisalat.cw.comm.util.JSONUtil;
import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.UtilHelper;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.jpa.soh.daos.AccountDao;
import ae.etisalat.cw.jpa.soh.daos.AccountServiceCreationDao;
import ae.etisalat.cw.jpa.soh.daos.PkgRpAcctSrvcInstMapping;
import ae.etisalat.cw.jpa.soh.entities.TSohAccAccountNumber;
import ae.etisalat.cw.jpa.soh.entities.TSohAccount;
import ae.etisalat.cw.restws.clients.OfferingDetailsList;
import ae.etisalat.cw.restws.clients.OrderInfo;
import ae.etisalat.cw.restws.clients.ServiceRegistry;
import ae.etisalat.cw.restws.context.SpringApplicationContext;

@Service
public class AccountServiceCreationApi extends ActivitiAPI{
	
	 private Expression JSON_REQUEST;
	 protected AccountServiceCreationDao accountServiceCreationDao;
	 protected AccountDao accDao;

	@Override
	public void init(DelegateExecution execution) throws Exception {
		accountServiceCreationDao = SpringApplicationContext.getApplicationContext().getBean(AccountServiceCreationDao.class);
		accDao = SpringApplicationContext.getApplicationContext().getBean(AccountDao.class);
	}
	

	@Override
	public void run(DelegateExecution execution) throws Exception {
		CWLog.logMessage(Level.INFO, "run Start");
		UtilHelper util = new UtilHelper();
		String jsonStr = (String) util.evalExpr(UtilConstants.JSON_REQUEST,JSON_REQUEST,execution);
		JsonObject json = new Gson().fromJson(jsonStr, JsonObject.class);
		ServiceRegistry srvRegistry = JSONUtil.jsonToObject(jsonStr,JsonSearchConstants.srvRegistryQry,ServiceRegistry.class);
		List<OfferingDetailsList> offeringDetailsLists = srvRegistry.getOfferingDetailsList();
		OrderInfo orderInfo = JSONUtil.jsonToObject(jsonStr,JsonSearchConstants.orderInfoQry,OrderInfo.class);
		TSohAccount tSohAccount=new TSohAccount();
		if(orderInfo.getOrderType()!=null && orderInfo.getOrderType().equalsIgnoreCase(UtilConstants.orderType_NEW))
			tSohAccount    =  execution.getVariable(UtilConstants.accountEntity, TSohAccount.class);
		else{
			TSohAccAccountNumber account=accDao.getAccountIdFromAccnum(srvRegistry.getAccountInfo().getAccountNumber());
			if(account!=null)
				tSohAccount=account.getTSohAccount();
		}
		List<PkgRpAcctSrvcInstMapping> acctServiceDtlsList = accountServiceCreationDao.createAccountServiceDtls
				(Long.valueOf(srvRegistry.getAccountInfo().getSubTypeId()), tSohAccount, offeringDetailsLists);
		if(acctServiceDtlsList!=null && acctServiceDtlsList.size()>0){
		  execution.setVariable(UtilConstants.accSrvInstDtl, acctServiceDtlsList);
		  json.addProperty(UtilConstants.accSrvInstDtl, acctServiceDtlsList.toString());
		}
		if(orderInfo.getOrderType()!=null && !orderInfo.getOrderType().equalsIgnoreCase(UtilConstants.orderType_NEW))
			execution.setVariable(UtilConstants.accountEntity, tSohAccount);
	  execution.setVariable(UtilConstants.orderParamValues, constructOrderParam(acctServiceDtlsList,tSohAccount,orderInfo));
	  execution.setVariable(UtilConstants.paramValue, constructParamValue(orderInfo));
	  execution.setVariable(UtilConstants.ACTIVITI_API_CTX, json.toString());
	  CWLog.logMessage(Level.INFO,"" + this.getClass() + "run end, output {}", "");
	}
	
	private HashMap<String,Object> constructOrderParam(List<PkgRpAcctSrvcInstMapping> acctServiceDtlsList,TSohAccount tSohAccount,OrderInfo orderInfo){
		HashMap<String,Object> orderParam=new HashMap<String,Object>();
		for (PkgRpAcctSrvcInstMapping pkgRp : acctServiceDtlsList) {
			if (pkgRp.getSrvcCategoryId() == 9){
				orderParam.put(UtilConstants.packageCode, pkgRp.getPackageCode());
				orderParam.put(UtilConstants.packageId, pkgRp.getPackageId());
				orderParam.put(UtilConstants.primaryRatePlanCode, pkgRp.getRatePlanCode());
				orderParam.put(UtilConstants.primaryRatePlanId, pkgRp.getRatePlanId());
				orderParam.put(UtilConstants.primaryServiceId, pkgRp.getSrvcId().toString());
				orderParam.put(UtilConstants.primaryAcctServiceId, pkgRp.getAcctSrvcId());
				orderParam.put(UtilConstants.primaryAcctServiceInstId, pkgRp.getAcctSrvcInstanceId().get(0));
			}
		}
		orderParam.put(UtilConstants.accountId, tSohAccount.getAccountId());
		orderParam.put(UtilConstants.accountNumber, orderInfo.getAccountNumber());
		orderParam.put(UtilConstants.accountSuffix, orderInfo.getAccountSuffix());
		orderParam.put(UtilConstants.partyId, tSohAccount.getPartyId());
		orderParam.put(UtilConstants.profileId, tSohAccount.getPartyProfileId());
		orderParam.put(UtilConstants.orderType, orderInfo.getOrderType());
		orderParam.put(UtilConstants.subRequestId, orderInfo.getSubRequestId());
		orderParam.put(UtilConstants.userId, orderInfo.getUserId());
		orderParam.put(UtilConstants.productId, tSohAccount.getProductId());
		orderParam.put(UtilConstants.productGroupId, tSohAccount.getProductGroupId());
		return orderParam;
	}
	private HashMap<String,Object> constructParamValue(OrderInfo orderInfo){
		HashMap<String,Object> paramValue=new HashMap<String,Object>();
		paramValue.put(UtilConstants.orderType, orderInfo.getOrderType());
		paramValue.put(UtilConstants.productCode, orderInfo.getProductCode());
		paramValue.put(UtilConstants.productGroupCode, orderInfo.getProductGroupCode());
		return paramValue;
	}

}
