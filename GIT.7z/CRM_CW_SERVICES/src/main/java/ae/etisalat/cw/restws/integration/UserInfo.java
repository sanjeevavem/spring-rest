
package ae.etisalat.cw.restws.integration;

import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class UserInfo {

    private String userType;
    private String userId;
    private String roleName;
    private String organizationId;
    private List<AdditionalInformation> additionalInfo;

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public UserInfo withUserType(String userType) {
        this.userType = userType;
        return this;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public UserInfo withUserId(String userId) {
        this.userId = userId;
        return this;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public UserInfo withRoleName(String roleName) {
        this.roleName = roleName;
        return this;
    }

    public String getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(String organizationId) {
        this.organizationId = organizationId;
    }

    public UserInfo withOrganizationId(String organizationId) {
        this.organizationId = organizationId;
        return this;
    }

    public List<AdditionalInformation> getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(List<AdditionalInformation> additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public UserInfo withAdditionalInfo(List<AdditionalInformation> additionalInfo) {
        this.additionalInfo = additionalInfo;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(userType).append(userId).append(roleName).append(organizationId).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof UserInfo) == false) {
            return false;
        }
        UserInfo rhs = ((UserInfo) other);
        return new EqualsBuilder().append(userType, rhs.userType).append(userId, rhs.userId).append(roleName, rhs.roleName)
            .append(organizationId, rhs.organizationId).isEquals();
    }

}
