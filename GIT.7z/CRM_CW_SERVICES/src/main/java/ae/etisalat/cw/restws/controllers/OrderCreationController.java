package ae.etisalat.cw.restws.controllers;

import org.apache.logging.log4j.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;

import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.restws.service.OrderCreationService;
import ae.etisalat.cw.restws.util.ServicesUtil;

@RestController
@RequestMapping("/")
public class OrderCreationController {
	
	@Autowired
	private OrderCreationService orderCreationService;
	
	@Autowired
	private ServicesUtil util;
    
	@RequestMapping(value = "/createorder", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public JsonObject createOrder(@RequestBody JsonObject orderDetails) throws Exception {
	  CWLog.logMessage(Level.INFO, "createOrder Start :"+orderDetails);
	   String UID = util.getUUID();
	   util.restServiceLogs(orderDetails, UID, UtilConstants.LOG_TYPE_REQUEST,this.getClass());
	   if(orderDetails!=null){
		   orderDetails.addProperty(UtilConstants.UID, UID); 
	   }

		JsonObject orderResponse = orderCreationService.createOrder(orderDetails);
		if(orderResponse!=null){
			orderResponse.addProperty("InternalRefNumber", UID);
		}
	  util.restServiceLogs(orderDetails, UID, UtilConstants.LOG_TYPE_REQUEST,this.getClass());
	  CWLog.logMessage(Level.INFO, "createOrder End :"+orderResponse);
	  return orderResponse;
	}
	
	@RequestMapping(value = "/refresh", method = RequestMethod.GET,consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public JsonObject loadDefaultConfiguration(@RequestBody JsonObject configAttributes) throws Exception {
		
		return orderCreationService.loadDefaultConfiguration(configAttributes);
	}

	@RequestMapping(value = "/test", method = RequestMethod.GET, produces = MediaType.TEXT_PLAIN_VALUE)
	public String testService() throws Exception {
		orderCreationService.loadDefaultConfiguration(new JsonObject());
		return "success";
	}
	


}
