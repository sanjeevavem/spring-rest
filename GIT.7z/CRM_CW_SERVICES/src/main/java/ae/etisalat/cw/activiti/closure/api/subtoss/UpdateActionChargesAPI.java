package ae.etisalat.cw.activiti.closure.api.subtoss;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.apache.logging.log4j.Level;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import ae.etisalat.activiti.core.ActivitiAPI;
import ae.etisalat.cw.comm.util.DateUtils;
import ae.etisalat.cw.comm.util.JSONUtil;
import ae.etisalat.cw.comm.util.Util;
import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.UtilHelper;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.jpa.psm.entities.TPsmMstOnetmChrgType;
import ae.etisalat.cw.jpa.soh.daos.AccountDao;
import ae.etisalat.cw.jpa.soh.daos.AccountTransCreationDao;
import ae.etisalat.cw.jpa.soh.entities.TSohAccount;
import ae.etisalat.cw.jpa.soh.entities.TSohAccountServiceDetail;
import ae.etisalat.cw.jpa.soh.entities.TSohSrtActionService;
import ae.etisalat.cw.jpa.soh.entities.TSohSubrequest;
import ae.etisalat.cw.restws.clients.OrderInfo;
import ae.etisalat.cw.restws.context.SpringApplicationContext;

@Service
public class UpdateActionChargesAPI   extends ActivitiAPI{
	
	private Expression JSON_REQUEST;
	
	protected AccountTransCreationDao accountTransCreationDao;
	protected AccountDao accDao;
	
	@Override
	public void init(DelegateExecution execution) throws Exception {
		accountTransCreationDao = SpringApplicationContext.getApplicationContext().getBean(AccountTransCreationDao.class);
		accDao = SpringApplicationContext.getApplicationContext().getBean(AccountDao.class);
	}

	@Override
	public void run(DelegateExecution execution) throws Exception {
		CWLog.logMessage(Level.INFO, "run Start");
		UtilHelper util = new UtilHelper();
		String jsonStr = (String) util.evalExpr(UtilConstants.JSON_REQUEST,JSON_REQUEST,execution);
		JsonObject json = new Gson().fromJson(jsonStr, JsonObject.class);
		OrderInfo orderInfo = JSONUtil.jsonToObject(jsonStr,"orderInfo",OrderInfo.class);
		TSohAccount tSohAccount    =  execution.getVariable(UtilConstants.accountEntity, TSohAccount.class);
		BigDecimal accountSrvcId = null;BigDecimal rateplanId = null;
		Long subReqId=null;TSohSubrequest subrequest=null;
		Date billCycleStartDate = DateUtils.startDateOfCurrentMonth();
		
		if(orderInfo.getSubRequestId()!=null){
			subReqId=Long.parseLong(orderInfo.getSubRequestId());
			subrequest = accDao.getsubRequestBySubrequestId(subReqId);
		}	
		List<TSohAccountServiceDetail> tSohAccountServiceDetails= accDao.fetchServiceDtlbyAcctId(tSohAccount.getAccountId());
		if(tSohAccountServiceDetails!=null && tSohAccountServiceDetails.size()>0){
			for(TSohAccountServiceDetail accountServiceDetail:tSohAccountServiceDetails){
				if(Util.isValidObject(accountServiceDetail.getIsPrimaryServiceFlag()) && accountServiceDetail.getIsPrimaryServiceFlag().equals("0")){					
					accountSrvcId = BigDecimal.valueOf(accountServiceDetail.getAccountServiceId());
					if(Util.isValidObject(accountServiceDetail.getTSohSubscriptionRateplnDtls()) && accountServiceDetail.getTSohSubscriptionRateplnDtls().size() > 0)										
						rateplanId = accountServiceDetail.getTSohSubscriptionRateplnDtls().get(0).getRatePlanId();
					else
						CWLog.logMessage(Level.ERROR,"Account Service Id ["+accountSrvcId+"] doesn't have Subscription Rateplan details"); 
				}
			}
		}
		if(Util.isValidObject(rateplanId)){
			TPsmMstOnetmChrgType tpsmMstOnetmChrgType = null;
			if(subrequest.getSrtMiscChargeId()!=null){
				BigDecimal srtMiscChargeId = subrequest.getSrtMiscChargeId();
				CWLog.logMessage(Level.INFO,"srtMiscChargeId is ["+srtMiscChargeId+"]"); 
				if(Util.isValidObject(srtMiscChargeId)){
					TSohSrtActionService tSohSrtActionService = accountTransCreationDao.getOneTimeChrgTypeBySrtMiscChrgId(srtMiscChargeId);
					if(Util.isValidObject(tSohSrtActionService)){
						BigDecimal OnetimeCrgTypeId = tSohSrtActionService.getOnetimeCrgTypeId();
						CWLog.logMessage(Level.INFO,"OnetimeCrgTypeId:"+OnetimeCrgTypeId);
						if(Util.isValidObject(OnetimeCrgTypeId)){
							tpsmMstOnetmChrgType = accountTransCreationDao.getOneTimeRate(OnetimeCrgTypeId.longValue());
							CWLog.logMessage(Level.INFO, "tpsmMstOnetmChrgType is ["+tpsmMstOnetmChrgType+"]"); 
							if(Util.isValidObject(tpsmMstOnetmChrgType)){
								Long chargeTypeId = tpsmMstOnetmChrgType.getId().getOnetimeChargeTypeId();
								BigDecimal transactionAmount = tpsmMstOnetmChrgType.getRate();
								CWLog.logMessage(Level.INFO,"got action charge "+transactionAmount+" chargeTypeId "+chargeTypeId);								
								boolean recordsUpdated = accountTransCreationDao.addBillTransaction(tSohAccount, accountSrvcId.longValue(),
		                    			tSohAccount.getBillCycleId().longValue(), billCycleStartDate, chargeTypeId, tSohAccount.getCreatedUserId(), null, rateplanId.longValue(),
		                    			orderInfo.getSubRequestId(), transactionAmount, "One Time", null, null,true, null);
								CWLog.logMessage(Level.INFO, "PostBill records updated: " + recordsUpdated);
							}
						}
					}
				}
			}
		}
	  execution.setVariable(UtilConstants.ACTIVITI_API_CTX, json.toString());
	  CWLog.logMessage(Level.INFO,"" + this.getClass() + "run end, output {}", "");
	}
}
