
package ae.etisalat.cw.restws.integration;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "additionalParameters", "action", "partySegmentValueId", "segmentValueId", "profileId", "partyId", "segmentCode",
        "effectiveFromDate", "effectiveTillDate"})
public class Segment {

    @JsonProperty("additionalParameters")
    private List<AdditionalParameter> additionalParameters = new ArrayList<AdditionalParameter>();
    @JsonProperty("action")
    private String action;
    @JsonProperty("partySegmentValueId")
    private Long partySegmentValueId;
    @JsonProperty("segmentValueId")
    private Long segmentValueId;
    @JsonProperty("profileId")
    private Long profileId;
    @JsonProperty("partyId")
    private Long partyId;
    @JsonProperty("segmentCode")
    private String segmentCode;
    @JsonProperty("effectiveFromDate")
    private Date effectiveFromDate;
    @JsonProperty("effectiveTillDate")
    private Date effectiveTillDate;

    @JsonProperty("additionalParameters")
    public List<AdditionalParameter> getAdditionalParameters() {
        return additionalParameters;
    }

    @JsonProperty("additionalParameters")
    public void setAdditionalParameters(List<AdditionalParameter> additionalParameters) {
        this.additionalParameters = additionalParameters;
    }

    public Segment withAdditionalParameters(List<AdditionalParameter> additionalParameters) {
        this.additionalParameters = additionalParameters;
        return this;
    }

    @JsonProperty("action")
    public String getAction() {
        return action;
    }

    @JsonProperty("action")
    public void setAction(String action) {
        this.action = action;
    }

    public Segment withAction(String action) {
        this.action = action;
        return this;
    }
    @JsonProperty("segmentValueId")
    public Long getSegmentValueId() {
        return segmentValueId;
    }

    @JsonProperty("segmentValueId")
    public void setSegmentValueId(Long segmentValueId) {
        this.segmentValueId = segmentValueId;
    }

    public Segment withSegmentValueId(Long segmentValueId) {
        this.segmentValueId = segmentValueId;
        return this;
    }

    @JsonProperty("profileId")
    public Long getProfileId() {
        return profileId;
    }

    @JsonProperty("profileId")
    public void setProfileId(Long profileId) {
        this.profileId = profileId;
    }

    public Segment withProfileId(Long profileId) {
        this.profileId = profileId;
        return this;
    }

    @JsonProperty("partyId")
    public Long getPartyId() {
        return partyId;
    }

    @JsonProperty("partyId")
    public void setPartyId(Long partyId) {
        this.partyId = partyId;
    }

    public Segment withPartyId(Long partyId) {
        this.partyId = partyId;
        return this;
    }
    @JsonProperty("segmentCode")
    public String getSegmentCode() {
        return segmentCode;
    }

    @JsonProperty("segmentCode")
    public void setSegmentCode(String segmentCode) {
        this.segmentCode = segmentCode;
    }

    public Segment withSegmentCode(String segmentCode) {
        this.segmentCode = segmentCode;
        return this;
    }

    @JsonProperty("partySegmentValueId")
    public Long getPartySegmentValueId() {
		return partySegmentValueId;
	}

    @JsonProperty("partySegmentValueId")
	public void setPartySegmentValueId(Long partySegmentValueId) {
		this.partySegmentValueId = partySegmentValueId;
	}

    @JsonProperty("effectiveFromDate")
	public Date getEffectiveFromDate() {
		return effectiveFromDate;
	}

    @JsonProperty("effectiveFromDate")
	public void setEffectiveFromDate(Date effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}

    @JsonProperty("effectiveTillDate")
	public Date getEffectiveTillDate() {
		return effectiveTillDate;
	}
    
    @JsonProperty("effectiveTillDate")
	public void setEffectiveTillDate(Date effectiveTillDate) {
		this.effectiveTillDate = effectiveTillDate;
	}

	@Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((action == null) ? 0 : action.hashCode());
		result = prime
				* result
				+ ((additionalParameters == null) ? 0 : additionalParameters
						.hashCode());
		result = prime
				* result
				+ ((effectiveFromDate == null) ? 0 : effectiveFromDate
						.hashCode());
		result = prime
				* result
				+ ((effectiveTillDate == null) ? 0 : effectiveTillDate
						.hashCode());
		result = prime * result + ((partyId == null) ? 0 : partyId.hashCode());
		result = prime
				* result
				+ ((partySegmentValueId == null) ? 0 : partySegmentValueId
						.hashCode());
		result = prime * result
				+ ((profileId == null) ? 0 : profileId.hashCode());
		result = prime * result
				+ ((segmentCode == null) ? 0 : segmentCode.hashCode());
		result = prime * result
				+ ((segmentValueId == null) ? 0 : segmentValueId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Segment other = (Segment) obj;
		if (action == null) {
			if (other.action != null)
				return false;
		} else if (!action.equals(other.action))
			return false;
		if (additionalParameters == null) {
			if (other.additionalParameters != null)
				return false;
		} else if (!additionalParameters.equals(other.additionalParameters))
			return false;
		if (effectiveFromDate == null) {
			if (other.effectiveFromDate != null)
				return false;
		} else if (!effectiveFromDate.equals(other.effectiveFromDate))
			return false;
		if (effectiveTillDate == null) {
			if (other.effectiveTillDate != null)
				return false;
		} else if (!effectiveTillDate.equals(other.effectiveTillDate))
			return false;
		if (partyId == null) {
			if (other.partyId != null)
				return false;
		} else if (!partyId.equals(other.partyId))
			return false;
		if (partySegmentValueId == null) {
			if (other.partySegmentValueId != null)
				return false;
		} else if (!partySegmentValueId.equals(other.partySegmentValueId))
			return false;
		if (profileId == null) {
			if (other.profileId != null)
				return false;
		} else if (!profileId.equals(other.profileId))
			return false;
		if (segmentCode == null) {
			if (other.segmentCode != null)
				return false;
		} else if (!segmentCode.equals(other.segmentCode))
			return false;
		if (segmentValueId == null) {
			if (other.segmentValueId != null)
				return false;
		} else if (!segmentValueId.equals(other.segmentValueId))
			return false;
		return true;
	}

   

}
