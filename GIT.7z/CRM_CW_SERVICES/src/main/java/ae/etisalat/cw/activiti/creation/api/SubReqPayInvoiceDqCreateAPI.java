package ae.etisalat.cw.activiti.creation.api;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.apache.logging.log4j.Level;

import ae.etisalat.activiti.core.ActivitiAPI;
import ae.etisalat.crmgw.util.JsonSearchConstants;
import ae.etisalat.cw.comm.util.JSONUtil;
import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.UtilHelper;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.jpa.soh.daos.SubReqCreationDao;
import ae.etisalat.cw.jpa.soh.entities.TSohRequest;
import ae.etisalat.cw.jpa.soh.entities.TSohSubrequest;
import ae.etisalat.cw.restws.clients.OrderInfo;
import ae.etisalat.cw.restws.clients.ServiceRegistry;
import ae.etisalat.cw.restws.context.SpringApplicationContext;

public class SubReqPayInvoiceDqCreateAPI  extends ActivitiAPI{

	private Expression JSON_REQUEST;
	protected SubReqCreationDao subReqCreation;

	@Override
	public void init(DelegateExecution execution) throws Exception {
		subReqCreation = SpringApplicationContext.getApplicationContext().getBean(SubReqCreationDao.class);
	}

	@Override
	public void run(DelegateExecution execution) throws Exception {
		CWLog.logMessage(Level.INFO, "run Start");
		UtilHelper util = new UtilHelper();
		String jsonStr = (String) util.evalExpr(UtilConstants.JSON_REQUEST,JSON_REQUEST,execution);
		OrderInfo orderInfo = JSONUtil.jsonToObject(jsonStr,"orderInfo",OrderInfo.class);
		ServiceRegistry srvRegistry = JSONUtil.jsonToObject(jsonStr,JsonSearchConstants.srvRegistryQry,ServiceRegistry.class);
		TSohRequest request    =  execution.getVariable(UtilConstants.requestEntity, TSohRequest.class);
		TSohSubrequest subRequest    =  execution.getVariable(UtilConstants.subRequestEntity, TSohSubrequest.class);
		subReqCreation.createInvoiceInfo(srvRegistry.getInvoiceDetails(), subRequest,orderInfo,srvRegistry.getAccountInfo(),request);
		subReqCreation.createPaymentInfo(srvRegistry.getPaymentTypeInfo(), subRequest,srvRegistry.getAccountInfo());
		subReqCreation.createDqInfo(srvRegistry.getDqResellerInfo(), subRequest,srvRegistry.getAccountInfo());
		CWLog.logMessage(Level.INFO,"" + this.getClass() + "run end, output {}", "");
	}

}
