package ae.etisalat.cw.restws.service.partyProfileManagement;

import ae.etisalat.cw.restws.integration.PartyProfileManageRequest;

import com.google.gson.JsonObject;

public interface PartyProfileManageService {

	public JsonObject createUpdatePartyProfile(PartyProfileManageRequest partyProfDetails) throws Exception;
}
