package ae.etisalat.cw.restws.integration;

import java.util.List;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class ChannelInfo {

    @NotNull
    private String channelName;
    @NotNull
    private String subchannel;
    private String originatingApplication;
    private String channelOrderReference;
    private List<AdditionalInformation> additionalInfo;

    
    public String getChannelName() {
        return channelName;
    }

    
    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public ChannelInfo withChannelName(String channelName) {
        this.channelName = channelName;
        return this;
    }

    
    public String getSubchannel() {
        return subchannel;
    }

    
    public void setSubchannel(String subchannel) {
        this.subchannel = subchannel;
    }

    public ChannelInfo withSubchannel(String subchannel) {
        this.subchannel = subchannel;
        return this;
    }

    
    public String getOriginatingApplication() {
        return originatingApplication;
    }

    
    public void setOriginatingApplication(String originatingApplication) {
        this.originatingApplication = originatingApplication;
    }

    public ChannelInfo withOriginatingApplication(String originatingApplication) {
        this.originatingApplication = originatingApplication;
        return this;
    }
    
	public String getChannelOrderReference() {
		return channelOrderReference;
	}


	public void setChannelOrderReference(String channelOrderReference) {
		this.channelOrderReference = channelOrderReference;
	}
	
	public ChannelInfo withChannelOrderReference(String channelOrderReference) {
        this.channelOrderReference = channelOrderReference;
        return this;
    }

    
    public List<AdditionalInformation> getAdditionalInfo() {
        return additionalInfo;
    }

    
    public void setAdditionalInfo(List<AdditionalInformation> additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public ChannelInfo withAdditionalInfo(List<AdditionalInformation> additionalInfo) {
        this.additionalInfo = additionalInfo;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(channelName).append(subchannel).append(originatingApplication).append(channelOrderReference).append(additionalInfo).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ChannelInfo) == false) {
            return false;
        }
        ChannelInfo rhs = ((ChannelInfo) other);
        return new EqualsBuilder().append(channelName, rhs.channelName).append(subchannel, rhs.subchannel).append(originatingApplication, rhs.originatingApplication)
        		.append(channelOrderReference, rhs.channelOrderReference).append(additionalInfo, rhs.additionalInfo).isEquals();
    }
}
