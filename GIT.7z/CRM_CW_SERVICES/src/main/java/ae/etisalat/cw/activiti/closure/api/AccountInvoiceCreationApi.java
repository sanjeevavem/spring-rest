package ae.etisalat.cw.activiti.closure.api;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.apache.logging.log4j.Level;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import ae.etisalat.activiti.core.ActivitiAPI;
import ae.etisalat.crmgw.util.JsonSearchConstants;
import ae.etisalat.cw.comm.util.JSONUtil;
import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.UtilHelper;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.jpa.soh.daos.AccountInvoiceInfoDao;
import ae.etisalat.cw.jpa.soh.entities.TSohAccount;
import ae.etisalat.cw.restws.clients.OrderInfo;
import ae.etisalat.cw.restws.clients.ServiceRegistry;
import ae.etisalat.cw.restws.context.SpringApplicationContext;

@Service
public class AccountInvoiceCreationApi  extends ActivitiAPI{
	
	private Expression JSON_REQUEST;
	
	protected AccountInvoiceInfoDao accountInvoiceInfoDao;

	@Override
	public void init(DelegateExecution execution) throws Exception {
		accountInvoiceInfoDao = SpringApplicationContext.getApplicationContext().getBean(AccountInvoiceInfoDao.class);		
	}
	
	@Override
	public void run(DelegateExecution execution) throws Exception {
		CWLog.logMessage(Level.INFO, "run Start");
		UtilHelper util = new UtilHelper();
		String jsonStr = (String) util.evalExpr(UtilConstants.JSON_REQUEST,JSON_REQUEST,execution);
		JsonObject json = new Gson().fromJson(jsonStr, JsonObject.class);
		ServiceRegistry srRegistry = JSONUtil.jsonToObject(jsonStr,JsonSearchConstants.srvRegistryQry,ServiceRegistry.class);
		OrderInfo orderInfo = JSONUtil.jsonToObject(jsonStr,JsonSearchConstants.orderInfoQry,OrderInfo.class);
		TSohAccount tSohAccount    =  execution.getVariable(UtilConstants.accountEntity, TSohAccount.class);
		Long subReqId=null;
		if(orderInfo.getSubRequestId()!=null)
			subReqId=Long.parseLong(orderInfo.getSubRequestId());
		boolean done = accountInvoiceInfoDao.processInvoiceInfo(tSohAccount, subReqId,srRegistry.getInvoiceDetails());
		execution.setVariable(UtilConstants.accInvPersistStatus, done);
		execution.setVariable(UtilConstants.ACTIVITI_API_CTX, json.toString());
		CWLog.logMessage(Level.INFO,"" + this.getClass() + "run end, output {}", "");
	}
	

}
