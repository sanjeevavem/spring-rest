package ae.etisalat.cw.activiti.creation.api;

import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.apache.logging.log4j.Level;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import ae.etisalat.activiti.core.ActivitiAPI;
import ae.etisalat.crmgw.util.JsonSearchConstants;
import ae.etisalat.cw.comm.util.JSONUtil;
import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.UtilHelper;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.jpa.soh.daos.PkgRpAcctSrvcInstMapping;
import ae.etisalat.cw.jpa.soh.daos.SubReqCreationDao;
import ae.etisalat.cw.jpa.soh.entities.TSohCustRequirement;
import ae.etisalat.cw.jpa.soh.entities.TSohRequest;
import ae.etisalat.cw.jpa.soh.entities.TSohRequirement;
import ae.etisalat.cw.jpa.soh.entities.TSohSubrequest;
import ae.etisalat.cw.restws.clients.OfferingDetailsList;
import ae.etisalat.cw.restws.clients.ServiceRegistry;
import ae.etisalat.cw.restws.context.SpringApplicationContext;

public class SubReqSrvcInstCreationAPI  extends ActivitiAPI{
	
	private Expression JSON_REQUEST;
	protected SubReqCreationDao subReqCreation;

	@Override
	public void init(DelegateExecution execution) throws Exception {
		subReqCreation = SpringApplicationContext.getApplicationContext().getBean(SubReqCreationDao.class);
	}

	@Override
	public void run(DelegateExecution execution) throws Exception {
		CWLog.logMessage(Level.INFO, "run Start");
		UtilHelper util = new UtilHelper();
		String jsonStr = (String) util.evalExpr(UtilConstants.JSON_REQUEST,JSON_REQUEST,execution);
		JsonObject json = new Gson().fromJson(jsonStr, JsonObject.class);
		ServiceRegistry srvRegistry = JSONUtil.jsonToObject(jsonStr,JsonSearchConstants.srvRegistryQry,ServiceRegistry.class);
		List<OfferingDetailsList> offeringDetailsLists = srvRegistry.getOfferingDetailsList();
		TSohRequest request    =  execution.getVariable(UtilConstants.requestEntity, TSohRequest.class);
		TSohSubrequest subRequest    =  execution.getVariable(UtilConstants.subRequestEntity, TSohSubrequest.class);
		TSohRequirement requirement    =  execution.getVariable(UtilConstants.requirementEntity, TSohRequirement.class);
		List<PkgRpAcctSrvcInstMapping> subReqSrvcDtls=subReqCreation.createServiceDtls(subRequest,requirement,request,offeringDetailsLists);
		TSohCustRequirement custRequirement=new TSohCustRequirement();
		for (PkgRpAcctSrvcInstMapping pkgRp : subReqSrvcDtls) {
			if (pkgRp.getSrvcCategoryId() == 9) {
				 custRequirement=subReqCreation.createCustRequirement(request,requirement,pkgRp,subRequest);
			}

		}
		execution.setVariable(UtilConstants.custRequirementEntity, custRequirement);
		execution.setVariable(UtilConstants.subReqSrvInstDtl, subReqSrvcDtls);
		execution.setVariable(UtilConstants.requestEntity, request);
		execution.setVariable(UtilConstants.ACTIVITI_API_CTX, json.toString());
		CWLog.logMessage(Level.INFO,"" + this.getClass() + "run end, output {}", "");
	}

}
