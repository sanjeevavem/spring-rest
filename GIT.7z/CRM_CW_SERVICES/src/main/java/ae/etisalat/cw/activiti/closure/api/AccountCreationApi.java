package ae.etisalat.cw.activiti.closure.api;

import java.math.BigDecimal;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.apache.logging.log4j.Level;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import ae.etisalat.activiti.core.ActivitiAPI;
import ae.etisalat.crmgw.util.JsonSearchConstants;
import ae.etisalat.cw.comm.util.JSONUtil;
import ae.etisalat.cw.comm.util.Util;
import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.UtilHelper;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.jpa.soh.daos.AccountCreationDao;
import ae.etisalat.cw.jpa.soh.entities.TSohAccAccountNumber;
import ae.etisalat.cw.jpa.soh.entities.TSohAccount;
import ae.etisalat.cw.jpa.soh.entities.TSohTestEntity;
import ae.etisalat.cw.restws.clients.OrderInfo;
import ae.etisalat.cw.restws.clients.ServiceRegistry;
import ae.etisalat.cw.restws.context.SpringApplicationContext;

@Service
public class AccountCreationApi extends ActivitiAPI {
	
	 private Expression JSON_REQUEST;
	 protected AccountCreationDao accDao;

	@Override
	public void init(DelegateExecution execution) throws Exception {
		
		accDao = SpringApplicationContext.getApplicationContext().getBean(AccountCreationDao.class);

	}

	@Override	
	public void run(DelegateExecution execution) throws Exception {
		
		CWLog.logMessage(Level.INFO, "run Start");
		UtilHelper util = new UtilHelper();
		String jsonStr = (String) util.evalExpr(UtilConstants.JSON_REQUEST,JSON_REQUEST,execution);
		JsonObject json = new Gson().fromJson(jsonStr, JsonObject.class);
		ServiceRegistry srRegistry = JSONUtil.jsonToObject(jsonStr,JsonSearchConstants.srvRegistryQry,ServiceRegistry.class);
		OrderInfo orderInfo = JSONUtil.jsonToObject(jsonStr,JsonSearchConstants.orderInfoQry,OrderInfo.class);
		

		AccountDetail accDtl = new AccountDetail();
		
		//Check account status
		Long accountNumber = Long.valueOf(srRegistry.getAccountInfo().getAccountNumber());
		long srId = 0l; //To be discussed
        boolean isAccExist = accDao.isExistingAccount(""+accountNumber, srId);
        if (isAccExist) {
            //failure
        }
        TSohAccAccountNumber tSohAccAccountNumber = accDao.getAccountInfo(""+accountNumber);
        if (Util.isValidObject(tSohAccAccountNumber)) {
            TSohAccount tSohAccount = tSohAccAccountNumber.getTSohAccount();
            if (null != tSohAccount && tSohAccount.getAccountStatusId() == new BigDecimal(1))
            {
                //fail already active
            }
        }
        TSohAccount tSohAccount =accDao.createAccount( srRegistry,orderInfo.getUserId(),orderInfo);

        String partyId = orderInfo.getPartyId();
        if (partyId != null && !"".equals(partyId.trim())) {
            TSohTestEntity tSohTestEntity = accDao.isValidTestAccount(partyId);
            if (tSohTestEntity != null) {
                accDao.insertTestAccount(""+accDtl.getAccountId(), orderInfo.getUserId());
            }
        }
	
//		if(output!=null && output.get("SUBREQUEST_ID")!=null){
//		  execution.setVariable("output_SubRequestId", output.get("SUBREQUEST_ID"));
//		  json.addProperty("output_SubRequestId", output.get("SUBREQUEST_ID").toString());
//		}
//		if(output!=null && output.get("REQUEST_ID")!=null){
//		  execution.setVariable("output_RequestId", output.get("REQUEST_ID"));
//		  json.addProperty("output_RequestId", output.get("REQUEST_ID").toString());
//		}
      execution.setVariable(UtilConstants.accountEntity, tSohAccount);
	  execution.setVariable(UtilConstants.JSON_RESPONSE,json.toString());  // need to remove
	  execution.setVariable(UtilConstants.ACTIVITI_API_CTX, json.toString());
	  CWLog.logMessage(Level.INFO,"" + this.getClass() + "run end, output {}", "");
	}
	
}
