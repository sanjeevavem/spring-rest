package ae.etisalat.cw.restws.service;

import com.google.gson.JsonObject;

public interface OrderStatusUpdateService {
	public JsonObject orderStatusUpdate(JsonObject orderRequest) throws Exception;
}
