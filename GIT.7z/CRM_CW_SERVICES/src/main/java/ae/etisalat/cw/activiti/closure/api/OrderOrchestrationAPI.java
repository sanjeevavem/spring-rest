package ae.etisalat.cw.activiti.closure.api;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.logging.log4j.Level;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;
import com.jayway.jsonpath.spi.json.GsonJsonProvider;
import com.jayway.jsonpath.spi.json.JsonProvider;
import com.jayway.jsonpath.spi.mapper.GsonMappingProvider;
import com.jayway.jsonpath.spi.mapper.MappingProvider;

import ae.etisalat.activiti.core.ActivitiAPI;
import ae.etisalat.cw.comm.util.JSONUtil;
import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.UtilHelper;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.restws.jpa.entities.CwMstFlowMap;

public class OrderOrchestrationAPI extends ActivitiAPI {

	
	@Override
	public void init(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void run(DelegateExecution execution) throws Exception {
		CWLog.logMessage(Level.INFO, "run Start");

		UtilHelper util = new UtilHelper();
		String jsonStr = (String)execution.getVariable("JSON_RESPONSE");
		JsonObject json = new Gson().fromJson(jsonStr, JsonObject.class);
		HashMap<String, Object> map = JSONUtil.convertJSONToMap(json);
		
		
		// jsonpath
		  Configuration.setDefaults(new Configuration.Defaults() {
		    private final JsonProvider jsonProvider = new GsonJsonProvider();
		    private final MappingProvider mappingProvider = new GsonMappingProvider();

		    @Override
		    public JsonProvider jsonProvider() {
		        return jsonProvider;
		    }

		    @Override
		    public MappingProvider mappingProvider() {
		        return mappingProvider;
		    }

		    @Override
		    public Set<Option> options() {
		        return EnumSet.noneOf(Option.class);
		    }
		});
		   Map<String, Object> book = JsonPath.read(json, "$.criteria");
		   System.out.println(book);
		   
		// validate the order details
		JsonObject ordeOrDetails = json.get("orderDetails").getAsJsonObject();
		JsonArray jsonArray = ordeOrDetails.get("offer_code").getAsJsonArray();
		StringBuilder offerCodes = new StringBuilder();
		for(JsonElement value : jsonArray){
		   if(offerCodes.length()>0) {
			   offerCodes.append(",");
			 }
		   offerCodes.append("'"+value.getAsJsonObject().get("offer_code").getAsString()+"'");
		    
		   System.out.println("value"+value);
		   System.out.println("value array"+value.getAsJsonObject().get("offer_attributes").getAsJsonArray());
		}
		
		// Find Sub flows
		 JsonObject  jsonObject = json.getAsJsonObject("criteria");
		 HashMap<String, Object> inMap= new HashMap<String, Object>();
		 inMap.put("ProductGroup", jsonObject.get("ProductGroup").getAsString());
		 inMap.put("Account_Number", jsonObject.get("Account_Number").getAsString());
		 inMap.put("Product", jsonObject.get("Product").getAsString());
		 inMap.put("Ordertype", jsonObject.get("Ordertype").getAsString());
		 inMap.put("OfferType", jsonObject.get("OfferType").getAsString());
		 inMap.put("OfferCode", jsonObject.get("OfferCode").getAsString());
		 inMap.put("OFFER_CODES", offerCodes);
		 inMap.put("OFFER_TYPE", UtilConstants.OFFER_TYPE_RATEPLAN);

		 List<CwMstFlowMap> flowList = activitiUtil.findProductSubFlow(inMap);
		
	     Map<String, Object> outputVaribales = activitiEngine.executeWorkflow("Generic_Service_Process", new HashMap<String,Object>());

	     CWLog.logMessage(Level.INFO, "run() end"+outputVaribales);
	}

}
