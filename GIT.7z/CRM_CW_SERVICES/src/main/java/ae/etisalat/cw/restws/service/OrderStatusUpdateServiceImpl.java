package ae.etisalat.cw.restws.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;

import ae.etisalat.activiti.core.ActivitiEngine;
import ae.etisalat.activiti.core.ActivitiUtil;
import ae.etisalat.cw.comm.util.JSONUtil;
import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.restws.jpa.entities.CwMstFlowMap;
import ae.etisalat.cw.restws.util.ServicesUtil;

@Service
public class OrderStatusUpdateServiceImpl implements OrderStatusUpdateService {

	@Autowired
	private JSONUtil util;
	
	@Autowired
	private ServicesUtil servicesUtil;
	
	@Autowired
	private ActivitiEngine activitiEngine;
	
	@Autowired
	private ActivitiUtil activitiUtil;
	
	@Override
	public JsonObject orderStatusUpdate(JsonObject orderRequest) throws Exception {
      CWLog.logMessage(Level.INFO, "orderStatusUpdate Start");
      Map<String, Object> outputVaribales = null;
	   String referenceNumber = null;
	   String UID = null;
	   
	  JsonObject responseJson = new JsonObject();
	  
	  try
	   {
		 referenceNumber = JSONUtil.getJSONValueByKey(orderRequest.toString(), "$.orderInfo.transactionId");
		 UID = orderRequest.get(UtilConstants.UID).toString();
		 responseJson.addProperty(UtilConstants.REF_NUMBER, referenceNumber);
		 responseJson.addProperty(UtilConstants.UID, UID);
		 
	  	} catch (Exception e) {
	  	  CWLog.logMessage(Level.ERROR, "Exception Message is : "+e.getMessage(),e);
	  	 return servicesUtil.errorRespone(UtilConstants.INVALID_REQUEST, UtilConstants.INVALID_REQUEST_MSG,referenceNumber,UID);
	  	}	  
	  
       Map<String, Object> criteriaMap = new HashMap<String, Object>();
       criteriaMap.put("ORDER_TYPE", "CLOSESR");
       criteriaMap.put("FLOW_TYPE", "MAIN");
       criteriaMap.put("PRODUCT_GROUP","CLOSESR");
       criteriaMap.put("PRODUCT","CLOSESR");
      

	  try 
		{
		  CwMstFlowMap cwMstFlowMap = activitiUtil.findProductFlow(criteriaMap); 

		  if(cwMstFlowMap== null || cwMstFlowMap.getFlowCode()==null){
		     return servicesUtil.errorRespone(UtilConstants.NO_FLOW_REQUEST,UtilConstants.NO_FLOW_REQUEST_MSG,referenceNumber,UID); 
		   }
		  
		  activitiUtil.executeValidationAPI(cwMstFlowMap,orderRequest);
		    criteriaMap.put("JSON_REQUEST", orderRequest.toString());  
		    criteriaMap.put("JSON_WORKFLOW_CONTEXT", "");
	       outputVaribales = activitiEngine.executeWorkflow(cwMstFlowMap.getFlowCode(), criteriaMap);
	       CWLog.logMessage(Level.INFO,"outputVaribales"+outputVaribales);
	       CWLog.logMessage(Level.DEBUG,"outputVaribales"+outputVaribales);
	   	 } catch (Exception e) {
	   	    CWLog.logMessage(Level.ERROR, "Exception Message is : "+e.getMessage(),e);
	    	return servicesUtil.errorRespone(UtilConstants.INVALID_REQUEST, UtilConstants.INVALID_REQUEST_MSG,referenceNumber,UID);
	 	}
      
     // Set the variables to JSON object 
	  if(outputVaribales!=null && outputVaribales.get("output_RequestId")!=null){
		  responseJson.addProperty("RequestId", outputVaribales.get("output_RequestId").toString());  
	  }
      CWLog.logMessage(Level.INFO, "orderStatusUpdate End");
     return responseJson;
	}

}
