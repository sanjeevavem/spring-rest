package ae.etisalat.cw.restws.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import ae.etisalat.activiti.core.ActivitiEngine;
import ae.etisalat.activiti.core.ActivitiUtil;
import ae.etisalat.cw.comm.util.JSONUtil;
import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.json.OfferDetails;
import ae.etisalat.cw.comm.util.json.OrderDetails;
import ae.etisalat.cw.comm.util.json.SubOrderDetails;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.restws.dao.generic.DataSourceType;
import ae.etisalat.cw.restws.dao.generic.GenericOrderCreationDAO;
import ae.etisalat.cw.restws.jpa.entities.CwMstFlowMap;
import ae.etisalat.cw.restws.util.ServicesUtil;

@Service
public class OrderCreationServiceImpl implements OrderCreationService {

	private static final Logger logger = LogManager.getLogger(OrderCreationServiceImpl.class);
	
	@Value("${cbcm.soh.insert.CW_ORDER_AUDIT}")
	private String cwOrderAudit;
	
	@Autowired
	private JSONUtil util;
	
	@Autowired
	private ServicesUtil servicesUtil;
	
	@Autowired
	private ActivitiEngine activitiEngine;
	
	@Autowired
	private ActivitiUtil activitiUtil;
    
    @Autowired(required=true)
    private GenericOrderCreationDAO genericOrderCreationDAO;
    

    
	public JsonObject createOrder(JsonObject orderRequest) {
	  CWLog.logMessage(Level.INFO, "createOrder Start"+orderRequest.toString());	
	  /**
	   *  1. validate
	   *  2. fetch input criteria
	   *  3. invoke the Activiti flow
	   *  4. prepare the response and handle the error if any issue
	   */
	   Map<String, Object> outputVaribales = null;
	   HashMap<String, Object> criteriaMap = null;
	   String referenceNumber = null;
	   String UID = null;
	   
	  JsonObject responseJson = new JsonObject();
	  try
	   {
		 referenceNumber = JSONUtil.getJSONValueByKey(orderRequest.toString(), "$.requestDetails.ReferenceNumber");
		 UID = orderRequest.get(UtilConstants.UID).toString();
		 responseJson.addProperty(UtilConstants.REF_NUMBER, referenceNumber);
		 responseJson.addProperty(UtilConstants.UID, UID);
		 criteriaMap = servicesUtil.getRequestCriteria(orderRequest, null);
		 
	  	} catch (Exception e) {
	  	  CWLog.logMessage(Level.ERROR, "Exception Message is : "+e.getMessage(),e);
	  	// return errorRespone(UtilConstants.INVALID_REQUEST, UtilConstants.INVALID_REQUEST_MSG,referenceNumber,UID);
	  	}
	  
	  try 
		{
		  
		 CwMstFlowMap cwMstFlowMap = activitiUtil.findProductFlow(criteriaMap);
		  if(cwMstFlowMap==null || cwMstFlowMap.getFlowCode()==null){
		     return errorRespone(UtilConstants.NO_FLOW_REQUEST,UtilConstants.NO_FLOW_REQUEST_MSG,referenceNumber,UID); 
		   }
	      // add other attributes to the criteriaMap
		    criteriaMap.put("JSON_REQUEST", orderRequest.toString());  
		    criteriaMap.put("JSON_WORKFLOW_CONTEXT", "");
	       outputVaribales = activitiEngine.executeWorkflow(cwMstFlowMap.getFlowCode(), criteriaMap);
	      logger.info("outputVaribales",outputVaribales);
	      logger.debug("outputVaribales",outputVaribales);
	   	 } catch (Exception e) {
	   	    CWLog.logMessage(Level.ERROR, "Exception Message is : "+e.getMessage(),e);
	    	return errorRespone(UtilConstants.INVALID_REQUEST, UtilConstants.INVALID_REQUEST_MSG,referenceNumber,UID);
	 	}
      
     // Set the variables to JSON object 
	  if(outputVaribales!=null && outputVaribales.get("output_RequestId")!=null){
		  responseJson.addProperty("RequestId", outputVaribales.get("output_RequestId").toString());  
	  }
	  CWLog.logMessage(Level.INFO, "createOrder End"+responseJson);	
	 return responseJson;
	}
	

	private JsonObject errorRespone(String errorCode,String errorDesc,String referenceNumber,String UID) {
	  JsonObject jsonObject = new JsonObject();
	  jsonObject.addProperty("errorCode", errorCode);
	  jsonObject.addProperty("errorDesc", errorDesc);
	  jsonObject.addProperty("ReferenceNumber", referenceNumber);
	  jsonObject.addProperty("InternalRefNumber", UID);
	 return jsonObject;
	}


	@Override
	@Transactional
	public JsonObject loadDefaultConfiguration(JsonObject orderRequest) throws Exception {
		logger.info(""+ this.getClass(), "loadDefaultConfiguration Start"+orderRequest.toString());	
		JsonObject jsonObject = new JsonObject();
		try
		 {
			activitiEngine.loadBPMNFiles();
			jsonObject.addProperty("RESPONSE_MSG", "success");			
		 }catch(Exception e){
			jsonObject.addProperty("RESPONSE_MSG", "Error");	
		}
		logger.info(""+ this.getClass(), "loadDefaultConfiguration End"+orderRequest.toString());		
		return new JsonObject();
	}
	
	/**
	 *  Generic API Testing Start
	 */
	
	private JsonObject test(JsonObject orderRequest) throws Exception{

		  CWLog.logMessage(Level.INFO, "test Start"+orderRequest.toString());	
		  
		  JsonObject  requestDetails = orderRequest.getAsJsonObject("requestDetails");
	      HashMap<String, Object> map = new HashMap<String, Object>();// util.getMapFromJson(orderRequest);
	      map.put(UtilConstants.JSON_REQUEST, orderRequest.toString());
	     
	      /*
	       * Generic API testing
	       */
	      OrderDetails orderDetails = new OrderDetails();
	      orderDetails.setOrderId(""+91328953);
	      orderDetails.setChannel("DirectChannel");
	      orderDetails.setSubChannel("CL");
	      
	      SubOrderDetails subOrderDetailsArray[] = new SubOrderDetails[2]; // need to check how to set the size and convert to the generic list
	      SubOrderDetails subOrderDetails = new SubOrderDetails();
	      subOrderDetails.setSubOrderId(""+175811734);
	      subOrderDetails.setProductGroup("BL");
	      subOrderDetails.setProduct("BFXI");
	      subOrderDetails.setAccountId("123234456");
	      subOrderDetails.setAccountNumber("042025918");
	      
	      OfferDetails offerDetailsArray[] = new OfferDetails[1];
	      OfferDetails offerDetails = new OfferDetails();
	      offerDetails.setOfferType("R");
	      offerDetails.setOfferCode("RP15003");
	      offerDetailsArray[0]=offerDetails;
	      subOrderDetails.setOfferDetails(offerDetailsArray);
	      subOrderDetailsArray[0]=subOrderDetails;
	      
	      
	      SubOrderDetails subOrderDetails1 = new SubOrderDetails();
	      subOrderDetails1.setSubOrderId(""+175811734);
	      subOrderDetails1.setProductGroup("BL");
	      subOrderDetails1.setProduct("BFXI");
	      subOrderDetails1.setAccountId("123234456");
	      subOrderDetails1.setAccountNumber("042025918");
	      
	      OfferDetails offerDetailsArray1[] = new OfferDetails[1];
	      OfferDetails offerDetails1 = new OfferDetails();
	      offerDetails1.setOfferType("R");
	      offerDetails1.setOfferCode("RP15004");
	      offerDetailsArray1[0]=offerDetails1;
	      subOrderDetails1.setOfferDetails(offerDetailsArray1);
	      subOrderDetailsArray[1]=subOrderDetails1;
	      
	      orderDetails.setSubOrderDetails(subOrderDetailsArray);
	      
	      Gson gson = new Gson();
	      JsonElement element = gson.toJsonTree(orderDetails,OrderDetails.class);
	      JsonObject jsonObjectAPI = element!=null ? element.getAsJsonObject() :  new JsonObject();
	      JsonObject jsonObject1 = new JsonObject();
	      jsonObject1.add(UtilConstants.ACTIVITI_REQ_JSON, jsonObjectAPI);
	      orderRequest.add("ACTIVITI_API_CONTEXT", jsonObject1);
	      map.put(UtilConstants.JSON_REQUEST, orderRequest.toString());
	      
	      Map<String, Object> outputVaribales = activitiEngine.executeWorkflow("TestProcess", map);
	      logger.info("outputVaribales :",outputVaribales);
	      logger.debug("outputVaribales :",outputVaribales);
	      
//	      genericDBQueryAPI.execute(map, new HashMap<String, Object>());
//	      logger.info("genericDBQueryAPI");  
		  
	      /**
	       * Generic API Testing end
	       */
	      String refernceNumber = orderRequest.get("RefernceNumber")!=null?orderRequest.get("RefernceNumber").getAsString():" ";
	/*      
	      if(refernceNumber  == null || (refernceNumber.length()<8 || refernceNumber.length()>20)){
	    	  return errorRespone("01","Refernce Number is missing in request");  // NEED TO CHANGE TO Util class  
	      }
	      
	      if(requestDetails==null){
	    	  return errorRespone("01","Order Criteria is missing in request");  // NEED TO CHANGE TO Util class  
	      }


	      Map<String, Object> flowMap = activitiUtil.findProductFlow(map);
	      
	      if(flowMap== null || flowMap.size()==0){
	    	  return errorRespone("99","Application Error");  // NEED TO CHANGE TO Util class
	      }
	      

	      
	      Map<String, Object> outputVaribales = activitiEngine.executeWorkflow(flowMap.get("FLOW_CODE").toString(), map);
	      logger.info("outputVaribales",outputVaribales);
	      logger.debug("outputVaribales",outputVaribales);*/
		  
			 // response
//		  OrderResponseWrapper orderResponseWrapper = new OrderResponseWrapper();
//		  orderResponseWrapper.setErrorCode("00");
//		  orderResponseWrapper.setErrorResponse("Success");
		  JsonObject jsonObject = new JsonObject();
		  if(outputVaribales!=null && outputVaribales.get("output_RequestId")!=null){
			  jsonObject.addProperty("orderNumber", outputVaribales.get("output_RequestId").toString());  
		  }
//		  orderResponseWrapper.setOrderResponse(jsonObject);
		  
	       Map<String, Object> parameters = new HashMap<>();
	       parameters.put("REFERENCE_NO", refernceNumber);
	       parameters.put("REQUEST_ID",outputVaribales.get("output_RequestId"));
	       parameters.put("SUBREQUEST_ID",outputVaribales.get("output_SubRequestId"));
	       parameters.put("NOTES", "CBCM CW Order");
	       parameters.put("CREATED_USER_ID", "CBCM_CW");
	       parameters.put("MODIFIED_USER_ID", "CBCM_CW");
	      
	      
		  genericOrderCreationDAO.insert(DataSourceType.cbcm_cw_datasource, cwOrderAudit, parameters);
		  
		  CWLog.logMessage(Level.INFO, "test End"+jsonObject);	
		 return jsonObject;
			
	}
	
	/**
	 * Generic API Testing End
	 */

}
