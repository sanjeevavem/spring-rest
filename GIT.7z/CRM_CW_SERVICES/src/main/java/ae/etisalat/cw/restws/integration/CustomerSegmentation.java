package ae.etisalat.cw.restws.integration;

public class CustomerSegmentation {

}
