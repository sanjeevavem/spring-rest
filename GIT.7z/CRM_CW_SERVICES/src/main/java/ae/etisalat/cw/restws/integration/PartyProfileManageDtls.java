package ae.etisalat.cw.restws.integration;

import java.util.Date;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class PartyProfileManageDtls {
	
	private String transactionId;
	@NotNull
    private ChannelInfo channelInfo;
	@NotNull
	private UserInfo userInfo;
	private String systemName;
	private Date receivedTime;
	private List<AdditionalInformation> additionalInfo;
	
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public ChannelInfo getChannelInfo() {
		return channelInfo;
	}
	public void setChannelInfo(ChannelInfo channelInfo) {
		this.channelInfo = channelInfo;
	}
	public UserInfo getUserInfo() {
		return userInfo;
	}
	public void setUserInfo(UserInfo userInfo) {
		this.userInfo = userInfo;
	}
	public String getSystemName() {
		return systemName;
	}
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	public Date getReceivedTime() {
		return receivedTime;
	}
	public void setReceivedTime(Date receivedTime) {
		this.receivedTime = receivedTime;
	}
	public List<AdditionalInformation> getAdditionalInfo() {
		return additionalInfo;
	}
	public void setAdditionalInfo(List<AdditionalInformation> additionalInfo) {
		this.additionalInfo = additionalInfo;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((additionalInfo == null) ? 0 : additionalInfo.hashCode());
		result = prime * result
				+ ((channelInfo == null) ? 0 : channelInfo.hashCode());
		result = prime * result
				+ ((receivedTime == null) ? 0 : receivedTime.hashCode());
		result = prime * result
				+ ((systemName == null) ? 0 : systemName.hashCode());
		result = prime * result
				+ ((transactionId == null) ? 0 : transactionId.hashCode());
		result = prime * result
				+ ((userInfo == null) ? 0 : userInfo.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PartyProfileManageDtls other = (PartyProfileManageDtls) obj;
		if (additionalInfo == null) {
			if (other.additionalInfo != null)
				return false;
		} else if (!additionalInfo.equals(other.additionalInfo))
			return false;
		if (channelInfo == null) {
			if (other.channelInfo != null)
				return false;
		} else if (!channelInfo.equals(other.channelInfo))
			return false;
		if (receivedTime == null) {
			if (other.receivedTime != null)
				return false;
		} else if (!receivedTime.equals(other.receivedTime))
			return false;
		if (systemName == null) {
			if (other.systemName != null)
				return false;
		} else if (!systemName.equals(other.systemName))
			return false;
		if (transactionId == null) {
			if (other.transactionId != null)
				return false;
		} else if (!transactionId.equals(other.transactionId))
			return false;
		if (userInfo == null) {
			if (other.userInfo != null)
				return false;
		} else if (!userInfo.equals(other.userInfo))
			return false;
		return true;
	}
	
	 @Override
	 public String toString() {
        return ToStringBuilder.reflectionToString(this);
	 }
	

}
