package ae.etisalat.cw.activiti.closure.api;

import java.util.HashMap;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.apache.logging.log4j.Level;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import ae.etisalat.activiti.core.ActivitiAPI;
import ae.etisalat.cw.comm.util.JSONUtil;
import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.UtilHelper;
import ae.etisalat.cw.comm.util.logger.CWLog;

public class GenericOrderCreationAPI extends ActivitiAPI {


	 private Expression JSON_WORKFLOW_CONTEXT;
	 private Expression JSON_REQUEST;
	 
	private static final String procedureName="CREATE_ADDSUBREQUEST17";

	@Override
	public void init(DelegateExecution execution) throws Exception {

	}

	@Override
	public void run(DelegateExecution execution) throws Exception {
		CWLog.logMessage(Level.INFO, "run Start");
		UtilHelper util = new UtilHelper();
		String jsonStr = (String) util.evalExpr(UtilConstants.JSON_REQUEST,JSON_REQUEST,execution);
		JsonObject json = new Gson().fromJson(jsonStr, JsonObject.class);
		HashMap<String, Object> map = JSONUtil.convertJSONToMap(json);
		

		String productGroup = map.get("ProductGroup")!=null?map.get("ProductGroup").toString():null; //(String) util.evalExpr("ProductGroup",ProductGroup,execution);
		String accNumber    =  map.get("Account_Number")!=null?map.get("Account_Number").toString():null; //(String) util.evalExpr("Account_Number",Account_Number,execution);
		String product      =  map.get("Product")!=null?map.get("Product").toString():null;//(String) util.evalExpr("Product", Product,execution);
		String ordertype    = map.get("Ordertype")!=null?map.get("Ordertype").toString():null; //(String) util.evalExpr("Ordertype", Ordertype,execution);
		String offerType    =  map.get("OfferType")!=null?map.get("OfferType").toString():null; //(String) util.evalExpr("OfferType", OfferType,execution);
		String offerCode    =  map.get("OfferCode")!=null?map.get("OfferCode").toString():null; //(String) util.evalExpr("OfferCode", OfferCode,execution);
		
		HashMap<String, Object> procIn = new HashMap<String, Object>();
		procIn.put("p_accountId", accNumber);
		procIn.put("p_Offer_type", "R");
		procIn.put("p_offer_code", offerCode);
		procIn.put("p_channel_id", "WEB");
		procIn.put("p_created_user_id", default_user_id);
		Map<String, Object> output = null;//genericOrderCreationDAO.executeProcedure(procedureName,procIn);


	
		if(output!=null && output.get("SUBREQUEST_ID")!=null){
		  execution.setVariable("output_SubRequestId", output.get("SUBREQUEST_ID"));
		  json.addProperty("output_SubRequestId", output.get("SUBREQUEST_ID").toString());
		}
		if(output!=null && output.get("REQUEST_ID")!=null){
		  execution.setVariable("output_RequestId", output.get("REQUEST_ID"));
		  json.addProperty("output_RequestId", output.get("REQUEST_ID").toString());
		}
	  execution.setVariable(UtilConstants.JSON_RESPONSE,json.toString());  // need to remove
	  execution.setVariable(UtilConstants.ACTIVITI_API_CTX, json.toString());
	  CWLog.logMessage(Level.INFO,"" + this.getClass() + "run end, output {}", ""+output);
	}

}
