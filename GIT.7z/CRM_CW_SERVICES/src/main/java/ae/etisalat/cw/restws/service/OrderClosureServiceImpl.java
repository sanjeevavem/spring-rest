package ae.etisalat.cw.restws.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;

import ae.etisalat.activiti.core.ActivitiEngine;
import ae.etisalat.activiti.core.ActivitiUtil;
import ae.etisalat.cw.comm.util.JSONUtil;
import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.jpa.soh.daos.AccountCreationDao;
import ae.etisalat.cw.restws.jpa.entities.CwMstFlowMap;
import ae.etisalat.cw.restws.util.ServicesUtil;

@Service
public class OrderClosureServiceImpl implements OrderClosureService {
	
	private static final Logger logger = LogManager.getLogger(OrderClosureServiceImpl.class);
	
	@Value("${cbcmcw.config.masterflow.select}")
	private String masterflow;
	
	@Value("${cbcm.soh.insert.CW_ORDER_AUDIT}")
	private String cwOrderAudit;

	@Autowired
	private ServicesUtil servicesUtil;
	
	@Autowired
	private ActivitiEngine activitiEngine;
	
	@Autowired
	private ActivitiUtil activitiUtil;
	
	@Autowired
	private AccountCreationDao accDao;

	@Override
	public JsonObject initiateOrderClosure(JsonObject closureRequest) throws Exception {
		  CWLog.logMessage(Level.INFO, "Order Closure Start"+closureRequest.toString());	

		  Map<String, Object> outputVaribales = null;
		   HashMap<String, Object> criteriaMap = null;
		   String referenceNumber = null;
		   String UID = null;
		   
		  JsonObject responseJson = new JsonObject();
		  try
		   {
			 referenceNumber = JSONUtil.getJSONValueByKey(closureRequest.toString(), "$.orderInfo.transactionId");
			 UID = closureRequest.get(UtilConstants.UID).toString();
			 responseJson.addProperty(UtilConstants.REF_NUMBER, referenceNumber);
			 responseJson.addProperty(UtilConstants.UID, UID);
			 criteriaMap = servicesUtil.getRequestCriteria(closureRequest, null);
			 
		  	} catch (Exception e) {
		  	  CWLog.logMessage(Level.ERROR, "Exception Message is : "+e.getMessage(),e);
		  	 return servicesUtil.errorRespone(UtilConstants.INVALID_REQUEST, UtilConstants.INVALID_REQUEST_MSG,referenceNumber,UID);
		  	}
		  

		  try 
			{
			  CwMstFlowMap cwMstFlowMap = activitiUtil.findProductFlow(criteriaMap);
			 
			  if(cwMstFlowMap== null || cwMstFlowMap.getFlowCode()==null){
			     return servicesUtil.errorRespone(UtilConstants.NO_FLOW_REQUEST,UtilConstants.NO_FLOW_REQUEST_MSG,referenceNumber,UID); 
			   }
			  
			  boolean validSchema = activitiUtil.validateSchema(cwMstFlowMap.getValidationSchemaTemplate(),closureRequest.toString());
		      // add other attributes to the criteriaMap
			    criteriaMap.put("JSON_REQUEST", closureRequest.toString());  
			    criteriaMap.put("JSON_WORKFLOW_CONTEXT", "");
		       outputVaribales = activitiEngine.executeWorkflow(cwMstFlowMap.getFlowCode(), criteriaMap);
		      logger.info("outputVaribales",outputVaribales);
		      logger.debug("outputVaribales",outputVaribales);
		   	 } catch (Exception e) {
		   	    CWLog.logMessage(Level.ERROR, "Exception Message is : "+e.getMessage(),e);
		    	return servicesUtil.errorRespone(UtilConstants.INVALID_REQUEST, UtilConstants.INVALID_REQUEST_MSG + "  "+e.getMessage(),referenceNumber,UID);
		 	}
	      
	     // Set the variables to JSON object 
		  if(outputVaribales!=null && outputVaribales.get("output_RequestId")!=null){
			  responseJson.addProperty("RequestId", outputVaribales.get("output_RequestId").toString());  
		  }
		  CWLog.logMessage(Level.INFO, "Order Closure End"+responseJson);	
		 return responseJson;
		}

}
