package ae.etisalat.cw.restws.controllers;

import org.apache.logging.log4j.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;

import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.restws.service.OrderClosureService;
import ae.etisalat.cw.restws.util.ServicesUtil;

@RestController
@RequestMapping("/")
public class OrderClosureController {
	
	@Autowired
	private OrderClosureService orderClosureService;
	
	@Autowired
	private ServicesUtil util;
	
	@RequestMapping(value = "/orderClosure", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public JsonObject createOrder(@RequestBody JsonObject closureDetails) throws Exception {
	  CWLog.logMessage(Level.INFO, "Order Closure Start :"+closureDetails);
	   String UID = util.getUUID();
	   util.restServiceLogs(closureDetails, UID, UtilConstants.LOG_TYPE_REQUEST,this.getClass());
	   if(closureDetails!=null){
		   closureDetails.addProperty(UtilConstants.UID, UID); 
	   }

		JsonObject orderResponse = orderClosureService.initiateOrderClosure(closureDetails);
		if(orderResponse!=null){
			orderResponse.addProperty("InternalRefNumber", UID);
		}
	  util.restServiceLogs(closureDetails, UID, UtilConstants.LOG_TYPE_REQUEST,this.getClass());
	  CWLog.logMessage(Level.INFO, "createOrder End :"+orderResponse);
	  return orderResponse;
	}

}
