package ae.etisalat.cw.restws.util;

import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.Level;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;

import ae.etisalat.crmgw.util.JsonSearchConstants;
import ae.etisalat.cw.comm.util.JSONUtil;
import ae.etisalat.cw.comm.util.Util;
import ae.etisalat.cw.comm.util.UtilHelper;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.restws.clients.OfferingDetailsList;
import ae.etisalat.cw.restws.clients.ServiceRegistry;

@Service
public class ServicesUtil extends UtilHelper {
 
	private String product ="$.orderInfo.productCode"; // ProductCode
	private String productGroup ="$.orderInfo.productGroupCode"; // ProductGroupCode
	private String orderType ="$.orderInfo.orderType"; // OrderType
	
	public HashMap<String, Object> getRequestCriteria(JsonObject jsonObject,String serviceType) throws Exception{
	  CWLog.logMessage(Level.INFO, "getRequestCriteria start");
	  HashMap<String, Object> map = new HashMap<String, Object>();
		try {
			map.put("PRODUCT",JSONUtil.getJSONValueByKey(jsonObject.toString(), product));
			map.put("PRODUCT_GROUP",JSONUtil.getJSONValueByKey(jsonObject.toString(), productGroup));
			map.put("ORDER_TYPE",JSONUtil.getJSONValueByKey(jsonObject.toString(), orderType));
			//map.put("OFFERS", loadOffers( jsonObject,serviceType));
		} catch (Exception e) {
			CWLog.logMessage(Level.ERROR, "Exception Message is : "+e.getMessage(),e);
			throw e;
		}
	  CWLog.logMessage(Level.INFO, "getRequestCriteria end, attributes : ");
	 return map;
	}

	private Object loadOffers(JsonObject jsonObject, String serviceType) throws Exception {
		ServiceRegistry srvRegistry = JSONUtil.jsonToObject(jsonObject.toString(), JsonSearchConstants.srvRegistryQry, ServiceRegistry.class);
		List<OfferingDetailsList> offrList = srvRegistry.getOfferingDetailsList();
		if(Util.isValidObject(offrList))
			return offrList;
		return null;
	}

	public JsonObject errorRespone(String errorCode,String errorDesc,String referenceNumber,String UID) {
	  JsonObject jsonObject = new JsonObject();
	  jsonObject.addProperty("errorCode", errorCode);
	  jsonObject.addProperty("errorDesc", errorDesc);
	  jsonObject.addProperty("ReferenceNumber", referenceNumber);
	  jsonObject.addProperty("InternalRefNumber", UID);
	 return jsonObject;
	}
}
