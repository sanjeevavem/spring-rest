package ae.etisalat.cw.restws.validation;

import org.apache.logging.log4j.Level;

import com.google.gson.JsonObject;

import ae.etisalat.cw.comm.util.ECRMValidator;
import ae.etisalat.cw.comm.util.logger.CWLog;

public class OrderClosureValidatorAPI implements ECRMValidator {

	private static final long serialVersionUID = 1L;

	@Override
	public JsonObject validate(Object... parameters) {
	  CWLog.logMessage(Level.INFO, "OrderClosureValidatorAPI validate() Start..");
	   
	  CWLog.logMessage(Level.INFO, "OrderClosureValidatorAPI validate() End..");
	return errorRespone("88", "Test error response");
	}

}
