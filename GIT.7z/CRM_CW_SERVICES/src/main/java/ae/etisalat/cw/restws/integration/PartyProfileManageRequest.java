package ae.etisalat.cw.restws.integration;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class PartyProfileManageRequest {

	@NotNull
	private PartyProfileManageDtls partyProfileManageDtls;

	public PartyProfileManageDtls getPartyProfileManageDtls() {
		return partyProfileManageDtls;
	}

	public void setPartyProfileManageDtls(
			PartyProfileManageDtls partyProfileManageDtls) {
		this.partyProfileManageDtls = partyProfileManageDtls;
	}
	
	public PartyProfileManageRequest withCustomerRequest(PartyProfileManageDtls partyProfileManageDtls) {
        this.partyProfileManageDtls = partyProfileManageDtls;
        return this;
    }
	
	@Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(partyProfileManageDtls).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PartyProfileManageRequest) == false) {
            return false;
        }
        PartyProfileManageRequest rhs = ((PartyProfileManageRequest) other);
        return new EqualsBuilder().append(partyProfileManageDtls, rhs.partyProfileManageDtls).isEquals();
    }
	
	
}
