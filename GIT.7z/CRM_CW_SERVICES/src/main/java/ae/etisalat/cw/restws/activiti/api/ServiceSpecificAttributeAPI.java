package ae.etisalat.cw.restws.activiti.api;

import java.util.HashMap;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.apache.logging.log4j.Level;

import ae.etisalat.activiti.core.ActivitiAPI;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.restws.dao.generic.DataSourceType;

public class ServiceSpecificAttributeAPI extends ActivitiAPI {


	private Expression serviceSpecificAttributes;
	
	@Override
	public void init(DelegateExecution execution) throws Exception {	

	}

	@Override
	public void run(DelegateExecution execution) throws Exception {
	 CWLog.logMessage(Level.INFO, "run() Start");
     System.out.println("execution -->"+execution.getVariable("output_SubRequestId"));
     Map<String, Object> parameters = new HashMap<>();
     parameters.put("REFERENCE_NO", "CWSRV1234");
     parameters.put("REQUEST_ID","123456789");
     parameters.put("SUBREQUEST_ID","123456789");
     parameters.put("NOTES", "CBCM CW Order");
     parameters.put("CREATED_USER_ID", "CBCM_CW");
     parameters.put("MODIFIED_USER_ID", "CBCM_CW");
    
    
	  String cwOrderAudit="INSERT INTO CW_ORDER_AUDIT (ID,REFERENCE_NO,REQUEST_ID,SUBREQUEST_ID,NOTES,CREATED_DATE,MODIFIED_DATE,CREATED_USER_ID,MODIFIED_USER_ID,DELETION_STATUS) VALUES (SQ_CW_ORDER_AUDIT.NEXTVAL,:REFERENCE_NO,:REQUEST_ID,:SUBREQUEST_ID,:NOTES,SYSDATE,SYSDATE,:CREATED_USER_ID,:MODIFIED_USER_ID,'N')";
	  genericOrderCreationDAO.insert(DataSourceType.cbcm_cw_datasource, cwOrderAudit, parameters);
	 CWLog.logMessage(Level.INFO, "run() end");
	}

}
