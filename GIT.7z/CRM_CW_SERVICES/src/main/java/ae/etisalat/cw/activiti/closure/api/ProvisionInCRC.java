package ae.etisalat.cw.activiti.closure.api;

import java.math.BigDecimal;
import java.net.URL;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Level;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import ae.etisalat.activiti.core.ActivitiAPI;
import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.UtilHelper;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.jpa.cms.entities.TCmsDtlPartyProfile;
import ae.etisalat.cw.jpa.soh.daos.AccountCreationDao;
import ae.etisalat.cw.jpa.soh.daos.PkgRpAcctSrvcInstMapping;
import ae.etisalat.cw.jpa.soh.entities.TSohAccount;
import ae.etisalat.cw.otherSystem.clients.crc.AccountSchemeAssignControllerBindingStub;
import ae.etisalat.cw.otherSystem.clients.crc.AccountSchemeAssignList;
import ae.etisalat.cw.otherSystem.clients.crc.AccountSchemeAssignRequest;
import ae.etisalat.cw.otherSystem.clients.crc.AccountSchemeAssignResponse;
import ae.etisalat.cw.otherSystem.clients.crc.AccountSchemeAssignWebSrvLocator;
import ae.etisalat.cw.restws.context.SpringApplicationContext;
import ae.etisalat.cw.restws.dao.generic.ConfigDao;

@Service
public class ProvisionInCRC extends ActivitiAPI {

	private Expression JSON_REQUEST;

	protected AccountCreationDao acctdao;
	protected ConfigDao configDao;

	@Override
	public void init(DelegateExecution execution) throws Exception {
		acctdao = SpringApplicationContext.getApplicationContext().getBean(AccountCreationDao.class);
		configDao = SpringApplicationContext.getApplicationContext().getBean(ConfigDao.class);
	}
	@SuppressWarnings("unchecked")
	@Override
	public void run(DelegateExecution execution) throws Exception {
		CWLog.logMessage(Level.INFO, "run Start");
		UtilHelper util = new UtilHelper();
		String jsonStr = (String) util.evalExpr(UtilConstants.JSON_REQUEST, JSON_REQUEST, execution);
		JsonObject json = new Gson().fromJson(jsonStr, JsonObject.class);
		TSohAccount tSohAccount = execution.getVariable(UtilConstants.accountEntity, TSohAccount.class);		
		List<PkgRpAcctSrvcInstMapping> pkgRpAcctSrvcInstMapList = (List<PkgRpAcctSrvcInstMapping>) execution
				.getVariable(UtilConstants.accSrvInstDtl, List.class);

		TCmsDtlPartyProfile dtlPartyProfile = acctdao.getPartyProfile(tSohAccount.getPartyProfileId().longValue());
		Long ratePlanId = null;
		Long serviceId = null;
		Long packageId = null;
		for (PkgRpAcctSrvcInstMapping pkgRp : pkgRpAcctSrvcInstMapList) {
			if (pkgRp.getSrvcCategoryId() == 9) {
				ratePlanId = pkgRp.getRatePlanId();
				serviceId = pkgRp.getSrvcId();
				packageId = pkgRp.getPackageId();
			}

		}

		AccountSchemeAssignWebSrvLocator locator = new AccountSchemeAssignWebSrvLocator();
		AccountSchemeAssignControllerBindingStub accountSchemeAssignControllerBindingStub = (AccountSchemeAssignControllerBindingStub) locator
				.getAccountSchemeAssignControllerPort(new URL(configDao.fetchConfigValue(UtilConstants.WEB_SERVICE, UtilConstants.CRC, UtilConstants.URL)));
		AccountSchemeAssignRequest accountSchemeAssignRequest = new AccountSchemeAssignRequest();
		accountSchemeAssignRequest.setIsPrimaryService(true);
		accountSchemeAssignRequest.setPartyTypeId(dtlPartyProfile.getPartyTypeId().longValue());
		accountSchemeAssignRequest.setPartySubTypeId(tSohAccount.getAccountCategoryId().longValue());
		accountSchemeAssignRequest.setRatePlanId(ratePlanId);
		accountSchemeAssignRequest.setServiceId(serviceId);
		accountSchemeAssignRequest.setRegionId(tSohAccount.getRegionId().longValue());
		accountSchemeAssignRequest.setOrgUnitId(tSohAccount.getOrgUnitId().longValue());
		accountSchemeAssignRequest.setBillingCycleFrequencyId(tSohAccount.getBillCycleId().longValue());
		accountSchemeAssignRequest.setPackageId(packageId);
		accountSchemeAssignRequest.setStdaloneFlag("null");

		CWLog.logMessage(Level.INFO,
				"" + this.getClass() + "Request for CRC webservice is : " + accountSchemeAssignRequest.toString());
		AccountSchemeAssignResponse accountSchemeAssignResponse = null;

		try {
			String unitTestHeaderValue =configDao.fetchConfigValue(UtilConstants.WEB_SERVICE, UtilConstants.COMMON_ATTRIBUTE, UtilConstants.WS_HEADER_VALUE);
			if (StringUtils.isNotBlank(unitTestHeaderValue)) {
				accountSchemeAssignControllerBindingStub.setHeader(configDao.fetchConfigValue(UtilConstants.WEB_SERVICE, UtilConstants.COMMON_ATTRIBUTE, UtilConstants.WS_NAMESPACE),
						unitTestHeaderValue, unitTestHeaderValue);
			}
			accountSchemeAssignResponse = accountSchemeAssignControllerBindingStub
					.performAccountSchemeAssignResponse(accountSchemeAssignRequest);
		} catch (Exception e) {

			CWLog.logMessage(Level.INFO, "" + this.getClass() + "Failed to provision in CRC with exception:", e);
			if (accountSchemeAssignResponse == null) {
				accountSchemeAssignResponse = new AccountSchemeAssignResponse();
				execution.setVariable(UtilConstants.RESPONSE_CODE, "Failed");
				json.addProperty(UtilConstants.RESPONSE_DESC,
						"Error while getting response from webservice: " + accountSchemeAssignResponse.getReason());
			}
			execution.setVariable(UtilConstants.RESPONSE_CODE, "Failed");
			json.addProperty(UtilConstants.RESPONSE_DESC,
					"Failed to provision in CRC with exception:" + e.getMessage());
		}

		if (null != accountSchemeAssignResponse) {
			if (accountSchemeAssignResponse.getStatus().equalsIgnoreCase("00")) {
				try {
					AccountSchemeAssignList[] accountSchemeAssignList = accountSchemeAssignResponse
							.getAccountSchemeAssignList();
					if (accountSchemeAssignList != null) {
						for (AccountSchemeAssignList accountSchemeAssign : accountSchemeAssignList) {
							acctdao.insertCrcSheme(BigDecimal.valueOf(accountSchemeAssign.getSchemeId()),
									BigDecimal.valueOf(accountSchemeAssign.getSchemeCategoryId()),
									BigDecimal.valueOf(tSohAccount.getAccountId()), "COMS");
						}
					}
				} catch (Exception exe) {
					CWLog.logMessage(Level.INFO,
							"" + this.getClass() + "Exception while inserting into CRC Scheme" + exe.getMessage());
					execution.setVariable(UtilConstants.RESPONSE_CODE, "Failed");
					json.addProperty(UtilConstants.RESPONSE_DESC, "Exception while inserting into CRC Scheme null");
				}
				execution.setVariable(UtilConstants.RESPONSE_CODE, "Done");
				json.addProperty(UtilConstants.RESPONSE_DESC,
						"Send the request to CRC service successfully" + accountSchemeAssignResponse.getStatus());
			} else if (accountSchemeAssignResponse.getStatus().equalsIgnoreCase("93")) {
				execution.setVariable(UtilConstants.RESPONSE_CODE, "Done");
				json.addProperty(UtilConstants.RESPONSE_DESC, "Response code 93 got from CRC: No schema for VIPs");
			} else {
				execution.setVariable(UtilConstants.RESPONSE_CODE, "Failed");
				json.addProperty(UtilConstants.RESPONSE_DESC,
						"Failure Response got from CRC: " + accountSchemeAssignResponse.getStatus());
			}
		} else {
			execution.setVariable(UtilConstants.RESPONSE_CODE, "Failed");
			json.addProperty(UtilConstants.RESPONSE_DESC, "No response got from CRC service");
		}
		execution.setVariable(UtilConstants.ACTIVITI_API_CTX, json.toString());
		CWLog.logMessage(Level.INFO, "" + this.getClass() + "run end, output {}", "");
	}

}
