package ae.etisalat.cw.restws.controllers;

import org.apache.logging.log4j.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;

import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.restws.service.OrderStatusUpdateServiceImpl;
import ae.etisalat.cw.restws.util.ServicesUtil;

@RestController
@RequestMapping("/")
public class OrderStatusUpdateController {
	
	@Autowired
	private OrderStatusUpdateServiceImpl statusUpdateServiceImpl;
	
	@Autowired
	private ServicesUtil util;
	
	@RequestMapping(value="closesubrequest",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
	public JsonObject orderStatusUpdate(@RequestBody JsonObject orderRequest) throws Exception {
	  CWLog.logMessage(Level.INFO, "orderStatusUpdate Start, orderRequest ->"+orderRequest);
	  String UID = util.getUUID();
	  util.restServiceLogs(orderRequest, UID, UtilConstants.LOG_TYPE_REQUEST,this.getClass());
	   if(orderRequest!=null){
		   orderRequest.addProperty(UtilConstants.UID, UID); 
	   }
	   JsonObject orderResponse = statusUpdateServiceImpl.orderStatusUpdate(orderRequest);
	   util.restServiceLogs(orderResponse, UID, UtilConstants.LOG_TYPE_RESPONSE,this.getClass());
	  CWLog.logMessage(Level.INFO, "orderStatusUpdate End, orderResponse ->"+orderResponse);
	 return orderResponse;
	}
	    
}
