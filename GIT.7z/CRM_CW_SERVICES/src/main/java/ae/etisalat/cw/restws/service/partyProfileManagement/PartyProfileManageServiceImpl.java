package ae.etisalat.cw.restws.service.partyProfileManagement;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ae.etisalat.activiti.core.ActivitiEngine;
import ae.etisalat.activiti.core.ActivitiUtil;
import ae.etisalat.cw.comm.util.JSONUtil;
import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.restws.dao.generic.GenericOrderCreationDAO;
import ae.etisalat.cw.restws.integration.PartyProfileManageRequest;
import ae.etisalat.cw.restws.jpa.entities.CwMstFlowMap;
import ae.etisalat.cw.restws.util.ServicesUtil;

import com.google.gson.JsonObject;

@Service
public class PartyProfileManageServiceImpl implements PartyProfileManageService{
	
private static final Logger logger = LogManager.getLogger(PartyProfileManageServiceImpl.class);
	
	@Value("${cbcmcw.config.masterflow.select}")
	private String masterflow;
	
	@Value("${cbcm.soh.insert.CW_ORDER_AUDIT}")
	private String cwOrderAudit;
	
	@Autowired
	private JSONUtil util;
	
	@Autowired
	private ServicesUtil servicesUtil;
	
	@Autowired
	private ActivitiEngine activitiEngine;
	
	@Autowired
	private ActivitiUtil activitiUtil;
    
    @Autowired(required=true)
    private GenericOrderCreationDAO genericOrderCreationDAO;

	public JsonObject createUpdatePartyProfile(PartyProfileManageRequest partyProfDetails)
			throws Exception {
		  CWLog.logMessage(Level.INFO, "createOrder Start"+partyProfDetails.toString());	
		  /**
		   *  1. validate
		   *  2. fetch input criteria
		   *  3. invoke the Activiti flow
		   *  4. prepare the response and handle the error if any issue
		   */
		   Map<String, Object> outputVaribales = null;
	       Map<String, Object> flowMap = null;
		   HashMap<String, Object> criteriaMap = null;
		   String referenceNumber = null;
		   String UID = null;
		   
		  JsonObject responseJson = new JsonObject();
		  try
		   {
			 referenceNumber = JSONUtil.getJSONValueByKey(partyProfDetails.toString(), "$.requestDetails.ReferenceNumber");
			// UID = partyProfDetails.get(UtilConstants.UID).toString();
			 responseJson.addProperty(UtilConstants.REF_NUMBER, referenceNumber);
			 responseJson.addProperty(UtilConstants.UID, UID);
			 //criteriaMap = servicesUtil.getRequestCriteria(partyProfDetails, null);
			 
		  	} catch (Exception e) {
		  	  CWLog.logMessage(Level.ERROR, "Exception Message is : "+e.getMessage(),e);
		  	 return errorRespone(UtilConstants.INVALID_REQUEST, UtilConstants.INVALID_REQUEST_MSG,referenceNumber,UID);
		  	}
		  

		  try 
			{
			 CwMstFlowMap cwMstFlowMap = activitiUtil.findProductFlow(criteriaMap);
			  if(cwMstFlowMap== null || cwMstFlowMap.getFlowCode()==null){
			     return errorRespone(UtilConstants.NO_FLOW_REQUEST,UtilConstants.NO_FLOW_REQUEST_MSG,referenceNumber,UID); 
			   }
		      // add other attributes to the criteriaMap
			    criteriaMap.put("JSON_REQUEST", partyProfDetails);
			    criteriaMap.put("JSON_WORKFLOW_CONTEXT", "");
		       outputVaribales = activitiEngine.executeWorkflow(flowMap.get("FLOW_CODE").toString(), criteriaMap);
		      logger.info("outputVaribales",outputVaribales);
		      logger.debug("outputVaribales",outputVaribales);
		   	 } catch (Exception e) {
		   	    CWLog.logMessage(Level.ERROR, "Exception Message is : "+e.getMessage(),e);
		    	return errorRespone(UtilConstants.INVALID_REQUEST, UtilConstants.INVALID_REQUEST_MSG,referenceNumber,UID);
		 	}
	      
	     // Set the variables to JSON object 
		  if(outputVaribales!=null && outputVaribales.get("output_RequestId")!=null){
			  responseJson.addProperty("RequestId", outputVaribales.get("output_RequestId").toString());  
		  }
		  CWLog.logMessage(Level.INFO, "createOrder End"+responseJson);	
		 return responseJson;
		}
	
	private JsonObject errorRespone(String errorCode,String errorDesc,String referenceNumber,String UID) {
		  JsonObject jsonObject = new JsonObject();
		  jsonObject.addProperty("errorCode", errorCode);
		  jsonObject.addProperty("errorDesc", errorDesc);
		  jsonObject.addProperty("ReferenceNumber", referenceNumber);
		  jsonObject.addProperty("InternalRefNumber", UID);
		 return jsonObject;
		}

}
