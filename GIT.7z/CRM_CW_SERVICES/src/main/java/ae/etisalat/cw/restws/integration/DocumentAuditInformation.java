
package ae.etisalat.cw.restws.integration;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "additionalParameters", "action", "accountId", "subrequestId", "createdDate", "documentNumber", "applicationFileName",
        "channel", "createdUserId", "deletionStatus", "identityFileName", "isApplicationScanned", "isEidRead", "isIdentityScanned",
        "isPassportRead", "modifiedDate", "modifiedUserId", "primId", "readerBypassReason", "readerBypassed", "scannerBypassReason",
        "scannerBypassed" })
public class DocumentAuditInformation {

    @JsonProperty("additionalParameters")
    private List<AdditionalParameter> additionalParameters = new ArrayList<AdditionalParameter>();
    @JsonProperty("action")
    private String action;
    @JsonProperty("accountId")
    private Long accountId;
    @JsonProperty("subrequestId")
    private Long subrequestId;
    @JsonProperty("createdDate")
    private Date createdDate;
    @JsonProperty("documentNumber")
    private String documentNumber;
    @JsonProperty("applicationFileName")
    private String applicationFileName;
    @JsonProperty("channel")
    private String channel;
    @JsonProperty("createdUserId")
    private String createdUserId;
    @JsonProperty("deletionStatus")
    private String deletionStatus;
    @JsonProperty("identityFileName")
    private String identityFileName;
    @JsonProperty("isApplicationScanned")
    private String isApplicationScanned;
    @JsonProperty("isEidRead")
    private String isEidRead;
    @JsonProperty("isIdentityScanned")
    private String isIdentityScanned;
    @JsonProperty("isPassportRead")
    private String isPassportRead;
    @JsonProperty("modifiedDate")
    private Date modifiedDate;
    @JsonProperty("modifiedUserId")
    private String modifiedUserId;
    @JsonProperty("primId")
    private Long primId;
    @JsonProperty("readerBypassReason")
    private String readerBypassReason;
    @JsonProperty("readerBypassed")
    private String readerBypassed;
    @JsonProperty("scannerBypassReason")
    private String scannerBypassReason;
    @JsonProperty("scannerBypassed")
    private String scannerBypassed;

    @JsonProperty("additionalParameters")
    public List<AdditionalParameter> getAdditionalParameters() {
        return additionalParameters;
    }

    @JsonProperty("additionalParameters")
    public void setAdditionalParameters(List<AdditionalParameter> additionalParameters) {
        this.additionalParameters = additionalParameters;
    }

    public DocumentAuditInformation withAdditionalParameters(List<AdditionalParameter> additionalParameters) {
        this.additionalParameters = additionalParameters;
        return this;
    }

    @JsonProperty("action")
    public String getAction() {
        return action;
    }

    @JsonProperty("action")
    public void setAction(String action) {
        this.action = action;
    }

    public DocumentAuditInformation withAction(String action) {
        this.action = action;
        return this;
    }

    @JsonProperty("accountId")
    public Long getAccountId() {
        return accountId;
    }

    @JsonProperty("accountId")
    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public DocumentAuditInformation withAccountId(Long accountId) {
        this.accountId = accountId;
        return this;
    }

    @JsonProperty("subrequestId")
    public Long getSubrequestId() {
        return subrequestId;
    }

    @JsonProperty("subrequestId")
    public void setSubrequestId(Long subrequestId) {
        this.subrequestId = subrequestId;
    }

    public DocumentAuditInformation withSubrequestId(Long subrequestId) {
        this.subrequestId = subrequestId;
        return this;
    }

    @JsonProperty("createdDate")
    public Date getCreatedDate() {
        return createdDate;
    }

    @JsonProperty("createdDate")
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public DocumentAuditInformation withCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
        return this;
    }

    @JsonProperty("documentNumber")
    public String getDocumentNumber() {
        return documentNumber;
    }

    @JsonProperty("documentNumber")
    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public DocumentAuditInformation withDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
        return this;
    }

    @JsonProperty("applicationFileName")
    public String getApplicationFileName() {
        return applicationFileName;
    }

    @JsonProperty("applicationFileName")
    public void setApplicationFileName(String applicationFileName) {
        this.applicationFileName = applicationFileName;
    }

    public DocumentAuditInformation withApplicationFileName(String applicationFileName) {
        this.applicationFileName = applicationFileName;
        return this;
    }

    @JsonProperty("channel")
    public String getChannel() {
        return channel;
    }

    @JsonProperty("channel")
    public void setChannel(String channel) {
        this.channel = channel;
    }

    public DocumentAuditInformation withChannel(String channel) {
        this.channel = channel;
        return this;
    }

    @JsonProperty("createdUserId")
    public String getCreatedUserId() {
        return createdUserId;
    }

    @JsonProperty("createdUserId")
    public void setCreatedUserId(String createdUserId) {
        this.createdUserId = createdUserId;
    }

    public DocumentAuditInformation withCreatedUserId(String createdUserId) {
        this.createdUserId = createdUserId;
        return this;
    }

    @JsonProperty("deletionStatus")
    public String getDeletionStatus() {
        return deletionStatus;
    }

    @JsonProperty("deletionStatus")
    public void setDeletionStatus(String deletionStatus) {
        this.deletionStatus = deletionStatus;
    }

    public DocumentAuditInformation withDeletionStatus(String deletionStatus) {
        this.deletionStatus = deletionStatus;
        return this;
    }

    @JsonProperty("identityFileName")
    public String getIdentityFileName() {
        return identityFileName;
    }

    @JsonProperty("identityFileName")
    public void setIdentityFileName(String identityFileName) {
        this.identityFileName = identityFileName;
    }

    public DocumentAuditInformation withIdentityFileName(String identityFileName) {
        this.identityFileName = identityFileName;
        return this;
    }

    @JsonProperty("isApplicationScanned")
    public String getIsApplicationScanned() {
        return isApplicationScanned;
    }

    @JsonProperty("isApplicationScanned")
    public void setIsApplicationScanned(String isApplicationScanned) {
        this.isApplicationScanned = isApplicationScanned;
    }

    public DocumentAuditInformation withIsApplicationScanned(String isApplicationScanned) {
        this.isApplicationScanned = isApplicationScanned;
        return this;
    }

    @JsonProperty("isEidRead")
    public String getIsEidRead() {
        return isEidRead;
    }

    @JsonProperty("isEidRead")
    public void setIsEidRead(String isEidRead) {
        this.isEidRead = isEidRead;
    }

    public DocumentAuditInformation withIsEidRead(String isEidRead) {
        this.isEidRead = isEidRead;
        return this;
    }

    @JsonProperty("isIdentityScanned")
    public String getIsIdentityScanned() {
        return isIdentityScanned;
    }

    @JsonProperty("isIdentityScanned")
    public void setIsIdentityScanned(String isIdentityScanned) {
        this.isIdentityScanned = isIdentityScanned;
    }

    public DocumentAuditInformation withIsIdentityScanned(String isIdentityScanned) {
        this.isIdentityScanned = isIdentityScanned;
        return this;
    }

    @JsonProperty("isPassportRead")
    public String getIsPassportRead() {
        return isPassportRead;
    }

    @JsonProperty("isPassportRead")
    public void setIsPassportRead(String isPassportRead) {
        this.isPassportRead = isPassportRead;
    }

    public DocumentAuditInformation withIsPassportRead(String isPassportRead) {
        this.isPassportRead = isPassportRead;
        return this;
    }

    @JsonProperty("modifiedDate")
    public Date getModifiedDate() {
        return modifiedDate;
    }

    @JsonProperty("modifiedDate")
    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public DocumentAuditInformation withModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
        return this;
    }

    @JsonProperty("modifiedUserId")
    public String getModifiedUserId() {
        return modifiedUserId;
    }

    @JsonProperty("modifiedUserId")
    public void setModifiedUserId(String modifiedUserId) {
        this.modifiedUserId = modifiedUserId;
    }

    public DocumentAuditInformation withModifiedUserId(String modifiedUserId) {
        this.modifiedUserId = modifiedUserId;
        return this;
    }

    @JsonProperty("primId")
    public Long getPrimId() {
        return primId;
    }

    @JsonProperty("primId")
    public void setPrimId(Long primId) {
        this.primId = primId;
    }

    public DocumentAuditInformation withPrimId(Long primId) {
        this.primId = primId;
        return this;
    }

    @JsonProperty("readerBypassReason")
    public String getReaderBypassReason() {
        return readerBypassReason;
    }

    @JsonProperty("readerBypassReason")
    public void setReaderBypassReason(String readerBypassReason) {
        this.readerBypassReason = readerBypassReason;
    }

    public DocumentAuditInformation withReaderBypassReason(String readerBypassReason) {
        this.readerBypassReason = readerBypassReason;
        return this;
    }

    @JsonProperty("readerBypassed")
    public String getReaderBypassed() {
        return readerBypassed;
    }

    @JsonProperty("readerBypassed")
    public void setReaderBypassed(String readerBypassed) {
        this.readerBypassed = readerBypassed;
    }

    public DocumentAuditInformation withReaderBypassed(String readerBypassed) {
        this.readerBypassed = readerBypassed;
        return this;
    }

    @JsonProperty("scannerBypassReason")
    public String getScannerBypassReason() {
        return scannerBypassReason;
    }

    @JsonProperty("scannerBypassReason")
    public void setScannerBypassReason(String scannerBypassReason) {
        this.scannerBypassReason = scannerBypassReason;
    }

    public DocumentAuditInformation withScannerBypassReason(String scannerBypassReason) {
        this.scannerBypassReason = scannerBypassReason;
        return this;
    }

    @JsonProperty("scannerBypassed")
    public String getScannerBypassed() {
        return scannerBypassed;
    }

    @JsonProperty("scannerBypassed")
    public void setScannerBypassed(String scannerBypassed) {
        this.scannerBypassed = scannerBypassed;
    }

    public DocumentAuditInformation withScannerBypassed(String scannerBypassed) {
        this.scannerBypassed = scannerBypassed;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(additionalParameters).append(action).append(accountId).append(subrequestId).append(createdDate)
            .append(documentNumber).append(applicationFileName).append(channel).append(createdUserId).append(deletionStatus)
            .append(identityFileName).append(isApplicationScanned).append(isEidRead).append(isIdentityScanned).append(isPassportRead)
            .append(modifiedDate).append(modifiedUserId).append(primId).append(readerBypassReason).append(readerBypassed)
            .append(scannerBypassReason).append(scannerBypassed).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DocumentAuditInformation) == false) {
            return false;
        }
        DocumentAuditInformation rhs = ((DocumentAuditInformation) other);
        return new EqualsBuilder().append(additionalParameters, rhs.additionalParameters).append(action, rhs.action)
            .append(accountId, rhs.accountId).append(subrequestId, rhs.subrequestId).append(createdDate, rhs.createdDate)
            .append(documentNumber, rhs.documentNumber).append(applicationFileName, rhs.applicationFileName).append(channel, rhs.channel)
            .append(createdUserId, rhs.createdUserId).append(deletionStatus, rhs.deletionStatus)
            .append(identityFileName, rhs.identityFileName).append(isApplicationScanned, rhs.isApplicationScanned)
            .append(isEidRead, rhs.isEidRead).append(isIdentityScanned, rhs.isIdentityScanned).append(isPassportRead, rhs.isPassportRead)
            .append(modifiedDate, rhs.modifiedDate).append(modifiedUserId, rhs.modifiedUserId).append(primId, rhs.primId)
            .append(readerBypassReason, rhs.readerBypassReason).append(readerBypassed, rhs.readerBypassed)
            .append(scannerBypassReason, rhs.scannerBypassReason).append(scannerBypassed, rhs.scannerBypassed).isEquals();
    }

}
