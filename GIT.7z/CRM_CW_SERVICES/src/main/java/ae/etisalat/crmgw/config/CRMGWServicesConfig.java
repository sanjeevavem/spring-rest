package ae.etisalat.crmgw.config;



import javax.naming.NamingException;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

import ae.etisalat.cw.restws.config.CBCMRestWebAppConfig;



@Configuration
@ComponentScan(basePackages = {"ae.etisalat.cw","ae.etisalat.cw.activiti" })
public class CRMGWServicesConfig extends CBCMRestWebAppConfig  {

	@Bean
	public JpaTransactionManager geJpaTransactionManager() throws NamingException {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
		transactionManager.setDataSource(crmDataSource());
		return transactionManager;
	}

	@Bean
	public LocalContainerEntityManagerFactoryBean entityManagerFactory() throws NamingException {
		LocalContainerEntityManagerFactoryBean lef = new LocalContainerEntityManagerFactoryBean();
		lef.setDataSource(crmDataSource());
		lef.setJpaVendorAdapter(jpaVendorAdapter());
		lef.setPackagesToScan("ae.etisalat.cw.restws.jpa","ae.etisalat.cw.jpa");
		return lef;
	}


}
