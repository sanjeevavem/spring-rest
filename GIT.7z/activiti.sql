select * from act_ru_execution
   
select * from act_hi_actinst
   
select * from act_hi_detail
