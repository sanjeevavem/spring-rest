--oracle liquibase scripts 
@D:\Applications\activiti-database\liquibase.oracle.activiti.drop.admin.sql
@D:\Applications\activiti-database\liquibase.oracle.activiti.drop.app.sql
@D:\Applications\activiti-database\liquibase.oracle.activiti.drop.form.sql
@D:\Applications\activiti-database\liquibase.oracle.activiti.drop.dmn.sql
--oracle core activiti scripts
@D:\Applications\activiti-database\activiti.oracle.drop.engine.sql
@D:\Applications\activiti-database\activiti.oracle.drop.identity.sql
@D:\Applications\activiti-database\activiti.oracle.drop.history.sql
