-- oracle liquisbase create scripts
@D:\CBCMInterfaces\envsetup\liquibase.oracle.activiti.create.admin.sql
@D:\CBCMInterfaces\envsetup\liquibase.oracle.activiti.create.app.sql
@D:\CBCMInterfaces\envsetup\liquibase.oracle.activiti.create.form.sql
@D:\CBCMInterfaces\envsetup\liquibase.oracle.activiti.create.dmn.sql
-- oracle core activiti create scripts
@D:\CBCMInterfaces\envsetup\activiti.oracle.create.engine.sql
@D:\CBCMInterfaces\envsetup\activiti.oracle.create.identity.sql
@D:\CBCMInterfaces\envsetup\activiti.oracle.create.history.sql
