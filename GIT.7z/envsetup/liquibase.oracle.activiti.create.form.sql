INSERT INTO DATABASECHANGELOGLOCK(ID, LOCKED, LOCKGRANTED, LOCKEDBY) VALUES
((select max(ID) from DATABASECHANGELOGLOCK) + 1, 0, NULL, NULL);   

INSERT INTO DATABASECHANGELOG(ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, EXECTYPE, MD5SUM, DESCRIPTION, COMMENTS, TAG, LIQUIBASE) VALUES
('9', 'activiti', 'META-INF/activiti-form-db-changelog.xml', TIMESTAMP '2017-07-18 17:24:57.958', 1, 'EXECUTED', '7:913aee6a78e577fe455efed1d40980f1', 'createTable (x4)', '', NULL, '3.1.0');
--------------------------------------------------------
--  DDL for Table ACT_FO_FORM_DEFINITION
--------------------------------------------------------

  CREATE TABLE "ACT_FO_FORM_DEFINITION" 
   (	"ID_" VARCHAR2(255 BYTE), 
	"NAME_" VARCHAR2(255 BYTE), 
	"VERSION_" NUMBER(10,0), 
	"KEY_" VARCHAR2(255 BYTE), 
	"CATEGORY_" VARCHAR2(255 BYTE), 
	"DEPLOYMENT_ID_" VARCHAR2(255 BYTE), 
	"PARENT_DEPLOYMENT_ID_" VARCHAR2(255 BYTE), 
	"TENANT_ID_" VARCHAR2(255 BYTE), 
	"RESOURCE_NAME_" VARCHAR2(255 BYTE), 
	"DESCRIPTION_" VARCHAR2(255 BYTE)
   ) ;
--------------------------------------------------------
--  DDL for Table ACT_FO_FORM_DEPLOYMENT
--------------------------------------------------------

  CREATE TABLE "ACT_FO_FORM_DEPLOYMENT" 
   (	"ID_" VARCHAR2(255 BYTE), 
	"NAME_" VARCHAR2(255 BYTE), 
	"CATEGORY_" VARCHAR2(255 BYTE), 
	"DEPLOY_TIME_" TIMESTAMP (6), 
	"TENANT_ID_" VARCHAR2(255 BYTE), 
	"PARENT_DEPLOYMENT_ID_" VARCHAR2(255 BYTE)
   ) ;
--------------------------------------------------------
--  DDL for Table ACT_FO_FORM_RESOURCE
--------------------------------------------------------

  CREATE TABLE "ACT_FO_FORM_RESOURCE" 
   (	"ID_" VARCHAR2(255 BYTE), 
	"NAME_" VARCHAR2(255 BYTE), 
	"DEPLOYMENT_ID_" VARCHAR2(255 BYTE), 
	"RESOURCE_BYTES_" BLOB
   ) ;
--------------------------------------------------------
--  DDL for Table ACT_FO_SUBMITTED_FORM
--------------------------------------------------------

  CREATE TABLE "ACT_FO_SUBMITTED_FORM" 
   (	"ID_" VARCHAR2(255 BYTE), 
	"FORM_ID_" VARCHAR2(255 BYTE), 
	"TASK_ID_" VARCHAR2(255 BYTE), 
	"PROC_INST_ID_" VARCHAR2(255 BYTE), 
	"PROC_DEF_ID_" VARCHAR2(255 BYTE), 
	"SUBMITTED_DATE_" TIMESTAMP (6), 
	"SUBMITTED_BY_" VARCHAR2(255 BYTE), 
	"FORM_VALUES_ID_" VARCHAR2(255 BYTE), 
	"TENANT_ID_" VARCHAR2(255 BYTE)
   ) ;

--------------------------------------------------------
--  DDL for Index PK_ACT_FO_FORM_DEFINITION
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_ACT_FO_FORM_DEFINITION" ON "ACT_FO_FORM_DEFINITION" ("ID_") 
  ;
--------------------------------------------------------
--  DDL for Index PK_ACT_FO_FORM_DEPLOYMENT
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_ACT_FO_FORM_DEPLOYMENT" ON "ACT_FO_FORM_DEPLOYMENT" ("ID_") 
 ;
--------------------------------------------------------
--  DDL for Index PK_ACT_FO_FORM_RESOURCE
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_ACT_FO_FORM_RESOURCE" ON "ACT_FO_FORM_RESOURCE" ("ID_") 
  ;
--------------------------------------------------------
--  DDL for Index PK_ACT_FO_SUBMITTED_FORM
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_ACT_FO_SUBMITTED_FORM" ON "ACT_FO_SUBMITTED_FORM" ("ID_") 
  ;
--------------------------------------------------------
--  Constraints for Table ACT_FO_FORM_DEFINITION
--------------------------------------------------------

  ALTER TABLE "ACT_FO_FORM_DEFINITION" ADD CONSTRAINT "PK_ACT_FO_FORM_DEFINITION" PRIMARY KEY ("ID_")
   ENABLE;
  ALTER TABLE "ACT_FO_FORM_DEFINITION" MODIFY ("ID_" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ACT_FO_FORM_DEPLOYMENT
--------------------------------------------------------

  ALTER TABLE "ACT_FO_FORM_DEPLOYMENT" ADD CONSTRAINT "PK_ACT_FO_FORM_DEPLOYMENT" PRIMARY KEY ("ID_")
  ENABLE;
  ALTER TABLE "ACT_FO_FORM_DEPLOYMENT" MODIFY ("ID_" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ACT_FO_FORM_RESOURCE
--------------------------------------------------------

  ALTER TABLE "ACT_FO_FORM_RESOURCE" ADD CONSTRAINT "PK_ACT_FO_FORM_RESOURCE" PRIMARY KEY ("ID_")
   ENABLE;
  ALTER TABLE "ACT_FO_FORM_RESOURCE" MODIFY ("ID_" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ACT_FO_SUBMITTED_FORM
--------------------------------------------------------

  ALTER TABLE "ACT_FO_SUBMITTED_FORM" ADD CONSTRAINT "PK_ACT_FO_SUBMITTED_FORM" PRIMARY KEY ("ID_")
   ENABLE;
  ALTER TABLE "ACT_FO_SUBMITTED_FORM" MODIFY ("FORM_ID_" NOT NULL ENABLE);
  ALTER TABLE "ACT_FO_SUBMITTED_FORM" MODIFY ("ID_" NOT NULL ENABLE);
  