--------------------------------------------------------
--  DDL for Table DATABASECHANGELOG
--------------------------------------------------------

  CREATE TABLE "DATABASECHANGELOG" 
   (	"ID" VARCHAR2(255 BYTE), 
	"AUTHOR" VARCHAR2(255 BYTE), 
	"FILENAME" VARCHAR2(255 BYTE), 
	"DATEEXECUTED" TIMESTAMP, 
	"ORDEREXECUTED" NUMBER(10,0), 
	"EXECTYPE" VARCHAR2(10 BYTE), 
	"MD5SUM" VARCHAR2(35 BYTE), 
	"DESCRIPTION" VARCHAR2(255 BYTE), 
	"COMMENTS" VARCHAR2(255 BYTE), 
	"TAG" VARCHAR2(255 BYTE), 
	"LIQUIBASE" VARCHAR2(20 BYTE)
   ) ;

 -- 7 +/- SELECT COUNT(*) FROM DATABASECHANGELOG;       
INSERT INTO DATABASECHANGELOG(ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, EXECTYPE, MD5SUM, DESCRIPTION, COMMENTS, TAG, LIQUIBASE) VALUES
('1', 'activiti', 'META-INF/liquibase/db-changelog.xml', CURRENT_TIMESTAMP, 1, 'EXECUTED', '7:dc16fcb9fc97d65ec61e149a93a5a990', 'createTable (x4), createIndex, addForeignKeyConstraint (x2), loadData (x3), createTable (x2), addForeignKeyConstraint, createTable, addForeignKeyConstraint', '', NULL, '3.1.0');
INSERT INTO DATABASECHANGELOG(ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, EXECTYPE, MD5SUM, DESCRIPTION, COMMENTS, TAG, LIQUIBASE) VALUES
('2', 'jbarrez', 'META-INF/liquibase/db-changelog.xml', CURRENT_TIMESTAMP, 2, 'EXECUTED', '7:65db705966deabf0f802659bdffa1a58', 'addColumn', '', NULL, '3.1.0');
INSERT INTO DATABASECHANGELOG(ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, EXECTYPE, MD5SUM, DESCRIPTION, COMMENTS, TAG, LIQUIBASE) VALUES
('3', 'tijsrademakers', 'META-INF/liquibase/db-changelog.xml', CURRENT_TIMESTAMP, 3, 'EXECUTED', '7:21a2bfefaf358eeed0f65579c372c11d', 'addColumn', '', NULL, '3.1.0');
INSERT INTO DATABASECHANGELOG(ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, EXECTYPE, MD5SUM, DESCRIPTION, COMMENTS, TAG, LIQUIBASE) VALUES
('4', 'activiti', 'META-INF/liquibase/db-changelog.xml', CURRENT_TIMESTAMP, 4, 'EXECUTED', '7:03775b6153f580ba0f8669a363ce3aa5', 'dropColumn (x11), loadData, addColumn, addForeignKeyConstraint', '', NULL, '3.1.0');
INSERT INTO DATABASECHANGELOG(ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, EXECTYPE, MD5SUM, DESCRIPTION, COMMENTS, TAG, LIQUIBASE) VALUES
('5', 'activiti', 'META-INF/liquibase/db-changelog.xml', CURRENT_TIMESTAMP, 5, 'EXECUTED', '7:68f42298922a12eb8be9af92ae487a9e', 'dropTable, createTable, addForeignKeyConstraint', '', NULL, '3.1.0');
INSERT INTO DATABASECHANGELOG(ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, EXECTYPE, MD5SUM, DESCRIPTION, COMMENTS, TAG, LIQUIBASE) VALUES
('6', 'activiti', 'META-INF/liquibase/db-changelog.xml', CURRENT_TIMESTAMP, 6, 'EXECUTED', '7:d827d8a126adcf54c1a6a1bef01e20da', 'addColumn', '', NULL, '3.1.0');
INSERT INTO DATABASECHANGELOG(ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, EXECTYPE, MD5SUM, DESCRIPTION, COMMENTS, TAG, LIQUIBASE) VALUES
('7', 'activiti', 'META-INF/liquibase/db-changelog.xml', CURRENT_TIMESTAMP, 7, 'EXECUTED', '7:39a16c8b2b57d6fd40731f77dd9bf0f9', 'addColumn', '', NULL, '3.1.0');   
   
--------------------------------------------------------
--  DDL for Table DATABASECHANGELOGLOCK
--------------------------------------------------------

  CREATE TABLE "DATABASECHANGELOGLOCK" 
   ( "ID" NUMBER(10,0), 
	 "LOCKED" NUMBER(1,0),
	 "LOCKGRANTED" TIMESTAMP, 
	 "LOCKEDBY" VARCHAR2(255 BYTE)
   );
--------------------------------------------------------
--  DDL for Table AUTHORITY
--------------------------------------------------------

  CREATE TABLE "AUTHORITY" 
   (	"NAME" VARCHAR2(255 BYTE)
   ) ;
--------------------------------------------------------
--  DDL for Table CLUSTER_CONFIG
--------------------------------------------------------

  CREATE TABLE "CLUSTER_CONFIG" 
   (	"ID" NUMBER(38,0), 
	"CLUSTER_NAME" VARCHAR2(255 BYTE), 
	"CLUSTER_PASSWORD" VARCHAR2(255 BYTE), 
	"REQUIRES_MASTER_CFG" NUMBER(1,0), 
	"METRIC_SENDING_INTERVAL" NUMBER(10,0), 
	"TCPIP_ADMIN_IP" VARCHAR2(255 BYTE), 
	"TCPIP_ADMIN_PORT" NUMBER(10,0), 
	"USER_ID" VARCHAR2(50 BYTE), 
	"CREATED_BY" VARCHAR2(50 BYTE)
   );

--------------------------------------------------------
--  DDL for Table HIBERNATE_SEQUENCES
--------------------------------------------------------

  CREATE TABLE "HIBERNATE_SEQUENCES" 
   (	"SEQUENCE_NAME" VARCHAR2(255 BYTE), 
	"SEQUENCE_NEXT_HI_VALUE" NUMBER(10,0)
   ) ;
--------------------------------------------------------
--  DDL for Table MASTER_CONFIG
--------------------------------------------------------

  CREATE TABLE "MASTER_CONFIG" 
   (	"ID" NUMBER(38,0), 
	"CONFIG_ID" VARCHAR2(255 BYTE), 
	"CLUSTER_CONFIG_ID" NUMBER(38,0), 
	"CONFIG_TYPE" VARCHAR2(255 BYTE), 
	"CONFIG_JSON" CLOB
   ) ;
--------------------------------------------------------
--  DDL for Table SERVER_CONFIG
--------------------------------------------------------

  CREATE TABLE "SERVER_CONFIG" 
   (	"ID" NUMBER(38,0), 
	"NAME" VARCHAR2(50 BYTE), 
	"DESCRIPTION" VARCHAR2(255 BYTE), 
	"SERVER_ADDRESS" VARCHAR2(100 BYTE), 
	"PORT" NUMBER(10,0), 
	"CONTEXT_ROOT" VARCHAR2(100 BYTE), 
	"REST_ROOT" VARCHAR2(100 BYTE), 
	"USER_NAME" VARCHAR2(100 BYTE), 
	"password" VARCHAR2(100 BYTE), 
	"CLUSTER_CONFIG_ID" NUMBER(38,0), 
	"TENANT_ID" VARCHAR2(50 BYTE)
   ) ;
--------------------------------------------------------
--  DDL for Table USER_AUTHORITY
--------------------------------------------------------

  CREATE TABLE "USER_AUTHORITY" 
   (	"LOGIN" VARCHAR2(50 BYTE), 
	"NAME" VARCHAR2(255 BYTE)
   );
--------------------------------------------------------
--  DDL for Table USER_INFO
--------------------------------------------------------

  CREATE TABLE "USER_INFO" 
   (	"LOGIN" VARCHAR2(50 BYTE), 
	"password" VARCHAR2(100 BYTE), 
	"FIRST_NAME" VARCHAR2(50 BYTE), 
	"LAST_NAME" VARCHAR2(50 BYTE), 
	"EMAIL" VARCHAR2(100 BYTE)
   ) ;

-- 1 +/- SELECT COUNT(*) FROM DATABASECHANGELOGLOCK;   
INSERT INTO DATABASECHANGELOGLOCK(ID, LOCKED, LOCKGRANTED, LOCKEDBY) VALUES
(1, 0, NULL, NULL);      
      
Insert into AUTHORITY (NAME) values ('ROLE_ADMIN');
Insert into AUTHORITY (NAME) values ('ROLE_CLUSTER_MANAGER');
Insert into AUTHORITY (NAME) values ('ROLE_USER');

Insert into USER_AUTHORITY (LOGIN,NAME) values ('admin','ROLE_ADMIN');
Insert into USER_AUTHORITY (LOGIN,NAME) values ('admin','ROLE_USER');

Insert into USER_INFO (LOGIN,"password",FIRST_NAME,LAST_NAME,EMAIL) values ('admin','b8f57d6d6ec0a60dfe2e20182d4615b12e321cad9e2979e0b9f81e0d6eda78ad9b6dcfe53e4e22d1',null,'Administrator',null);
--------------------------------------------------------
--  DDL for Index PK_AUTHORITY
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_AUTHORITY" ON "AUTHORITY" ("NAME") ;
 
--------------------------------------------------------
--  DDL for Index PK_CLUSTER_CONFIG
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_CLUSTER_CONFIG" ON "CLUSTER_CONFIG" ("ID") 
  ;
--------------------------------------------------------
--  DDL for Index PK_MASTER_CONFIG
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_MASTER_CONFIG" ON "MASTER_CONFIG" ("ID") 
  ;
--------------------------------------------------------
--  DDL for Index PK_SERVER_CONFIG
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_SERVER_CONFIG" ON "SERVER_CONFIG" ("ID") 
  ;
--------------------------------------------------------
--  DDL for Index IDX_USER_AUTHORITY
--------------------------------------------------------

  CREATE UNIQUE INDEX "IDX_USER_AUTHORITY" ON "USER_AUTHORITY" ("LOGIN", "NAME") 
  ;
--------------------------------------------------------
--  DDL for Index PK_USER_INFO
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_USER_INFO" ON "USER_INFO" ("LOGIN") 
  ;
--------------------------------------------------------
--  Constraints for Table AUTHORITY
--------------------------------------------------------

  ALTER TABLE "AUTHORITY" ADD CONSTRAINT "PK_AUTHORITY" PRIMARY KEY ("NAME")
  ENABLE;
  ALTER TABLE "AUTHORITY" MODIFY ("NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CLUSTER_CONFIG
--------------------------------------------------------

  ALTER TABLE "CLUSTER_CONFIG" ADD CONSTRAINT "PK_CLUSTER_CONFIG" PRIMARY KEY ("ID")
  ENABLE;
  ALTER TABLE "CLUSTER_CONFIG" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table DATABASECHANGELOG
--------------------------------------------------------

  ALTER TABLE "DATABASECHANGELOG" MODIFY ("EXECTYPE" NOT NULL ENABLE);
  ALTER TABLE "DATABASECHANGELOG" MODIFY ("ORDEREXECUTED" NOT NULL ENABLE);
  ALTER TABLE "DATABASECHANGELOG" MODIFY ("DATEEXECUTED" NOT NULL ENABLE);
  ALTER TABLE "DATABASECHANGELOG" MODIFY ("FILENAME" NOT NULL ENABLE);
  ALTER TABLE "DATABASECHANGELOG" MODIFY ("AUTHOR" NOT NULL ENABLE);
  ALTER TABLE "DATABASECHANGELOG" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table DATABASECHANGELOGLOCK
--------------------------------------------------------

  ALTER TABLE "DATABASECHANGELOGLOCK" ADD CONSTRAINT "PK_DATABASECHANGELOGLOCK" PRIMARY KEY ("ID")
  ENABLE;
  ALTER TABLE "DATABASECHANGELOGLOCK" MODIFY ("LOCKED" NOT NULL ENABLE);
  ALTER TABLE "DATABASECHANGELOGLOCK" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table MASTER_CONFIG
--------------------------------------------------------

  ALTER TABLE "MASTER_CONFIG" ADD CONSTRAINT "PK_MASTER_CONFIG" PRIMARY KEY ("ID") ENABLE;
  
  ALTER TABLE "MASTER_CONFIG" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table SERVER_CONFIG
--------------------------------------------------------

  ALTER TABLE "SERVER_CONFIG" ADD CONSTRAINT "PK_SERVER_CONFIG" PRIMARY KEY ("ID")
  ENABLE;
  ALTER TABLE "SERVER_CONFIG" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table USER_INFO
--------------------------------------------------------

  ALTER TABLE "USER_INFO" ADD CONSTRAINT "PK_USER_INFO" PRIMARY KEY ("LOGIN")
  ENABLE;
  ALTER TABLE "USER_INFO" MODIFY ("LOGIN" NOT NULL ENABLE);
--------------------------------------------------------
--  Ref Constraints for Table CLUSTER_CONFIG
--------------------------------------------------------

  ALTER TABLE "CLUSTER_CONFIG" ADD CONSTRAINT "FK_CLUSTER_CFG_USER" FOREIGN KEY ("USER_ID")
	  REFERENCES "USER_INFO" ("LOGIN") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table MASTER_CONFIG
--------------------------------------------------------

  ALTER TABLE "MASTER_CONFIG" ADD CONSTRAINT "FK_MASTER_CFG_CLUSTER_CFG_ID" FOREIGN KEY ("CLUSTER_CONFIG_ID")
	  REFERENCES "CLUSTER_CONFIG" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table SERVER_CONFIG
--------------------------------------------------------

  ALTER TABLE "SERVER_CONFIG" ADD CONSTRAINT "FK_SERVERCFG_CLUSTER_CFG_ID" FOREIGN KEY ("CLUSTER_CONFIG_ID")
	  REFERENCES "CLUSTER_CONFIG" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table USER_AUTHORITY
--------------------------------------------------------

  ALTER TABLE "USER_AUTHORITY" ADD CONSTRAINT "FK_AUTHORITY_NAME" FOREIGN KEY ("NAME")
	  REFERENCES "AUTHORITY" ("NAME") ENABLE;
  ALTER TABLE "USER_AUTHORITY" ADD CONSTRAINT "FK_USER_LOGIN" FOREIGN KEY ("LOGIN")
	  REFERENCES "USER_INFO" ("LOGIN") ENABLE;
