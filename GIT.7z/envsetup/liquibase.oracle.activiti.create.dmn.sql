-- 1 +/- SELECT COUNT(*) FROM DATABASECHANGELOGLOCK;   
INSERT INTO DATABASECHANGELOGLOCK(ID, LOCKED, LOCKGRANTED, LOCKEDBY) VALUES
((SELECT MAX(ID) FROM DATABASECHANGELOGLOCK)+1, 0, NULL, NULL);   

-- 1 +/- SELECT COUNT(*) FROM DATABASECHANGELOG;       
INSERT INTO DATABASECHANGELOG(ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, EXECTYPE, MD5SUM, DESCRIPTION, COMMENTS, TAG, LIQUIBASE) VALUES
('10', 'activiti', 'META-INF/activiti-dmn-db-changelog.xml', CURRENT_TIMESTAMP, 1, 'EXECUTED', '7:d878c2672ead57b5801578fd39c423af', 'createTable (x3)', '', NULL, '3.1.0');        

--------------------------------------------------------
--  DDL for Table ACT_DMN_DECISION_TABLE
--------------------------------------------------------

  CREATE TABLE "ACT_DMN_DECISION_TABLE" 
   (	"ID_" VARCHAR2(255 BYTE), 
	"NAME_" VARCHAR2(255 BYTE), 
	"VERSION_" NUMBER(10,0), 
	"KEY_" VARCHAR2(255 BYTE), 
	"CATEGORY_" VARCHAR2(255 BYTE), 
	"DEPLOYMENT_ID_" VARCHAR2(255 BYTE), 
	"PARENT_DEPLOYMENT_ID_" VARCHAR2(255 BYTE), 
	"TENANT_ID_" VARCHAR2(255 BYTE), 
	"RESOURCE_NAME_" VARCHAR2(255 BYTE), 
	"DESCRIPTION_" VARCHAR2(255 BYTE)
   ) ;
--------------------------------------------------------
--  DDL for Table ACT_DMN_DEPLOYMENT
--------------------------------------------------------

  CREATE TABLE "ACT_DMN_DEPLOYMENT" 
   (	"ID_" VARCHAR2(255 BYTE), 
	"NAME_" VARCHAR2(255 BYTE), 
	"CATEGORY_" VARCHAR2(255 BYTE), 
	"DEPLOY_TIME_" TIMESTAMP (6), 
	"TENANT_ID_" VARCHAR2(255 BYTE), 
	"PARENT_DEPLOYMENT_ID_" VARCHAR2(255 BYTE)
   ) ;
--------------------------------------------------------
--  DDL for Table ACT_DMN_DEPLOYMENT_RESOURCE
--------------------------------------------------------

  CREATE TABLE "ACT_DMN_DEPLOYMENT_RESOURCE" 
   (	"ID_" VARCHAR2(255 BYTE), 
	"NAME_" VARCHAR2(255 BYTE), 
	"DEPLOYMENT_ID_" VARCHAR2(255 BYTE), 
	"RESOURCE_BYTES_" BLOB
   ) ;

--------------------------------------------------------
--  DDL for Index PK_ACT_DMN_DECISION_TABLE
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_ACT_DMN_DECISION_TABLE" ON "ACT_DMN_DECISION_TABLE" ("ID_") 
 ;
--------------------------------------------------------
--  DDL for Index PK_ACT_DMN_DEPLOYMENT
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_ACT_DMN_DEPLOYMENT" ON "ACT_DMN_DEPLOYMENT" ("ID_") 
  ;
--------------------------------------------------------
--  DDL for Index PK_ACT_DMN_DEPLOYMENT_RESOURCE
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_ACT_DMN_DEPLOYMENT_RESOURCE" ON "ACT_DMN_DEPLOYMENT_RESOURCE" ("ID_") 
  ;
--------------------------------------------------------
--  Constraints for Table ACT_DMN_DECISION_TABLE
--------------------------------------------------------

  ALTER TABLE "ACT_DMN_DECISION_TABLE" ADD CONSTRAINT "PK_ACT_DMN_DECISION_TABLE" PRIMARY KEY ("ID_")
   ENABLE;
  ALTER TABLE "ACT_DMN_DECISION_TABLE" MODIFY ("ID_" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ACT_DMN_DEPLOYMENT
--------------------------------------------------------

  ALTER TABLE "ACT_DMN_DEPLOYMENT" ADD CONSTRAINT "PK_ACT_DMN_DEPLOYMENT" PRIMARY KEY ("ID_")
  ENABLE;
  ALTER TABLE "ACT_DMN_DEPLOYMENT" MODIFY ("ID_" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ACT_DMN_DEPLOYMENT_RESOURCE
--------------------------------------------------------

  ALTER TABLE "ACT_DMN_DEPLOYMENT_RESOURCE" ADD CONSTRAINT "PK_ACT_DMN_DEPLOYMENT_RESOURCE" PRIMARY KEY ("ID_")
  ENABLE;
  ALTER TABLE "ACT_DMN_DEPLOYMENT_RESOURCE" MODIFY ("ID_" NOT NULL ENABLE);
  