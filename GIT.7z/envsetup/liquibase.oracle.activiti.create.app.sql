INSERT INTO DATABASECHANGELOGLOCK(ID, LOCKED, LOCKGRANTED, LOCKEDBY) VALUES
(2,0, NULL, NULL);   

INSERT INTO DATABASECHANGELOG(ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, EXECTYPE, MD5SUM, DESCRIPTION, COMMENTS, TAG, LIQUIBASE) VALUES
('8', 'activiti', 'META-INF/liquibase/activiti-app-db-changelog.xml', CURRENT_TIMESTAMP, 1, 'EXECUTED', '7:670797aeab8d035a4350ea2c794a7e46', 'createTable (x3), createIndex, createTable, createIndex, createTable, createIndex (x2), createTable, createIndex (x3), createTable, addForeignKeyConstraint (x2)', '', NULL, '3.1.0');              

--------------------------------------------------------
--  DDL for Table ACT_DE_MODEL
--------------------------------------------------------

  CREATE TABLE "ACT_DE_MODEL" 
   (	"ID" VARCHAR2(255 BYTE), 
	"NAME" VARCHAR2(400 BYTE), 
	"MODEL_KEY" VARCHAR2(400 BYTE), 
	"DESCRIPTION" VARCHAR2(4000 BYTE), 
	"MODEL_COMMENT" VARCHAR2(4000 BYTE), 
	"CREATED" TIMESTAMP (6), 
	"CREATED_BY" VARCHAR2(255 BYTE), 
	"LAST_UPDATED" TIMESTAMP (6), 
	"LAST_UPDATED_BY" VARCHAR2(255 BYTE), 
	"VERSION" NUMBER(10,0), 
	"MODEL_EDITOR_JSON" CLOB, 
	"THUMBNAIL" BLOB, 
	"MODEL_TYPE" NUMBER(10,0)
   ) ;
--------------------------------------------------------
--  DDL for Table ACT_DE_MODEL_HISTORY
--------------------------------------------------------

  CREATE TABLE "ACT_DE_MODEL_HISTORY" 
   (	"ID" VARCHAR2(255 BYTE), 
	"NAME" VARCHAR2(400 BYTE), 
	"MODEL_KEY" VARCHAR2(400 BYTE), 
	"DESCRIPTION" VARCHAR2(4000 BYTE), 
	"MODEL_COMMENT" VARCHAR2(4000 BYTE), 
	"CREATED" TIMESTAMP (6), 
	"CREATED_BY" VARCHAR2(255 BYTE), 
	"LAST_UPDATED" TIMESTAMP (6), 
	"LAST_UPDATED_BY" VARCHAR2(255 BYTE), 
	"REMOVAL_DATE" TIMESTAMP (6), 
	"VERSION" NUMBER(10,0), 
	"MODEL_EDITOR_JSON" CLOB, 
	"MODEL_ID" VARCHAR2(255 BYTE), 
	"MODEL_TYPE" NUMBER(10,0)
   ) ;
--------------------------------------------------------
--  DDL for Table ACT_DE_MODEL_RELATION
--------------------------------------------------------

  CREATE TABLE "ACT_DE_MODEL_RELATION" 
   (	"ID" VARCHAR2(255 BYTE), 
	"PARENT_MODEL_ID" VARCHAR2(255 BYTE), 
	"MODEL_ID" VARCHAR2(255 BYTE), 
	"RELATION_TYPE" VARCHAR2(255 BYTE)
   ) ;
--------------------------------------------------------
--  DDL for Table ACT_IDM_PERSISTENT_TOKEN
--------------------------------------------------------

  CREATE TABLE "ACT_IDM_PERSISTENT_TOKEN" 
   (	"SERIES" VARCHAR2(255 BYTE), 
	"USER_ID" VARCHAR2(255 BYTE), 
	"TOKEN_VALUE" VARCHAR2(255 BYTE), 
	"TOKEN_DATE" TIMESTAMP (6), 
	"IP_ADDRESS" VARCHAR2(39 BYTE), 
	"USER_AGENT" VARCHAR2(255 BYTE)
   ) ;
--------------------------------------------------------
--  DDL for Table ACT_WO_COMMENTS
--------------------------------------------------------

  CREATE TABLE "ACT_WO_COMMENTS" 
   (	"ID" NUMBER(38,0), 
	"MESSAGE" VARCHAR2(4000 BYTE), 
	"CREATED" TIMESTAMP (6), 
	"CREATED_BY" VARCHAR2(255 BYTE), 
	"TASK_ID" VARCHAR2(255 BYTE), 
	"PROC_INST_ID" VARCHAR2(255 BYTE), 
	"COMMENT_DEFINITION" CLOB
   );
--------------------------------------------------------
--  DDL for Table ACT_WO_RELATED_CONTENT
--------------------------------------------------------

  CREATE TABLE "ACT_WO_RELATED_CONTENT" 
   (	"ID" NUMBER(38,0), 
	"NAME" VARCHAR2(255 BYTE), 
	"CREATED" TIMESTAMP (6), 
	"CREATED_BY" VARCHAR2(255 BYTE), 
	"TASK_ID" VARCHAR2(255 BYTE), 
	"PROCESS_ID" VARCHAR2(255 BYTE), 
	"CONTENT_SOURCE" VARCHAR2(255 BYTE), 
	"SOURCE_ID" VARCHAR2(4000 BYTE), 
	"STORE_ID" VARCHAR2(255 BYTE), 
	"MIME_TYPE" VARCHAR2(255 BYTE), 
	"FIELD" VARCHAR2(400 BYTE), 
	"RELATED_CONTENT" NUMBER(1,0), 
	"LINK" NUMBER(1,0), 
	"LINK_URL" VARCHAR2(4000 BYTE), 
	"CONTENT_AVAILABLE" NUMBER(1,0) DEFAULT 0, 
	"LOCKED" NUMBER(1,0) DEFAULT 0, 
	"LOCK_DATE" TIMESTAMP (6), 
	"LOCK_EXP_DATE" TIMESTAMP (6), 
	"LOCK_OWNER" VARCHAR2(255 BYTE), 
	"CHECKED_OUT" NUMBER(1,0) DEFAULT 0, 
	"CHECKOUT_DATE" TIMESTAMP (6), 
	"CHECKOUT_OWNER" VARCHAR2(255 BYTE), 
	"LAST_MODIFIED" TIMESTAMP (6), 
	"LAST_MODIFIED_BY" VARCHAR2(255 BYTE), 
	"CHECKED_OUT_TO_LOCAL" NUMBER(1,0) DEFAULT 0, 
	"CONTENT_SIZE" NUMBER(38,0) DEFAULT 0
   ) ;

--------------------------------------------------------
--  DDL for Index PK_ACT_DE_MODEL
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_ACT_DE_MODEL" ON "ACT_DE_MODEL" ("ID") 
  ;
--------------------------------------------------------
--  DDL for Index IDX_PROC_MOD_CREATED
--------------------------------------------------------

  CREATE INDEX "IDX_PROC_MOD_CREATED" ON "ACT_DE_MODEL" ("CREATED_BY") 
 ;
--------------------------------------------------------
--  DDL for Index PK_ACT_DE_MODEL_HISTORY
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_ACT_DE_MODEL_HISTORY" ON "ACT_DE_MODEL_HISTORY" ("ID") 
;
--------------------------------------------------------
--  DDL for Index IDX_PROC_MOD_HISTORY_PROC
--------------------------------------------------------

  CREATE INDEX "IDX_PROC_MOD_HISTORY_PROC" ON "ACT_DE_MODEL_HISTORY" ("MODEL_ID") 
  ;
--------------------------------------------------------
--  DDL for Index PK_ACT_DE_MODEL_RELATION
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_ACT_DE_MODEL_RELATION" ON "ACT_DE_MODEL_RELATION" ("ID") 
;
--------------------------------------------------------
--  DDL for Index PK_ACT_IDM_PERSISTENT_TOKEN
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_ACT_IDM_PERSISTENT_TOKEN" ON "ACT_IDM_PERSISTENT_TOKEN" ("SERIES") 
 ;
--------------------------------------------------------
--  DDL for Index PK_ACT_WO_COMMENTS
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_ACT_WO_COMMENTS" ON "ACT_WO_COMMENTS" ("ID") 
 ;
--------------------------------------------------------
--  DDL for Index COMMENT_TASK_CREATED
--------------------------------------------------------

  CREATE INDEX "COMMENT_TASK_CREATED" ON "ACT_WO_COMMENTS" ("TASK_ID", "CREATED") 
 ;
--------------------------------------------------------
--  DDL for Index COMMENT_PROC_CREATED
--------------------------------------------------------

  CREATE INDEX "COMMENT_PROC_CREATED" ON "ACT_WO_COMMENTS" ("PROC_INST_ID", "CREATED") 
  ;
--------------------------------------------------------
--  DDL for Index PK_ACT_WO_RELATED_CONTENT
--------------------------------------------------------

  CREATE UNIQUE INDEX "PK_ACT_WO_RELATED_CONTENT" ON "ACT_WO_RELATED_CONTENT" ("ID") 
  ;
--------------------------------------------------------
--  DDL for Index IDX_RELCONT_CREATEDBY
--------------------------------------------------------

  CREATE INDEX "IDX_RELCONT_CREATEDBY" ON "ACT_WO_RELATED_CONTENT" ("CREATED_BY") 
  ;
--------------------------------------------------------
--  DDL for Index IDX_RELCONT_TASKID
--------------------------------------------------------

  CREATE INDEX "IDX_RELCONT_TASKID" ON "ACT_WO_RELATED_CONTENT" ("TASK_ID") 
;
--------------------------------------------------------
--  DDL for Index IDX_RELCONT_PROCID
--------------------------------------------------------

  CREATE INDEX "IDX_RELCONT_PROCID" ON "ACT_WO_RELATED_CONTENT" ("PROCESS_ID") 
  ;
--------------------------------------------------------
--  Constraints for Table ACT_DE_MODEL
--------------------------------------------------------

  ALTER TABLE "ACT_DE_MODEL" ADD CONSTRAINT "PK_ACT_DE_MODEL" PRIMARY KEY ("ID")
 ENABLE;
  ALTER TABLE "ACT_DE_MODEL" MODIFY ("MODEL_KEY" NOT NULL ENABLE);
  ALTER TABLE "ACT_DE_MODEL" MODIFY ("NAME" NOT NULL ENABLE);
  ALTER TABLE "ACT_DE_MODEL" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ACT_DE_MODEL_HISTORY
--------------------------------------------------------

  ALTER TABLE "ACT_DE_MODEL_HISTORY" ADD CONSTRAINT "PK_ACT_DE_MODEL_HISTORY" PRIMARY KEY ("ID")
ENABLE;
  ALTER TABLE "ACT_DE_MODEL_HISTORY" MODIFY ("MODEL_ID" NOT NULL ENABLE);
  ALTER TABLE "ACT_DE_MODEL_HISTORY" MODIFY ("MODEL_KEY" NOT NULL ENABLE);
  ALTER TABLE "ACT_DE_MODEL_HISTORY" MODIFY ("NAME" NOT NULL ENABLE);
  ALTER TABLE "ACT_DE_MODEL_HISTORY" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ACT_DE_MODEL_RELATION
--------------------------------------------------------

  ALTER TABLE "ACT_DE_MODEL_RELATION" ADD CONSTRAINT "PK_ACT_DE_MODEL_RELATION" PRIMARY KEY ("ID")
  ENABLE;
  ALTER TABLE "ACT_DE_MODEL_RELATION" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ACT_IDM_PERSISTENT_TOKEN
--------------------------------------------------------

  ALTER TABLE "ACT_IDM_PERSISTENT_TOKEN" ADD CONSTRAINT "PK_ACT_IDM_PERSISTENT_TOKEN" PRIMARY KEY ("SERIES")
  ENABLE;
  ALTER TABLE "ACT_IDM_PERSISTENT_TOKEN" MODIFY ("SERIES" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ACT_WO_COMMENTS
--------------------------------------------------------

  ALTER TABLE "ACT_WO_COMMENTS" ADD CONSTRAINT "PK_ACT_WO_COMMENTS" PRIMARY KEY ("ID")
  ENABLE;
  ALTER TABLE "ACT_WO_COMMENTS" MODIFY ("MESSAGE" NOT NULL ENABLE);
  ALTER TABLE "ACT_WO_COMMENTS" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ACT_WO_RELATED_CONTENT
--------------------------------------------------------

  ALTER TABLE "ACT_WO_RELATED_CONTENT" ADD CONSTRAINT "PK_ACT_WO_RELATED_CONTENT" PRIMARY KEY ("ID")
   ENABLE;
  ALTER TABLE "ACT_WO_RELATED_CONTENT" MODIFY ("LINK" NOT NULL ENABLE);
  ALTER TABLE "ACT_WO_RELATED_CONTENT" MODIFY ("RELATED_CONTENT" NOT NULL ENABLE);
  ALTER TABLE "ACT_WO_RELATED_CONTENT" MODIFY ("NAME" NOT NULL ENABLE);
  ALTER TABLE "ACT_WO_RELATED_CONTENT" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Ref Constraints for Table ACT_DE_MODEL_RELATION
--------------------------------------------------------

  ALTER TABLE "ACT_DE_MODEL_RELATION" ADD CONSTRAINT "FK_RELATION_CHILD" FOREIGN KEY ("MODEL_ID")
	  REFERENCES "ACT_DE_MODEL" ("ID") ENABLE;
  ALTER TABLE "ACT_DE_MODEL_RELATION" ADD CONSTRAINT "FK_RELATION_PARENT" FOREIGN KEY ("PARENT_MODEL_ID")
	  REFERENCES "ACT_DE_MODEL" ("ID") ENABLE;
