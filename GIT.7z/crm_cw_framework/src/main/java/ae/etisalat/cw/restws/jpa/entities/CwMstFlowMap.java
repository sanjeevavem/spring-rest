package ae.etisalat.cw.restws.jpa.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the CW_MST_FLOW_MAP database table.
 * 
 */
@Entity
@Table(name="CW_MST_FLOW_MAP")
@NamedNativeQueries({
@NamedNativeQuery(name="CwMstFlowMap.findAll",query="SELECT * FROM CW_MST_FLOW_MAP",resultClass=CwMstFlowMap.class),
@NamedNativeQuery(name="CwMstFlowMap.findByOrderTypeAndFlowTypeAndPGAndProduct",query="SELECT * FROM CW_MST_FLOW_MAP WHERE ORDER_TYPE=:ORDER_TYPE AND FLOW_TYPE=:FLOW_TYPE AND PRODUCT_GROUP=:PRODUCT_GROUP AND PRODUCT=:PRODUCT AND DELETION_STATUS='N'",resultClass=CwMstFlowMap.class)
})

public class CwMstFlowMap implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="MST_FLOW_MAP_GENERATOR", sequenceName="SQ_CW_MST_FLOW_MAP",allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="MST_FLOW_MAP_GENERATOR")
	private BigDecimal id;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	private String description;

	@Column(name="FLOW_CODE")
	private String flowCode;

	@Column(name="FLOW_SEQUENCE")
	private BigDecimal flowSequence;

	@Column(name="FLOW_TYPE")
	private String flowType;

	@Lob
	@Column(name="JSON_VALIDATION_TEMPLATE")
	private String jsonValidationTemplate;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="OFFER_CODE")
	private String offerCode;

	@Column(name="OFFER_TYPE")
	private String offerType;

	@Column(name="ORDER_TYPE")
	private String orderType;

	private String product;

	@Column(name="PRODUCT_GROUP")
	private String productGroup;

	private String region;

	@Column(name="VALIDATION_SCHEMA_TEMPLATE")
	private String validationSchemaTemplate;

	public CwMstFlowMap() {
	}

	public BigDecimal getId() {
		return this.id;
	}

	public void setId(BigDecimal id) {
		this.id = id;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFlowCode() {
		return this.flowCode;
	}

	public void setFlowCode(String flowCode) {
		this.flowCode = flowCode;
	}

	public BigDecimal getFlowSequence() {
		return this.flowSequence;
	}

	public void setFlowSequence(BigDecimal flowSequence) {
		this.flowSequence = flowSequence;
	}

	public String getFlowType() {
		return this.flowType;
	}

	public void setFlowType(String flowType) {
		this.flowType = flowType;
	}

	public String getJsonValidationTemplate() {
		return this.jsonValidationTemplate;
	}

	public void setJsonValidationTemplate(String jsonValidationTemplate) {
		this.jsonValidationTemplate = jsonValidationTemplate;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getOfferCode() {
		return this.offerCode;
	}

	public void setOfferCode(String offerCode) {
		this.offerCode = offerCode;
	}

	public String getOfferType() {
		return this.offerType;
	}

	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}

	public String getOrderType() {
		return this.orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public String getProduct() {
		return this.product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getProductGroup() {
		return this.productGroup;
	}

	public void setProductGroup(String productGroup) {
		this.productGroup = productGroup;
	}

	public String getRegion() {
		return this.region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getValidationSchemaTemplate() {
		return this.validationSchemaTemplate;
	}

	public void setValidationSchemaTemplate(String validationSchemaTemplate) {
		this.validationSchemaTemplate = validationSchemaTemplate;
	}

}