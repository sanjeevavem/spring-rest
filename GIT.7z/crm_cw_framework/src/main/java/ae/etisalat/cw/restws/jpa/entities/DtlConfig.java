package ae.etisalat.cw.restws.jpa.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name="DTL_CONFIG")
@NamedNativeQueries({
	@NamedNativeQuery(name="DtlConfig.findAll",query="SELECT * FROM DTL_CONFIG where DELETION_STATUS='N' ",resultClass=DtlConfig.class)
})
public class DtlConfig implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="attribute")
	private String attribute;
	
	@Column(name="VALUE")
	private String value;
	
	@Column(name="description")
	private String description;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;
	
	@Column(name="DELETION_STATUS")
	private String deletionStatus;

    @Id
	@ManyToOne
	@JoinColumn(name="CONFIG_CODE")
	private MstConfig mstConfig;

	public DtlConfig() {
	}

	public String getAttribute() {
		return this.attribute;
	}

	public void setAttribute(String attribute) {
		this.attribute = attribute;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public MstConfig getMstConfig() {
		return this.mstConfig;
	}

	public void setMstConfig(MstConfig mstConfig) {
		this.mstConfig = mstConfig;
	}

}