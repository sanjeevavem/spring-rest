package ae.etisalat.cw.restws.jpa.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Entity
@Table(name="GENERIC_VALIDATION_PARAMETER")
@NamedNativeQueries({
	@NamedNativeQuery(name="GenericValidationParameter.findAll",query="SELECT * FROM GENERIC_VALIDATION_PARAMETER G WHERE G.DELETION_STATUS='N'",resultClass=GenericValidationParameter.class)
})
public class GenericValidationParameter implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PARAM_ID")
	private long paramId;

	@Column(name="ACTION")
	private String action;

	@Column(name="ATTRIBUTE_NAME")
	private String attributeName;

	@Column(name="FIELD_SIZE")
	private BigDecimal fieldSize;

	@Column(name="IS_UPDATABLE")
	private String isUpdatable;

    @Column(name="JSONATTRIBUTETYPE")
	private String jsonattributetype;

    @Column(name="JSONPATH")
	private String jsonpath;

	@Column(name="MANDATORY_FLAG")
	private String mandatoryFlag;

	@Column(name="REG_EXP")
	private String regExp;

	@Column(name="VALIDATION_CLASS")
	private String validationClass;

	@Column(name="VALIDATION_TYPE")
	private String validationType;

	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ERROR_CODE_ID")
	private ErrorCode errorCode;

	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="VALIDATION_TEMPLATE_ID")
	private GenericValidation genericValidation;
	
	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;
	
	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	public GenericValidationParameter() {
	}

	public long getParamId() {
		return this.paramId;
	}

	public void setParamId(long paramId) {
		this.paramId = paramId;
	}

	public String getAction() {
		return this.action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getAttributeName() {
		return this.attributeName;
	}

	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public BigDecimal getFieldSize() {
		return this.fieldSize;
	}

	public void setFieldSize(BigDecimal fieldSize) {
		this.fieldSize = fieldSize;
	}

	public String getIsUpdatable() {
		return this.isUpdatable;
	}

	public void setIsUpdatable(String isUpdatable) {
		this.isUpdatable = isUpdatable;
	}

	public String getJsonattributetype() {
		return this.jsonattributetype;
	}

	public void setJsonattributetype(String jsonattributetype) {
		this.jsonattributetype = jsonattributetype;
	}

	public String getJsonpath() {
		return this.jsonpath;
	}

	public void setJsonpath(String jsonpath) {
		this.jsonpath = jsonpath;
	}

	public String getMandatoryFlag() {
		return this.mandatoryFlag;
	}

	public void setMandatoryFlag(String mandatoryFlag) {
		this.mandatoryFlag = mandatoryFlag;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getRegExp() {
		return this.regExp;
	}

	public void setRegExp(String regExp) {
		this.regExp = regExp;
	}

	public String getValidationClass() {
		return this.validationClass;
	}

	public void setValidationClass(String validationClass) {
		this.validationClass = validationClass;
	}

	public String getValidationType() {
		return this.validationType;
	}

	public void setValidationType(String validationType) {
		this.validationType = validationType;
	}

	public ErrorCode getErrorCode() {
		return this.errorCode;
	}

	public void setErrorCode(ErrorCode errorCode) {
		this.errorCode = errorCode;
	}

	public GenericValidation getGenericValidation() {
		return this.genericValidation;
	}

	public void setGenericValidation(GenericValidation genericValidation) {
		this.genericValidation = genericValidation;
	}

}
