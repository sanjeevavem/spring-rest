package ae.etisalat.cw.restws.config;


import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.activiti.engine.ProcessEngineConfiguration;
import org.activiti.engine.impl.asyncexecutor.DefaultAsyncJobExecutor;
import org.activiti.engine.impl.history.HistoryLevel;
import org.activiti.spring.ProcessEngineFactoryBean;
import org.activiti.spring.SpringProcessEngineConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.CommonAnnotationBeanPostProcessor;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
//import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.GsonHttpMessageConverter;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@Configuration
@EnableWebMvc
@EnableTransactionManagement
@PropertySources({
 @PropertySource("classpath:cwapplication.properties"),
 @PropertySource("classpath:sql-queries.properties")
})

@ComponentScan(basePackages = { "ae.etisalat.cw.restws", "ae.etisalat.activiti","ae.etisalat.cw.comm" })
public class CBCMRestWebAppConfig extends WebMvcConfigurerAdapter  {

	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	@Bean
	public CommonAnnotationBeanPostProcessor commonAnnotationBeanPostProcessor() {
		CommonAnnotationBeanPostProcessor processor = new CommonAnnotationBeanPostProcessor();
		processor.setAlwaysUseJndiLookup(true);
		return processor;
	}

	@Override
	public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
		GsonHttpMessageConverter msgConverter = new GsonHttpMessageConverter();
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		msgConverter.setGson(gson);
		converters.add(msgConverter);
		converters.add(new StringHttpMessageConverter());
		super.configureMessageConverters(converters);
	}

	@Bean(destroyMethod="")
	public DataSource crmDataSource() throws NamingException {
		DataSource crmDataSource = (DataSource) new InitialContext().lookup("cbcm_cw_datasource");
		return crmDataSource;
	}
	
	@Bean
	public NamedParameterJdbcTemplate crmJdbcTemplate() throws NamingException {
		return new NamedParameterJdbcTemplate(crmDataSource());
	}

	
	
	 /* 
	  * Spring JPA Start
	  */

	   @Bean
	   public JpaTransactionManager geJpaTransactionManager() throws NamingException {
	      JpaTransactionManager transactionManager = new JpaTransactionManager();
	      transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
	      transactionManager.setDataSource(crmDataSource());
	      return transactionManager;
	   }
	   
	    @Bean
	    public LocalContainerEntityManagerFactoryBean entityManagerFactory() throws NamingException {
	        LocalContainerEntityManagerFactoryBean lef = new LocalContainerEntityManagerFactoryBean();
	        lef.setDataSource(crmDataSource());
	        lef.setJpaVendorAdapter(jpaVendorAdapter());
	        lef.setPackagesToScan("ae.etisalat.cw.restws.jpa");
	        return lef;
	    }
	
	    @Bean
	    public JpaVendorAdapter jpaVendorAdapter() {
	        HibernateJpaVendorAdapter hibernateJpaVendorAdapter = new HibernateJpaVendorAdapter();
	        hibernateJpaVendorAdapter.setShowSql(false);
	        hibernateJpaVendorAdapter.setDatabase(Database.ORACLE);
	        return hibernateJpaVendorAdapter;
	    }
	    
	 /* 
	  * Spring JPA End
	  */
	    
	/* Activiti spring Start*/

	@Bean
	public ProcessEngineFactoryBean processEngine() throws NamingException {
		ProcessEngineFactoryBean processEngineFactoryBean = new ProcessEngineFactoryBean();
		SpringProcessEngineConfiguration configuration = new SpringProcessEngineConfiguration();
		configuration.setTransactionManager(this.dataSourceTransactionManager());
//		configuration.setDatabaseType("oracle");
		configuration.setAsyncExecutorActivate(true);
		configuration.setEnableProcessDefinitionInfoCache(true);
		configuration.setHistoryLevel(HistoryLevel.FULL);
		configuration.setDataSource(crmDataSource());
		configuration.setDatabaseSchemaUpdate(ProcessEngineConfiguration.DB_SCHEMA_UPDATE_FALSE);

		DefaultAsyncJobExecutor asyncExecutor = new DefaultAsyncJobExecutor();
		asyncExecutor.setCorePoolSize(50);
		asyncExecutor.setMaxPoolSize(100);
		asyncExecutor.setAsyncJobLockTimeInMillis(60000);
		asyncExecutor.setDefaultTimerJobAcquireWaitTimeInMillis(1);
		asyncExecutor.setMaxAsyncJobsDuePerAcquisition(100);
		asyncExecutor.setDefaultAsyncJobAcquireWaitTimeInMillis(1);
		asyncExecutor.setRetryWaitTimeInMillis(1000);
		asyncExecutor.setMaxTimerJobsPerAcquisition(50);
		asyncExecutor.setQueueSize(500);

		configuration.setAsyncExecutor(asyncExecutor);
		processEngineFactoryBean.setProcessEngineConfiguration(configuration);
		return processEngineFactoryBean;
	}


	public DataSourceTransactionManager dataSourceTransactionManager() throws NamingException {
		DataSourceTransactionManager dataSourceTransactionManager = new DataSourceTransactionManager();
		dataSourceTransactionManager.setDataSource(crmDataSource());
	 return dataSourceTransactionManager;
	}
	
	/* Activiti spring End*/
}
