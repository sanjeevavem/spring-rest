package ae.etisalat.cw.restws.jpa.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="CW_JSONPATH_CONFIG")
public class JsonPathConfig implements Serializable {

	private static final long serialVersionUID = 381701751906222166L;
	
	@Id
	@Column(name="JSONPATH_CODE")
	private String jSONPathCode;
	
	@Column(name="JSONPATH")
	private String jSONPath;
	
	@Column(name="VERSION_ID")
	private String versionId;
	
	@Column(name="CREATED_USER_ID")
	private String createdUserId;
	
	@Column(name="CREATED_DATE")
	private Timestamp createdDate;
	
	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;
	
	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;
	
	public String getjSONPath() {
		return jSONPath;
	}
	public void setjSONPath(String jSONPath) {
		this.jSONPath = jSONPath;
	}
	public String getVersionId() {
		return versionId;
	}
	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}
	public String getCreatedUserId() {
		return createdUserId;
	}
	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getModifiedUserId() {
		return modifiedUserId;
	}
	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}
	public Timestamp getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getjSONPathCode() {
		return jSONPathCode;
	}
	public void setjSONPathCode(String jSONPathCode) {
		this.jSONPathCode = jSONPathCode;
	}
	
	@Override
	public String toString() {
		return "JsonPathConfig [jSONPathCode=" + jSONPathCode + ", jSONPath=" + jSONPath + ", versionId=" + versionId
				+ ", createdUserId=" + createdUserId + ", createdDate=" + createdDate + ", modifiedUserId="
				+ modifiedUserId + ", modifiedDate=" + modifiedDate + "]";
	}

}
