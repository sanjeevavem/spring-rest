package ae.etisalat.cw.comm.util;

import java.util.Collection;
import java.util.List;

public class Util {

	public static boolean isValidObject(Object obj) {

		boolean isValid = false;
		if (obj != null && !"".equals(obj)) {
			isValid = true;
		}
		return isValid;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static <T> T getFirstObjectFromList(List list){
        if(list != null && !list.isEmpty()){
        	return (T) list.get(0);
        }
		return null;
	}
	
	@SuppressWarnings("rawtypes")
    public static boolean isValidateCollection(Collection collection) {
        boolean isValidList = false;
        if (collection != null && !collection.isEmpty()) {
            isValidList = true;
        }
        return isValidList;
    }

}
