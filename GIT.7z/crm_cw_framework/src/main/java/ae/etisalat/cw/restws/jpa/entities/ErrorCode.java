package ae.etisalat.cw.restws.jpa.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;

@Entity
@Table(name="ERROR_CODES")
@NamedNativeQueries({
	@NamedNativeQuery(name="ErrorCode.findAll",query="SELECT * FROM ERROR_CODES where DELETION_STATUS='N' ",resultClass=ErrorCode.class)
})
public class ErrorCode implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ERROR_CODE_ID")
	private String errorCodeId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="ERROR_DESCRIPTION")
	private String errorDescription;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	//bi-directional many-to-one association to GenericValidationParameter
	@OneToMany(mappedBy="errorCode")
	private List<GenericValidationParameter> genericValidationParameters;

	public ErrorCode() {
	}

	public String getErrorCodeId() {
		return this.errorCodeId;
	}

	public void setErrorCodeId(String errorCodeId) {
		this.errorCodeId = errorCodeId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public String getErrorDescription() {
		return this.errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public List<GenericValidationParameter> getGenericValidationParameters() {
		return this.genericValidationParameters;
	}

	public void setGenericValidationParameters(List<GenericValidationParameter> genericValidationParameters) {
		this.genericValidationParameters = genericValidationParameters;
	}

	public GenericValidationParameter addGenericValidationParameter(GenericValidationParameter genericValidationParameter) {
		getGenericValidationParameters().add(genericValidationParameter);
		genericValidationParameter.setErrorCode(this);

		return genericValidationParameter;
	}

	public GenericValidationParameter removeGenericValidationParameter(GenericValidationParameter genericValidationParameter) {
		getGenericValidationParameters().remove(genericValidationParameter);
		genericValidationParameter.setErrorCode(null);

		return genericValidationParameter;
	}

}