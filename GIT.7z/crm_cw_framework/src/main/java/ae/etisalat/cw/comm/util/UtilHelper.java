package ae.etisalat.cw.comm.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;

import ae.etisalat.cw.restws.jpa.entities.JsonPathConfig;
import ae.etisalat.cw.restws.jpa.entities.SQLParameters;
import ae.etisalat.cw.restws.dao.generic.GenericOrderCreationDAO;
import ae.etisalat.cw.restws.jms.LogJMSProvider;


@Service
public class UtilHelper {

	private static final Logger logger = LogManager.getLogger(UtilHelper.class);
	
	@Autowired
	protected GenericOrderCreationDAO genericDAO;
	
	@Autowired
	protected LogJMSProvider logJMSProvider;
	  
	public  Object evalExpr(String fieldName, Expression expVariable, DelegateExecution delegateExecution) {
		Object returnValue = expVariable == null ? null : expVariable.getValue(delegateExecution);
		if (logger.isDebugEnabled()) {
			Throwable t = new Throwable();
			StackTraceElement[] elements = t.getStackTrace();
			String callerClassName = elements[1].getClassName();
			LogManager.getLogger(callerClassName).debug("fieldName:[{}], value:[{}]", fieldName, returnValue);
		}
		return returnValue;
	}
	
	
    public static List<String> getQueryParams(String source, String queryParamPattern) {
        List<String> queryParams = new ArrayList<String>();
        Pattern pattern = Pattern.compile(queryParamPattern);
        Matcher matcher = pattern.matcher(source);
        while (matcher.find()) {
            queryParams.add(matcher.group(0));
        }
        return queryParams;
    }
	
	
	public String getUUID(){
	  ThreadContext.put(UtilConstants.UID, UUID.randomUUID().toString());
	  String txnId = org.apache.logging.log4j.ThreadContext.get(UtilConstants.UID);
	  logger.debug("TXN_ID from thread context: " + txnId);
        if (StringUtils.isBlank(txnId)) {
            txnId = UUID.randomUUID().toString();
        }
       ThreadContext.put(UtilConstants.UID, txnId);
     return txnId;
	}
	
	public void populateThreadContext(String channel, String sub_channel, String transaction_id,String operation) {
		if (StringUtils.isNotBlank(channel)) {
			ThreadContext.put(UtilConstants.CHANNEL, channel);
		}
		if (StringUtils.isNotBlank(sub_channel)) {
			ThreadContext.put(UtilConstants.SUB_CHANNEL, sub_channel);
		}
		if (StringUtils.isNotBlank(transaction_id)) {
			ThreadContext.put(UtilConstants.UID, transaction_id);
		} else {
			ThreadContext.put(UtilConstants.UID, UUID.randomUUID().toString());
		}
		if (StringUtils.isNotBlank(operation)) {
			ThreadContext.put(UtilConstants.OPERATION, operation);
		} 
	}
	
    public Object getDynamicparamValue(String accountNumber, HashMap<String, Object> orderInformation,
            SQLParameters param, HashMap<String, Object> currentContext) throws JsonSyntaxException, Exception {
    	 Object value = null;
    	 String attributeValue = param.getAttributeValue();
    	 String jsonValue = null; 
    	 String request = orderInformation!=null? (orderInformation.get(UtilConstants.JSON_REQUEST)!=null?orderInformation.get(UtilConstants.JSON_REQUEST).toString():""):"";
    	 if(param==null || param.getAttributeValue() ==null){
    		 return null; // need to modify
    	 }
    	 System.out.println(attributeValue);
    	 // need to fetch SUb request and account numbers
    	 if(attributeValue.startsWith("$VAL_") ){
    		 String key = param.getAttributeValue().substring(5);//$VAL_
    		 value=orderInformation.get(key);
    	 }else if(attributeValue.startsWith("$JSON_")){
    		 String jsonConfig  = param.getAttributeValue().substring(6);
    		 JsonPathConfig jsonPathConfig = genericDAO.findById(JsonPathConfig.class,jsonConfig);
    		 if(jsonPathConfig!=null && jsonPathConfig.getjSONPath()!=null) {
        	   jsonValue = JSONUtil.getJSONValueByKey(request, jsonPathConfig.getjSONPath());	 
    		 }
    		value = jsonValue;
    	 }else if(attributeValue.startsWith("$REF_")) {
    		 value = param.getAttributeValue().substring(5);
    	 }else {
    		 value = param.getAttributeValue();
    	 }
	 return value;
    }

  public <T> void restServiceLogs(JsonObject orderDetails,String UID,String logtype,Class<T> className) throws Exception {
	  orderDetails.addProperty(UtilConstants.API, ""+className);
	  orderDetails.addProperty(UtilConstants.UID, UID);
	  orderDetails.addProperty(UtilConstants.LOG_TYPE, logtype);
	// logJMSProvider.sendMsg(orderDetails);		  
  }
  
  public static boolean isValidObject(Object obj) {
      boolean isValid = false;
      if (obj != null && !"".equals(obj)) {
          isValid = true;
      }
      return isValid;
  }

}
