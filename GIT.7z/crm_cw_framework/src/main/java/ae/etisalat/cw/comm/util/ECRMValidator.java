package ae.etisalat.cw.comm.util;

import java.io.Serializable;

import com.google.gson.JsonObject;



public interface ECRMValidator extends Serializable {

	public JsonObject validate(Object... parameters);
	
	public default JsonObject errorRespone(String errorCode,String errorDesc) {
		  JsonObject jsonObject = new JsonObject();
		  jsonObject.addProperty(UtilConstants.RESPONSE_CODE, errorCode);
		  jsonObject.addProperty(UtilConstants.RESPONSE_DESC, errorDesc);
		 return jsonObject;
		}
}
