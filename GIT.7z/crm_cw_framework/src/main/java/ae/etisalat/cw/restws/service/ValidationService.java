package ae.etisalat.cw.restws.service;

import com.google.gson.JsonObject;

public interface ValidationService {
	public JsonObject validate(JsonObject validationConfig,JsonObject jsonObject, Object[] parameters) throws Exception;
}
