package ae.etisalat.cw.restws.dao.generic;

public enum DataSourceType {
	cbcm_cw_datasource
}
