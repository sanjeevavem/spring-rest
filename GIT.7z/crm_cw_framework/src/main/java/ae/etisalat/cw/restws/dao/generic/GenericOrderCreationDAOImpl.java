package ae.etisalat.cw.restws.dao.generic;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.restws.exceptions.DAOException;

@Repository
public class GenericOrderCreationDAOImpl implements GenericOrderCreationDAO {

	
    private static final Logger logger = LogManager.getLogger(GenericOrderCreationDAOImpl.class);
    
    @Autowired
    @Qualifier("crmJdbcTemplate")
	private NamedParameterJdbcTemplate crmJdbcTemplate;
    
    
    @Autowired
    @Qualifier("crmDataSource")
    private DataSource cDataSource;
    

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Map<String, Object> query(DataSourceType dataSourceType, String sql, Map<String, Object> args) 	throws DataAccessException {
		CWLog.logMessage(Level.INFO, "Executing the query[{}], with params[{}] for a single record", Objects.toString(sql), Objects.toString(args));
        Map<String, Object> result = null;

        try {
            result = jdbcTemplate(dataSourceType).queryForMap(sql, args);
        }
        catch (DataAccessException e) {
            if (e instanceof EmptyResultDataAccessException) {
            	CWLog.logMessage(Level.WARN, "No results found for the given query");
            }
            else {
            	CWLog.logMessage(Level.ERROR, "Error in executing the query",e);
                throw e;
            }
        }
        return result;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public List<Map<String, Object>> queryList(DataSourceType dataSourceType, String sql, Map<String, Object> args)	throws DataAccessException {
		
		CWLog.logMessage(Level.INFO,"Executing the query[{}], with params[{}] for a list", Objects.toString(sql), Objects.toString(args));
        List<Map<String, Object>> result = null;
        try {
            result = jdbcTemplate(dataSourceType).queryForList(sql, args);
        }
        catch (DataAccessException e) {
            if (e instanceof EmptyResultDataAccessException) {
            	CWLog.logMessage(Level.WARN,"No results found for the given query");
            }
            else {
            	CWLog.logMessage(Level.ERROR, "Error in executing the query", e);
                throw e;
            }
        }
        return result;
	}
	

    @Override
	public int insert(DataSourceType dataSourceType, String sql, Map<String, Object> args)	throws DataAccessException {
		
    	CWLog.logMessage(Level.INFO,"Executing the query[{}], with params[{}] for a list", Objects.toString(sql), Objects.toString(args));
        int result = 0;
        try {
            result = jdbcTemplate(dataSourceType).update(sql, args);
        }
        catch (DataAccessException e) {
            if (e instanceof EmptyResultDataAccessException) {
            	CWLog.logMessage(Level.WARN,"No results found for the given query");
            }
            else {
            	CWLog.logMessage(Level.ERROR,"Error in executing the query", e);
                throw e;
            }
        }
        return result;
	}
	
    private NamedParameterJdbcTemplate jdbcTemplate(DataSourceType dataSourceType) {
        if (DataSourceType.cbcm_cw_datasource.equals(dataSourceType)) {
            return crmJdbcTemplate;
        }else{
           return null;
        }
    }
       
    /**
     *  JPA realated Implementation
     */
    
    @PersistenceContext
    private EntityManager em;
    
	public <T> T findById(Class<T> entityClass, Serializable id) throws DataAccessException {
	 CWLog.logMessage(Level.INFO,"findById() Start");
		T record = null;
		if (id == null || entityClass == null) {
		CWLog.logMessage(Level.WARN, "Either ID or the targetEntityType is null");
			return record;
		}
		try {
			CWLog.logMessage(Level.DEBUG, "Getting entity " + entityClass.getSimpleName() + " by id: " + id);
			record = em.find(entityClass,id);
			CWLog.logMessage(Level.DEBUG, "Entity retrieved: " + record);
		} catch (Exception e) {
			CWLog.logMessage(e.getCause(), "Error in getting entity by ID.");
			throw e;  // need to check
		}
	  CWLog.logMessage(Level.INFO,"findById() End");
	 return record;
	}
	
	public <T> T update(Object entity,Class<T> entityClass) throws DataAccessException {
	  CWLog.logMessage(Level.INFO, "update Start");
		 T t =(T)em.merge(entity);
	  CWLog.logMessage(Level.INFO, "update End");
     return t;
	}
	
	public int executeNativeUpdateQuery(String sql, Map<String,Object> params) throws DataAccessException, DAOException {
	 CWLog.logMessage(Level.INFO,"executeNativeUpdateQuery() Start");
	  int rowsUpdated = 0;
	  try {
	      Query nativeQuery = em.createNativeQuery(sql);
	      Set<String> set = params.keySet();
	       Iterator<String> itr = set.iterator();
	       while(itr.hasNext()){
	    	   String key = itr.next();
	    	   nativeQuery.setParameter(key.substring(1), params.get(key));  
	       }

	      rowsUpdated = nativeQuery.executeUpdate();
	  }
	  catch (Exception e) {
	      throw new DAOException(StringUtils.join("Error in executing the native query[", sql, "] with params[", params,
	          "]. Exception[", e.getClass(), "], Exception message[", e.getMessage(), "]"), e);
	  }
	  CWLog.logMessage(Level.INFO,"executeNativeUpdateQuery() End");
	 return rowsUpdated;
	}	
	
	 public  <T> List<T> executeQueryList(String sql, Map<String,Object> params,Class<T> entityClass) throws DataAccessException, DAOException {
	  CWLog.logMessage(Level.INFO,"executeQueryList() Start");
	  List<T> result = null;
		  try {
		      Query nativeQuery = em.createNamedQuery(sql);  
		      Set<String> set = params.keySet(); 
		       Iterator<String> itr = set.iterator();
		       while(itr.hasNext()){
		    	   String key = itr.next();
		    	   nativeQuery.setParameter(key, params.get(key));  
		       }
		       result = nativeQuery.getResultList();
		  }
		  catch (Exception e) {
		      throw new DAOException(StringUtils.join("Error in executing the native query[", sql, "] with params[", params,
		          "]. Exception[", e.getClass(), "], Exception message[", e.getMessage(), "]"), e);
		  }
	 CWLog.logMessage(Level.INFO,"executeQueryList() End");
	 return result;
	 }	
	 
	 public  <T> T executeQuery(String sql, Map<String,Object> params,Class<T> entityClass) throws DataAccessException, DAOException {
		 CWLog.logMessage(Level.INFO,"executeQuery() Start");
		  T result = null;
			  try {
			      Query nativeQuery = em.createNamedQuery(sql);  
			      Set<String> set = params.keySet(); 
			       Iterator<String> itr = set.iterator();
			       while(itr.hasNext()){
			    	   String key = itr.next();
			    	   nativeQuery.setParameter(key, params.get(key));  
			       }
			       result =(T) nativeQuery.getSingleResult();
			  }catch(NoResultException nre){
				CWLog.logMessage(Level.ERROR,"executeQuery() -->", nre); 
			  }
			  catch (Exception e) {
			      throw new DAOException(StringUtils.join("Error in executing the native query[", sql, "] with params[", params,
			          "]. Exception[", e.getClass(), "], Exception message[", e.getMessage(), "]"), e);
			  }
		  CWLog.logMessage(Level.INFO,"executeQuery() End");
		 return result;
		}
	
}
