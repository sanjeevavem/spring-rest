package ae.etisalat.cw.restws.exceptions;

public class CBCMRestWSException extends Exception {
	
	private static final long serialVersionUID = -3611311958721878271L;
	
	protected String code;
    protected String description;	
	
    public String getCode() {
		return code;
	}

	public String getDescription() {
		return description;
	}

	public CBCMRestWSException() {
		super();
	}
	
	public CBCMRestWSException(String code, String description) {
		super(description);
		this.code = code;
		this.description = description;
	}
	
    public CBCMRestWSException(String code, String description, Throwable cause) {
        super(description, cause);
        this.code = code;
        this.description = description;
    }
    
    public CBCMRestWSException(String description, Throwable cause) {
        super(description, cause);
        this.description = description;
    }

}
