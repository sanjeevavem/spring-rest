package ae.etisalat.cw.comm.util.json;

import java.io.Serializable;

public class SubOrderDetails implements Serializable {

 private static final long serialVersionUID = -2731077368242990075L;
 
 private String SubOrderId;
 private String ProductGroup;
 private String Product;
 private String AccountId;
 private String AccountNumber;

 private OfferDetails[] OfferDetails;

	public String getProductGroup() {
		return ProductGroup;
	}
	
	public void setProductGroup(String productGroup) {
		ProductGroup = productGroup;
	}
	
	public String getSubOrderId() {
		return SubOrderId;
	}
	
	public void setSubOrderId(String subOrderId) {
		SubOrderId = subOrderId;
	}
	
	public String getProduct() {
		return Product;
	}
	
	public void setProduct(String product) {
		Product = product;
	}
	
	public String getAccountId() {
		return AccountId;
	}
	
	public void setAccountId(String accountId) {
		AccountId = accountId;
	}
	
	public String getAccountNumber() {
		return AccountNumber;
	}
	
	public void setAccountNumber(String accountNumber) {
		AccountNumber = accountNumber;
	}
	
	public OfferDetails[] getOfferDetails() {
		return OfferDetails;
	}
	
	public void setOfferDetails(OfferDetails[] offerDetails) {
		OfferDetails = offerDetails;
	}

}
