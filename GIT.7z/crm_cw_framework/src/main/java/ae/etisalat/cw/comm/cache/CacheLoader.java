package ae.etisalat.cw.comm.cache;

import java.io.Serializable;

import javax.annotation.PostConstruct;

import org.apache.logging.log4j.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.restws.dao.generic.ConfigDao;

@Component
public class CacheLoader implements Serializable {

	private static final long serialVersionUID = 1L;
	@Autowired
	private ConfigDao configDao;
	
	@PostConstruct
	public void contextInitialized() {
		CWLog.logMessage(Level.INFO, "Starts CacheLoader@PostConstruct.");
		loadCache();
		CWLog.logMessage(Level.INFO,"Ends CacheLoader@PostConstruct.");
	}
	
	public void loadCache() {
		long start = System.currentTimeMillis();
		CWLog.logMessage(Level.INFO,"Starts loadCache");
		CacheHashMap.configMap=configDao.fetchConfigMap();
		CWLog.logMessage(Level.INFO,
				"Ends loadCache in " + (System.currentTimeMillis() - start) + " milliseconds");
	}
	
}
