package ae.etisalat.cw.comm.util.json;

import java.io.Serializable;

public class OfferDetails implements Serializable {

 private static final long serialVersionUID = 8640662161047782257L;

	private String offerType;
	private String offerCode;
	
	public String getOfferType() {
		return offerType;
	}
	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}
	public String getOfferCode() {
		return offerCode;
	}
	public void setOfferCode(String offerCode) {
		this.offerCode = offerCode;
	}
 
}
