package ae.etisalat.cw.comm.cache;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ae.etisalat.cw.restws.jpa.entities.DtlConfig;

public class CacheHashMap {
	public static HashMap<String, String> configSettings = null;
	public static Map<String, List<DtlConfig>> configMap = null;

}
