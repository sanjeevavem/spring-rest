package ae.etisalat.cw.comm.util;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.JsonPathException;
import com.jayway.jsonpath.Option;
import com.jayway.jsonpath.PathNotFoundException;
import com.jayway.jsonpath.spi.json.GsonJsonProvider;
import com.jayway.jsonpath.spi.json.JsonProvider;
import com.jayway.jsonpath.spi.mapper.GsonMappingProvider;
import com.jayway.jsonpath.spi.mapper.MappingProvider;

import ae.etisalat.cw.comm.util.logger.CWLog;

@Component
public class JSONUtil {

	private static final Logger logger = LogManager.getLogger(JSONUtil.class);
	private static final Gson gson = new GsonBuilder().setPrettyPrinting().enableComplexMapKeySerialization().create();	  
	public HashMap<String, Object> getMapFromJson(JsonObject jsonObject){

		HashMap<String, Object> map = new HashMap<String, Object>();
		//   \"productGroup\": \"BL\",\"Account_Number\":\"0503264246\",\"Product\":\"BFXI\",\"ordertype\":\"NEW\",\"OFFERTYPE\":\"RATEPLAN\",\"OFFERCODE\":\"RP1001\"
		map.put("ProductGroup", jsonObject.get("ProductGroup").getAsString());
		map.put("Account_Number", jsonObject.get("Account_Number").getAsString());
		map.put("Product", jsonObject.get("Product").getAsString());
		map.put("Ordertype", jsonObject.get("Ordertype").getAsString());
		map.put("OfferType", jsonObject.get("OfferType").getAsString());
		map.put("OfferCode", jsonObject.get("OfferCode").getAsString());

		return map;
	}

	public static Object evalExpr(String fieldName, Expression expVariable, DelegateExecution delegateExecution) {
		Object returnValue = expVariable == null ? null : expVariable.getValue(delegateExecution);
		if (logger.isDebugEnabled()) {
			Throwable t = new Throwable();
			StackTraceElement[] elements = t.getStackTrace();
			String callerClassName = elements[1].getClassName();
			LogManager.getLogger(callerClassName).debug("fieldName:[{}], value:[{}]", fieldName, returnValue);
		}
		return returnValue;
	}


	public static HashMap<String, Object> convertJSONToMap(JsonObject json){
		Type type = new TypeToken<HashMap<String, Object>>(){}.getType();
		HashMap<String, Object> map= new Gson().fromJson(json, type);
		return map;
	}

	public static HashMap<String, Object> convertJSONStringToMap(String jsonStr){
		JsonObject json = new Gson().fromJson(jsonStr, JsonObject.class);
		Type type = new TypeToken<HashMap<String, Object>>(){}.getType();
		return new Gson().fromJson(json, type);
	}

	public static JsonObject convertJSONStringToJSONObject(String jsonStr){
		return new Gson().fromJson(jsonStr, JsonObject.class);
	}	

	public static String getJSONValueByKey(String jsonObject,String jsonKey) throws Exception {
		/**
		 * set GsonJsonProvider to the JSON Path
		 */
		Configuration.setDefaults(new Configuration.Defaults() {
			private final JsonProvider jsonProvider = new GsonJsonProvider();
			private final MappingProvider mappingProvider = new GsonMappingProvider();

			@Override
			public JsonProvider jsonProvider() {
				return jsonProvider;
			}

			@Override
			public MappingProvider mappingProvider() {
				return mappingProvider;
			}

			@Override
			public Set<Option> options() {
				return EnumSet.noneOf(Option.class);
			}
		});

		JsonElement element = null;
		try
		  {
		    element = JsonPath.read(jsonObject,jsonKey);	  
		  }catch(PathNotFoundException pe){
			  pe.printStackTrace();
		  }catch(JsonPathException ie){
			  ie.printStackTrace();
		   }catch(Exception e){
			  e.printStackTrace();
		  }
	return element!=null?element.getAsString():"";	
   }
  
  public static <T> T jsonToObject(String json, Class<T> targetType) {
      T obj = null;
      try {
          obj = new Gson().fromJson(json, targetType);
		} catch (Exception e) {
			e.printStackTrace();
      }
      return obj;
  }
  
  public static String objectToJson(Object object) {
      String jsonObj = null;
      try {
             jsonObj = new Gson().toJson(object);
      }
      catch (Exception e) {
             logger.debug("Error in objectToJson");
      }
      return jsonObj;
}

	public static <T> T jsonToObject(String json,String query, Class<T> targetType) {
		T obj = null;
		JsonElement jsonQuery = parseJson(query,json);
		try {
			obj = gson.fromJson(jsonQuery, targetType);
		}
		catch (Exception e) {
			logger.log(Level.ERROR, "Error in converting JSON to object",e);
		}
		return obj;
	}

	private static JsonElement parseJson(String query,String json) {
		JsonParser p = new JsonParser();
		JsonElement jsonContainer = p.parse(json);
		JsonElement jsonQuery = ((JsonObject) jsonContainer).get(query);
		return jsonQuery;
	}
	
	public static List<JsonObject> getSortedJsonObjectByElement(JsonArray jsonArray,String key){
	 CWLog.logMessage(Level.INFO, "getSortedJsonObjectByElement Start jsonArray"+jsonArray+",Key"+key);
		   List<JsonObject> list = new ArrayList<JsonObject>();
		      for(JsonElement element : jsonArray){
		    	  JsonObject jsonObjectValTemp = (JsonObject)element;
		    	  list.add(jsonObjectValTemp);
		      }
	  List<JsonObject> sortedList = list.stream().sorted(Comparator.comparing((t) -> Double.parseDouble(((JsonObject) t).get(key).toString().trim()))).collect(Collectors.toList());
	  CWLog.logMessage(Level.INFO, "getSortedJsonObjectByElement End sortedList"+sortedList);
	 return sortedList;
	}

}
