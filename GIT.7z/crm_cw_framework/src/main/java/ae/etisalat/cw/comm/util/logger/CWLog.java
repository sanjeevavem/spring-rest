package ae.etisalat.cw.comm.util.logger;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;
@Service
public class CWLog {
	public static String getLogMessage(long subrequestId, String... messages) {
		return StringUtils.join(messages);
	}

	public static String getLogMessage(String accountNumber, String... messages) {
		return StringUtils.join(messages);
	}

	public static String getLogMessage(long subrequestId, long accountNumber, String... messages) {
		return StringUtils.join(messages);
	}

	public static String getLogMessage(long subrequestId, long accountNumber, long accountId, String... messages) {
		return StringUtils.join(messages);
	}

	private static String getCallerClass(int callerStackIndex) {
		Throwable t = new Throwable();
		StackTraceElement[] elements = t.getStackTrace();
		String callerClassName = elements[callerStackIndex].getClassName();
		return callerClassName;
	}
	
	public static void defaultLogMessage(Level logLevel, String message) {
		Logger logger = getLogger(4);
		logger.log(logLevel, message);
	}
	
	public static void defaultLogMessage(Throwable t, String... messages) {
		 Logger logger = getLogger(4);
		 logger.error(StringUtils.join(messages),t);
	 }

	private static Logger getLogger(int callerStackIndex) {
		String callerClassName = getCallerClass(callerStackIndex);
		return LogManager.getLogger(callerClassName);
	}

	public static void logMessage(Level logLevel, String message) {
		Logger logger = getLogger(3);
		logger.log(logLevel, message);
		
	}
	
	public static void logMessage(Level logLevel, String message,Throwable t) {
		Logger logger = getLogger(3);
		logger.log(logLevel, message,t);
		
	}

	public static void logMessage(Level logLevel, long subrequestId, String... messages) {
		Logger logger = getLogger(3);
		logger.log(logLevel, StringUtils.join(messages));
	}

	public static void logMessage(Level logLevel, String accountNumber, String... messages) {
		Logger logger = getLogger(3);
		if (StringUtils.isNumeric(accountNumber)) {
		    logger.log(logLevel, StringUtils.join(messages));
        }
		else {
		    logger.log(logLevel, StringUtils.join(accountNumber, StringUtils.join(messages)));
        }
	}
	
	public static void logMessage(Level logLevel, long subrequestId, long accountNumber, String... messages) {
		Logger logger = getLogger(3);
		logger.log(logLevel, StringUtils.join(messages));
	}

	public static void logMessage(Level logLevel, long subrequestId, long accountNumber, long accountId, String... messages) {
		Logger logger = getLogger(3);
		logger.log(logLevel, StringUtils.join(messages));
	}


	/**
	 * Below methods are for logging error messages and stack traces
	 */
	 public static void logMessage(Throwable t, String... messages) {
		 Logger logger = getLogger(3);
		 logger.error(StringUtils.join(messages),t);
	 }

	/**
	 * Below methods are for logging error messages and stack traces for provided loglevel 
	 */
	 public static void logMessage(Level logLevel, Throwable t, String... messages) {
		 Logger logger = getLogger(3);
		 logger.log(logLevel, StringUtils.join(messages),t);
	 }


	 public static void logMessage(Throwable t, long subrequestId, String... messages) {
		 Logger logger = getLogger(3);
		 logger.error(StringUtils.join(messages),t);
	 }

	 public static void logMessage(Throwable t,long subrequestId, long accountNumber, String... messages) {
		 Logger logger = getLogger(3);
		 logger.error(StringUtils.join(messages),t);
	 }

	 public static void logMessage(Throwable t, long subrequestId, long accountNumber, long accountId, String... messages) {
		 Logger logger = getLogger(3);
		 logger.error(StringUtils.join(messages),t);
	 }
}
