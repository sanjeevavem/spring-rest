package ae.etisalat.cw.restws.dao.generic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import ae.etisalat.cw.restws.jpa.entities.DtlConfig;
import ae.etisalat.cw.restws.jpa.entities.MstConfig;

@Repository
@Transactional
public class ConfigDao {
	
	private static final Logger logger = LogManager.getLogger(ConfigDao.class);
	
	@PersistenceContext
    private EntityManager em;
	
	
	
	public String fetchConfigValue(String configType,String configCode,String attribute)throws Exception{
		String value=null;
		try{
			value=(String)em.createQuery("select dtl.value from MstConfig mst,DtlConfig dtl where mst.configType= :configType and"
					+ " mst.configCode= :configCode and dtl.attribute= :attribute and mst.configCode=dtl.configCode and mst.deletionStatus='N' and dtl.deletionStatus='N'")
					.setParameter("configType", configType).setParameter("configCode", configCode).setParameter("attribute", attribute).getSingleResult();
		}catch(Exception e){
			logger.error("Error in fetchConfigValue"+e.getMessage());
		}
		return value;
	}
	
	
	@SuppressWarnings("unchecked")
	public  Map<String, List<DtlConfig>> fetchConfigMap() {
		Map<String, List<DtlConfig>> list = new HashMap<>();
		List<MstConfig> mstConfigList=(List<MstConfig>)em.createQuery("select t from MstConfig t where t.deletionStatus='N'").getResultList();
		if(mstConfigList!=null && mstConfigList.size()>0){
			List<DtlConfig> dtlConfigList=(List<DtlConfig>)em.createQuery("select t from DtlConfig t where t.deletionStatus='N'").getResultList();
			if(dtlConfigList!=null && dtlConfigList.size()>0){
				for(MstConfig mstConfig:mstConfigList){
					List<DtlConfig> dtlCOnfigMapList=new ArrayList<DtlConfig>();
					for(DtlConfig dtlConfig :dtlConfigList){						
						if(dtlConfig.getMstConfig().getConfigCode().equalsIgnoreCase(mstConfig.getConfigCode()))
							dtlCOnfigMapList.add(dtlConfig);							
					}
					if(dtlCOnfigMapList!=null && dtlCOnfigMapList.size()>0)
						list.put(mstConfig.getConfigCode(), dtlCOnfigMapList);						
				}
			}
		}
		logger.info("fetchConfigMap size is: " + list.size() +" and content is: "+list.toString());
		return list;
	}

}
