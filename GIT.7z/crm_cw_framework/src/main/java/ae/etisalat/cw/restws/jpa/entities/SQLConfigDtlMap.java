package ae.etisalat.cw.restws.jpa.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="CW_DTL_SQL_CONFIG_MAP")
@NamedNativeQueries({
@NamedNativeQuery (name="SQLConfigDtlMap.findAll",
 query=" SELECT * FROM CW_DTL_SQL_CONFIG_MAP ",resultClass= SQLConfigDtlMap.class),
@NamedNativeQuery (name="SQLConfigDtlMap.findByOfferTypeOrderTypeOrderCode",
 query=" SELECT * FROM CW_DTL_SQL_CONFIG_MAP WHERE PRODUCT_GROUP=:PRODUCT_GROUP AND PRODUCT=:PRODUCT AND ORDER_TYPE =:ORDER_TYPE",resultClass=SQLConfigDtlMap.class )	
})

public class SQLConfigDtlMap implements Serializable {

	private static final long serialVersionUID = 8135148611734425359L;


    @Id
    @Column(name="ID") 
    private long id;
 
    @Column(name="DESCRIPTION")
	private String description;
    
    @Column(name="ORDER_TYPE")
    private String orderType;
    
    @Column(name="OFFER_TYPE")
    private String offerType;
    
    @Column(name="OFFER_CODE")
    private String offerCode;
    
    @Column(name="FLOW_SEQUENCE")
    private String flowSequence;
    
    @Column(name="PRODUCT_GROUP")
    private String productGroup;
    
    @Column(name="PRODUCT")
    private String product;
    
    @Column(name="CONDITION")
    private String condition;
    
    @Column(name="REF_ATTRIBUTES")
    private String refAttributes;
    
    @Column(name="RESPONSE_ATTRIBUTES")
    private String responseAttributes;
    
    @OneToOne(fetch=FetchType.EAGER)
    @JoinColumn(name="CONFIG_CODE")
    private SQLConfig sqlConfig;
 
	@Column(name="CREATED_USER_ID")
	private String createdUserId;
	
	@Column(name="CREATED_DATE")
	private Timestamp createdDate;
	
	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;
	
	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;
	
	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public String getOfferType() {
		return offerType;
	}

	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}

	public String getOfferCode() {
		return offerCode;
	}

	public void setOfferCode(String offerCode) {
		this.offerCode = offerCode;
	}

	public String getFlowSequence() {
		return flowSequence;
	}

	public void setFlowSequence(String flowSequence) {
		this.flowSequence = flowSequence;
	}

	public String getProductGroup() {
		return productGroup;
	}

	public void setProductGroup(String productGroup) {
		this.productGroup = productGroup;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getCondition() {
		return condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

	public String getRefAttributes() {
		return refAttributes;
	}

	public void setRefAttributes(String refAttributes) {
		this.refAttributes = refAttributes;
	}

	public String getResponseAttributes() {
		return responseAttributes;
	}

	public void setResponseAttributes(String responseAttributes) {
		this.responseAttributes = responseAttributes;
	}

	public SQLConfig getSqlConfig() {
		return sqlConfig;
	}

	public void setSqlConfig(SQLConfig sqlConfig) {
		this.sqlConfig = sqlConfig;
	}

	public String getCreatedUserId() {
		return createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedUserId() {
		return modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public Timestamp getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getDeletionStatus() {
		return deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}
}
