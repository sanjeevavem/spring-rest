package ae.etisalat.cw.comm.util;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.logging.log4j.Level;

import ae.etisalat.cw.comm.util.logger.CWLog;


public class DateUtils {

    public static Date getLastDayOfTheCurrentMonth() {
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.set(Calendar.DAY_OF_MONTH, c.getActualMaximum(Calendar.DAY_OF_MONTH));
        return c.getTime();
    }

    public static Date addToDate(Date date, int number, int field) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(field, number);
        return calendar.getTime();
    }


    public static Date substractFromDate(Date aDate, int number, int field) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(aDate);
        calendar.add(field, -(number));
        return calendar.getTime();
    }

    public static int monthsBetween(Date startDate, Date endDate) {
        Calendar startCalendar = Calendar.getInstance();
        startCalendar.setTime(startDate);
        Calendar endCalendar = Calendar.getInstance();
        endCalendar.setTime(endDate);

        int diffYear = endCalendar.get(Calendar.YEAR) - startCalendar.get(Calendar.YEAR);
        return diffYear * 12 + endCalendar.get(Calendar.MONTH) - startCalendar.get(Calendar.MONTH);
    }


    public static int daysBetween(Date startDate, Date endDate) {
        int totalNoOfDays = 0;
        int serviceActivationDateFromBase = 0;
        int serviceCessationDateFromBase = 0;
        if (startDate.compareTo(endDate) == 0) {
            return totalNoOfDays;
        }
        Calendar firstCal = Calendar.getInstance();
        if (startDate != null) {
            firstCal.setTime(startDate);
        }
        Calendar secondCal = Calendar.getInstance();
        if (endDate != null) {
            secondCal.setTime(endDate);
        }
        int day1 = firstCal.get(Calendar.DATE);
        int day2 = secondCal.get(Calendar.DATE);
        int month1 = firstCal.get(Calendar.MONTH);
        int month2 = secondCal.get(Calendar.MONTH);
        int year1 = firstCal.get(Calendar.YEAR);
        int year2 = secondCal.get(Calendar.YEAR);

        Calendar baseLineCal = Calendar.getInstance();
        // baseLineCal is Jan 1st and year is the year of service activation
        // date.
        baseLineCal.set(Calendar.DATE, 1);
        baseLineCal.set(Calendar.MONTH, 0);
        baseLineCal.set(Calendar.YEAR, year1);

        int baseLineDay = baseLineCal.get(Calendar.DATE);
        int baseLineMonth = baseLineCal.get(Calendar.MONTH);
        int baseLineYear = baseLineCal.get(Calendar.YEAR);

        serviceActivationDateFromBase = (month1 - baseLineMonth) * 30 + (day1 - baseLineDay);
        serviceCessationDateFromBase = (year2 - baseLineYear) * 360 + (month2 - baseLineMonth) * 30 + (day2 - baseLineDay);

        totalNoOfDays = serviceCessationDateFromBase - serviceActivationDateFromBase;

        return totalNoOfDays;
    }
    
    public static Date startDateOfCurrentMonth() {
        java.sql.Date today = new java.sql.Date(new Date().getTime());
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(today);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        java.sql.Date firstDay = new java.sql.Date(calendar.getTime().getTime());

        return firstDay;
    }

    public static int getQuarter(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        // In Java API, the months are 0-11, not 1-12.
        return (calendar.get(Calendar.MONTH) / 3) + 1;
    }

    public static Date startDayOfTheNextQuarter(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int quarter = getQuarter(date);
        switch (quarter) {
            case 1:
                calendar.set(Calendar.MONTH, 3);
                break;

            case 2:
                calendar.set(Calendar.MONTH, 6);
                break;

            case 3:
                calendar.set(Calendar.MONTH, 9);
                break;
            case 4:
                calendar.set(Calendar.MONTH, 0);
                calendar.set(Calendar.YEAR, calendar.get(Calendar.YEAR) + 1);
                break;

            default:
                break;
        }
        calendar.set(Calendar.DATE, 1);
        return calendar.getTime();
    }

    public static Date startDayOfTheNextMonth() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, 1);
        calendar.set(Calendar.DATE, calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
        return calendar.getTime();
    }

    public static Date startDayOfTheNextQuarter() {
        return startDayOfTheNextQuarter(new Date());
    }

    public static Date startDayOfTheNextHalf(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int half = (calendar.get(Calendar.MONTH) / 6) + 1;
        switch (half) {
            case 1:
                calendar.set(Calendar.MONTH, 6);
                break;

            case 2:
                calendar.set(Calendar.MONTH, 0);
                calendar.set(Calendar.YEAR, calendar.get(Calendar.YEAR) + 1);
                break;

            default:
                break;
        }
        calendar.set(Calendar.DATE, 1);
        calendar.set(Calendar.HOUR, 00);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }

    public static Date startDayOfTheNextHalf() {
        return startDayOfTheNextHalf(new Date());
    }
static int getField(Date date, int field) {
    	Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(field);
    }

	public static int compareDates(String firstDate, String secondDate, String dateFormat) {
		int flag = -1;//0 Equal 1 - First Date Greater than second , 2- Second date Greater than first date  
		try {
			
			CWLog.logMessage(Level.INFO,"firstDate:[",firstDate,"] seconddate[",secondDate,"]");
			DateFormat format = new SimpleDateFormat(dateFormat);
			
			Date startDate = format.parse(firstDate);
			Date expiryDate = format.parse(secondDate);
			
			int status = startDate.compareTo(expiryDate);
			
			if(status == 0){
				flag = 0;
			}else if (status < 0){
				flag = 2;
			}else {
				flag = 1;
			}
			

		} catch (Exception e) 
		{
			CWLog.logMessage(Level.ERROR,e,"Exception while compareDates()");
		}
		return flag;
	}
	
	public static boolean isTimeBetweenTwoTime(String initialTime, String finalTime, String currentTime, String timeFormat)
        throws Exception {
        boolean valid = false;
        try {
            // Start Time
            java.util.Date inTime = new SimpleDateFormat(timeFormat).parse(initialTime);
            Calendar initialTimeCalendar = Calendar.getInstance();
            initialTimeCalendar.setTime(inTime);

            // Current Time
            java.util.Date checkTime = new SimpleDateFormat(timeFormat).parse(currentTime);
            Calendar currentTimeCalendar = Calendar.getInstance();
            currentTimeCalendar.setTime(checkTime);

            // End Time
            java.util.Date finTime = new SimpleDateFormat(timeFormat).parse(finalTime);
            Calendar finalTimeCalendar = Calendar.getInstance();
            finalTimeCalendar.setTime(finTime);

            //initialTime(scheduler start time) = "08:00", finalTime(scheduler end time) = "11:00", currentTime = "09:00" - then time is valid
            //initialTime(scheduler start time) = "08:00", finalTime(scheduler end time) = "11:00", currentTime = "11:45" - then time is not valid
            if (finalTime.compareTo(initialTime) > 0) {
                java.util.Date actualTime = currentTimeCalendar.getTime();
                if ((actualTime.after(initialTimeCalendar.getTime()) || actualTime.compareTo(initialTimeCalendar.getTime()) == 0)
                    && actualTime.before(finalTimeCalendar.getTime())) {
                    valid = true;
                }
            }
            //initialTime(scheduler start time) = "12:45", finalTime(scheduler end time) = "11:30", currentTime = "15:00" - then time is valid
            //initialTime(scheduler start time) = "12:45", finalTime(scheduler end time) = "11:30", currentTime = "11:45" - then time is not valid
            if (finalTime.compareTo(initialTime) < 0) {
                java.util.Date actualTime = currentTimeCalendar.getTime();
                if (actualTime.before(finalTimeCalendar.getTime()) || actualTime.after(initialTimeCalendar.getTime())) {
                    valid = true;
                }
            }
        }
        catch (Exception e) {
        	CWLog.logMessage(Level.ERROR,e, "Exception while in isTimeBetweenTwoTime()");
            valid = false;
        }
        return valid;
    }
       
       public static String getDayOfWeekAsString(int value){
    	   String day = "";
    	   switch(value){
    	   case 1:
    		   day="SUNDAY";
    		   break;
    	   case 2:
    		   day="MONDAY";
    		   break;
    	   case 3:
    		   day="TUESDAY";
    		   break;
    	   case 4:
    		   day="WEDNESDAY";
    		   break;
    	   case 5:
    		   day="THURSDAY";
    		   break;
    	   case 6:
    		   day="FRIDAY";
    		   break;
    	   case 7:
    		   day="SATURDAY";
    		   break;
    	   }
    	   return day;
       }
       
       public static String getDateAsString(Date date, SimpleDateFormat dateFormat){
           return dateFormat.format(date);
       }
       
       public static String getCurrentDateAsString(SimpleDateFormat dateFormat){
           Date currentDate = Calendar.getInstance().getTime();
           return dateFormat.format(currentDate);
       }

    public static Date obligationPeriodDate(int obliPeriod, int obliUOM, Date effectiveFromDate) {
        Date obliPeriodDate = null;

        Calendar calendar1 = Calendar.getInstance();
        calendar1.setTime(effectiveFromDate);

        if (obliUOM == 1) {
            // this is for Days
            calendar1.add(Calendar.DATE, obliPeriod);
            obliPeriodDate = calendar1.getTime();
        }
        else if (obliUOM == 2) {
            // this is for months
            calendar1.add(Calendar.MONTH, obliPeriod);
            obliPeriodDate = calendar1.getTime();
        }
        else if (obliUOM == 3) {
            // this is for years
            calendar1.add(Calendar.YEAR, obliPeriod);
            obliPeriodDate = calendar1.getTime();
        }
        if (obliPeriodDate != null) {
            obliPeriodDate = DateUtils.addToDate(obliPeriodDate, -1, Calendar.DATE);
        }

        return obliPeriodDate;
    }

	public static Calendar toCalendar(Date date) {
		Calendar c = null;
		if (date != null) {
			c = Calendar.getInstance();
			c.setTime(date);
		}
		return c;
	}
	
	public static Date parseDate(String dateStr, String format)throws Exception{
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		try {
			return sdf.parse(dateStr);
		} catch (ParseException e) {
			new Exception(e);
		}
		return null;
	}
    
	public static Timestamp  getCurrentTime(){
		return new Timestamp(Calendar.getInstance().getTimeInMillis());
	}
    public static void main(String[] args) {
    	System.out.println(compareDates("SUN DEC 26 02 02 44 2010", "SUN DEC 26 02 02 44 2010", "EEE MMM dd HH mm ss yyyy"));
    	/*Calendar c1 = Calendar.getInstance();
    	c1.set(2015, 12, 1);
    	Date startDate = c1.getTime();
    	c1.set(2016, 10, 31);
		Date endDate = c1.getTime();
		System.out.println(daysBetween(startDate, endDate)/30.0);*/
	}
}
