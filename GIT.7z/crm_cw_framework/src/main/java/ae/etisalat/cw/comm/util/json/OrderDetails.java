package ae.etisalat.cw.comm.util.json;

import java.io.Serializable;

public class OrderDetails implements Serializable {

	private static final long serialVersionUID = -1172522085456684090L;
	
    private String OrderId;
    private String channel;
    private String subChannel;
    
    private SubOrderDetails[] subOrderDetails;

	public String getOrderId() {
		return OrderId;
	}

	public void setOrderId(String orderId) {
		OrderId = orderId;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getSubChannel() {
		return subChannel;
	}

	public void setSubChannel(String subChannel) {
		this.subChannel = subChannel;
	}

	public SubOrderDetails[] getSubOrderDetails() {
		return subOrderDetails;
	}

	public void setSubOrderDetails(SubOrderDetails[] subOrderDetails) {
		this.subOrderDetails = subOrderDetails;
	}
}
