package ae.etisalat.cw.restws.jpa.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


@Entity
@Table(name="GENERIC_VALIDATION")
@NamedNativeQueries({
	@NamedNativeQuery(name="GenericValidation.findByTemplateId",query="SELECT * FROM GENERIC_VALIDATION G WHERE G.VALIDATION_TEMPLATE_ID=:VALIDATION_TEMPLATE AND G.DELETION_STATUS='N'",resultClass=GenericValidation.class),
	@NamedNativeQuery(name="GenericValidation.findAll",query="SELECT * FROM GENERIC_VALIDATION where DELETION_STATUS='N' ",resultClass=GenericValidation.class)
})
public class GenericValidation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="VALIDATION_TEMPLATE_ID")
	private String validationTemplateId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="TEMPLATE_DESCRIPTION")
	private String templateDescription;

	@OneToMany(mappedBy="genericValidation",fetch=FetchType.EAGER)
	private List<GenericValidationParameter> genericValidationParameters;

	public GenericValidation() {
	}

	public String getValidationTemplateId() {
		return this.validationTemplateId;
	}

	public void setValidationTemplateId(String validationTemplateId) {
		this.validationTemplateId = validationTemplateId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getTemplateDescription() {
		return this.templateDescription;
	}

	public void setTemplateDescription(String templateDescription) {
		this.templateDescription = templateDescription;
	}

	public List<GenericValidationParameter> getGenericValidationParameters() {
		return this.genericValidationParameters;
	}

	public void setGenericValidationParameters(List<GenericValidationParameter> genericValidationParameters) {
		this.genericValidationParameters = genericValidationParameters;
	}

	public GenericValidationParameter addGenericValidationParameter(GenericValidationParameter genericValidationParameter) {
		getGenericValidationParameters().add(genericValidationParameter);
		genericValidationParameter.setGenericValidation(this);

		return genericValidationParameter;
	}

	public GenericValidationParameter removeGenericValidationParameter(GenericValidationParameter genericValidationParameter) {
		getGenericValidationParameters().remove(genericValidationParameter);
		genericValidationParameter.setGenericValidation(null);

		return genericValidationParameter;
	}

}