package ae.etisalat.cw.comm.util;

public class UtilConstants {
	
 /**
  * Hibernate JPA Constants
  */
 public static final String HIBERNATE_DIALECT_PROPERTY = "hibernate.dialect";
 public static final String HIBERNATE_DIALECT = "${" + HIBERNATE_DIALECT_PROPERTY + "}";
 public static final String HIBERNATE_SHOW_SQL_PROPERTY = "hibernate.show_sql";
 public static final String HIBERNATE_CURRENT_SESSION_CONTEXT_CLASS_PROPERTY = "current_session_context_class";
 public static final String HIBERNATE_CONNECTION_DATASOURCE = "hibernate.connection.datasource";

  public static final String UID = "TXN_ID";
  public static final String REF_NUMBER = "ReferenceNumber";
  public static final String API="API";
  public static final String LOG_TYPE="LOG_TYPE";
  public static final String LOG_TYPE_REQUEST="REQUEST";
  public static final String LOG_TYPE_RESPONSE="RESPONSE";

  public static final String CHANNEL="CHANNEL";
  public static final String SUB_CHANNEL="SUB_CHANNEL";
  public static final String OPERATION="OPERATION";
  public static final String JSON_REQUEST="JSON_REQUEST";
  public static final String JSON_RESPONSE="JSON_RESPONSE";
  
  /**
   * Application 
   */
  public static final String DEFAULT_USER="ECRMG";
  
  
  /**
   *  Activiti related constants
   */
  public static final String ACTIVITI_API_CTX="ACTIVITI_API_CONTEXT";
  public static final String ACTIVITI_REQ_JSON="ACTIVITI_REQ_JSON_OBJ";
  public static final String accountEntity="t_soh_account";
  public static final String accInvPersistStatus = "account_invoice_persist";
  public static final String accSrvInstDtl = "account_service_instance_details";
  public static final String accPaymentStatus = "persist_account_payment";
  public static final String orderParamValues = "order_param";
  public static final String paramValue = "paramValue";
  public static final String requestEntity = "TSohRequest";
  public static final String subRequestEntity = "TSohSubrequest";
  public static final String requirementEntity = "TSohRequirement";
  public static final String custRequirementEntity = "TSohCustRequirement";
  public static final String subReqSrvInstDtl = "SubReqSrvcInstList";
  // Offers
  public static final String OFFER_TYPE_RATEPLAN="R";
  public static final String SQL_RESPONSE="JSON_RESPONSE";
  public static final String SQL_CONFIG_TEMPLATE="SQL_CONFIG_TEMPLATE";
  
  /**
   * Error Codes and Description
   */
  
  /*** Default Response */
  public static final String RESPONSE_CODE="responseCode";
  public static final String RESPONSE_DESC="responseDesc";
  
  // INVALID Reqeust level 11 to 40
  public static final String INVALID_REQUEST="11";
  public static final String INVALID_REQUEST_MSG="Basic Attributes are missign in Reqeust";
  public static final String INVALID_OFFERS_REQUEST="12";
  
  // Application level 90 to 99
  public static final String NO_FLOW_REQUEST="90";
  public static final String NO_FLOW_REQUEST_MSG="Configruation is missing in Application";
  
  //OrderType
  public static final String orderType_NEW="NEW";
  
  //Order Param Keys
  public static final String packageCode="packageCode";
  public static final String packageId="packageId";
  public static final String primaryRatePlanCode="primaryRatePlanCode";
  public static final String primaryRatePlanId="primaryRatePlanId";
  public static final String primaryServiceId="primaryServiceId";
  public static final String primaryAcctServiceId="primaryAcctServiceId";
  public static final String primaryAcctServiceInstId="primaryAcctServiceInstId";
  public static final String accountId="accountId";
  public static final String accountNumber="accountNumber";
  public static final String accountSuffix="accountSuffix";
  public static final String partyId="partyId";
  public static final String profileId="profileId";
  public static final String orderType="ORDER_TYPE";
  public static final String subRequestId="subRequestId";
  public static final String productCode="PRODUCT";
  public static final String productGroupCode="PRODUCT_GROUP";
  public static final String userId="userId";
  public static final String productId="productId";
  public static final String productGroupId="productGroupId";
  
  //Config attribute
  public static final String WEB_SERVICE="WEB_SERVICE";
  public static final String CRC="CRC";
  public static final String URL="URL";
  public static final String COMMON_ATTRIBUTE="COMMON_ATTRIBUTE";
  public static final String WS_HEADER_VALUE="WS_HEADER_VALUE";
  public static final String WS_NAMESPACE="WS_NAMESPACE";
  public static final String PREPAYMENT="PREPAYMENT";
  
  public static final Long[] SUBREQUEST_STATUS_CANCEL_AND_CLOSED = {90l,91l};
  public static final Long[] REQUEST_STATUS_CANCEL_AND_CLOSED={489l,490l};
  public static String VAL_FLAG="FLAG";
  public static String VAL_OFF_FLAG="true";
  
}
