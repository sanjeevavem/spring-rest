package ae.etisalat.cw.restws.exceptions;

public class DAOException extends CBCMRestWSException {

	private static final long serialVersionUID = 2319648010439025977L;

	public DAOException() {
        super();
    }

    public DAOException(String code, String description) {
        super(code, description);
    }

    public DAOException(String code, String description, Throwable cause) {
        super(code, description, cause);
    }
    
    public DAOException(String description, Throwable cause) {
        super(description, cause);
    }

}