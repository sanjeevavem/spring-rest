package ae.etisalat.cw.restws.jpa.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="CW_DTL_SQL_PARAMETERS")
public class SQLParameters implements Serializable {
	private static final long serialVersionUID = -2557350713008274688L;
	
	@Id
	@Column(name="PARAM_ID")
	private String paramId;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="CONFIG_CODE")
	private SQLConfig sQLConfig;
	
	@Column(name="ATTRIBUTE_NAME")
	private String attributeName;
	
	@Column(name="ATTRIBUTE_VALUE")
	private String attributeValue;
	
	@Column(name="VERSION_ID")
	private String versionId;
	
	@Column(name="CREATED_USER_ID")
	private String createdUserId;
	
	@Column(name="CREATED_DATE")
	private Timestamp createdDate;
	
	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;
	
	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;
	
	public String getParamId() {
		return paramId;
	}
	public SQLConfig getsQLConfig() {
		return sQLConfig;
	}
	public void setsQLConfig(SQLConfig sQLConfig) {
		this.sQLConfig = sQLConfig;
	}
	public void setParamId(String paramId) {
		this.paramId = paramId;
	}

	public String getAttributeName() {
		return attributeName;
	}
	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}
	public String getAttributeValue() {
		return attributeValue;
	}
	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}
	public String getVersionId() {
		return versionId;
	}
	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}
	
	public String getCreatedUserId() {
		return createdUserId;
	}
	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getModifiedUserId() {
		return modifiedUserId;
	}
	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}
	public Timestamp getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	@Override
	public String toString() {
		return "SQLParameters [paramId=" + paramId + ", sQLConfig=" + sQLConfig + ", attributeName=" + attributeName
				+ ", attributeValue=" + attributeValue + ", versionId=" + versionId + ", createdUserId=" + createdUserId
				+ ", createdDate=" + createdDate + ", modifiedUserId=" + modifiedUserId + ", modifiedDate="
				+ modifiedDate + "]";
	}
	

	
}
