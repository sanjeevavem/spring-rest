package ae.etisalat.cw.restws.service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.logging.log4j.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import ae.etisalat.cw.comm.util.ECRMValidator;
import ae.etisalat.cw.comm.util.JSONUtil;
import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.UtilHelper;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.restws.dao.generic.GenericOrderCreationDAO;
import ae.etisalat.cw.restws.jpa.entities.ErrorCode;
import ae.etisalat.cw.restws.jpa.entities.GenericValidation;
import ae.etisalat.cw.restws.jpa.entities.GenericValidationParameter;
@Service
public class ValidationServiceImpl implements ValidationService {
	
	private GenericValidation genericValidation;
	
    @Autowired(required=true)
    private GenericOrderCreationDAO genericOrderCreationDAO;

	@Override
	public JsonObject validate(JsonObject validationConfig,JsonObject request,Object... parameters) throws Exception {
		if(!UtilHelper.isValidObject(request)){
			CWLog.logMessage(Level.INFO, "Not passed validate JSONObject");	
		}
		CWLog.logMessage(Level.INFO, "validate Start "+request.toString());
		
		JsonObject responseJsonObject = new JsonObject();
		
		JsonArray valTemplateArray = validationConfig.get("validationTeamplates").getAsJsonArray();  
		// Need to update the dynamic errorMessages
		
		List<JsonObject> valList = JSONUtil.getSortedJsonObjectByElement(valTemplateArray, "sequence");
		for(JsonObject jsonObj :valList ){
			  JsonObject jsonObjectValTemp = jsonObj;
			  String flag =  jsonObjectValTemp.get(UtilConstants.VAL_FLAG).getAsString();
			  if(flag!=null && UtilConstants.VAL_OFF_FLAG.equalsIgnoreCase(flag)){
				 continue;
			  }
			  String validationTemplate = jsonObjectValTemp.get("validationTemplate").getAsString();
			  
		    HashMap<String, Object> queryParamMap = new HashMap<String, Object>();
		    queryParamMap.put("VALIDATION_TEMPLATE", validationTemplate);
			List<GenericValidation> list =  genericOrderCreationDAO.executeQueryList("GenericValidation.findByTemplateId", queryParamMap, GenericValidation.class);
			
			if(list!=null && list.size()>0 ){
				GenericValidation genericValidation = list.get(0);
				for(GenericValidationParameter validationParameters : genericValidation.getGenericValidationParameters() ){
					String attributeName = validationParameters.getAttributeName();
					String jsonType = validationParameters.getJsonattributetype();
					String jsonPath = validationParameters.getJsonpath();
					String mandatoryFlag = validationParameters.getMandatoryFlag();
					BigDecimal fieldSize = validationParameters.getFieldSize();
					String regExpression = validationParameters.getRegExp();
					String validationType = validationParameters.getValidationType();
					String validationClass = validationParameters.getValidationClass();
					String isUpdatable = validationParameters.getIsUpdatable();
					String action = validationParameters.getAction();
					ErrorCode errorCode =  validationParameters.getErrorCode();
		       	CWLog.logMessage(Level.INFO, "Validation Parameters --> attributeName : "+request.toString()+" jsonType :"+jsonType+" jsonPath :"+jsonPath
					+"mandatoryFlag :"+mandatoryFlag+" fieldSize:"+fieldSize+" regExpression:"+regExpression+" validationType:"+validationType+" validationClass:"+validationClass+" isUpdatable:"+isUpdatable+" action:"+action);	
				    
					/*** Validate Mandatory Parameter ***/
					if(UtilHelper.isValidObject(mandatoryFlag) && (mandatoryFlag.equalsIgnoreCase("YES"))){
						String mandatoryresult = validateParameterExistence(attributeName,jsonType, jsonPath);
		
					}
					
					/*** Validate value Parameter Size ***/
					if(UtilHelper.isValidObject(fieldSize) && fieldSize.longValue() != 0){
						String fieldSizeResult = validateParameterValueSize(attributeName,jsonType, jsonPath, fieldSize.longValue());
	
					}
					
					/*** Validate REGEX Expression ***/
					if(UtilHelper.isValidObject(regExpression)){
						String regexExperssionResult = validateREGEXExpression(attributeName,request,jsonPath,regExpression);
							if(UtilHelper.isValidObject(regexExperssionResult)){
								responseJsonObject = errorRespone(errorCode.getErrorCodeId(), errorCode.getErrorDescription());
								return responseJsonObject;
							}
					}
				     
					/*** Validate Using Business Logic ***/
				  if(UtilHelper.isValidObject(validationClass)){
					 Class validatorClass = Class.forName(validationClass).asSubclass(ECRMValidator.class);
					 ECRMValidator validatorObj =(ECRMValidator) validatorClass.newInstance();
					 responseJsonObject = validatorObj.validate(request.toString());
					}

				  if(UtilHelper.isValidObject(responseJsonObject) && UtilHelper.isValidObject(responseJsonObject.get(UtilConstants.RESPONSE_CODE))){
					  System.out.println("Test ");
					  return responseJsonObject;
				  }
					
				} // End of for loop
			}// end of If
			
 
		}
		
		CWLog.logMessage(Level.INFO, "validate End "+request.toString());
	 return responseJsonObject;
	}

	private String validateParameterValueSize(String attributeName, String jsonType, String jsonPath, long longValue) {

		return null;
	}

	private String validateParameterExistence(String attributeName, String jsonType, String jsonPath) {

		return null;
	}
	
	private static String validateREGEXExpression(String paramName,JsonObject jsonObject,String jsonPath, String regExpression) throws Exception {
		String paramValue = JSONUtil.getJSONValueByKey(jsonObject.toString(),jsonPath);
		Pattern pattern = Pattern.compile(regExpression);   
		Matcher matcher = pattern.matcher(paramValue);   
		if(matcher.matches()){   
			return null;
		} 
	 return  "The value of param name: "+paramName + " is not matched the expected REGEX expression";
	}
	
	public JsonObject errorRespone(String errorCode,String errorDesc) {
		  JsonObject jsonObject = new JsonObject();
		  jsonObject.addProperty(UtilConstants.RESPONSE_CODE, errorCode);
		  jsonObject.addProperty(UtilConstants.RESPONSE_DESC, errorDesc);
		 return jsonObject;
	 }

}
