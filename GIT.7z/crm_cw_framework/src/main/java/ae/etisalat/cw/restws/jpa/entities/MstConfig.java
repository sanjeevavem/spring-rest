package ae.etisalat.cw.restws.jpa.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;

@Entity
@Table(name="MST_CONFIG")
public class MstConfig implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CONFIG_CODE")
	private String configCode;

	@Column(name="CONFIG_TYPE")
	private String configType;

	@Column(name="description")
	private String description;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;
	
	@Column(name="CREATED_DATE")
	private Timestamp createdDate;
	
	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@OneToMany(mappedBy="mstConfig")
	private List<DtlConfig> dtlConfigs;

	public MstConfig() {
	}

	public String getConfigCode() {
		return this.configCode;
	}

	public void setConfigCode(String configCode) {
		this.configCode = configCode;
	}

	public String getConfigType() {
		return this.configType;
	}

	public void setConfigType(String configType) {
		this.configType = configType;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public List<DtlConfig> getDtlConfigs() {
		return this.dtlConfigs;
	}

	public void setDtlConfigs(List<DtlConfig> dtlConfigs) {
		this.dtlConfigs = dtlConfigs;
	}

	public DtlConfig addDtlConfig(DtlConfig dtlConfig) {
		getDtlConfigs().add(dtlConfig);
		dtlConfig.setMstConfig(this);

		return dtlConfig;
	}

	public DtlConfig removeDtlConfig(DtlConfig dtlConfig) {
		getDtlConfigs().remove(dtlConfig);
		dtlConfig.setMstConfig(null);

		return dtlConfig;
	}

}