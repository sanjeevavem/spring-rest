package ae.etisalat.cw.restws.jpa.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the CW_VALIDATION_SCHEMA database table.
 * 
 */
@Entity
@Table(name="CW_VALIDATION_SCHEMA")
@NamedNativeQueries({
@NamedNativeQuery(name="CwValidationSchema.findAll",query="SELECT c FROM CwValidationSchema c",resultClass=CwValidationSchema.class),
@NamedNativeQuery(name="CwValidationSchema.findByTemplateId",query="SELECT * FROM CW_VALIDATION_SCHEMA WHERE TEMPLATE_ID=:templateId ",resultClass=CwValidationSchema.class)
})

public class CwValidationSchema implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long id;

	@Lob
	@Column(name="JSON_SCHEMA")
	private String jsonSchema;

	@Column(name="TEMPLATE_ID")
	private String templateId;

	public CwValidationSchema() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getJsonSchema() {
		return this.jsonSchema;
	}

	public void setJsonSchema(String jsonSchema) {
		this.jsonSchema = jsonSchema;
	}

	public String getTemplateId() {
		return this.templateId;
	}

	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

}