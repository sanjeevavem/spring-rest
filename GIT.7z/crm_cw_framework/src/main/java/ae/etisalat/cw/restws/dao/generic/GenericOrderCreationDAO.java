package ae.etisalat.cw.restws.dao.generic;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import ae.etisalat.cw.restws.exceptions.DAOException;


public interface GenericOrderCreationDAO {

    /**
     * Method to execute query which results in single record.
     */
    public Map<String, Object> query(DataSourceType dataSourceType, String sql, Map<String, Object> args) throws DAOException;

    /**
     * Method to execute query which results in a list of records.
     */
    public List<Map<String, Object>> queryList(DataSourceType dataSourceType, String sql, Map<String, Object> args) throws DAOException;
   
    /**
     * Method to insert into table
     */
	public int insert(DataSourceType dataSourceType, String sql, Map<String, Object> args) throws DAOException;
	
	public <T> T update(Object entity,Class<T> entityClass) throws DAOException;
	
	public <T> T findById(Class<T> entityClass, Serializable id) throws DAOException;
	
    public int executeNativeUpdateQuery(String sql, Map<String, Object> args) throws  DAOException;
    
	public  <T> List<T> executeQueryList(String sql, Map<String,Object> params,Class<T> entityClass)throws DAOException;
	 
	public  <T> T executeQuery(String sql, Map<String,Object> params,Class<T> entityClass) throws DAOException;
    
}
