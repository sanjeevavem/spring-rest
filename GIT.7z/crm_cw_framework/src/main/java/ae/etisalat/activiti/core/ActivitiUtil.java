package ae.etisalat.activiti.core;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.logging.log4j.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.github.fge.jsonschema.core.report.ProcessingMessage;
import com.google.gson.JsonObject;

import ae.etisalat.cw.comm.util.JSONUtil;
import ae.etisalat.cw.comm.util.Util;
import ae.etisalat.cw.comm.util.ValidationUtils;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.restws.dao.generic.GenericOrderCreationDAO;
import ae.etisalat.cw.restws.exceptions.CBCMRestWSException;
import ae.etisalat.cw.restws.exceptions.DAOException;
import ae.etisalat.cw.restws.jpa.entities.CwMstFlowMap;
import ae.etisalat.cw.restws.jpa.entities.CwValidationSchema;
import ae.etisalat.cw.restws.service.ValidationService;

@Component
public class ActivitiUtil {
	@Autowired
	private GenericOrderCreationDAO genericOrderCreationDAO;
	
	@Autowired
	private ValidationService validationService;

	public CwMstFlowMap findProductFlow(Map<String, Object> request) throws Exception {
      CWLog.logMessage(Level.INFO, "findProductFlow Start"+request.toString());	
		HashMap<String, Object> paramValuesMap = new HashMap<String, Object>(); 
		 paramValuesMap.put("ORDER_TYPE", request.get("ORDER_TYPE"));
		 paramValuesMap.put("FLOW_TYPE", "MAIN");
		 paramValuesMap.put("PRODUCT_GROUP",request.get("PRODUCT_GROUP"));
		 paramValuesMap.put("PRODUCT",request.get("PRODUCT"));
		 List<CwMstFlowMap> list = genericOrderCreationDAO.executeQueryList("CwMstFlowMap.findByOrderTypeAndFlowTypeAndPGAndProduct", paramValuesMap,CwMstFlowMap.class);
	   CWLog.logMessage(Level.INFO, "findProductFlow End"+request.toString());	
	   return list!=null?list.get(0):null;
	}
	
	public List<CwMstFlowMap> findProductSubFlow(Map<String, Object> request) throws Exception {
      CWLog.logMessage(Level.INFO, "findProductSubFlow Start"+request.toString());	
		HashMap<String, Object> paramValuesMap = new HashMap<String, Object>(); 
		 paramValuesMap.put("ORDER_TYPE", request.get("ORDER_TYPE"));
		 paramValuesMap.put("FLOW_TYPE", "DEPENDENT");
		 paramValuesMap.put("PRODUCT_GROUP",request.get("PRODUCT_GROUP"));
		 paramValuesMap.put("PRODUCT",request.get("PRODUCT"));
		 paramValuesMap.put("OFFER_CODES", request.get("OFFER_CODES"));
		 List<CwMstFlowMap> list = genericOrderCreationDAO.executeQueryList("CwMstFlowMap.findByOrderTypeAndFlowTypeAndPGAndProduct", paramValuesMap,CwMstFlowMap.class);
	   CWLog.logMessage(Level.INFO, "findProductSubFlow End"+request.toString());	
	   return list;
	}
	
	public JsonObject executeValidationAPI(CwMstFlowMap cwMstFlowMap,JsonObject request) throws Exception{
	   CWLog.logMessage(Level.INFO, "executeValidationAPI Start"+cwMstFlowMap);
		if(cwMstFlowMap!=null && cwMstFlowMap.getJsonValidationTemplate()!=null){
		   String jsonValStr = cwMstFlowMap.getJsonValidationTemplate();
		   JsonObject jsonValObj = JSONUtil.convertJSONStringToJSONObject(jsonValStr);
		   validationService.validate(jsonValObj,request, null);  
		 }
	   CWLog.logMessage(Level.INFO, "executeValidationAPI End"+cwMstFlowMap);
	  return null;
	}

	public CwValidationSchema getJsonSchema(String templateId) throws Exception {
		HashMap<String, Object> paramValuesMap = new HashMap<String, Object>(); 
		paramValuesMap.put("templateId", templateId);
		List<CwValidationSchema> list =
				Optional.ofNullable((genericOrderCreationDAO.executeQueryList("CwValidationSchema.findByTemplateId", paramValuesMap,CwValidationSchema.class)))
				.orElseThrow(() -> new DAOException("1234", "JSON Schema Not Found"));
			return list.get(0);
	}
	public boolean validateSchema(String jsonValidationTemplate, String json) throws Exception {
		String jsonSchema = getJsonSchema(jsonValidationTemplate).getJsonSchema();
		Stream<ProcessingMessage> errorMsgStream = ValidationUtils.validateWithErrorMsg(jsonSchema,json);
		if (!Util.isValidObject(errorMsgStream)){
			CWLog.logMessage(Level.INFO, "Schema Validation successful");
		}else{
			List<String> errors = errorMsgStream.map(sc -> sc.getMessage()).collect(Collectors.toList());
			throw new CBCMRestWSException("101","Schema Validation Failed" + String.join(",", errors));
		}
		return true;
	}


}
