package ae.etisalat.activiti.core;

import java.util.HashMap;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.apache.logging.log4j.Level;
import org.hibernate.mapping.Map;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;

import ae.etisalat.cw.comm.util.JSONUtil;
import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.UtilHelper;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.restws.jpa.entities.SQLConfigDtlMap;

@Service
public class GenericDBQueryActivitiAPI extends ActivitiAPI {

	UtilHelper util = null;
	JSONUtil jsonUtil = null;
	
	private Expression JSON_REQUEST;
	
	@Override
	public void init(DelegateExecution execution) throws Exception {
		util = new UtilHelper();
		jsonUtil = new JSONUtil();
	}
	@SuppressWarnings("unchecked")
	@Override
	public void run(DelegateExecution execution) throws Exception {
		CWLog.logMessage(Level.INFO, "run Start");
		HashMap<String, Object> orderInfoMap =execution.getVariable(UtilConstants.orderParamValues,HashMap.class); 
		 util = new UtilHelper();
		String jsonReq = (String)execution.getVariable(UtilConstants.JSON_REQUEST);
		String apiContext = (String)execution.getVariable(UtilConstants.ACTIVITI_API_CTX);
		
		JsonObject jsonReqObj = JSONUtil.convertJSONStringToJSONObject(jsonReq);  
		JsonObject apiContextJSON = jsonReqObj;//JSONUtil.convertJSONStringToJSONObject(apiContext); // need to integreate
	//	JsonObject requestContextJSON = apiContextJSON.get(UtilConstants.ACTIVITI_REQ_JSON).getAsJsonObject();
		
		/**
		 *  1. fetech offer attributes
		 *  2. fetech sub request attributes like reqeust id, sub request id, instance id
		 *  3. fetech config from CW_DTL_SQL_CONFIG_MAP and sequnce, skip then execute set response output 
		 */
		
		HashMap<String, Object> paramValuesMap =execution.getVariable(UtilConstants.paramValue,HashMap.class);
		List<SQLConfigDtlMap> list = genericOrderCreationDAO.executeQueryList("SQLConfigDtlMap.findByOfferTypeOrderTypeOrderCode", paramValuesMap,SQLConfigDtlMap.class);
		/**
		 * Configuration Sequencing need to be implemented
		 */
		try {
			for(SQLConfigDtlMap sqlConfigDtlMap:list){
				orderInfoMap.put(UtilConstants.JSON_REQUEST, jsonReqObj);
				paramValuesMap.put(UtilConstants.SQL_CONFIG_TEMPLATE, sqlConfigDtlMap.getSqlConfig());
				genericDBQueryAPI.execute(orderInfoMap, paramValuesMap);				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}

	     //Map<String, Object> outputVaribales = activitiEngine.executeWorkflow("Generic_Service_Process", new HashMap<String,Object>());


	     CWLog.logMessage(Level.INFO, "run() end");
	
	

	}

}
