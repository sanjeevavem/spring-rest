package ae.etisalat.activiti.core;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.activiti.engine.HistoryService;
import org.activiti.engine.ManagementService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.history.HistoricVariableInstance;
import org.activiti.engine.repository.DeploymentBuilder;
import org.activiti.engine.runtime.ProcessInstance;
import org.apache.logging.log4j.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ae.etisalat.cw.comm.util.logger.CWLog;

@Service
@Transactional
public class ActivitiEngine {

	@Autowired
	private ProcessEngine processEngine;
	
	private RuntimeService runtimeService;
	private HistoryService historyService;
	private ManagementService managementService;
	
	@Value("${app.BPMN.files.location}")
	private String workFlowFilesLocation;

	@PostConstruct
	public void init() {
		try {
			runtimeService = processEngine.getRuntimeService();
			RepositoryService repositoryService = processEngine.getRepositoryService();
			historyService = processEngine.getHistoryService();
			managementService = processEngine.getManagementService();
		} catch (Exception e) {
			CWLog.logMessage(e,"Failed to initiate ACTIVITI Engine");
		} finally {
			CWLog.logMessage(Level.INFO,"init() - finished");
		}
	}
	
	public void loadBPMNFiles() throws Exception
	{
	  try 
		 {
			RepositoryService repositoryService = processEngine.getRepositoryService();
			loadBPMNFiles(repositoryService);
		 } catch (Exception e) {
			CWLog.logMessage(e,"Failed to initiate ACTIVITI Engine");
			throw new Exception(e);
		 } finally {
			CWLog.logMessage(Level.INFO,"init() - finished");
		}	 
	 }
	
	public void loadBPMNFiles(RepositoryService repositoryService) throws Exception
	{
	 CWLog.logMessage(Level.INFO, "loadBPMNFiles Start");	
	  try 
		 {
		  DeploymentBuilder deploymentBuilder = repositoryService.createDeployment();
		  File folder = new File(workFlowFilesLocation);  
		  CWLog.logMessage(Level.INFO, "BPMN Files location",folder.getPath());
			for(File file:folder.listFiles() ){
				if(!file.isDirectory()){
					CWLog.logMessage(Level.INFO,"BPMN File Name -> "+file.getAbsoluteFile());
					deploymentBuilder.addInputStream(file.getName(), new FileInputStream(file.getAbsoluteFile()));
				}
			}
			deploymentBuilder.deploy();
		 } catch (Exception e) {
			CWLog.logMessage(e,"Failed to initiate ACTIVITI Engine");
			throw new Exception(e);
		 } finally {
			CWLog.logMessage(Level.INFO,"init() - finished");
		}
	  CWLog.logMessage(Level.INFO, "loadBPMNFiles End");
	 }


	public Map<String, Object> executeWorkflow(String workflow, Map<String, Object> variables) throws Exception {
		CWLog.logMessage(Level.INFO,"init(executeWorkflow for processDefinitionKey {}) - start",workflow);
		long beforeCall = System.nanoTime();
		Map<String, Object> outputVariables = new HashMap<String, Object>();
		try {
			ProcessInstance processInstance = runtimeService.startProcessInstanceByKey(workflow, variables);
			outputVariables = populateOutputVariables(processInstance);
			System.out.println("outputVariables" + outputVariables);
			CWLog.logMessage(Level.INFO,"[{}] - Done: {} MillSeconds ",""+processInstance.getId(),""+ ((System.nanoTime() - beforeCall) / 1000000.0));
			return outputVariables;
		} catch (Exception e) {
			CWLog.logMessage(e,"Error occured during executeWorkflow ");
			throw e;
		} finally {
			CWLog.logMessage(Level.INFO,"init(workflow={}) - finished", workflow);
		}
	}

	private Map<String, Object> populateOutputVariables(ProcessInstance processInstance) {
		Map<String, Object> outputVariables = new HashMap<String, Object>();
		outputVariables.put("processInstanceId", processInstance.getProcessInstanceId());
		for (HistoricVariableInstance variableInstance : processEngine.getHistoryService()
				.createHistoricVariableInstanceQuery().processInstanceId(processInstance.getId()).list()) {
			outputVariables.put(variableInstance.getVariableName(), variableInstance.getValue());
		}
		return outputVariables;
	}

	public ProcessEngine getProcessEngine() {
		return processEngine;
	}

	public void setProcessEngine(ProcessEngine processEngine) {
		this.processEngine = processEngine;
	}

	public RuntimeService getRuntimeService() {
		return runtimeService;
	}

	public void setRuntimeService(RuntimeService runtimeService) {
		this.runtimeService = runtimeService;
	}

	public HistoryService getHistoryService() {
		return historyService;
	}

	public void setHistoryService(HistoryService historyService) {
		this.historyService = historyService;
	}

}
