package ae.etisalat.activiti.core;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.google.gson.JsonObject;

import ae.etisalat.cw.comm.util.JSONUtil;
import ae.etisalat.cw.comm.util.UtilConstants;
import ae.etisalat.cw.comm.util.UtilHelper;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.restws.jpa.entities.SQLConfig;
import ae.etisalat.cw.restws.jpa.entities.SQLParameters;
import ae.etisalat.cw.restws.dao.generic.GenericOrderCreationDAO;
import ae.etisalat.cw.restws.exceptions.DAOException;


@Component
public class GenericDBQueryAPI implements Serializable {

	@Autowired
	private GenericOrderCreationDAO genericDAO;
	
	@Autowired
	@Qualifier("utilHelper")
	private UtilHelper util;
	
	private static final long serialVersionUID = 1750067248214560916L;
	

	public HashMap<String, Object> execute (HashMap<String, Object> orderInfo,HashMap<String,Object> inputParam) throws Exception {
		CWLog.logMessage(Level.INFO,"init(executeWorkflow for processDefinitionKey {}) - start",orderInfo.toString());
		HashMap<String, Object> map = new HashMap<String, Object>();
		JsonObject restReqeust = JSONUtil.convertJSONStringToJSONObject(orderInfo.get(UtilConstants.JSON_REQUEST).toString());
		//JsonObject restResponse = JSONUtil.convertJSONStringToJSONObject(orderInfo.get(UtilConstants.JSON_RESPONSE).toString());
		/*
		 * 1. fetech the configuration
		 * 2. fetech config parameters
		 * 3. check json path
		 */
		
		SQLConfig sqlConfigT = inputParam.get(UtilConstants.SQL_CONFIG_TEMPLATE)!=null?(SQLConfig)inputParam.get(UtilConstants.SQL_CONFIG_TEMPLATE):null;
		
			try 
			{
			 HashMap<String, Object> queryParamMap = new HashMap<String, Object>();
			 queryParamMap.put("config_code", sqlConfigT.getConfigCode());
			  List<SQLConfig>  sqlConfigList = genericDAO.executeQueryList("SQLConfig.findByConfigCode", queryParamMap, SQLConfig.class);
			  SQLConfig sqlConfig = sqlConfigList.get(0);
			  System.out.println(sqlConfigList);
			  HashMap<String, Object> valueMap = this.getSQLParameters(sqlConfig,orderInfo);
			  String query = valueMap.get("query")!=null?valueMap.get("query").toString():null;
			  
				List<String> queryParams = UtilHelper.getQueryParams(query, ":\\w+");

				List<Object> paramValues = new ArrayList<Object>();
				HashMap<String, Object> paramValuesMap = new HashMap<String, Object>(); 
				int size = queryParams.size();
				for (int i = 0; i < size; i++) {
					paramValuesMap.put(queryParams.get(i).toString(),valueMap.get(queryParams.get(i).toString()));
				}

			   genericDAO.executeNativeUpdateQuery(query, paramValuesMap);
			  
			  if( sqlConfig!=null && sqlConfig.getsQLParameters()!=null)
			     sqlConfig.getsQLParameters().forEach(System.out::println);
			} catch (DAOException e) {
			  e.printStackTrace();
			}
		
		CWLog.logMessage(Level.INFO,"init(executeWorkflow for processDefinitionKey {}) - end",orderInfo.toString());
	    return map;
	   }
	


   private HashMap<String, Object> getSQLParameters(SQLConfig sqlConfig, HashMap<String, Object> orderInfo) throws Exception {
	   HashMap<String, Object> sqlMap = new HashMap<String, Object>();
	   for(SQLParameters sqlParameters: sqlConfig.getsQLParameters()){
		   Object value = util.getDynamicparamValue("", orderInfo, sqlParameters, new HashMap<String, Object>());
		   sqlMap.put(sqlParameters.getAttributeName(), value);
	   }
	   return sqlMap;
   }

}
