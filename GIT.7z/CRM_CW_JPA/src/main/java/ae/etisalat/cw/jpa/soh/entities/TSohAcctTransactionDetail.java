package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the T_SOH_ACCT_TRANSACTION_DETAILS database table.
 * 
 */
@Entity
@Table(name="T_SOH_ACCT_TRANSACTION_DETAILS")
@NamedQuery(name="TSohAcctTransactionDetail.findAll", query="SELECT t FROM TSohAcctTransactionDetail t")
public class TSohAcctTransactionDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_SOH_ACCT_TRANSACTION_DETAILS_TRANSACTIONID_GENERATOR", sequenceName="SQ_T_SOH_ACCT_TRANSACTION_DTL",allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_SOH_ACCT_TRANSACTION_DETAILS_TRANSACTIONID_GENERATOR")
	@Column(name="TRANSACTION_ID")
	private long transactionId;

	@Column(name="ACCOUNT_ID")
	private BigDecimal accountId;

	@Column(name="ACTIVATION_DATE")
	private Timestamp activationDate;

	@Column(name="BILL_CYCLE_ID")
	private BigDecimal billCycleId;

	@Temporal(TemporalType.DATE)
	@Column(name="BILL_CYCLE_START_DATE")
	private Date billCycleStartDate;

	@Column(name="CHARGE_TYPE_ID")
	private BigDecimal chargeTypeId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="DEVICE_CONTRACT_RP")
	private BigDecimal deviceContractRp;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="NEXT_DUE_DATE")
	private Date nextDueDate;

	@Column(name="RATE_PLAN_ID")
	private BigDecimal ratePlanId;

	@Column(name="SUBREQUEST_ID")
	private BigDecimal subrequestId;

	@Temporal(TemporalType.DATE)
	@Column(name="TRANS_FROM_DATE")
	private Date transFromDate;

	@Temporal(TemporalType.DATE)
	@Column(name="TRANS_TO_DATE")
	private Date transToDate;

	@Column(name="TRANSACTION_AMOUNT")
	private BigDecimal transactionAmount;

	@Column(name="TRANSACTION_DATE")
	private Timestamp transactionDate;

	@Column(name="TRANSACTION_TYPE")
	private String transactionType;

	@Column(name="TXN_TYPE")
	private BigDecimal txnType;

	//bi-directional many-to-one association to TSohAccountServiceDetail
	@ManyToOne
	@JoinColumn(name="ACCOUNT_SERVICE_ID")
	private TSohAccountServiceDetail TSohAccountServiceDetail;

	public TSohAcctTransactionDetail() {
	}

	public long getTransactionId() {
		return this.transactionId;
	}

	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}

	public BigDecimal getAccountId() {
		return this.accountId;
	}

	public void setAccountId(BigDecimal accountId) {
		this.accountId = accountId;
	}

	public Timestamp getActivationDate() {
		return this.activationDate;
	}

	public void setActivationDate(Timestamp activationDate) {
		this.activationDate = activationDate;
	}

	public BigDecimal getBillCycleId() {
		return this.billCycleId;
	}

	public void setBillCycleId(BigDecimal billCycleId) {
		this.billCycleId = billCycleId;
	}

	public Date getBillCycleStartDate() {
		return this.billCycleStartDate;
	}

	public void setBillCycleStartDate(Date billCycleStartDate) {
		this.billCycleStartDate = billCycleStartDate;
	}

	public BigDecimal getChargeTypeId() {
		return this.chargeTypeId;
	}

	public void setChargeTypeId(BigDecimal chargeTypeId) {
		this.chargeTypeId = chargeTypeId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public BigDecimal getDeviceContractRp() {
		return this.deviceContractRp;
	}

	public void setDeviceContractRp(BigDecimal deviceContractRp) {
		this.deviceContractRp = deviceContractRp;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public Date getNextDueDate() {
		return this.nextDueDate;
	}

	public void setNextDueDate(Date nextDueDate) {
		this.nextDueDate = nextDueDate;
	}

	public BigDecimal getRatePlanId() {
		return this.ratePlanId;
	}

	public void setRatePlanId(BigDecimal ratePlanId) {
		this.ratePlanId = ratePlanId;
	}

	public BigDecimal getSubrequestId() {
		return this.subrequestId;
	}

	public void setSubrequestId(BigDecimal subrequestId) {
		this.subrequestId = subrequestId;
	}

	public Date getTransFromDate() {
		return this.transFromDate;
	}

	public void setTransFromDate(Date transFromDate) {
		this.transFromDate = transFromDate;
	}

	public Date getTransToDate() {
		return this.transToDate;
	}

	public void setTransToDate(Date transToDate) {
		this.transToDate = transToDate;
	}

	public BigDecimal getTransactionAmount() {
		return this.transactionAmount;
	}

	public void setTransactionAmount(BigDecimal transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public Timestamp getTransactionDate() {
		return this.transactionDate;
	}

	public void setTransactionDate(Timestamp transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getTransactionType() {
		return this.transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public BigDecimal getTxnType() {
		return this.txnType;
	}

	public void setTxnType(BigDecimal txnType) {
		this.txnType = txnType;
	}

	public TSohAccountServiceDetail getTSohAccountServiceDetail() {
		return this.TSohAccountServiceDetail;
	}

	public void setTSohAccountServiceDetail(TSohAccountServiceDetail TSohAccountServiceDetail) {
		this.TSohAccountServiceDetail = TSohAccountServiceDetail;
	}

}