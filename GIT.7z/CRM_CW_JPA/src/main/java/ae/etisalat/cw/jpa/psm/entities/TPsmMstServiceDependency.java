package ae.etisalat.cw.jpa.psm.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the T_PSM_MST_SERVICE_DEPENDENCY database table.
 * 
 */
@Entity
@Table(name="T_PSM_MST_SERVICE_DEPENDENCY")
@NamedQuery(name="TPsmMstServiceDependency.findAll", query="SELECT t FROM TPsmMstServiceDependency t")
public class TPsmMstServiceDependency implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="SERVICE_DEPENDENCY_ID")
	private long serviceDependencyId;

	@Column(name="ADD_REMOVE_FLG")
	private String addRemoveFlg;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="OR_DEPENDENCY")
	private String orDependency;

	@Column(name="PACKAGE_ID")
	private BigDecimal packageId;

	@Column(name="RATE_PLAN_ID")
	private BigDecimal ratePlanId;

	@Column(name="SERVICE_DEPENDENCY_CODE")
	private String serviceDependencyCode;

	@Column(name="SERVICE_DEPENDENCY_DESC")
	private String serviceDependencyDesc;

	//bi-directional many-to-one association to TPsmDtlServiceDependency
	@OneToMany(mappedBy="TPsmMstServiceDependency")
	private List<TPsmDtlServiceDependency> TPsmDtlServiceDependencies;

	//bi-directional many-to-one association to TPsmMstSrvc
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="EFFECTIVE_FROM_DATE", referencedColumnName="EFFECTIVE_FROM_DATE"),
		@JoinColumn(name="SRVC_ID", referencedColumnName="SRVC_ID")
		})
	private TPsmMstSrvc TPsmMstSrvc;

	public TPsmMstServiceDependency() {
	}

	public long getServiceDependencyId() {
		return this.serviceDependencyId;
	}

	public void setServiceDependencyId(long serviceDependencyId) {
		this.serviceDependencyId = serviceDependencyId;
	}

	public String getAddRemoveFlg() {
		return this.addRemoveFlg;
	}

	public void setAddRemoveFlg(String addRemoveFlg) {
		this.addRemoveFlg = addRemoveFlg;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getOrDependency() {
		return this.orDependency;
	}

	public void setOrDependency(String orDependency) {
		this.orDependency = orDependency;
	}

	public BigDecimal getPackageId() {
		return this.packageId;
	}

	public void setPackageId(BigDecimal packageId) {
		this.packageId = packageId;
	}

	public BigDecimal getRatePlanId() {
		return this.ratePlanId;
	}

	public void setRatePlanId(BigDecimal ratePlanId) {
		this.ratePlanId = ratePlanId;
	}

	public String getServiceDependencyCode() {
		return this.serviceDependencyCode;
	}

	public void setServiceDependencyCode(String serviceDependencyCode) {
		this.serviceDependencyCode = serviceDependencyCode;
	}

	public String getServiceDependencyDesc() {
		return this.serviceDependencyDesc;
	}

	public void setServiceDependencyDesc(String serviceDependencyDesc) {
		this.serviceDependencyDesc = serviceDependencyDesc;
	}

	public List<TPsmDtlServiceDependency> getTPsmDtlServiceDependencies() {
		return this.TPsmDtlServiceDependencies;
	}

	public void setTPsmDtlServiceDependencies(List<TPsmDtlServiceDependency> TPsmDtlServiceDependencies) {
		this.TPsmDtlServiceDependencies = TPsmDtlServiceDependencies;
	}

	public TPsmDtlServiceDependency addTPsmDtlServiceDependency(TPsmDtlServiceDependency TPsmDtlServiceDependency) {
		getTPsmDtlServiceDependencies().add(TPsmDtlServiceDependency);
		TPsmDtlServiceDependency.setTPsmMstServiceDependency(this);

		return TPsmDtlServiceDependency;
	}

	public TPsmDtlServiceDependency removeTPsmDtlServiceDependency(TPsmDtlServiceDependency TPsmDtlServiceDependency) {
		getTPsmDtlServiceDependencies().remove(TPsmDtlServiceDependency);
		TPsmDtlServiceDependency.setTPsmMstServiceDependency(null);

		return TPsmDtlServiceDependency;
	}

	public TPsmMstSrvc getTPsmMstSrvc() {
		return this.TPsmMstSrvc;
	}

	public void setTPsmMstSrvc(TPsmMstSrvc TPsmMstSrvc) {
		this.TPsmMstSrvc = TPsmMstSrvc;
	}

}