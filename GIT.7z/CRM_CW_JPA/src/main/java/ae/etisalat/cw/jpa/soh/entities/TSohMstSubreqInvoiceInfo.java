package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;

import javax.persistence.*;

import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the T_SOH_MST_SUBREQ_INVOICE_INFO database table.
 * 
 */
@Entity
@Table(name="T_SOH_MST_SUBREQ_INVOICE_INFO")
@NamedQuery(name="TSohMstSubreqInvoiceInfo.findAll", query="SELECT t FROM TSohMstSubreqInvoiceInfo t")
public class TSohMstSubreqInvoiceInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="SQ_T_SOH_MST_SUBREQ_INV_INF_ID", sequenceName="SQ_T_SOH_MST_SUBREQ_INV_INF_ID",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SQ_T_SOH_MST_SUBREQ_INV_INF_ID")
	@Column(name="SUBREQ_INVOICE_ID")
	private long subreqInvoiceId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="EMAIL_ID")
	private String emailId;

	@Column(name="INVOICE_NAME_ARABIC")
	private String invoiceNameArabic;

	@Column(name="INVOICE_NAME_ENG")
	private String invoiceNameEng;

	@Column(name="INVOICE_REQUIRED_FLAG")
	private String invoiceRequiredFlag;

	@Column(name="INVOICE_TYPE_ID")
	private String invoiceTypeId;

	private String mobile;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="PREFERED_DELIVERY_MODE")
	private BigDecimal preferedDeliveryMode;

	@Column(name="USAGE_CLASSIFICATION")
	private BigDecimal usageClassification;

	@Column(name="BSA_ACCOUNT_ID")
	private BigDecimal bsaAccountId;

	@Column(name="BSA_AVAILABLE_FLAG")
	private String bsaAvailableFlag;

	@Column(name="BSA_LINK_STATUS")
	private BigDecimal bsaLinkStatus;

	public TSohMstSubreqInvoiceInfo() {
	}

	public long getSubreqInvoiceId() {
		return this.subreqInvoiceId;
	}

	public void setSubreqInvoiceId(long subreqInvoiceId) {
		this.subreqInvoiceId = subreqInvoiceId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public String getEmailId() {
		return this.emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getInvoiceNameArabic() {
		return this.invoiceNameArabic;
	}

	public void setInvoiceNameArabic(String invoiceNameArabic) {
		this.invoiceNameArabic = invoiceNameArabic;
	}

	public String getInvoiceNameEng() {
		return this.invoiceNameEng;
	}

	public void setInvoiceNameEng(String invoiceNameEng) {
		this.invoiceNameEng = invoiceNameEng;
	}

	public String getInvoiceRequiredFlag() {
		return this.invoiceRequiredFlag;
	}

	public void setInvoiceRequiredFlag(String invoiceRequiredFlag) {
		this.invoiceRequiredFlag = invoiceRequiredFlag;
	}

	public String getInvoiceTypeId() {
		return this.invoiceTypeId;
	}

	public void setInvoiceTypeId(String invoiceTypeId) {
		this.invoiceTypeId = invoiceTypeId;
	}

	public String getMobile() {
		return this.mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getPreferedDeliveryMode() {
		return this.preferedDeliveryMode;
	}

	public void setPreferedDeliveryMode(BigDecimal preferedDeliveryMode) {
		this.preferedDeliveryMode = preferedDeliveryMode;
	}

	public BigDecimal getUsageClassification() {
		return this.usageClassification;
	}

	public void setUsageClassification(BigDecimal usageClassification) {
		this.usageClassification = usageClassification;
	}

	public BigDecimal getBsaAccountId() {
		return this.bsaAccountId;
	}

	public void setBsaAccountId(BigDecimal bsaAccountId) {
		this.bsaAccountId = bsaAccountId;
	}

	public String getBsaAvailableFlag() {
		return this.bsaAvailableFlag;
	}

	public void setBsaAvailableFlag(String bsaAvailableFlag) {
		this.bsaAvailableFlag = bsaAvailableFlag;
	}

	public BigDecimal getBsaLinkStatus() {
		return this.bsaLinkStatus;
	}

	public void setBsaLinkStatus(BigDecimal bsaLinkStatus) {
		this.bsaLinkStatus = bsaLinkStatus;
	}

}