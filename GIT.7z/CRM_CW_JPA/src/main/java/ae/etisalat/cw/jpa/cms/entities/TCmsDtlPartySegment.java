package ae.etisalat.cw.jpa.cms.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the T_CMS_DTL_PARTY_SEGMENT database table.
 * 
 */
@Entity
@Table(name="T_CMS_DTL_PARTY_SEGMENT")
@NamedQuery(name="TCmsDtlPartySegment.findAll", query="SELECT t FROM TCmsDtlPartySegment t")
public class TCmsDtlPartySegment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_CMS_DTL_PARTY_SEGMENT_PARTYSEGMENTVALUEID_GENERATOR", sequenceName="SQ_CMS_PARTY_SEG")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_CMS_DTL_PARTY_SEGMENT_PARTYSEGMENTVALUEID_GENERATOR")
	@Column(name="PARTY_SEGMENT_VALUE_ID")
	private long partySegmentValueId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_FROM")
	private Date effectiveFrom;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_TILL")
	private Date effectiveTill;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="PARTY_ID")
	private BigDecimal partyId;

	@Column(name="PROFILE_ID")
	private BigDecimal profileId;

	@Column(name="SEGMENT_CODE")
	private String segmentCode;

	@Column(name="SEGMENT_VALUE_ID")
	private BigDecimal segmentValueId;

	public TCmsDtlPartySegment() {
	}

	public long getPartySegmentValueId() {
		return this.partySegmentValueId;
	}

	public void setPartySegmentValueId(long partySegmentValueId) {
		this.partySegmentValueId = partySegmentValueId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Date getEffectiveFrom() {
		return this.effectiveFrom;
	}

	public void setEffectiveFrom(Date effectiveFrom) {
		this.effectiveFrom = effectiveFrom;
	}

	public Date getEffectiveTill() {
		return this.effectiveTill;
	}

	public void setEffectiveTill(Date effectiveTill) {
		this.effectiveTill = effectiveTill;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getPartyId() {
		return this.partyId;
	}

	public void setPartyId(BigDecimal partyId) {
		this.partyId = partyId;
	}

	public BigDecimal getProfileId() {
		return this.profileId;
	}

	public void setProfileId(BigDecimal profileId) {
		this.profileId = profileId;
	}

	public String getSegmentCode() {
		return this.segmentCode;
	}

	public void setSegmentCode(String segmentCode) {
		this.segmentCode = segmentCode;
	}

	public BigDecimal getSegmentValueId() {
		return this.segmentValueId;
	}

	public void setSegmentValueId(BigDecimal segmentValueId) {
		this.segmentValueId = segmentValueId;
	}

}