package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the T_SOH_HST_PARTY database table.
 * 
 */
@Entity
@Table(name="T_SOH_HST_PARTY")
@NamedQuery(name="TSohHstParty.findAll", query="SELECT t FROM TSohHstParty t")
public class TSohHstParty implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_SOH_HST_PARTY_ACCTPARTYID_GENERATOR", sequenceName="SQ_T_SOH_HST_PARTY",allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_SOH_HST_PARTY_ACCTPARTYID_GENERATOR")
	@Column(name="ACCT_PARTY_ID")
	private long acctPartyId;

	@Column(name="ACCOUNT_ID")
	private BigDecimal accountId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="EFF_FROM")
	private Timestamp effFrom;

	@Column(name="EFF_TILL")
	private Timestamp effTill;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="MODULE_FLAG")
	private String moduleFlag;

	@Column(name="OLD_PARTY_ID")
	private BigDecimal oldPartyId;

	@Column(name="PARTY_ID")
	private BigDecimal partyId;

	public TSohHstParty() {
	}

	public long getAcctPartyId() {
		return this.acctPartyId;
	}

	public void setAcctPartyId(long acctPartyId) {
		this.acctPartyId = acctPartyId;
	}

	public BigDecimal getAccountId() {
		return this.accountId;
	}

	public void setAccountId(BigDecimal accountId) {
		this.accountId = accountId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getEffFrom() {
		return this.effFrom;
	}

	public void setEffFrom(Timestamp effFrom) {
		this.effFrom = effFrom;
	}

	public Timestamp getEffTill() {
		return this.effTill;
	}

	public void setEffTill(Timestamp effTill) {
		this.effTill = effTill;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getModuleFlag() {
		return this.moduleFlag;
	}

	public void setModuleFlag(String moduleFlag) {
		this.moduleFlag = moduleFlag;
	}

	public BigDecimal getOldPartyId() {
		return this.oldPartyId;
	}

	public void setOldPartyId(BigDecimal oldPartyId) {
		this.oldPartyId = oldPartyId;
	}

	public BigDecimal getPartyId() {
		return this.partyId;
	}

	public void setPartyId(BigDecimal partyId) {
		this.partyId = partyId;
	}

}