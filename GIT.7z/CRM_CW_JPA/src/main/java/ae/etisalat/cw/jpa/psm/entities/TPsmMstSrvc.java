package ae.etisalat.cw.jpa.psm.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the T_PSM_MST_SRVC database table.
 * 
 */
@Entity
@Table(name="T_PSM_MST_SRVC")
@NamedQueries({
	@NamedQuery(name="TPsmMstSrvc.findAll", query="SELECT t FROM TPsmMstSrvc t"),
	@NamedQuery(name="TPsmMstSrvc.findBySrvcCodes",query="SELECT t FROM TPsmMstSrvc t where t.srvcCode in :srvcCodes and (t.effectiveTillDate is null or t.effectiveTillDate >=current_timestamp) and t.deletionStatus=:deletionStatus")
})
public class TPsmMstSrvc implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TPsmMstSrvcPK id;

	@Column(name="CONTROL_ACCOUNT")
	private BigDecimal controlAccount;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="CREDIT_CONTROL_FLAG")
	private BigDecimal creditControlFlag;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="DESCRIPTION_ID")
	private BigDecimal descriptionId;

	@Column(name="EFFECTIVE_TILL_DATE")
	private Timestamp effectiveTillDate;

	@Column(name="EQUIPMENT_FLAG")
	private BigDecimal equipmentFlag;

	@Column(name="LINK_SRVC_INDICATOR")
	private BigDecimal linkSrvcIndicator;

	@Column(name="MAXIMUM_QUANTITY")
	private BigDecimal maximumQuantity;

	@Column(name="MDI_AUTO_FLAG")
	private BigDecimal mdiAutoFlag;

	@Column(name="MINIMUM_QUANTITY")
	private BigDecimal minimumQuantity;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="MUL_INSTANCE_FLAG")
	private BigDecimal mulInstanceFlag;

	
	
	@Column(name="NUMBER_STRUCTURE_ID")
	private BigDecimal numberStructureId;

	@Column(name="OFFER_FROM_DATE")
	private Timestamp offerFromDate;

	@Column(name="OFFER_TILL_DATE")
	private Timestamp offerTillDate;

	@Column(name="PAYMENT_PRIORITY")
	private BigDecimal paymentPriority;

	@Column(name="PRODUCT_ID")
	private BigDecimal productId;

	private String remarks;

	@Column(name="REVENUE_SHARING_FLAG")
	private BigDecimal revenueSharingFlag;

	@Column(name="SRVC_CATEGORY_ID")
	private BigDecimal srvcCategoryId;

	@Column(name="SRVC_CODE")
	private String srvcCode;

	@Column(name="SRVC_TYPE")
	private BigDecimal srvcType;

	@Column(name="SRVC_VERSION")
	private BigDecimal srvcVersion;

	@Column(name="TOS_INDICATOR")
	private BigDecimal tosIndicator;

	//bi-directional many-to-one association to TPsmMstRatePlan
	@OneToMany(mappedBy="TPsmMstSrvc")
	private List<TPsmMstRatePlan> TPsmMstRatePlans;
	
//bi-directional many-to-one association to TPsmMstServiceDependency
	@OneToMany(mappedBy="TPsmMstSrvc")
	private List<TPsmMstServiceDependency> TPsmMstServiceDependencies;

	//bi-directional many-to-one association to TPsmMstSrvc
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="ASSO_PM_EFFECTIVE_FROM_DATE", referencedColumnName="EFFECTIVE_FROM_DATE"),
		@JoinColumn(name="ASSOCIATED_PRIMARY_ID", referencedColumnName="SRVC_ID")
		})
	private TPsmMstSrvc TPsmMstSrvc;

	//bi-directional many-to-one association to TPsmMstSrvc
	@OneToMany(mappedBy="TPsmMstSrvc")
	private List<TPsmMstSrvc> TPsmMstSrvcs;

	//bi-directional many-to-one association to TPsmMstRecurrChrgType
	@OneToMany(mappedBy="TPsmMstSrvc")
	private List<TPsmMstRecurrChrgType> TPsmMstRecurrChrgTypes;

	//bi-directional many-to-one association to TPsmDtlSystemCodeValue
	@ManyToOne
	@JoinColumn(name="STATUS_ID")
	private TPsmDtlSystemCodeValue TPsmDtlSystemCodeValue1;

	//bi-directional many-to-one association to TPsmDtlSystemCodeValue
	@ManyToOne
	@JoinColumn(name="NETWORK_ELEMENT_TYPE_ID")
	private TPsmDtlSystemCodeValue TPsmDtlSystemCodeValue2;
	
	
	
//bi-directional many-to-one association to TPsmMstOnetmChrgType
	@OneToMany(mappedBy="TPsmMstSrvc")
	private List<TPsmMstOnetmChrgType> TPsmMstOnetmChrgTypes;
	public TPsmMstSrvc() {
	}

	public TPsmMstSrvcPK getId() {
		return this.id;
	}

	public void setId(TPsmMstSrvcPK id) {
		this.id = id;
	}

	public BigDecimal getControlAccount() {
		return this.controlAccount;
	}

	public void setControlAccount(BigDecimal controlAccount) {
		this.controlAccount = controlAccount;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public BigDecimal getCreditControlFlag() {
		return this.creditControlFlag;
	}

	public void setCreditControlFlag(BigDecimal creditControlFlag) {
		this.creditControlFlag = creditControlFlag;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public BigDecimal getDescriptionId() {
		return this.descriptionId;
	}

	public void setDescriptionId(BigDecimal descriptionId) {
		this.descriptionId = descriptionId;
	}

	public Timestamp getEffectiveTillDate() {
		return this.effectiveTillDate;
	}

	public void setEffectiveTillDate(Timestamp effectiveTillDate) {
		this.effectiveTillDate = effectiveTillDate;
	}

	public BigDecimal getEquipmentFlag() {
		return this.equipmentFlag;
	}

	public void setEquipmentFlag(BigDecimal equipmentFlag) {
		this.equipmentFlag = equipmentFlag;
	}

	public BigDecimal getLinkSrvcIndicator() {
		return this.linkSrvcIndicator;
	}

	public void setLinkSrvcIndicator(BigDecimal linkSrvcIndicator) {
		this.linkSrvcIndicator = linkSrvcIndicator;
	}

	public BigDecimal getMaximumQuantity() {
		return this.maximumQuantity;
	}

	public void setMaximumQuantity(BigDecimal maximumQuantity) {
		this.maximumQuantity = maximumQuantity;
	}

	public BigDecimal getMdiAutoFlag() {
		return this.mdiAutoFlag;
	}

	public void setMdiAutoFlag(BigDecimal mdiAutoFlag) {
		this.mdiAutoFlag = mdiAutoFlag;
	}

	public BigDecimal getMinimumQuantity() {
		return this.minimumQuantity;
	}

	public void setMinimumQuantity(BigDecimal minimumQuantity) {
		this.minimumQuantity = minimumQuantity;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getMulInstanceFlag() {
		return this.mulInstanceFlag;
	}

	public void setMulInstanceFlag(BigDecimal mulInstanceFlag) {
		this.mulInstanceFlag = mulInstanceFlag;
	}

	
	public BigDecimal getNumberStructureId() {
		return this.numberStructureId;
	}

	public void setNumberStructureId(BigDecimal numberStructureId) {
		this.numberStructureId = numberStructureId;
	}

	public Timestamp getOfferFromDate() {
		return this.offerFromDate;
	}

	public void setOfferFromDate(Timestamp offerFromDate) {
		this.offerFromDate = offerFromDate;
	}

	public Timestamp getOfferTillDate() {
		return this.offerTillDate;
	}

	public void setOfferTillDate(Timestamp offerTillDate) {
		this.offerTillDate = offerTillDate;
	}

	public BigDecimal getPaymentPriority() {
		return this.paymentPriority;
	}

	public void setPaymentPriority(BigDecimal paymentPriority) {
		this.paymentPriority = paymentPriority;
	}

	public BigDecimal getProductId() {
		return this.productId;
	}

	public void setProductId(BigDecimal productId) {
		this.productId = productId;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public BigDecimal getRevenueSharingFlag() {
		return this.revenueSharingFlag;
	}

	public void setRevenueSharingFlag(BigDecimal revenueSharingFlag) {
		this.revenueSharingFlag = revenueSharingFlag;
	}

	public BigDecimal getSrvcCategoryId() {
		return this.srvcCategoryId;
	}

	public void setSrvcCategoryId(BigDecimal srvcCategoryId) {
		this.srvcCategoryId = srvcCategoryId;
	}

	public String getSrvcCode() {
		return this.srvcCode;
	}

	public void setSrvcCode(String srvcCode) {
		this.srvcCode = srvcCode;
	}

	public BigDecimal getSrvcType() {
		return this.srvcType;
	}

	public void setSrvcType(BigDecimal srvcType) {
		this.srvcType = srvcType;
	}

	public BigDecimal getSrvcVersion() {
		return this.srvcVersion;
	}

	public void setSrvcVersion(BigDecimal srvcVersion) {
		this.srvcVersion = srvcVersion;
	}

	public BigDecimal getTosIndicator() {
		return this.tosIndicator;
	}

	public void setTosIndicator(BigDecimal tosIndicator) {
		this.tosIndicator = tosIndicator;
	}

	public List<TPsmMstRatePlan> getTPsmMstRatePlans() {
		return this.TPsmMstRatePlans;
	}

	public void setTPsmMstRatePlans(List<TPsmMstRatePlan> TPsmMstRatePlans) {
		this.TPsmMstRatePlans = TPsmMstRatePlans;
	}

	public TPsmMstRatePlan addTPsmMstRatePlan(TPsmMstRatePlan TPsmMstRatePlan) {
		getTPsmMstRatePlans().add(TPsmMstRatePlan);
		TPsmMstRatePlan.setTPsmMstSrvc(this);

		return TPsmMstRatePlan;
	}

	public TPsmMstRatePlan removeTPsmMstRatePlan(TPsmMstRatePlan TPsmMstRatePlan) {
		getTPsmMstRatePlans().remove(TPsmMstRatePlan);
		TPsmMstRatePlan.setTPsmMstSrvc(null);

		return TPsmMstRatePlan;
	}
	public List<TPsmMstServiceDependency> getTPsmMstServiceDependencies() {
		return this.TPsmMstServiceDependencies;
	}

	public void setTPsmMstServiceDependencies(List<TPsmMstServiceDependency> TPsmMstServiceDependencies) {
		this.TPsmMstServiceDependencies = TPsmMstServiceDependencies;
	}

	public TPsmMstServiceDependency addTPsmMstServiceDependency(TPsmMstServiceDependency TPsmMstServiceDependency) {
		getTPsmMstServiceDependencies().add(TPsmMstServiceDependency);
		TPsmMstServiceDependency.setTPsmMstSrvc(this);

		return TPsmMstServiceDependency;
	}

	public TPsmMstServiceDependency removeTPsmMstServiceDependency(TPsmMstServiceDependency TPsmMstServiceDependency) {
		getTPsmMstServiceDependencies().remove(TPsmMstServiceDependency);
		TPsmMstServiceDependency.setTPsmMstSrvc(null);

		return TPsmMstServiceDependency;
	}
	public TPsmMstSrvc getTPsmMstSrvc() {
		return this.TPsmMstSrvc;
	}

	public void setTPsmMstSrvc(TPsmMstSrvc TPsmMstSrvc) {
		this.TPsmMstSrvc = TPsmMstSrvc;
	}

	public List<TPsmMstSrvc> getTPsmMstSrvcs() {
		return this.TPsmMstSrvcs;
	}

	public void setTPsmMstSrvcs(List<TPsmMstSrvc> TPsmMstSrvcs) {
		this.TPsmMstSrvcs = TPsmMstSrvcs;
	}

	public TPsmMstSrvc addTPsmMstSrvc(TPsmMstSrvc TPsmMstSrvc) {
		getTPsmMstSrvcs().add(TPsmMstSrvc);
		TPsmMstSrvc.setTPsmMstSrvc(this);

		return TPsmMstSrvc;
	}

	public TPsmMstSrvc removeTPsmMstSrvc(TPsmMstSrvc TPsmMstSrvc) {
		getTPsmMstSrvcs().remove(TPsmMstSrvc);
		TPsmMstSrvc.setTPsmMstSrvc(null);

		return TPsmMstSrvc;
	}

	public List<TPsmMstRecurrChrgType> getTPsmMstRecurrChrgTypes() {
		return this.TPsmMstRecurrChrgTypes;
	}

	public void setTPsmMstRecurrChrgTypes(List<TPsmMstRecurrChrgType> TPsmMstRecurrChrgTypes) {
		this.TPsmMstRecurrChrgTypes = TPsmMstRecurrChrgTypes;
	}

	public TPsmMstRecurrChrgType addTPsmMstRecurrChrgType(TPsmMstRecurrChrgType TPsmMstRecurrChrgType) {
		getTPsmMstRecurrChrgTypes().add(TPsmMstRecurrChrgType);
		TPsmMstRecurrChrgType.setTPsmMstSrvc(this);

		return TPsmMstRecurrChrgType;
	}

	public TPsmMstRecurrChrgType removeTPsmMstRecurrChrgType(TPsmMstRecurrChrgType TPsmMstRecurrChrgType) {
		getTPsmMstRecurrChrgTypes().remove(TPsmMstRecurrChrgType);
		TPsmMstRecurrChrgType.setTPsmMstSrvc(null);

		return TPsmMstRecurrChrgType;
	}

	public TPsmDtlSystemCodeValue getTPsmDtlSystemCodeValue1() {
		return this.TPsmDtlSystemCodeValue1;
	}

	public void setTPsmDtlSystemCodeValue1(TPsmDtlSystemCodeValue TPsmDtlSystemCodeValue1) {
		this.TPsmDtlSystemCodeValue1 = TPsmDtlSystemCodeValue1;
	}

	public TPsmDtlSystemCodeValue getTPsmDtlSystemCodeValue2() {
		return this.TPsmDtlSystemCodeValue2;
	}

	public void setTPsmDtlSystemCodeValue2(TPsmDtlSystemCodeValue TPsmDtlSystemCodeValue2) {
		this.TPsmDtlSystemCodeValue2 = TPsmDtlSystemCodeValue2;
	}
	public List<TPsmMstOnetmChrgType> getTPsmMstOnetmChrgTypes() {
		return this.TPsmMstOnetmChrgTypes;
	}

	public void setTPsmMstOnetmChrgTypes(List<TPsmMstOnetmChrgType> TPsmMstOnetmChrgTypes) {
		this.TPsmMstOnetmChrgTypes = TPsmMstOnetmChrgTypes;
	}

	public TPsmMstOnetmChrgType addTPsmMstOnetmChrgType(TPsmMstOnetmChrgType TPsmMstOnetmChrgType) {
		getTPsmMstOnetmChrgTypes().add(TPsmMstOnetmChrgType);
		TPsmMstOnetmChrgType.setTPsmMstSrvc(this);

		return TPsmMstOnetmChrgType;
	}

	public TPsmMstOnetmChrgType removeTPsmMstOnetmChrgType(TPsmMstOnetmChrgType TPsmMstOnetmChrgType) {
		getTPsmMstOnetmChrgTypes().remove(TPsmMstOnetmChrgType);
		TPsmMstOnetmChrgType.setTPsmMstSrvc(null);

		return TPsmMstOnetmChrgType;
	}
}