package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;


/**
 * The persistent class for the T_SOH_SUBREQ_FLOW_SEQUENCE database table.
 * 
 */
@Entity
@Table(name="T_SOH_SUBREQ_FLOW_SEQUENCE")
@NamedQuery(name="TSohSubreqFlowSequence.findAll", query="SELECT t FROM TSohSubreqFlowSequence t")
public class TSohSubreqFlowSequence implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="SQ_SOH_SUBREQ_FLOW_SEQUENCE", sequenceName="SQ_SOH_SUBREQ_FLOW_SEQUENCE",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SQ_SOH_SUBREQ_FLOW_SEQUENCE")
	@Column(name="SUB_REQ_FLOW_SEQ_ID")
	private long subReqFlowSeqId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="DEPENDENT_SEQ_ID")
	private BigDecimal dependentSeqId;

	@Column(name="EFFECTIVE_FROM_DATE")
	private Timestamp effectiveFromDate;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="SEQUENCE_NUMBER")
	private BigDecimal sequenceNumber;

	private BigDecimal status;

	@Column(name="SUB_REQ_RT_FLOW_ID")
	private BigDecimal subReqRtFlowId;

	@Column(name="SUBREQ_FLOW_ID")
	private BigDecimal subreqFlowId;

	@Column(name="SUBREQUEST_ID")
	private BigDecimal subrequestId;

	public TSohSubreqFlowSequence() {
	}

	public long getSubReqFlowSeqId() {
		return this.subReqFlowSeqId;
	}

	public void setSubReqFlowSeqId(long subReqFlowSeqId) {
		this.subReqFlowSeqId = subReqFlowSeqId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public BigDecimal getDependentSeqId() {
		return this.dependentSeqId;
	}

	public void setDependentSeqId(BigDecimal dependentSeqId) {
		this.dependentSeqId = dependentSeqId;
	}

	public Timestamp getEffectiveFromDate() {
		return this.effectiveFromDate;
	}

	public void setEffectiveFromDate(Timestamp effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getSequenceNumber() {
		return this.sequenceNumber;
	}

	public void setSequenceNumber(BigDecimal sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public BigDecimal getStatus() {
		return this.status;
	}

	public void setStatus(BigDecimal status) {
		this.status = status;
	}

	public BigDecimal getSubReqRtFlowId() {
		return this.subReqRtFlowId;
	}

	public void setSubReqRtFlowId(BigDecimal subReqRtFlowId) {
		this.subReqRtFlowId = subReqRtFlowId;
	}

	public BigDecimal getSubreqFlowId() {
		return this.subreqFlowId;
	}

	public void setSubreqFlowId(BigDecimal subreqFlowId) {
		this.subreqFlowId = subreqFlowId;
	}

	public BigDecimal getSubrequestId() {
		return this.subrequestId;
	}

	public void setSubrequestId(BigDecimal subrequestId) {
		this.subrequestId = subrequestId;
	}

}