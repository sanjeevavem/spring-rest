package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import ae.etisalat.cw.jpa.adm.entities.TAdmMstRegion;


/**
 * The persistent class for the T_SOH_IPTV_NUM_POOL database table.
 * 
 */
@Entity
@Table(name="T_SOH_IPTV_NUM_POOL")
@NamedQuery(name="TSohIptvNumPool.findAll", query="SELECT t FROM TSohIptvNumPool t")
public class TSohIptvNumPool implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="ACC_SERV_INSTANCE_ID")
	private BigDecimal accServInstanceId;

	@Column(name="ACCOUNT_ID")
	private BigDecimal accountId;

	@Column(name="ACCOUNT_SUFFIX")
	private BigDecimal accountSuffix;

	@Column(name="ALLOC_SUBREQ_ID")
	private BigDecimal allocSubreqId;

	@Column(name="AREA_CODE")
	private String areaCode;

	@Column(name="CESSATION_IND")
	private BigDecimal cessationInd;

	@Column(name="CONNECT_ID")
	private String connectId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DSLAM_ID")
	private String dslamId;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_FROM_DATE")
	private Date effectiveFromDate;

	@Id
	@Column(name="IPTV_NUMBER_POOL_ID")
	private BigDecimal iptvNumberPoolId;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	private String notes;

	@Column(name="ORG_UNIT_ID")
	private BigDecimal orgUnitId;

	@Column(name="PAIR_ID")
	private String pairId;

	@Column(name="PARTY_SUB_TYPE")
	private BigDecimal partySubType;

	@Column(name="PLAN_NUMBER")
	private BigDecimal planNumber;

	@Column(name="PORT_ID")
	private String portId;

	@Column(name="PRODUCT_GROUP_ID")
	private BigDecimal productGroupId;

	@Column(name="PRODUCT_ID")
	private BigDecimal productId;

	@Column(name="PRODUCT_NUMBER")
	private BigDecimal productNumber;

	@Column(name="PRODUCT_NUMBER_STATUS")
	private BigDecimal productNumberStatus;

	@Temporal(TemporalType.DATE)
	@Column(name="RESERVED_TILL_DATE")
	private Date reservedTillDate;

	@Column(name="SERVICE_ID")
	private BigDecimal serviceId;

	@Column(name="SR_SERV_INSTANCE_ID")
	private BigDecimal srServInstanceId;

	@Column(name="STATUS_TO")
	private BigDecimal statusTo;

	@Column(name="STATUS_TO_FLAG")
	private String statusToFlag;

	@Column(name="SUBREQUEST_ID")
	private BigDecimal subrequestId;

	@Column(name="USER_NAME")
	private String userName;

	//bi-directional many-to-one association to TAdmMstRegion
	@ManyToOne
	@JoinColumn(name="REGION_ID")
	private TAdmMstRegion TAdmMstRegion;

	public TSohIptvNumPool() {
	}

	public BigDecimal getAccServInstanceId() {
		return this.accServInstanceId;
	}

	public void setAccServInstanceId(BigDecimal accServInstanceId) {
		this.accServInstanceId = accServInstanceId;
	}

	public BigDecimal getAccountId() {
		return this.accountId;
	}

	public void setAccountId(BigDecimal accountId) {
		this.accountId = accountId;
	}

	public BigDecimal getAccountSuffix() {
		return this.accountSuffix;
	}

	public void setAccountSuffix(BigDecimal accountSuffix) {
		this.accountSuffix = accountSuffix;
	}

	public BigDecimal getAllocSubreqId() {
		return this.allocSubreqId;
	}

	public void setAllocSubreqId(BigDecimal allocSubreqId) {
		this.allocSubreqId = allocSubreqId;
	}

	public String getAreaCode() {
		return this.areaCode;
	}

	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

	public BigDecimal getCessationInd() {
		return this.cessationInd;
	}

	public void setCessationInd(BigDecimal cessationInd) {
		this.cessationInd = cessationInd;
	}

	public String getConnectId() {
		return this.connectId;
	}

	public void setConnectId(String connectId) {
		this.connectId = connectId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDslamId() {
		return this.dslamId;
	}

	public void setDslamId(String dslamId) {
		this.dslamId = dslamId;
	}

	public Date getEffectiveFromDate() {
		return this.effectiveFromDate;
	}

	public void setEffectiveFromDate(Date effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}

	public BigDecimal getIptvNumberPoolId() {
		return this.iptvNumberPoolId;
	}

	public void setIptvNumberPoolId(BigDecimal iptvNumberPoolId) {
		this.iptvNumberPoolId = iptvNumberPoolId;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getNotes() {
		return this.notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public BigDecimal getOrgUnitId() {
		return this.orgUnitId;
	}

	public void setOrgUnitId(BigDecimal orgUnitId) {
		this.orgUnitId = orgUnitId;
	}

	public String getPairId() {
		return this.pairId;
	}

	public void setPairId(String pairId) {
		this.pairId = pairId;
	}

	public BigDecimal getPartySubType() {
		return this.partySubType;
	}

	public void setPartySubType(BigDecimal partySubType) {
		this.partySubType = partySubType;
	}

	public BigDecimal getPlanNumber() {
		return this.planNumber;
	}

	public void setPlanNumber(BigDecimal planNumber) {
		this.planNumber = planNumber;
	}

	public String getPortId() {
		return this.portId;
	}

	public void setPortId(String portId) {
		this.portId = portId;
	}

	public BigDecimal getProductGroupId() {
		return this.productGroupId;
	}

	public void setProductGroupId(BigDecimal productGroupId) {
		this.productGroupId = productGroupId;
	}

	public BigDecimal getProductId() {
		return this.productId;
	}

	public void setProductId(BigDecimal productId) {
		this.productId = productId;
	}

	public BigDecimal getProductNumber() {
		return this.productNumber;
	}

	public void setProductNumber(BigDecimal productNumber) {
		this.productNumber = productNumber;
	}

	public BigDecimal getProductNumberStatus() {
		return this.productNumberStatus;
	}

	public void setProductNumberStatus(BigDecimal productNumberStatus) {
		this.productNumberStatus = productNumberStatus;
	}

	public Date getReservedTillDate() {
		return this.reservedTillDate;
	}

	public void setReservedTillDate(Date reservedTillDate) {
		this.reservedTillDate = reservedTillDate;
	}

	public BigDecimal getServiceId() {
		return this.serviceId;
	}

	public void setServiceId(BigDecimal serviceId) {
		this.serviceId = serviceId;
	}

	public BigDecimal getSrServInstanceId() {
		return this.srServInstanceId;
	}

	public void setSrServInstanceId(BigDecimal srServInstanceId) {
		this.srServInstanceId = srServInstanceId;
	}

	public BigDecimal getStatusTo() {
		return this.statusTo;
	}

	public void setStatusTo(BigDecimal statusTo) {
		this.statusTo = statusTo;
	}

	public String getStatusToFlag() {
		return this.statusToFlag;
	}

	public void setStatusToFlag(String statusToFlag) {
		this.statusToFlag = statusToFlag;
	}

	public BigDecimal getSubrequestId() {
		return this.subrequestId;
	}

	public void setSubrequestId(BigDecimal subrequestId) {
		this.subrequestId = subrequestId;
	}

	public String getUserName() {
		return this.userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public TAdmMstRegion getTAdmMstRegion() {
		return this.TAdmMstRegion;
	}

	public void setTAdmMstRegion(TAdmMstRegion TAdmMstRegion) {
		this.TAdmMstRegion = TAdmMstRegion;
	}

}