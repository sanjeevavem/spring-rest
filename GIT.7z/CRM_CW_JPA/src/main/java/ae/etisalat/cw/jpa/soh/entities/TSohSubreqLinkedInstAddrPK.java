package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the T_SOH_SUBREQ_LINKED_INST_ADDR database table.
 * 
 */
@Embeddable
public class TSohSubreqLinkedInstAddrPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="SUBREQ_ADDRESS_ID", insertable=false, updatable=false)
	private long subreqAddressId;

	@Column(name="SUBREQUEST_ID", insertable=false, updatable=false)
	private long subrequestId;

	public TSohSubreqLinkedInstAddrPK() {
	}
	public long getSubreqAddressId() {
		return this.subreqAddressId;
	}
	public void setSubreqAddressId(long subreqAddressId) {
		this.subreqAddressId = subreqAddressId;
	}
	public long getSubrequestId() {
		return this.subrequestId;
	}
	public void setSubrequestId(long subrequestId) {
		this.subrequestId = subrequestId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TSohSubreqLinkedInstAddrPK)) {
			return false;
		}
		TSohSubreqLinkedInstAddrPK castOther = (TSohSubreqLinkedInstAddrPK)other;
		return 
			(this.subreqAddressId == castOther.subreqAddressId)
			&& (this.subrequestId == castOther.subrequestId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.subreqAddressId ^ (this.subreqAddressId >>> 32)));
		hash = hash * prime + ((int) (this.subrequestId ^ (this.subrequestId >>> 32)));
		
		return hash;
	}
}