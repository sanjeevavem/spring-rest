package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;

import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the T_SOH_DTL_ACCINFO_CRCSCHEMES database table.
 * 
 */
@Entity
@Table(name="T_SOH_DTL_ACCINFO_CRCSCHEMES")
@NamedQuery(name="TSohDtlAccinfoCrcscheme.findAll", query="SELECT t FROM TSohDtlAccinfoCrcscheme t")
public class TSohDtlAccinfoCrcscheme implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="SQ_T_SOH_DTL_ACC_CRCSCHEMES", sequenceName="SQ_T_SOH_DTL_ACC_CRCSCHEMES", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SQ_T_SOH_DTL_ACC_CRCSCHEMES")
	@Column(name="ACC_CREDIT_SCHEME_ID")
	private long accCreditSchemeId;

	@Column(name="ACCOUNT_ID")
	private java.math.BigDecimal accountId;

	@Column(name="ACCOUNT_SERVICE_ID")
	private java.math.BigDecimal accountServiceId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="CREDIT_CATEGORY_ID")
	private java.math.BigDecimal creditCategoryId;

	@Column(name="CREDIT_SCHEME_ID")
	private java.math.BigDecimal creditSchemeId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	public TSohDtlAccinfoCrcscheme() {
	}

	public long getAccCreditSchemeId() {
		return this.accCreditSchemeId;
	}

	public void setAccCreditSchemeId(long accCreditSchemeId) {
		this.accCreditSchemeId = accCreditSchemeId;
	}

	public java.math.BigDecimal getAccountId() {
		return this.accountId;
	}

	public void setAccountId(java.math.BigDecimal accountId) {
		this.accountId = accountId;
	}

	public java.math.BigDecimal getAccountServiceId() {
		return this.accountServiceId;
	}

	public void setAccountServiceId(java.math.BigDecimal accountServiceId) {
		this.accountServiceId = accountServiceId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public java.math.BigDecimal getCreditCategoryId() {
		return this.creditCategoryId;
	}

	public void setCreditCategoryId(java.math.BigDecimal creditCategoryId) {
		this.creditCategoryId = creditCategoryId;
	}

	public java.math.BigDecimal getCreditSchemeId() {
		return this.creditSchemeId;
	}

	public void setCreditSchemeId(java.math.BigDecimal creditSchemeId) {
		this.creditSchemeId = creditSchemeId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

}