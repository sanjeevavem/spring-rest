package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;


/**
 * The persistent class for the T_SOH_DTL_SUBREQ_INV_ATTR_INFO database table.
 * 
 */
@Entity
@Table(name="T_SOH_DTL_SUBREQ_INV_ATTR_INFO")
@NamedQuery(name="TSohDtlSubreqInvAttrInfo.findAll", query="SELECT t FROM TSohDtlSubreqInvAttrInfo t")
public class TSohDtlSubreqInvAttrInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_SOH_DTL_SUBREQ_INV_ATTR_INFO_INVOICEDETAILSID_GENERATOR", sequenceName="SQ_T_SOH_DTL_SUBREQ_INV_DTL_ID",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_SOH_DTL_SUBREQ_INV_ATTR_INFO_INVOICEDETAILSID_GENERATOR")
	@Column(name="INVOICE_DETAILS_ID")
	private long invoiceDetailsId;

	@Column(name="BILLING_ADDRESS_ID")
	private BigDecimal billingAddressId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="DELIVERY_ADDRESS_ID")
	private BigDecimal deliveryAddressId;

	@Column(name="DETAILS_INVOICE_FLAG")
	private String detailsInvoiceFlag;

	@Column(name="HIDE_NAME_FLAG")
	private String hideNameFlag;

	@Column(name="INVOICE_MEDIA_ID")
	private BigDecimal invoiceMediaId;

	@Column(name="INVOICE_TEMPLATE_ID")
	private BigDecimal invoiceTemplateId;

	@Column(name="LANGUAGE_ID")
	private BigDecimal languageId;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	//bi-directional many-to-one association to TSohMstSubreqInvoiceInfo
	@ManyToOne
	@JoinColumn(name="SUBREQ_INVOICE_ID")
	private TSohMstSubreqInvoiceInfo TSohMstSubreqInvoiceInfo;

	public TSohDtlSubreqInvAttrInfo() {
	}

	public long getInvoiceDetailsId() {
		return this.invoiceDetailsId;
	}

	public void setInvoiceDetailsId(long invoiceDetailsId) {
		this.invoiceDetailsId = invoiceDetailsId;
	}

	public BigDecimal getBillingAddressId() {
		return this.billingAddressId;
	}

	public void setBillingAddressId(BigDecimal billingAddressId) {
		this.billingAddressId = billingAddressId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public BigDecimal getDeliveryAddressId() {
		return this.deliveryAddressId;
	}

	public void setDeliveryAddressId(BigDecimal deliveryAddressId) {
		this.deliveryAddressId = deliveryAddressId;
	}

	public String getDetailsInvoiceFlag() {
		return this.detailsInvoiceFlag;
	}

	public void setDetailsInvoiceFlag(String detailsInvoiceFlag) {
		this.detailsInvoiceFlag = detailsInvoiceFlag;
	}

	public String getHideNameFlag() {
		return this.hideNameFlag;
	}

	public void setHideNameFlag(String hideNameFlag) {
		this.hideNameFlag = hideNameFlag;
	}

	public BigDecimal getInvoiceMediaId() {
		return this.invoiceMediaId;
	}

	public void setInvoiceMediaId(BigDecimal invoiceMediaId) {
		this.invoiceMediaId = invoiceMediaId;
	}

	public BigDecimal getInvoiceTemplateId() {
		return this.invoiceTemplateId;
	}

	public void setInvoiceTemplateId(BigDecimal invoiceTemplateId) {
		this.invoiceTemplateId = invoiceTemplateId;
	}

	public BigDecimal getLanguageId() {
		return this.languageId;
	}

	public void setLanguageId(BigDecimal languageId) {
		this.languageId = languageId;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public TSohMstSubreqInvoiceInfo getTSohMstSubreqInvoiceInfo() {
		return this.TSohMstSubreqInvoiceInfo;
	}

	public void setTSohMstSubreqInvoiceInfo(TSohMstSubreqInvoiceInfo TSohMstSubreqInvoiceInfo) {
		this.TSohMstSubreqInvoiceInfo = TSohMstSubreqInvoiceInfo;
	}

}