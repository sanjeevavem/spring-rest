package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the T_SOH_ACCOUNT_STATUS_SRT_MAP database table.
 * 
 */
@Entity
@Table(name="T_SOH_ACCOUNT_STATUS_SRT_MAP")
@NamedQueries(value = { @NamedQuery(name="TSohAccountStatusSrtMap.findAll", query="SELECT t FROM TSohAccountStatusSrtMap t"),
@NamedQuery(name="TSohAccountStatusSrtMap.findBySubreqTypeId", query="SELECT t FROM TSohAccountStatusSrtMap t where t.subRequestTypeId = :subRequestTypeId and t.deletionStatus =:deletionStatus") })
public class TSohAccountStatusSrtMap implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_SOH_ACCOUNT_STATUS_SRT_MAP_ACCOUNTSTATUSMAPID_GENERATOR", sequenceName="SQ_T_SOH_ACC_STATUS_SRT_MAP",allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_SOH_ACCOUNT_STATUS_SRT_MAP_ACCOUNTSTATUSMAPID_GENERATOR")
	@Column(name="ACCOUNT_STATUS_MAP_ID")
	private long accountStatusMapId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="SUB_REQUEST_TYPE_ID")
	private long subRequestTypeId;

	//bi-directional many-to-one association to TSohDtlSystemCodeValue
	@ManyToOne
	@JoinColumn(name="ACCT_SERVICE_STATUS_ID")
	private TSohDtlSystemCodeValue TSohDtlSystemCodeValue1;

	//bi-directional many-to-one association to TSohDtlSystemCodeValue
	@ManyToOne
	@JoinColumn(name="ACCOUNT_STATUS_ID")
	private TSohDtlSystemCodeValue TSohDtlSystemCodeValue2;

	public TSohAccountStatusSrtMap() {
	}

	public long getAccountStatusMapId() {
		return this.accountStatusMapId;
	}

	public void setAccountStatusMapId(long accountStatusMapId) {
		this.accountStatusMapId = accountStatusMapId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public long getSubRequestTypeId() {
		return this.subRequestTypeId;
	}

	public void setSubRequestTypeId(long subRequestTypeId) {
		this.subRequestTypeId = subRequestTypeId;
	}

	public TSohDtlSystemCodeValue getTSohDtlSystemCodeValue1() {
		return this.TSohDtlSystemCodeValue1;
	}

	public void setTSohDtlSystemCodeValue1(TSohDtlSystemCodeValue TSohDtlSystemCodeValue1) {
		this.TSohDtlSystemCodeValue1 = TSohDtlSystemCodeValue1;
	}

	public TSohDtlSystemCodeValue getTSohDtlSystemCodeValue2() {
		return this.TSohDtlSystemCodeValue2;
	}

	public void setTSohDtlSystemCodeValue2(TSohDtlSystemCodeValue TSohDtlSystemCodeValue2) {
		this.TSohDtlSystemCodeValue2 = TSohDtlSystemCodeValue2;
	}

}