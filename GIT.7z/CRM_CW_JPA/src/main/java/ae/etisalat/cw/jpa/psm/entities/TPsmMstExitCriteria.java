package ae.etisalat.cw.jpa.psm.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the T_PSM_MST_EXIT_CRITERIA database table.
 * 
 */
@Entity
@Table(name="T_PSM_MST_EXIT_CRITERIA")
@NamedQuery(name="TPsmMstExitCriteria.findAll", query="SELECT t FROM TPsmMstExitCriteria t")
public class TPsmMstExitCriteria implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="EXIT_CRITERIA_ID")
	private long exitCriteriaId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="EXIT_CRITERIA_CODE")
	private String exitCriteriaCode;

	@Column(name="EXIT_CRITERIA_DESC")
	private String exitCriteriaDesc;

	@Column(name="MIN_NOTICE_PERIOD")
	private BigDecimal minNoticePeriod;

	@Column(name="MIN_OBLIGATION_PERIOD")
	private BigDecimal minObligationPeriod;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="NOTICE_PERIOD_UOM")
	private BigDecimal noticePeriodUom;

	@Column(name="OBLIGATION_PERIOD_UOM")
	private BigDecimal obligationPeriodUom;

	@Column(name="ONETIME_CHARGE_TYPE_CODE")
	private String onetimeChargeTypeCode;

	@Column(name="ONETIME_CHARGE_TYPE_ID")
	private BigDecimal onetimeChargeTypeId;

	@Column(name="ONETIME_CHARGE_VERSION")
	private BigDecimal onetimeChargeVersion;

	@Column(name="TERMINATION_IND")
	private BigDecimal terminationInd;

	//bi-directional many-to-one association to TPsmRpExitPolicy
	@OneToMany(mappedBy="TPsmMstExitCriteria")
	private List<TPsmRpExitPolicy> TPsmRpExitPolicies;

	public TPsmMstExitCriteria() {
	}

	public long getExitCriteriaId() {
		return this.exitCriteriaId;
	}

	public void setExitCriteriaId(long exitCriteriaId) {
		this.exitCriteriaId = exitCriteriaId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public String getExitCriteriaCode() {
		return this.exitCriteriaCode;
	}

	public void setExitCriteriaCode(String exitCriteriaCode) {
		this.exitCriteriaCode = exitCriteriaCode;
	}

	public String getExitCriteriaDesc() {
		return this.exitCriteriaDesc;
	}

	public void setExitCriteriaDesc(String exitCriteriaDesc) {
		this.exitCriteriaDesc = exitCriteriaDesc;
	}

	public BigDecimal getMinNoticePeriod() {
		return this.minNoticePeriod;
	}

	public void setMinNoticePeriod(BigDecimal minNoticePeriod) {
		this.minNoticePeriod = minNoticePeriod;
	}

	public BigDecimal getMinObligationPeriod() {
		return this.minObligationPeriod;
	}

	public void setMinObligationPeriod(BigDecimal minObligationPeriod) {
		this.minObligationPeriod = minObligationPeriod;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getNoticePeriodUom() {
		return this.noticePeriodUom;
	}

	public void setNoticePeriodUom(BigDecimal noticePeriodUom) {
		this.noticePeriodUom = noticePeriodUom;
	}

	public BigDecimal getObligationPeriodUom() {
		return this.obligationPeriodUom;
	}

	public void setObligationPeriodUom(BigDecimal obligationPeriodUom) {
		this.obligationPeriodUom = obligationPeriodUom;
	}

	public String getOnetimeChargeTypeCode() {
		return this.onetimeChargeTypeCode;
	}

	public void setOnetimeChargeTypeCode(String onetimeChargeTypeCode) {
		this.onetimeChargeTypeCode = onetimeChargeTypeCode;
	}

	public BigDecimal getOnetimeChargeTypeId() {
		return this.onetimeChargeTypeId;
	}

	public void setOnetimeChargeTypeId(BigDecimal onetimeChargeTypeId) {
		this.onetimeChargeTypeId = onetimeChargeTypeId;
	}

	public BigDecimal getOnetimeChargeVersion() {
		return this.onetimeChargeVersion;
	}

	public void setOnetimeChargeVersion(BigDecimal onetimeChargeVersion) {
		this.onetimeChargeVersion = onetimeChargeVersion;
	}

	public BigDecimal getTerminationInd() {
		return this.terminationInd;
	}

	public void setTerminationInd(BigDecimal terminationInd) {
		this.terminationInd = terminationInd;
	}

	public List<TPsmRpExitPolicy> getTPsmRpExitPolicies() {
		return this.TPsmRpExitPolicies;
	}

	public void setTPsmRpExitPolicies(List<TPsmRpExitPolicy> TPsmRpExitPolicies) {
		this.TPsmRpExitPolicies = TPsmRpExitPolicies;
	}

	public TPsmRpExitPolicy addTPsmRpExitPolicy(TPsmRpExitPolicy TPsmRpExitPolicy) {
		getTPsmRpExitPolicies().add(TPsmRpExitPolicy);
		TPsmRpExitPolicy.setTPsmMstExitCriteria(this);

		return TPsmRpExitPolicy;
	}

	public TPsmRpExitPolicy removeTPsmRpExitPolicy(TPsmRpExitPolicy TPsmRpExitPolicy) {
		getTPsmRpExitPolicies().remove(TPsmRpExitPolicy);
		TPsmRpExitPolicy.setTPsmMstExitCriteria(null);

		return TPsmRpExitPolicy;
	}

}