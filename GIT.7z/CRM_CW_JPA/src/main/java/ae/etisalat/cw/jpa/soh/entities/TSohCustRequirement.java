package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import ae.etisalat.cw.jpa.adm.entities.TAdmMstRegion;
import ae.etisalat.cw.jpa.cms.entities.TCmsMstPartySubtype;


/**
 * The persistent class for the T_SOH_CUST_REQUIREMENTS database table.
 * 
 */
@Entity
@Table(name="T_SOH_CUST_REQUIREMENTS")
@NamedQuery(name="TSohCustRequirement.findAll", query="SELECT t FROM TSohCustRequirement t")
public class TSohCustRequirement implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="REQUIREMENT_ID")
	private long requirementId;

	@Column(name="ACCOUNT_ID")
	private BigDecimal accountId;

	@Column(name="BUNDLE_ID")
	private BigDecimal bundleId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="EMIRATE_ID")
	private BigDecimal emirateId;

	@Column(name="LINKED_ACCOUNT_ID")
	private BigDecimal linkedAccountId;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="NEW_ACCOUNT_CATEGORY")
	private BigDecimal newAccountCategory;

	@Column(name="OLD_BUNDLE_ID")
	private BigDecimal oldBundleId;

	@Column(name="OLD_PACKAGE_ID")
	private BigDecimal oldPackageId;

	@Column(name="OLD_RATE_PLAN_ID")
	private BigDecimal oldRatePlanId;

	@Column(name="OWNER_ACCOUNT_ID")
	private BigDecimal ownerAccountId;

	@Column(name="PACKAGE_ID")
	private BigDecimal packageId;

	@Column(name="PRESTIGE_TYPE")
	private String prestigeType;

	@Column(name="PRESTIGE_VALUE")
	private String prestigeValue;

	@Column(name="QUANTITY")
	private BigDecimal quantity;

	@Column(name="RATE_PLAN_ID")
	private BigDecimal ratePlanId;

	@Column(name="RETAILER_ID")
	private BigDecimal retailerId;

//	@Column(name="RETENTION_FLAG")
//	private String retentionFlag;

	@Temporal(TemporalType.DATE)
	@Column(name="SERVC_REQUIRED_TILL_DATE")
	private Date servcRequiredTillDate;

	@Column(name="TRANSFER_ACCOUNT_ID")
	private BigDecimal transferAccountId;
	
	//bi-directional one-to-one association to TSohRequirement
	@OneToOne
	@JoinColumn(name="REQUIREMENT_ID")
	private TSohRequirement TSohRequirement;

	//bi-directional many-to-one association to TAdmMstRegion
	@ManyToOne
	@JoinColumn(name="REGION_ID")
	private TAdmMstRegion TAdmMstRegion;

	//bi-directional many-to-one association to TCmsMstPartySubtype
	@ManyToOne
	@JoinColumn(name="ACCOUNT_CATEGORY_ID")
	private TCmsMstPartySubtype TCmsMstPartySubtype;

	public TSohCustRequirement() {
	}

	public long getRequirementId() {
		return this.requirementId;
	}

	public void setRequirementId(long requirementId) {
		this.requirementId = requirementId;
	}

	public BigDecimal getAccountId() {
		return this.accountId;
	}

	public void setAccountId(BigDecimal accountId) {
		this.accountId = accountId;
	}

	public BigDecimal getBundleId() {
		return this.bundleId;
	}

	public void setBundleId(BigDecimal bundleId) {
		this.bundleId = bundleId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public BigDecimal getEmirateId() {
		return this.emirateId;
	}

	public void setEmirateId(BigDecimal emirateId) {
		this.emirateId = emirateId;
	}

	public BigDecimal getLinkedAccountId() {
		return this.linkedAccountId;
	}

	public void setLinkedAccountId(BigDecimal linkedAccountId) {
		this.linkedAccountId = linkedAccountId;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getNewAccountCategory() {
		return this.newAccountCategory;
	}

	public void setNewAccountCategory(BigDecimal newAccountCategory) {
		this.newAccountCategory = newAccountCategory;
	}

	public BigDecimal getOldBundleId() {
		return this.oldBundleId;
	}

	public void setOldBundleId(BigDecimal oldBundleId) {
		this.oldBundleId = oldBundleId;
	}

	public BigDecimal getOldPackageId() {
		return this.oldPackageId;
	}

	public void setOldPackageId(BigDecimal oldPackageId) {
		this.oldPackageId = oldPackageId;
	}

	public BigDecimal getOldRatePlanId() {
		return this.oldRatePlanId;
	}

	public void setOldRatePlanId(BigDecimal oldRatePlanId) {
		this.oldRatePlanId = oldRatePlanId;
	}

	public BigDecimal getOwnerAccountId() {
		return this.ownerAccountId;
	}

	public void setOwnerAccountId(BigDecimal ownerAccountId) {
		this.ownerAccountId = ownerAccountId;
	}

	public BigDecimal getPackageId() {
		return this.packageId;
	}

	public void setPackageId(BigDecimal packageId) {
		this.packageId = packageId;
	}

	public String getPrestigeType() {
		return this.prestigeType;
	}

	public void setPrestigeType(String prestigeType) {
		this.prestigeType = prestigeType;
	}

	public String getPrestigeValue() {
		return this.prestigeValue;
	}

	public void setPrestigeValue(String prestigeValue) {
		this.prestigeValue = prestigeValue;
	}

	public BigDecimal getQuantity() {
		return this.quantity;
	}

	public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
	}

	public BigDecimal getRatePlanId() {
		return this.ratePlanId;
	}

	public void setRatePlanId(BigDecimal ratePlanId) {
		this.ratePlanId = ratePlanId;
	}

	public BigDecimal getRetailerId() {
		return this.retailerId;
	}

	public void setRetailerId(BigDecimal retailerId) {
		this.retailerId = retailerId;
	}

//	public String getRetentionFlag() {
//		return this.retentionFlag;
//	}
//
//	public void setRetentionFlag(String retentionFlag) {
//		this.retentionFlag = retentionFlag;
//	}

	public Date getServcRequiredTillDate() {
		return this.servcRequiredTillDate;
	}

	public void setServcRequiredTillDate(Date servcRequiredTillDate) {
		this.servcRequiredTillDate = servcRequiredTillDate;
	}

	public BigDecimal getTransferAccountId() {
		return this.transferAccountId;
	}

	public void setTransferAccountId(BigDecimal transferAccountId) {
		this.transferAccountId = transferAccountId;
	}

	public TAdmMstRegion getTAdmMstRegion() {
		return this.TAdmMstRegion;
	}

	public void setTAdmMstRegion(TAdmMstRegion TAdmMstRegion) {
		this.TAdmMstRegion = TAdmMstRegion;
	}

	public TCmsMstPartySubtype getTCmsMstPartySubtype() {
		return this.TCmsMstPartySubtype;
	}

	public void setTCmsMstPartySubtype(TCmsMstPartySubtype TCmsMstPartySubtype) {
		this.TCmsMstPartySubtype = TCmsMstPartySubtype;
	}
	
	public TSohRequirement getTSohRequirement() {
		return this.TSohRequirement;
	}

	public void setTSohRequirement(TSohRequirement TSohRequirement) {
		this.TSohRequirement = TSohRequirement;
	}

}