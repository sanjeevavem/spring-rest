package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the T_SOH_HST_ACCT_BIL_CYC database table.
 * 
 */
@Entity
@Table(name="T_SOH_HST_ACCT_BIL_CYC")
@NamedQuery(name="TSohHstAcctBilCyc.findAll", query="SELECT t FROM TSohHstAcctBilCyc t")
public class TSohHstAcctBilCyc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_SOH_HST_ACCT_BIL_CYC_ACCTBILCYCID_GENERATOR", sequenceName="SQ_T_SOH_HST_ACCT_BIL_CYC",allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_SOH_HST_ACCT_BIL_CYC_ACCTBILCYCID_GENERATOR")
	@Column(name="ACCT_BIL_CYC_ID")
	private long acctBilCycId;

	@Temporal(TemporalType.DATE)
	@Column(name="BILL_CYCLE_DATE")
	private Date billCycleDate;

	@Column(name="BILL_CYCLE_ID")
	private BigDecimal billCycleId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="EFF_FROM")
	private Timestamp effFrom;

	@Column(name="EFF_TILL")
	private Timestamp effTill;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="OLD_BILL_CYCLE_DATE")
	private Date oldBillCycleDate;

	@Column(name="OLD_BILL_CYCLE_ID")
	private BigDecimal oldBillCycleId;

	//bi-directional many-to-one association to TSohAccount
	@ManyToOne
	@JoinColumn(name="ACCOUNT_ID")
	private TSohAccount TSohAccount;

	public TSohHstAcctBilCyc() {
	}

	public long getAcctBilCycId() {
		return this.acctBilCycId;
	}

	public void setAcctBilCycId(long acctBilCycId) {
		this.acctBilCycId = acctBilCycId;
	}

	public Date getBillCycleDate() {
		return this.billCycleDate;
	}

	public void setBillCycleDate(Date billCycleDate) {
		this.billCycleDate = billCycleDate;
	}

	public BigDecimal getBillCycleId() {
		return this.billCycleId;
	}

	public void setBillCycleId(BigDecimal billCycleId) {
		this.billCycleId = billCycleId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getEffFrom() {
		return this.effFrom;
	}

	public void setEffFrom(Timestamp effFrom) {
		this.effFrom = effFrom;
	}

	public Timestamp getEffTill() {
		return this.effTill;
	}

	public void setEffTill(Timestamp effTill) {
		this.effTill = effTill;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public Date getOldBillCycleDate() {
		return this.oldBillCycleDate;
	}

	public void setOldBillCycleDate(Date oldBillCycleDate) {
		this.oldBillCycleDate = oldBillCycleDate;
	}

	public BigDecimal getOldBillCycleId() {
		return this.oldBillCycleId;
	}

	public void setOldBillCycleId(BigDecimal oldBillCycleId) {
		this.oldBillCycleId = oldBillCycleId;
	}

	public TSohAccount getTSohAccount() {
		return this.TSohAccount;
	}

	public void setTSohAccount(TSohAccount TSohAccount) {
		this.TSohAccount = TSohAccount;
	}

}