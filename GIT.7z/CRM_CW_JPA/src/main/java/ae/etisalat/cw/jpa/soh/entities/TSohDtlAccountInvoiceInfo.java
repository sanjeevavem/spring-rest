package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the T_SOH_DTL_ACCOUNT_INVOICE_INFO database table.
 * 
 */
@Entity
@Table(name="T_SOH_DTL_ACCOUNT_INVOICE_INFO")
@NamedQuery(name="TSohDtlAccountInvoiceInfo.findAll", query="SELECT t FROM TSohDtlAccountInvoiceInfo t")
public class TSohDtlAccountInvoiceInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_SOH_DTL_ACCOUNT_INVOICE_INFO_ACCINVOICEDTLID_GENERATOR", sequenceName="SQ_T_SOH_DTL_ACCT_INV_INFO",allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_SOH_DTL_ACCOUNT_INVOICE_INFO_ACCINVOICEDTLID_GENERATOR")
	@Column(name="ACC_INVOICE_DTL_ID")
	private long accInvoiceDtlId;

	@Column(name="ACCOUNT_ID")
	private java.math.BigDecimal accountId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="SUBREQUEST_ID")
	private java.math.BigDecimal subrequestId;

	//bi-directional many-to-one association to TSohMstAccountInvoiceInfo
	@ManyToOne
	@JoinColumn(name="ACC_INVOICE_ID")
	private TSohMstAccountInvoiceInfo TSohMstAccountInvoiceInfo;

	public TSohDtlAccountInvoiceInfo() {
	}

	public long getAccInvoiceDtlId() {
		return this.accInvoiceDtlId;
	}

	public void setAccInvoiceDtlId(long accInvoiceDtlId) {
		this.accInvoiceDtlId = accInvoiceDtlId;
	}

	public java.math.BigDecimal getAccountId() {
		return this.accountId;
	}

	public void setAccountId(java.math.BigDecimal accountId) {
		this.accountId = accountId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public java.math.BigDecimal getSubrequestId() {
		return this.subrequestId;
	}

	public void setSubrequestId(java.math.BigDecimal subrequestId) {
		this.subrequestId = subrequestId;
	}

	public TSohMstAccountInvoiceInfo getTSohMstAccountInvoiceInfo() {
		return this.TSohMstAccountInvoiceInfo;
	}

	public void setTSohMstAccountInvoiceInfo(TSohMstAccountInvoiceInfo TSohMstAccountInvoiceInfo) {
		this.TSohMstAccountInvoiceInfo = TSohMstAccountInvoiceInfo;
	}

}