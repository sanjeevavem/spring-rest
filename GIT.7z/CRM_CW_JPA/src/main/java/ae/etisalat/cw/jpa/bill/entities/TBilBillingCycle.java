package ae.etisalat.cw.jpa.bill.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the T_BIL_BILLING_CYCLE database table.
 * 
 */
@Entity
@Table(name="T_BIL_BILLING_CYCLE")
@NamedQuery(name="TBilBillingCycle.findAll", query="SELECT t FROM TBilBillingCycle t")
public class TBilBillingCycle implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="BILLING_CYCLE_ID")
	private long billingCycleId;

	@Column(name="BILLING_CYCLE_CODE")
	private String billingCycleCode;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	private String description;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_FROM_DATE")
	private Date effectiveFromDate;

	private String frequency;

	@Column(name="FREQUENCY_ID")
	private BigDecimal frequencyId;

	@Column(name="INVOICE_SUFFIX")
	private String invoiceSuffix;

	@Column(name="MINIMUM_DURATION_ELAPSED")
	private BigDecimal minimumDurationElapsed;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	private String status;

	@Column(name="STATUS_ID")
	private BigDecimal statusId;

	public TBilBillingCycle() {
	}

	public long getBillingCycleId() {
		return this.billingCycleId;
	}

	public void setBillingCycleId(long billingCycleId) {
		this.billingCycleId = billingCycleId;
	}

	public String getBillingCycleCode() {
		return this.billingCycleCode;
	}

	public void setBillingCycleCode(String billingCycleCode) {
		this.billingCycleCode = billingCycleCode;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getEffectiveFromDate() {
		return this.effectiveFromDate;
	}

	public void setEffectiveFromDate(Date effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}

	public String getFrequency() {
		return this.frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public BigDecimal getFrequencyId() {
		return this.frequencyId;
	}

	public void setFrequencyId(BigDecimal frequencyId) {
		this.frequencyId = frequencyId;
	}

	public String getInvoiceSuffix() {
		return this.invoiceSuffix;
	}

	public void setInvoiceSuffix(String invoiceSuffix) {
		this.invoiceSuffix = invoiceSuffix;
	}

	public BigDecimal getMinimumDurationElapsed() {
		return this.minimumDurationElapsed;
	}

	public void setMinimumDurationElapsed(BigDecimal minimumDurationElapsed) {
		this.minimumDurationElapsed = minimumDurationElapsed;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public BigDecimal getStatusId() {
		return this.statusId;
	}

	public void setStatusId(BigDecimal statusId) {
		this.statusId = statusId;
	}

}