package ae.etisalat.cw.jpa.psm.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the T_PSM_RP_EXIT_POLICY database table.
 * 
 */
@Entity
@Table(name="T_PSM_RP_EXIT_POLICY")
@NamedQueries({
	@NamedQuery(name="TPsmRpExitPolicy.findAll", query="SELECT t FROM TPsmRpExitPolicy t"),
	@NamedQuery(name="TPsmRpExitPolicy.findByRatePlanIds",query="select a from TPsmRpExitPolicy a  where a.id.ratePlanId in :ratePlanIds and a.deletionStatus=:deletionStatus")

})
public class TPsmRpExitPolicy implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TPsmRpExitPolicyPK id;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	//bi-directional many-to-one association to TPsmMstExitCriteria
	@ManyToOne
	@PrimaryKeyJoinColumns({ @PrimaryKeyJoinColumn(name="EXIT_CRITERIA_ID", referencedColumnName="EXIT_CRITERIA_ID")})          
	private TPsmMstExitCriteria TPsmMstExitCriteria;

	public TPsmRpExitPolicy() {
	}

	public TPsmRpExitPolicyPK getId() {
		return this.id;
	}

	public void setId(TPsmRpExitPolicyPK id) {
		this.id = id;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public TPsmMstExitCriteria getTPsmMstExitCriteria() {
		return this.TPsmMstExitCriteria;
	}

	public void setTPsmMstExitCriteria(TPsmMstExitCriteria TPsmMstExitCriteria) {
		this.TPsmMstExitCriteria = TPsmMstExitCriteria;
	}

}