package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the T_SOH_SUBSCRIPTION_RATEPLN_DTL database table.
 * 
 */
@Entity
@Table(name="T_SOH_SUBSCRIPTION_RATEPLN_DTL")
@NamedQuery(name="TSohSubscriptionRateplnDtl.findAll", query="SELECT t FROM TSohSubscriptionRateplnDtl t")
public class TSohSubscriptionRateplnDtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_SOH_SUBSCRIPTION_RATEPLN_DTL_RATEPLANSUBSCRIPTIONID_GENERATOR", sequenceName="SQ_T_SOH_SUBSCRIPTION_RPLN_DTL",allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_SOH_SUBSCRIPTION_RATEPLN_DTL_RATEPLANSUBSCRIPTIONID_GENERATOR")
	@Column(name="RATEPLAN_SUBSCRIPTION_ID")
	private long rateplanSubscriptionId;

	@Column(name="ACCOUNT_ID")
	private BigDecimal accountId;

	@Column(name="AUTO_RENEWAL_FLAG")
	private String autoRenewalFlag;

	@Column(name="BILLING_REGION_ID")
	private BigDecimal billingRegionId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_FROM_DATE")
	private Date effectiveFromDate;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_TILL_DATE")
	private Date effectiveTillDate;

	@Temporal(TemporalType.DATE)
	@Column(name="EXIT_PLCY_END_DATE")
	private Date exitPlcyEndDate;

	@Column(name="EXIT_PLCY_FLAG")
	private String exitPlcyFlag;

	@Column(name="EXIT_PLCY_ID")
	private BigDecimal exitPlcyId;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="MONTHLY_DEDUCTION_DATE")
	private Date monthlyDeductionDate;

	@Column(name="RATE_PLAN_ID")
	private BigDecimal ratePlanId;

	@Column(name="RENEWAL_COUNT")
	private BigDecimal renewalCount;

	@Temporal(TemporalType.DATE)
	@Column(name="SUBSCRIPTION_RENEWAL_DATE")
	private Date subscriptionRenewalDate;

	//bi-directional many-to-one association to TSohAccountServiceDetail
	@ManyToOne
	@JoinColumn(name="ACCOUNT_SERVICE_ID")
	private TSohAccountServiceDetail TSohAccountServiceDetail;

	//bi-directional many-to-one association to TSohSubscriptionPackageDtl
	@ManyToOne
	@JoinColumn(name="PACKAGE_SUBSCRIPTION_ID")
	private TSohSubscriptionPackageDtl TSohSubscriptionPackageDtl;

	public TSohSubscriptionRateplnDtl() {
	}

	public long getRateplanSubscriptionId() {
		return this.rateplanSubscriptionId;
	}

	public void setRateplanSubscriptionId(long rateplanSubscriptionId) {
		this.rateplanSubscriptionId = rateplanSubscriptionId;
	}

	public BigDecimal getAccountId() {
		return this.accountId;
	}

	public void setAccountId(BigDecimal accountId) {
		this.accountId = accountId;
	}

	public String getAutoRenewalFlag() {
		return this.autoRenewalFlag;
	}

	public void setAutoRenewalFlag(String autoRenewalFlag) {
		this.autoRenewalFlag = autoRenewalFlag;
	}

	public BigDecimal getBillingRegionId() {
		return this.billingRegionId;
	}

	public void setBillingRegionId(BigDecimal billingRegionId) {
		this.billingRegionId = billingRegionId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Date getEffectiveFromDate() {
		return this.effectiveFromDate;
	}

	public void setEffectiveFromDate(Date effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}

	public Date getEffectiveTillDate() {
		return this.effectiveTillDate;
	}

	public void setEffectiveTillDate(Date effectiveTillDate) {
		this.effectiveTillDate = effectiveTillDate;
	}

	public Date getExitPlcyEndDate() {
		return this.exitPlcyEndDate;
	}

	public void setExitPlcyEndDate(Date exitPlcyEndDate) {
		this.exitPlcyEndDate = exitPlcyEndDate;
	}

	public String getExitPlcyFlag() {
		return this.exitPlcyFlag;
	}

	public void setExitPlcyFlag(String exitPlcyFlag) {
		this.exitPlcyFlag = exitPlcyFlag;
	}

	public BigDecimal getExitPlcyId() {
		return this.exitPlcyId;
	}

	public void setExitPlcyId(BigDecimal exitPlcyId) {
		this.exitPlcyId = exitPlcyId;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public Date getMonthlyDeductionDate() {
		return this.monthlyDeductionDate;
	}

	public void setMonthlyDeductionDate(Date monthlyDeductionDate) {
		this.monthlyDeductionDate = monthlyDeductionDate;
	}

	public BigDecimal getRatePlanId() {
		return this.ratePlanId;
	}

	public void setRatePlanId(BigDecimal ratePlanId) {
		this.ratePlanId = ratePlanId;
	}

	public BigDecimal getRenewalCount() {
		return this.renewalCount;
	}

	public void setRenewalCount(BigDecimal renewalCount) {
		this.renewalCount = renewalCount;
	}

	public Date getSubscriptionRenewalDate() {
		return this.subscriptionRenewalDate;
	}

	public void setSubscriptionRenewalDate(Date subscriptionRenewalDate) {
		this.subscriptionRenewalDate = subscriptionRenewalDate;
	}

	public TSohAccountServiceDetail getTSohAccountServiceDetail() {
		return this.TSohAccountServiceDetail;
	}

	public void setTSohAccountServiceDetail(TSohAccountServiceDetail TSohAccountServiceDetail) {
		this.TSohAccountServiceDetail = TSohAccountServiceDetail;
	}

	public TSohSubscriptionPackageDtl getTSohSubscriptionPackageDtl() {
		return this.TSohSubscriptionPackageDtl;
	}

	public void setTSohSubscriptionPackageDtl(TSohSubscriptionPackageDtl TSohSubscriptionPackageDtl) {
		this.TSohSubscriptionPackageDtl = TSohSubscriptionPackageDtl;
	}

}