package ae.etisalat.cw.jpa.psm.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the T_BIL_BILLING_PERIOD database table.
 * 
 */
@Entity
@Table(name="T_BIL_BILLING_PERIOD")
@NamedQuery(name="TBilBillingPeriod.findAll", query="SELECT t FROM TBilBillingPeriod t")
public class TBilBillingPeriod implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="BILLING_PERIOD_ID")
	private long billingPeriodId;

	@Column(name="BILLING_CYCLE_ID")
	private BigDecimal billingCycleId;

	@Temporal(TemporalType.DATE)
	@Column(name="BILLING_END_DATE")
	private Date billingEndDate;

	@Temporal(TemporalType.DATE)
	@Column(name="BILLING_START_DATE")
	private Date billingStartDate;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	private BigDecimal status;

	public TBilBillingPeriod() {
	}

	public long getBillingPeriodId() {
		return this.billingPeriodId;
	}

	public void setBillingPeriodId(long billingPeriodId) {
		this.billingPeriodId = billingPeriodId;
	}

	public BigDecimal getBillingCycleId() {
		return this.billingCycleId;
	}

	public void setBillingCycleId(BigDecimal billingCycleId) {
		this.billingCycleId = billingCycleId;
	}

	public Date getBillingEndDate() {
		return this.billingEndDate;
	}

	public void setBillingEndDate(Date billingEndDate) {
		this.billingEndDate = billingEndDate;
	}

	public Date getBillingStartDate() {
		return this.billingStartDate;
	}

	public void setBillingStartDate(Date billingStartDate) {
		this.billingStartDate = billingStartDate;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getStatus() {
		return this.status;
	}

	public void setStatus(BigDecimal status) {
		this.status = status;
	}

}