package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the T_SOH_ACCOUNT database table.
 * 
 */
@Entity
@Table(name="T_SOH_ACCOUNT")
public class TSohAccount implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_SOH_ACCOUNT_ACCOUNTID_GENERATOR", sequenceName="SQ_T_SOH_ACCOUNT",allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_SOH_ACCOUNT_ACCOUNTID_GENERATOR")
	@Column(name="ACCOUNT_ID")
	private long accountId;

	@Column(name="ACCESS_FLAG")
	private String accessFlag;

	@Column(name="ACCOUNT_CATEGORY_ID")
	private BigDecimal accountCategoryId;

	@Column(name="ACCOUNT_CURRENCY_ID")
	private BigDecimal accountCurrencyId;

	@Column(name="ACCOUNT_FULL_NAME_ARABIC")
	private String accountFullNameArabic;

	@Column(name="ACCOUNT_FULL_NAME_ENG")
	private String accountFullNameEng;

	@Column(name="ACCOUNT_SECURITY_ID")
	private BigDecimal accountSecurityId;

	@Column(name="ACCOUNT_STATUS_ID")
	private BigDecimal accountStatusId;

	@Temporal(TemporalType.DATE)
	@Column(name="ACTIVATION_DATE")
	private Date activationDate;

	private BigDecimal amount;

	@Column(name="AUTH_PERSON_ID")
	private String authPersonId;

	@Column(name="AUTH_PERSON_NAME")
	private String authPersonName;

	@Column(name="BAD_DEBT_FLAG")
	private String badDebtFlag;

	@Temporal(TemporalType.DATE)
	@Column(name="BILL_CYCLE_DATE")
	private Date billCycleDate;

	@Column(name="BILL_CYCLE_ID")
	private BigDecimal billCycleId;

	@Column(name="BILL_CYCLE_TYPE")
	private String billCycleType;

	@Column(name="BS_REQUEST_FLAG")
	private String bsRequestFlag;

	@Column(name="CBCM_CATEGORY_ID")
	private BigDecimal cbcmCategoryId;

	@Column(name="CCB_INTERNAL_ACCT_NO")
	private BigDecimal ccbInternalAcctNo;

	@Temporal(TemporalType.DATE)
	@Column(name="CESSATION_DATE")
	private Date cessationDate;

	@Temporal(TemporalType.DATE)
	@Column(name="CHEQUE_OVERRIDE_TILLDATE")
	private Date chequeOverrideTilldate;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="CREDIT_REASON_ID")
	private BigDecimal creditReasonId;

	@Column(name="CREDIT_STATUS_ID")
	private BigDecimal creditStatusId;

	@Column(name="DATE_ACCT_STAT")
	private Timestamp dateAcctStat;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="DOMAIN_NAME")
	private String domainName;

	@Column(name="EMIRATE_ID")
	private BigDecimal emirateId;

	@Column(name="FAX_FLAG")
	private String faxFlag;

	@Column(name="GROUP_PROCESS_FLAG")
	private BigDecimal groupProcessFlag;

	@Column(name="GUIDING_ID")
	private String guidingId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_PAYMENT_DATE")
	private Date lastPaymentDate;

	@Column(name="MAINTAINANCE_PRIORITY")
	private BigDecimal maintainancePriority;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="ORG_UNIT_ID")
	private BigDecimal orgUnitId;

	@Column(name="PARTY_ID")
	private BigDecimal partyId;

	@Column(name="PARTY_PROFILE_ID")
	private BigDecimal partyProfileId;

	@Column(name="PAYMENT_PRIORITY")
	private BigDecimal paymentPriority;

	@Column(name="PRODUCT_GROUP_ID")
	private BigDecimal productGroupId;

	@Column(name="PRODUCT_ID")
	private BigDecimal productId;

	@Column(name="REASON_ID")
	private BigDecimal reasonId;

	@Column(name="REGION_ID")
	private BigDecimal regionId;

	private String remarks;

	@Temporal(TemporalType.DATE)
	@Column(name="SERVICE_REQUIRED_TILL_DATE")
	private Date serviceRequiredTillDate;

	@Column(name="SPONSOR_FLAG")
	private String sponsorFlag;

	@Column(name="UPGRADE_COUNT")
	private BigDecimal upgradeCount;

	@Column(name="VB_FLAG")
	private String vbFlag;

	//bi-directional many-to-one association to TSohAccount
	@ManyToOne
	@JoinColumn(name="LINKED_ACCOUNT_ID")
	private TSohAccount TSohAccount1;

	//bi-directional many-to-one association to TSohAccount
	@OneToMany(mappedBy="TSohAccount1")
	private List<TSohAccount> TSohAccounts1;

	//bi-directional many-to-one association to TSohAccount
	@ManyToOne
	@JoinColumn(name="OWNER_ACCOUNT_ID")
	private TSohAccount TSohAccount2;

	//bi-directional many-to-one association to TSohAccount
	@OneToMany(mappedBy="TSohAccount2")
	private List<TSohAccount> TSohAccounts2;

	//bi-directional many-to-one association to TSohAccAccountNumber
	@OneToMany(mappedBy="TSohAccount")
	private List<TSohAccAccountNumber> TSohAccAccountNumbers;

	//bi-directional many-to-one association to TSohHstAccountNumber
	@OneToMany(mappedBy="TSohAccount")
	private List<TSohHstAccountNumber> TSohHstAccountNumbers;

	//bi-directional many-to-one association to TSohHstAccountStatus
	@OneToMany(mappedBy="TSohAccount")
	private List<TSohHstAccountStatus> TSohHstAccountStatuses;

	//bi-directional many-to-one association to TSohHstAcctBilCyc
	@OneToMany(mappedBy="TSohAccount")
	private List<TSohHstAcctBilCyc> TSohHstAcctBilCycs;

	//bi-directional many-to-one association to TSohHstAcctCurrency
	@OneToMany(mappedBy="TSohAccount")
	private List<TSohHstAcctCurrency> TSohHstAcctCurrencies;

	public TSohAccount() {
	}

	public long getAccountId() {
		return this.accountId;
	}

	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}

	public String getAccessFlag() {
		return this.accessFlag;
	}

	public void setAccessFlag(String accessFlag) {
		this.accessFlag = accessFlag;
	}

	public BigDecimal getAccountCategoryId() {
		return this.accountCategoryId;
	}

	public void setAccountCategoryId(BigDecimal accountCategoryId) {
		this.accountCategoryId = accountCategoryId;
	}

	public BigDecimal getAccountCurrencyId() {
		return this.accountCurrencyId;
	}

	public void setAccountCurrencyId(BigDecimal accountCurrencyId) {
		this.accountCurrencyId = accountCurrencyId;
	}

	public String getAccountFullNameArabic() {
		return this.accountFullNameArabic;
	}

	public void setAccountFullNameArabic(String accountFullNameArabic) {
		this.accountFullNameArabic = accountFullNameArabic;
	}

	public String getAccountFullNameEng() {
		return this.accountFullNameEng;
	}

	public void setAccountFullNameEng(String accountFullNameEng) {
		this.accountFullNameEng = accountFullNameEng;
	}

	public BigDecimal getAccountSecurityId() {
		return this.accountSecurityId;
	}

	public void setAccountSecurityId(BigDecimal accountSecurityId) {
		this.accountSecurityId = accountSecurityId;
	}

	public BigDecimal getAccountStatusId() {
		return this.accountStatusId;
	}

	public void setAccountStatusId(BigDecimal accountStatusId) {
		this.accountStatusId = accountStatusId;
	}

	public Date getActivationDate() {
		return this.activationDate;
	}

	public void setActivationDate(Date activationDate) {
		this.activationDate = activationDate;
	}

	public BigDecimal getAmount() {
		return this.amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getAuthPersonId() {
		return this.authPersonId;
	}

	public void setAuthPersonId(String authPersonId) {
		this.authPersonId = authPersonId;
	}

	public String getAuthPersonName() {
		return this.authPersonName;
	}

	public void setAuthPersonName(String authPersonName) {
		this.authPersonName = authPersonName;
	}

	public String getBadDebtFlag() {
		return this.badDebtFlag;
	}

	public void setBadDebtFlag(String badDebtFlag) {
		this.badDebtFlag = badDebtFlag;
	}

	public Date getBillCycleDate() {
		return this.billCycleDate;
	}

	public void setBillCycleDate(Date billCycleDate) {
		this.billCycleDate = billCycleDate;
	}

	public BigDecimal getBillCycleId() {
		return this.billCycleId;
	}

	public void setBillCycleId(BigDecimal billCycleId) {
		this.billCycleId = billCycleId;
	}

	public String getBillCycleType() {
		return this.billCycleType;
	}

	public void setBillCycleType(String billCycleType) {
		this.billCycleType = billCycleType;
	}

	public String getBsRequestFlag() {
		return this.bsRequestFlag;
	}

	public void setBsRequestFlag(String bsRequestFlag) {
		this.bsRequestFlag = bsRequestFlag;
	}

	public BigDecimal getCbcmCategoryId() {
		return this.cbcmCategoryId;
	}

	public void setCbcmCategoryId(BigDecimal cbcmCategoryId) {
		this.cbcmCategoryId = cbcmCategoryId;
	}

	public BigDecimal getCcbInternalAcctNo() {
		return this.ccbInternalAcctNo;
	}

	public void setCcbInternalAcctNo(BigDecimal ccbInternalAcctNo) {
		this.ccbInternalAcctNo = ccbInternalAcctNo;
	}

	public Date getCessationDate() {
		return this.cessationDate;
	}

	public void setCessationDate(Date cessationDate) {
		this.cessationDate = cessationDate;
	}

	public Date getChequeOverrideTilldate() {
		return this.chequeOverrideTilldate;
	}

	public void setChequeOverrideTilldate(Date chequeOverrideTilldate) {
		this.chequeOverrideTilldate = chequeOverrideTilldate;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public BigDecimal getCreditReasonId() {
		return this.creditReasonId;
	}

	public void setCreditReasonId(BigDecimal creditReasonId) {
		this.creditReasonId = creditReasonId;
	}

	public BigDecimal getCreditStatusId() {
		return this.creditStatusId;
	}

	public void setCreditStatusId(BigDecimal creditStatusId) {
		this.creditStatusId = creditStatusId;
	}

	public Timestamp getDateAcctStat() {
		return this.dateAcctStat;
	}

	public void setDateAcctStat(Timestamp dateAcctStat) {
		this.dateAcctStat = dateAcctStat;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public String getDomainName() {
		return this.domainName;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	public BigDecimal getEmirateId() {
		return this.emirateId;
	}

	public void setEmirateId(BigDecimal emirateId) {
		this.emirateId = emirateId;
	}

	public String getFaxFlag() {
		return this.faxFlag;
	}

	public void setFaxFlag(String faxFlag) {
		this.faxFlag = faxFlag;
	}

	public BigDecimal getGroupProcessFlag() {
		return this.groupProcessFlag;
	}

	public void setGroupProcessFlag(BigDecimal groupProcessFlag) {
		this.groupProcessFlag = groupProcessFlag;
	}

	public String getGuidingId() {
		return this.guidingId;
	}

	public void setGuidingId(String guidingId) {
		this.guidingId = guidingId;
	}

	public Date getLastPaymentDate() {
		return this.lastPaymentDate;
	}

	public void setLastPaymentDate(Date lastPaymentDate) {
		this.lastPaymentDate = lastPaymentDate;
	}

	public BigDecimal getMaintainancePriority() {
		return this.maintainancePriority;
	}

	public void setMaintainancePriority(BigDecimal maintainancePriority) {
		this.maintainancePriority = maintainancePriority;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getOrgUnitId() {
		return this.orgUnitId;
	}

	public void setOrgUnitId(BigDecimal orgUnitId) {
		this.orgUnitId = orgUnitId;
	}

	public BigDecimal getPartyId() {
		return this.partyId;
	}

	public void setPartyId(BigDecimal partyId) {
		this.partyId = partyId;
	}

	public BigDecimal getPartyProfileId() {
		return this.partyProfileId;
	}

	public void setPartyProfileId(BigDecimal partyProfileId) {
		this.partyProfileId = partyProfileId;
	}

	public BigDecimal getPaymentPriority() {
		return this.paymentPriority;
	}

	public void setPaymentPriority(BigDecimal paymentPriority) {
		this.paymentPriority = paymentPriority;
	}

	public BigDecimal getProductGroupId() {
		return this.productGroupId;
	}

	public void setProductGroupId(BigDecimal productGroupId) {
		this.productGroupId = productGroupId;
	}

	public BigDecimal getProductId() {
		return this.productId;
	}

	public void setProductId(BigDecimal productId) {
		this.productId = productId;
	}

	public BigDecimal getReasonId() {
		return this.reasonId;
	}

	public void setReasonId(BigDecimal reasonId) {
		this.reasonId = reasonId;
	}

	public BigDecimal getRegionId() {
		return this.regionId;
	}

	public void setRegionId(BigDecimal regionId) {
		this.regionId = regionId;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Date getServiceRequiredTillDate() {
		return this.serviceRequiredTillDate;
	}

	public void setServiceRequiredTillDate(Date serviceRequiredTillDate) {
		this.serviceRequiredTillDate = serviceRequiredTillDate;
	}

	public String getSponsorFlag() {
		return this.sponsorFlag;
	}

	public void setSponsorFlag(String sponsorFlag) {
		this.sponsorFlag = sponsorFlag;
	}

	public BigDecimal getUpgradeCount() {
		return this.upgradeCount;
	}

	public void setUpgradeCount(BigDecimal upgradeCount) {
		this.upgradeCount = upgradeCount;
	}

	public String getVbFlag() {
		return this.vbFlag;
	}

	public void setVbFlag(String vbFlag) {
		this.vbFlag = vbFlag;
	}

	public TSohAccount getTSohAccount1() {
		return this.TSohAccount1;
	}

	public void setTSohAccount1(TSohAccount TSohAccount1) {
		this.TSohAccount1 = TSohAccount1;
	}

	public List<TSohAccount> getTSohAccounts1() {
		return this.TSohAccounts1;
	}

	public void setTSohAccounts1(List<TSohAccount> TSohAccounts1) {
		this.TSohAccounts1 = TSohAccounts1;
	}

	public TSohAccount addTSohAccounts1(TSohAccount TSohAccounts1) {
		getTSohAccounts1().add(TSohAccounts1);
		TSohAccounts1.setTSohAccount1(this);

		return TSohAccounts1;
	}

	public TSohAccount removeTSohAccounts1(TSohAccount TSohAccounts1) {
		getTSohAccounts1().remove(TSohAccounts1);
		TSohAccounts1.setTSohAccount1(null);

		return TSohAccounts1;
	}

	public TSohAccount getTSohAccount2() {
		return this.TSohAccount2;
	}

	public void setTSohAccount2(TSohAccount TSohAccount2) {
		this.TSohAccount2 = TSohAccount2;
	}

	public List<TSohAccount> getTSohAccounts2() {
		return this.TSohAccounts2;
	}

	public void setTSohAccounts2(List<TSohAccount> TSohAccounts2) {
		this.TSohAccounts2 = TSohAccounts2;
	}

	public TSohAccount addTSohAccounts2(TSohAccount TSohAccounts2) {
		getTSohAccounts2().add(TSohAccounts2);
		TSohAccounts2.setTSohAccount2(this);

		return TSohAccounts2;
	}

	public TSohAccount removeTSohAccounts2(TSohAccount TSohAccounts2) {
		getTSohAccounts2().remove(TSohAccounts2);
		TSohAccounts2.setTSohAccount2(null);

		return TSohAccounts2;
	}

	public List<TSohAccAccountNumber> getTSohAccAccountNumbers() {
		return this.TSohAccAccountNumbers;
	}

	public void setTSohAccAccountNumbers(List<TSohAccAccountNumber> TSohAccAccountNumbers) {
		this.TSohAccAccountNumbers = TSohAccAccountNumbers;
	}

	public TSohAccAccountNumber addTSohAccAccountNumber(TSohAccAccountNumber TSohAccAccountNumber) {
		getTSohAccAccountNumbers().add(TSohAccAccountNumber);
		TSohAccAccountNumber.setTSohAccount(this);

		return TSohAccAccountNumber;
	}

	public TSohAccAccountNumber removeTSohAccAccountNumber(TSohAccAccountNumber TSohAccAccountNumber) {
		getTSohAccAccountNumbers().remove(TSohAccAccountNumber);
		TSohAccAccountNumber.setTSohAccount(null);

		return TSohAccAccountNumber;
	}

	public List<TSohHstAccountNumber> getTSohHstAccountNumbers() {
		return this.TSohHstAccountNumbers;
	}

	public void setTSohHstAccountNumbers(List<TSohHstAccountNumber> TSohHstAccountNumbers) {
		this.TSohHstAccountNumbers = TSohHstAccountNumbers;
	}

	public TSohHstAccountNumber addTSohHstAccountNumber(TSohHstAccountNumber TSohHstAccountNumber) {
		getTSohHstAccountNumbers().add(TSohHstAccountNumber);
		TSohHstAccountNumber.setTSohAccount(this);

		return TSohHstAccountNumber;
	}

	public TSohHstAccountNumber removeTSohHstAccountNumber(TSohHstAccountNumber TSohHstAccountNumber) {
		getTSohHstAccountNumbers().remove(TSohHstAccountNumber);
		TSohHstAccountNumber.setTSohAccount(null);

		return TSohHstAccountNumber;
	}

	public List<TSohHstAccountStatus> getTSohHstAccountStatuses() {
		return this.TSohHstAccountStatuses;
	}

	public void setTSohHstAccountStatuses(List<TSohHstAccountStatus> TSohHstAccountStatuses) {
		this.TSohHstAccountStatuses = TSohHstAccountStatuses;
	}

	public TSohHstAccountStatus addTSohHstAccountStatus(TSohHstAccountStatus TSohHstAccountStatus) {
		getTSohHstAccountStatuses().add(TSohHstAccountStatus);
		TSohHstAccountStatus.setTSohAccount(this);

		return TSohHstAccountStatus;
	}

	public TSohHstAccountStatus removeTSohHstAccountStatus(TSohHstAccountStatus TSohHstAccountStatus) {
		getTSohHstAccountStatuses().remove(TSohHstAccountStatus);
		TSohHstAccountStatus.setTSohAccount(null);

		return TSohHstAccountStatus;
	}

	public List<TSohHstAcctBilCyc> getTSohHstAcctBilCycs() {
		return this.TSohHstAcctBilCycs;
	}

	public void setTSohHstAcctBilCycs(List<TSohHstAcctBilCyc> TSohHstAcctBilCycs) {
		this.TSohHstAcctBilCycs = TSohHstAcctBilCycs;
	}

	public TSohHstAcctBilCyc addTSohHstAcctBilCyc(TSohHstAcctBilCyc TSohHstAcctBilCyc) {
		getTSohHstAcctBilCycs().add(TSohHstAcctBilCyc);
		TSohHstAcctBilCyc.setTSohAccount(this);

		return TSohHstAcctBilCyc;
	}

	public TSohHstAcctBilCyc removeTSohHstAcctBilCyc(TSohHstAcctBilCyc TSohHstAcctBilCyc) {
		getTSohHstAcctBilCycs().remove(TSohHstAcctBilCyc);
		TSohHstAcctBilCyc.setTSohAccount(null);

		return TSohHstAcctBilCyc;
	}

	public List<TSohHstAcctCurrency> getTSohHstAcctCurrencies() {
		return this.TSohHstAcctCurrencies;
	}

	public void setTSohHstAcctCurrencies(List<TSohHstAcctCurrency> TSohHstAcctCurrencies) {
		this.TSohHstAcctCurrencies = TSohHstAcctCurrencies;
	}

	public TSohHstAcctCurrency addTSohHstAcctCurrency(TSohHstAcctCurrency TSohHstAcctCurrency) {
		getTSohHstAcctCurrencies().add(TSohHstAcctCurrency);
		TSohHstAcctCurrency.setTSohAccount(this);

		return TSohHstAcctCurrency;
	}

	public TSohHstAcctCurrency removeTSohHstAcctCurrency(TSohHstAcctCurrency TSohHstAcctCurrency) {
		getTSohHstAcctCurrencies().remove(TSohHstAcctCurrency);
		TSohHstAcctCurrency.setTSohAccount(null);

		return TSohHstAcctCurrency;
	}

}