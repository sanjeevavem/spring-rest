package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the T_SOH_SUBREQ_PAYMENTINFO database table.
 * 
 */
@Entity
@Table(name="T_SOH_SUBREQ_PAYMENTINFO")
@NamedQuery(name="TSohSubreqPaymentinfo.findAll", query="SELECT t FROM TSohSubreqPaymentinfo t")
public class TSohSubreqPaymentinfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SUBREQ_PAYTYPE_ID")
	private long subreqPaytypeId;

	@Column(name="ACCOUNT_ID")
	private BigDecimal accountId;

	@Column(name="ACCOUNT_NUMBER")
	private String accountNumber;

	@Column(name="AUTHROIZATION_CODE")
	private String authroizationCode;

	@Column(name="BANK_ACC_NUMBER")
	private String bankAccNumber;

	@Column(name="BANK_BRANCH_ID")
	private BigDecimal bankBranchId;

	@Column(name="BANK_ID")
	private BigDecimal bankId;

	@Temporal(TemporalType.DATE)
	@Column(name="CARD_EXPIRY_DATE")
	private Date cardExpiryDate;

	@Column(name="CARD_NUMBER")
	private String cardNumber;

	@Column(name="CARD_TYPE_ID")
	private BigDecimal cardTypeId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="CREDITCARD_COMPANY_ID")
	private BigDecimal creditcardCompanyId;

	@Column(name="CVV_NUMBER")
	private String cvvNumber;

	@Temporal(TemporalType.DATE)
	@Column(name="DD_EXPIRY_DATE")
	private Date ddExpiryDate;

	@Column(name="DD_REGISTRATION_STATUS")
	private String ddRegistrationStatus;

	@Temporal(TemporalType.DATE)
	@Column(name="DD_START_DATE")
	private Date ddStartDate;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="EMIRATESID_NO")
	private String emiratesidNo;

	@Column(name="EPG_STATUS")
	private String epgStatus;

	@Column(name="EPG_TRANS_ID")
	private String epgTransId;

	@Column(name="INSTALLAMENT_FLAG")
	private String installamentFlag;

	@Column(name="MOBILE_CONTACT")
	private String mobileContact;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="NAME_ON_CARD")
	private String nameOnCard;

	@Column(name="PAY_TYPE_MODE_ID")
	private BigDecimal payTypeModeId;

	@Column(name="PAYMENT_AMOUNT")
	private BigDecimal paymentAmount;

	@Column(name="PAYMENT_DAY")
	private BigDecimal paymentDay;

	@Column(name="PAYMENT_FREQUENCY")
	private String paymentFrequency;

	@Column(name="PAYMENT_OPTION")
	private String paymentOption;

	@Column(name="PAYMENT_REF_NUMBER")
	private String paymentRefNumber;

	@Column(name="SOURCE_CHANNEL")
	private String sourceChannel;

	@Column(name="SUBREQUEST_ID")
	private BigDecimal subrequestId;

	@Column(name="WEB_SR_STATUS")
	private String webSrStatus;

	@Column(name="WEB_SR_STATUS1")
	private String webSrStatus1;

	@Column(name="WEB_TRANSACTION_ID")
	private String webTransactionId;

	public TSohSubreqPaymentinfo() {
	}

	public long getSubreqPaytypeId() {
		return this.subreqPaytypeId;
	}

	public void setSubreqPaytypeId(long subreqPaytypeId) {
		this.subreqPaytypeId = subreqPaytypeId;
	}

	public BigDecimal getAccountId() {
		return this.accountId;
	}

	public void setAccountId(BigDecimal accountId) {
		this.accountId = accountId;
	}

	public String getAccountNumber() {
		return this.accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAuthroizationCode() {
		return this.authroizationCode;
	}

	public void setAuthroizationCode(String authroizationCode) {
		this.authroizationCode = authroizationCode;
	}

	public String getBankAccNumber() {
		return this.bankAccNumber;
	}

	public void setBankAccNumber(String bankAccNumber) {
		this.bankAccNumber = bankAccNumber;
	}

	public BigDecimal getBankBranchId() {
		return this.bankBranchId;
	}

	public void setBankBranchId(BigDecimal bankBranchId) {
		this.bankBranchId = bankBranchId;
	}

	public BigDecimal getBankId() {
		return this.bankId;
	}

	public void setBankId(BigDecimal bankId) {
		this.bankId = bankId;
	}

	public Date getCardExpiryDate() {
		return this.cardExpiryDate;
	}

	public void setCardExpiryDate(Date cardExpiryDate) {
		this.cardExpiryDate = cardExpiryDate;
	}

	public String getCardNumber() {
		return this.cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public BigDecimal getCardTypeId() {
		return this.cardTypeId;
	}

	public void setCardTypeId(BigDecimal cardTypeId) {
		this.cardTypeId = cardTypeId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public BigDecimal getCreditcardCompanyId() {
		return this.creditcardCompanyId;
	}

	public void setCreditcardCompanyId(BigDecimal creditcardCompanyId) {
		this.creditcardCompanyId = creditcardCompanyId;
	}

	public String getCvvNumber() {
		return this.cvvNumber;
	}

	public void setCvvNumber(String cvvNumber) {
		this.cvvNumber = cvvNumber;
	}

	public Date getDdExpiryDate() {
		return this.ddExpiryDate;
	}

	public void setDdExpiryDate(Date ddExpiryDate) {
		this.ddExpiryDate = ddExpiryDate;
	}

	public String getDdRegistrationStatus() {
		return this.ddRegistrationStatus;
	}

	public void setDdRegistrationStatus(String ddRegistrationStatus) {
		this.ddRegistrationStatus = ddRegistrationStatus;
	}

	public Date getDdStartDate() {
		return this.ddStartDate;
	}

	public void setDdStartDate(Date ddStartDate) {
		this.ddStartDate = ddStartDate;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public String getEmiratesidNo() {
		return this.emiratesidNo;
	}

	public void setEmiratesidNo(String emiratesidNo) {
		this.emiratesidNo = emiratesidNo;
	}

	public String getEpgStatus() {
		return this.epgStatus;
	}

	public void setEpgStatus(String epgStatus) {
		this.epgStatus = epgStatus;
	}

	public String getEpgTransId() {
		return this.epgTransId;
	}

	public void setEpgTransId(String epgTransId) {
		this.epgTransId = epgTransId;
	}

	public String getInstallamentFlag() {
		return this.installamentFlag;
	}

	public void setInstallamentFlag(String installamentFlag) {
		this.installamentFlag = installamentFlag;
	}

	public String getMobileContact() {
		return this.mobileContact;
	}

	public void setMobileContact(String mobileContact) {
		this.mobileContact = mobileContact;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getNameOnCard() {
		return this.nameOnCard;
	}

	public void setNameOnCard(String nameOnCard) {
		this.nameOnCard = nameOnCard;
	}

	public BigDecimal getPayTypeModeId() {
		return this.payTypeModeId;
	}

	public void setPayTypeModeId(BigDecimal payTypeModeId) {
		this.payTypeModeId = payTypeModeId;
	}

	public BigDecimal getPaymentAmount() {
		return this.paymentAmount;
	}

	public void setPaymentAmount(BigDecimal paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public BigDecimal getPaymentDay() {
		return this.paymentDay;
	}

	public void setPaymentDay(BigDecimal paymentDay) {
		this.paymentDay = paymentDay;
	}

	public String getPaymentFrequency() {
		return this.paymentFrequency;
	}

	public void setPaymentFrequency(String paymentFrequency) {
		this.paymentFrequency = paymentFrequency;
	}

	public String getPaymentOption() {
		return this.paymentOption;
	}

	public void setPaymentOption(String paymentOption) {
		this.paymentOption = paymentOption;
	}

	public String getPaymentRefNumber() {
		return this.paymentRefNumber;
	}

	public void setPaymentRefNumber(String paymentRefNumber) {
		this.paymentRefNumber = paymentRefNumber;
	}

	public String getSourceChannel() {
		return this.sourceChannel;
	}

	public void setSourceChannel(String sourceChannel) {
		this.sourceChannel = sourceChannel;
	}

	public BigDecimal getSubrequestId() {
		return this.subrequestId;
	}

	public void setSubrequestId(BigDecimal subrequestId) {
		this.subrequestId = subrequestId;
	}

	public String getWebSrStatus() {
		return this.webSrStatus;
	}

	public void setWebSrStatus(String webSrStatus) {
		this.webSrStatus = webSrStatus;
	}

	public String getWebSrStatus1() {
		return this.webSrStatus1;
	}

	public void setWebSrStatus1(String webSrStatus1) {
		this.webSrStatus1 = webSrStatus1;
	}

	public String getWebTransactionId() {
		return this.webTransactionId;
	}

	public void setWebTransactionId(String webTransactionId) {
		this.webTransactionId = webTransactionId;
	}

}