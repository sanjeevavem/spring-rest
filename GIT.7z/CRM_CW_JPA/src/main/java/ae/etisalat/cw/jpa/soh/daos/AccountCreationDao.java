package ae.etisalat.cw.jpa.soh.daos;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import ae.etisalat.cw.comm.util.Util;
import ae.etisalat.cw.comm.util.logger.CWLog;
import ae.etisalat.cw.jpa.adm.entities.TAdmMstEmirate;
import ae.etisalat.cw.jpa.adm.entities.TAdmMstRegion;
import ae.etisalat.cw.jpa.cms.entities.TCmsDtlPartyProfile;
import ae.etisalat.cw.jpa.psm.entities.TPsmMstProduct;
import ae.etisalat.cw.jpa.soh.entities.TSohAccAccountNumber;
import ae.etisalat.cw.jpa.soh.entities.TSohAccount;
import ae.etisalat.cw.jpa.soh.entities.TSohAccountStatusSrtMap;
import ae.etisalat.cw.jpa.soh.entities.TSohDtlAccinfoCrcscheme;
import ae.etisalat.cw.jpa.soh.entities.TSohHstAccountNumber;
import ae.etisalat.cw.jpa.soh.entities.TSohHstAccountStatus;
import ae.etisalat.cw.jpa.soh.entities.TSohHstAcctBilCyc;
import ae.etisalat.cw.jpa.soh.entities.TSohHstAcctCurrency;
import ae.etisalat.cw.jpa.soh.entities.TSohHstParty;
import ae.etisalat.cw.jpa.soh.entities.TSohMstSubRequestType;
import ae.etisalat.cw.jpa.soh.entities.TSohTestEntity;
import ae.etisalat.cw.restws.clients.AccountInfo;
import ae.etisalat.cw.restws.clients.OrderInfo;
import ae.etisalat.cw.restws.clients.ServiceRegistry;
import ae.etisalat.cw.restws.dao.generic.GenericOrderCreationDAOImpl;

@Repository
@Transactional
public class AccountCreationDao  {
	private static final Logger logger = LogManager.getLogger(AccountCreationDao.class);

	@PersistenceContext
	private EntityManager em;

	GenericOrderCreationDAOImpl genericDao;

	public TSohAccAccountNumber getAccountInfo(String accountNumber) {
		try {
			Query query = 
					em.createQuery("select a from TSohAccAccountNumber a where a.accountNumber = :accountNumber and a.accountSuffix= (select max(h.accountSuffix) from  TSohAccAccountNumber h where h.accountNumber = :accountNumber)");
			query.setParameter("accountNumber", accountNumber);
			TSohAccAccountNumber account =Util.getFirstObjectFromList(query.getResultList());
			if (account != null) {
				return account;
			}
		}catch(Exception e){

		}
		finally{

		}
		return null;
	} 

	public boolean isExistingAccount(String account_number, long subrequest_id) {
		try {
			String jpql = "select a "
					+ "from TSohAccAccountNumber a "
					+ "where a.accountNumber = :accountNumber and a.accountSuffix = (select max(h.accountSuffix) "
					+ "from  TSohAccAccountNumber h "
					+ "where h.accountNumber = :accountNumber)";

			Map<String, Object> queryConditions = new HashMap<String, Object>();
			queryConditions.put("accountNumber", account_number);
			List<TSohAccAccountNumber> tSohAccAccountNumber = search(jpql, queryConditions);
			if(tSohAccAccountNumber != null && tSohAccAccountNumber.size() != 0){
				TSohAccAccountNumber accAccountNumber = tSohAccAccountNumber.get(0);
				if(accAccountNumber != null){
					long account_id  = accAccountNumber.getTSohAccount().getAccountId();
					String accountQuery = "SELECT t FROM TSohAccount t where t.accountId = :accountId and t.TSohDtlSystemCodeValue1.systemCodeValueId in :systemCodeValueId";
					Map<String, Object> accountQueryConditions = new HashMap<String, Object>();
					accountQueryConditions.put("accountId", account_id);
					accountQueryConditions.put("systemCodeValueId", "1");
					List<TSohAccount> tSohAccount = search(accountQuery, accountQueryConditions);
					if(tSohAccount != null && tSohAccount.size() != 0){
						return true;
					}
				}

			}


		} catch (Exception e) {
		}

		return false;
	}
	@SuppressWarnings("unchecked")
	public <T> List<T> search(String jpql, Map<String, Object> queryConditions) throws DataAccessException {
		List<T> entities = null;
		try {
			Query query = em.createQuery(jpql);
			if (queryConditions != null && !queryConditions.isEmpty()) {
				Set<Entry<String,Object>> entrySet = queryConditions.entrySet();
				for (Entry<String, Object> entry : entrySet) {
					query.setParameter(entry.getKey(), entry.getValue());
				}
			}
			entities = (List<T>) query.getResultList();
			return entities;
		} catch (Exception e) {
			return entities;
		}

	}
	public TSohAccount createAccount(ServiceRegistry srvRegistry,String userId,OrderInfo orderInfo) throws Exception {
		TSohAccount  tSohAccount  = null;
		if (userId == null) {
			userId = "SYSTEM";
		}
		try{
			AccountInfo accInfo = srvRegistry.getAccountInfo();
			tSohAccount = new TSohAccount(); 			
 			tSohAccount.setProductId(getProductId(orderInfo.getProductCode()));
			tSohAccount.setProductGroupId(getProductGroupIdByCode(orderInfo.getProductCode()));
			//			tSohAccount.setServiceRequiredTillDate(null);//
			tSohAccount.setGuidingId(accInfo.getGUIDINGID());
			tSohAccount.setCcbInternalAcctNo(BigDecimal.valueOf(0));
			tSohAccount.setAmount(BigDecimal.valueOf(0.00));
			tSohAccount.setGroupProcessFlag(BigDecimal.valueOf(0));
			tSohAccount.setUpgradeCount(BigDecimal.valueOf(0));

			tSohAccount.setRegionId(new BigDecimal(getRegionByCode(orderInfo.getRegionName()).getRegionId()));
			tSohAccount.setEmirateId(new BigDecimal(getEmiratesByCode(orderInfo.getEmirate()).getEmirateId()));
			tSohAccount.setSponsorFlag(accInfo.getSPONSORFLAG());
			//			tSohAccount.setRemarks("");
			tSohAccount.setFaxFlag(accInfo.getFAXFLAG());

			tSohAccount.setPartyId(new BigDecimal(accInfo.getPartyId()));
			tSohAccount.setPartyProfileId(new BigDecimal(accInfo.getPartyProfileId()));
			tSohAccount.setOrgUnitId(new BigDecimal(accInfo.getPHYORGUNITID()));
			tSohAccount.setPaymentPriority(new BigDecimal(accInfo.getPAYMENTPRIORITY()));

			tSohAccount.setAccountFullNameArabic(accInfo.getACCOUNTFULLNAMEARABIC());
			tSohAccount.setAccountFullNameEng(accInfo.getACCOUNTFULLNAMEENG());
			tSohAccount.setDomainName(accInfo.getDOMAINNAME());
			tSohAccount.setCbcmCategoryId(new BigDecimal(accInfo.getCBCMCATEGORYID()));
			tSohAccount.setAccountCurrencyId(new BigDecimal(accInfo.getACCOUNTCURRENCYID()));
			tSohAccount.setBillCycleDate(new Date());
			tSohAccount.setBillCycleId(new BigDecimal(accInfo.getBILLCYCLEID()));
			tSohAccount.setBillCycleType("2");
			tSohAccount.setAccountCategoryId(new BigDecimal(accInfo.getSubTypeId()));
			tSohAccount.setAccountSecurityId(null);//Null fro now
			tSohAccount.setAccountStatusId(getAccountStatusId(getSubrequestTypeId(orderInfo.getOrderType())));
			tSohAccount.setCreditStatusId(BigDecimal.valueOf(54));

			tSohAccount.setDateAcctStat(new Timestamp(new Date().getTime()));
			tSohAccount.setActivationDate(new Date());
			tSohAccount.setBadDebtFlag("N");
			tSohAccount.setBsRequestFlag(accInfo.getBSREQUESTFLAG());
			tSohAccount.setCreatedUserId(userId);
			tSohAccount.setCreatedDate(new Timestamp(new Date().getTime()));
			tSohAccount.setModifiedUserId(userId);
			tSohAccount.setModifiedDate(new Timestamp(new Date().getTime()));
			tSohAccount.setDeletionStatus("N");
			// 			tSohAccount.setAccountId(sohSubreqAcctid.getAccountId()); //Primary key
			
			tSohAccount.setMaintainancePriority(new BigDecimal(22));

			em.persist(tSohAccount);
			storeAccountNumber(tSohAccount,userId,accInfo);

			processAllHistoryTables(tSohAccount,userId,accInfo,em);


		}catch(Exception e)
		{
			CWLog.logMessage(Level.ERROR, "Exception Message is : "+e.getMessage(),e);
			 throw e;		
		}
		return tSohAccount;
	}	

	public BigDecimal getProductId(String productCode) {
		Query query =  em.createNativeQuery("select prod.product_id from T_Psm_Mst_Product prod where prod.product_Code = :productCode and prod.deletion_Status = 'N'");
		query.setParameter("productCode", productCode);
		return Util.getFirstObjectFromList(query.getResultList());
	}
	public TSohTestEntity isValidTestAccount(String partyId) throws Exception {
		String query = "Select t From TSohTestEntity t Where t.entityId =:entityId and t.entityCategory=:entityCategory and t.deletionStatus='N'";
		Query qry = em.createQuery(query);
		qry.setParameter("entityId", new BigDecimal(partyId));
		qry.setParameter("entityCategory", "TEST_PARTY");

		TSohTestEntity tSohTestEntity = Util.getFirstObjectFromList(qry.getResultList());

		if (tSohTestEntity != null)
			return tSohTestEntity;
		return null;
	}
	public void insertTestAccount(String accountId, String userId) throws Exception {

		TSohTestEntity tSohTestEntity = new TSohTestEntity();
		tSohTestEntity.setCreatedDate(new Timestamp(new Date().getTime()));
		tSohTestEntity.setCreatedUserId(userId);
		tSohTestEntity.setEntityCategory("TEST_ACCOUNT");
		tSohTestEntity.setEntityId(new BigDecimal(accountId));
		tSohTestEntity.setModifiedDate(new Timestamp(new Date().getTime()));
		tSohTestEntity.setModifiedUserId(userId);
		tSohTestEntity.setDeletionStatus("N");
		em.persist(tSohTestEntity);


	}
	private TSohAccAccountNumber storeAccountNumber(TSohAccount  tSohAccount,String userId,AccountInfo accInfo)throws Exception{

		TSohAccAccountNumber tSohAccAccountNumber = null;
		try{
			tSohAccAccountNumber = new TSohAccAccountNumber();
			tSohAccAccountNumber.setTSohAccount(tSohAccount);
			tSohAccAccountNumber.setAccountNumber(accInfo.getAccountNumber());
			tSohAccAccountNumber.setAreaCode(accInfo.getAreaCode());
			tSohAccAccountNumber.setProductNumber(new BigDecimal(accInfo.getProductNumber()));
			tSohAccAccountNumber.setAccountSuffix(new BigDecimal(accInfo.getAccountSuffix()));
			tSohAccAccountNumber.setCreatedDate(new Timestamp(new Date().getTime()));
			tSohAccAccountNumber.setCreatedUserId(userId);
			tSohAccAccountNumber.setModifiedDate(new Timestamp(new Date().getTime()));
			tSohAccAccountNumber.setModifiedUserId(userId);
			tSohAccAccountNumber.setDeletionStatus("N");
			em.persist(tSohAccAccountNumber);


		}catch(Exception e){
			throw e;
		}
		return tSohAccAccountNumber;
	}

	public void processAllHistoryTables(TSohAccount  tSohAccount,String userId,AccountInfo accInfo,EntityManager em)throws Exception
	{
		TSohHstAccountStatus tSohHstAccountStatus = null;
		TSohHstAcctBilCyc tSohHstAcctBilCyc = null;
		TSohHstAcctCurrency tSohHstAcctCurrency = null;
		TSohHstParty tSohHstParty = null;
		TSohHstAccountNumber tSohHstAccountNumber = null;
		try
		{
			if(tSohAccount != null)
			{
				tSohHstAccountStatus = new TSohHstAccountStatus();	
				tSohHstAccountStatus.setTSohAccount(tSohAccount);
				tSohHstAccountStatus.setAccountStatusId(tSohAccount.getAccountStatusId());
				tSohHstAccountStatus.setCrdtStatusId(tSohAccount.getCreditStatusId());

				if(tSohAccount.getDateAcctStat() != null){
					tSohHstAccountStatus.setEffFrom(tSohAccount.getDateAcctStat());
				}else{
					tSohHstAccountStatus.setEffFrom(new Timestamp(tSohAccount.getActivationDate().getTime()) );
				}
				tSohHstAccountStatus.setCrdtReasonId(tSohAccount.getCreditReasonId());
				if(null!=tSohAccount.getReasonId()) {
					tSohHstAccountStatus.setReasonId(tSohAccount.getReasonId()); 	 				
				}
				tSohHstAccountStatus.setCreatedUserId(userId);
				tSohHstAccountStatus.setCreatedDate(new Timestamp(new Date().getTime()));
				tSohHstAccountStatus.setModifiedDate(new Timestamp(new Date().getTime()));
				tSohHstAccountStatus.setModifiedUserId(userId);
				tSohHstAccountStatus.setDeletionStatus("N");

				em.persist(tSohHstAccountStatus);
				tSohHstAcctBilCyc = new  TSohHstAcctBilCyc();
				//21-06-2014
				tSohHstAcctBilCyc.setTSohAccount(tSohAccount);
				tSohHstAcctBilCyc.setBillCycleDate(tSohAccount.getBillCycleDate());
				tSohHstAcctBilCyc.setBillCycleId(tSohAccount.getBillCycleId());
				tSohHstAcctBilCyc.setEffFrom(tSohAccount.getModifiedDate());
				tSohHstAcctBilCyc.setCreatedDate(new Timestamp(new Date().getTime()));
				tSohHstAcctBilCyc.setCreatedUserId(userId);
				tSohHstAcctBilCyc.setModifiedUserId(userId);
				tSohHstAcctBilCyc.setModifiedDate(new Timestamp(new Date().getTime()));
				tSohHstAcctBilCyc.setDeletionStatus("N");
				em.persist(tSohHstAcctBilCyc);
				tSohHstAcctCurrency = new TSohHstAcctCurrency();
				tSohHstAcctCurrency.setTSohAccount(tSohAccount);
				tSohHstAcctCurrency.setCurrencyId(tSohAccount.getAccountCurrencyId());
				tSohHstAcctCurrency.setCreatedDate(new Timestamp(new Date().getTime()));
				tSohHstAcctCurrency.setCreatedUserId(userId);
				tSohHstAcctCurrency.setDeletionStatus("N");
				tSohHstAcctCurrency.setEffFrom(tSohAccount.getModifiedDate());
				tSohHstAcctCurrency.setModifiedDate(new Timestamp(new Date().getTime()));
				tSohHstAcctCurrency.setModifiedUserId(userId);
				em.persist(tSohHstAcctCurrency);
				tSohHstAccountNumber = new TSohHstAccountNumber();
				tSohHstAccountNumber.setTSohAccount(tSohAccount);
				tSohHstAccountNumber.setAccountNumber(accInfo.getAccountNumber());
				tSohHstAccountNumber.setEffFrom(tSohAccount.getModifiedDate());
				tSohHstAccountNumber.setAreaCode(accInfo.getAreaCode());
				tSohHstAccountNumber.setProductNumber(new BigDecimal(accInfo.getProductNumber()));
				tSohHstAccountNumber.setAccountSuffix(new BigDecimal(accInfo.getAccountSuffix()));
				tSohHstAccountNumber.setDeletionStatus("N");
				tSohHstAccountNumber.setCreatedUserId(userId);
				tSohHstAccountNumber.setCreatedDate(new Timestamp(new Date().getTime()));
				tSohHstAccountNumber.setModifiedDate(new Timestamp(new Date().getTime()));
				tSohHstAccountNumber.setModifiedUserId(userId);
				em.persist(tSohHstAccountNumber);

				tSohHstParty = new TSohHstParty();
				tSohHstParty.setAccountId(BigDecimal.valueOf(tSohAccount.getAccountId()));
				tSohHstParty.setCreatedDate(new Timestamp(new Date().getTime()));
				tSohHstParty.setCreatedUserId(userId);
				tSohHstParty.setDeletionStatus("N");
				tSohHstParty.setPartyId(tSohAccount.getPartyId());
				tSohHstParty.setEffFrom(tSohAccount.getModifiedDate());
				tSohHstParty.setModifiedDate(new Timestamp(new Date().getTime()));
				tSohHstParty.setModifiedUserId(userId);
				em.persist(tSohHstParty);
			}else
			{
				throw new Exception("Account Details is null,So unable to update the history table ");
			}	
		}catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
	}

	public BigDecimal getAccountStatusId(long subRequestTypeId)
	{
		TSohAccountStatusSrtMap tSohAccountStatusSrtMap = (TSohAccountStatusSrtMap) em.createNamedQuery("TSohAccountStatusSrtMap.findBySubreqTypeId")
				.setParameter("subRequestTypeId", subRequestTypeId).setParameter("deletionStatus", "N").getSingleResult();

		return new BigDecimal(tSohAccountStatusSrtMap.getTSohDtlSystemCodeValue2().getSystemCodeValueId());               

	}
	public long getSubrequestTypeId(String subReqType) {
		long subreqTypeId = 0;
		TSohMstSubRequestType stype = (TSohMstSubRequestType)em.createNamedQuery("TSohMstSubRequestType.findbytypeCode").setParameter("subRequestTypeCode", subReqType).setMaxResults(1).getSingleResult();
		subreqTypeId = stype.getSubRequestTypeId();
		return subreqTypeId;
	}
	public TAdmMstRegion getRegionByCode(String regionCode) {

		Query query = em.createQuery("select a from TAdmMstRegion a where a.regionCode = :regionCode and a.deletionStatus =:deletionStatus");
		query.setParameter("regionCode", regionCode);
		query.setParameter("deletionStatus", "N");
		TAdmMstRegion tAdmMstRegion = Util.getFirstObjectFromList(query.getResultList());//CBCMCOMS-4753
		if (tAdmMstRegion != null) {
			return tAdmMstRegion;
		}
		return null;
	}

	public TAdmMstEmirate getEmiratesByCode(String code) {

		try {
			Query query = em.createQuery("select a from TAdmMstEmirate a where a.code = :code and a.deletionStatus ='N'");
			query.setParameter("code", code);
			TAdmMstEmirate tAdmMstEmirate = Util.getFirstObjectFromList(query.getResultList());
			if (tAdmMstEmirate != null) {
				return tAdmMstEmirate;
			}
		} finally {
		}
		return null;
	}

	public BigDecimal getProductGroupIdByCode(String productCode) {
		TPsmMstProduct product = (TPsmMstProduct) em.createNamedQuery("TPsmMstProduct.findByCode")
				.setParameter("productCode", productCode).setParameter("deletionStatus","N").getSingleResult();

		return product.getProductGroupId();               

	}
public TCmsDtlPartyProfile getPartyProfile(long partProfileId) {
			long start = System.currentTimeMillis();
			try {
				TCmsDtlPartyProfile tCmsDtlPartyProfile = em.find(TCmsDtlPartyProfile.class, partProfileId);                                                
				logger.debug(" Parameters are : account id :" + partProfileId); 
				if (tCmsDtlPartyProfile != null) {
					logger.info("Part Profile has been fetched in "+ (System.currentTimeMillis() - start)+ " milliseconds");
					return tCmsDtlPartyProfile;
				}
			}catch(Exception e){
				logger.debug("Exception" + e.getMessage());
			}
			finally{

			}
			return null;
		} 
	 
	 public void insertCrcSheme(BigDecimal creditSchemeId, BigDecimal creditCategoryId, BigDecimal accountId,String userId)throws Exception{
	 		
	 		TSohDtlAccinfoCrcscheme tSohDtlAccinfoCrcscheme = null;
	 		try{
	 			tSohDtlAccinfoCrcscheme = new TSohDtlAccinfoCrcscheme();
	 			tSohDtlAccinfoCrcscheme.setCreditSchemeId(creditSchemeId);;
	 			tSohDtlAccinfoCrcscheme.setCreditCategoryId(creditCategoryId);
	 			tSohDtlAccinfoCrcscheme.setAccountId(accountId);
	 			tSohDtlAccinfoCrcscheme.setCreatedDate(new Timestamp(new Date().getTime()));
	 			tSohDtlAccinfoCrcscheme.setCreatedUserId(userId);
	 			tSohDtlAccinfoCrcscheme.setModifiedDate(new Timestamp(new Date().getTime()));
	 			tSohDtlAccinfoCrcscheme.setModifiedUserId(userId);
	 			tSohDtlAccinfoCrcscheme.setDeletionStatus("N");
	 			em.persist(tSohDtlAccinfoCrcscheme);

	 		}catch(Exception e){
	 			logger.error(" Exception while creating the account number for subrequest  ");
	 			throw e;
	 		}
	 		logger.info(" End of the storeAccountNumber for the subrequest id  ");
	 	
	 	}

}

