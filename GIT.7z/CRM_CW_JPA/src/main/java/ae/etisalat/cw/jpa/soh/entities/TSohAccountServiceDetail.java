package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the T_SOH_ACCOUNT_SERVICE_DETAILS database table.
 * 
 */
@Entity
@Table(name="T_SOH_ACCOUNT_SERVICE_DETAILS")
@NamedQuery(name="TSohAccountServiceDetail.findAll", query="SELECT t FROM TSohAccountServiceDetail t")
public class TSohAccountServiceDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_SOH_ACCOUNT_SERVICE_DETAILS_ACCOUNTSERVICEID_GENERATOR", sequenceName="SQ_T_SOH_ACCOUNT_SERVICE_DTL",allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_SOH_ACCOUNT_SERVICE_DETAILS_ACCOUNTSERVICEID_GENERATOR")
	@Column(name="ACCOUNT_SERVICE_ID")
	private long accountServiceId;

	@Column(name="ACCOUNT_ID")
	private BigDecimal accountId;

	@Column(name="BAD_DEBT_FLAG")
	private String badDebtFlag;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="CREDIT_REASON_ID")
	private BigDecimal creditReasonId;

	@Column(name="CREDIT_STATUS_ID")
	private BigDecimal creditStatusId;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_ACCT_STAT")
	private Date dateAcctStat;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_FROM_DATE")
	private Date effectiveFromDate;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_TILL_DATE")
	private Date effectiveTillDate;

	@Column(name="IS_PRIMARY_SERVICE_FLAG")
	private String isPrimaryServiceFlag;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="NO_OF_INSTANCES")
	private BigDecimal noOfInstances;

	@Column(name="PRODUCT_TYPE")
	private String productType;

	@Column(name="REASON_ID")
	private BigDecimal reasonId;

	@Column(name="RETAILER_ID")
	private BigDecimal retailerId;

	@Column(name="SERVICE_ID")
	private BigDecimal serviceId;

	@Column(name="SERVICE_STATUS_ID")
	private BigDecimal serviceStatusId;

	@Column(name="SPONSOR_FLAG")
	private String sponsorFlag;

	@Column(name="SUBACCT_NUM_ID")
	private BigDecimal subacctNumId;

	//bi-directional many-to-one association to TSohAccountChargeDetail
	@OneToMany(mappedBy="TSohAccountServiceDetail")
	private List<TSohAccountChargeDetail> TSohAccountChargeDetails;

	//bi-directional many-to-one association to TSohAccountInstanceDetail
	@OneToMany(mappedBy="TSohAccountServiceDetail")
	private List<TSohAccountInstanceDetail> TSohAccountInstanceDetails;

	//bi-directional many-to-one association to TSohAcctTransactionDetail
	@OneToMany(mappedBy="TSohAccountServiceDetail")
	private List<TSohAcctTransactionDetail> TSohAcctTransactionDetails;

	//bi-directional many-to-one association to TSohSubscriptionRateplnDtl
	@OneToMany(mappedBy="TSohAccountServiceDetail")
	private List<TSohSubscriptionRateplnDtl> TSohSubscriptionRateplnDtls;

	public TSohAccountServiceDetail() {
	}

	public long getAccountServiceId() {
		return this.accountServiceId;
	}

	public void setAccountServiceId(long accountServiceId) {
		this.accountServiceId = accountServiceId;
	}

	public BigDecimal getAccountId() {
		return this.accountId;
	}

	public void setAccountId(BigDecimal accountId) {
		this.accountId = accountId;
	}

	public String getBadDebtFlag() {
		return this.badDebtFlag;
	}

	public void setBadDebtFlag(String badDebtFlag) {
		this.badDebtFlag = badDebtFlag;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public BigDecimal getCreditReasonId() {
		return this.creditReasonId;
	}

	public void setCreditReasonId(BigDecimal creditReasonId) {
		this.creditReasonId = creditReasonId;
	}

	public BigDecimal getCreditStatusId() {
		return this.creditStatusId;
	}

	public void setCreditStatusId(BigDecimal creditStatusId) {
		this.creditStatusId = creditStatusId;
	}

	public Date getDateAcctStat() {
		return this.dateAcctStat;
	}

	public void setDateAcctStat(Date dateAcctStat) {
		this.dateAcctStat = dateAcctStat;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Date getEffectiveFromDate() {
		return this.effectiveFromDate;
	}

	public void setEffectiveFromDate(Date effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}

	public Date getEffectiveTillDate() {
		return this.effectiveTillDate;
	}

	public void setEffectiveTillDate(Date effectiveTillDate) {
		this.effectiveTillDate = effectiveTillDate;
	}

	public String getIsPrimaryServiceFlag() {
		return this.isPrimaryServiceFlag;
	}

	public void setIsPrimaryServiceFlag(String isPrimaryServiceFlag) {
		this.isPrimaryServiceFlag = isPrimaryServiceFlag;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getNoOfInstances() {
		return this.noOfInstances;
	}

	public void setNoOfInstances(BigDecimal noOfInstances) {
		this.noOfInstances = noOfInstances;
	}

	public String getProductType() {
		return this.productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public BigDecimal getReasonId() {
		return this.reasonId;
	}

	public void setReasonId(BigDecimal reasonId) {
		this.reasonId = reasonId;
	}

	public BigDecimal getRetailerId() {
		return this.retailerId;
	}

	public void setRetailerId(BigDecimal retailerId) {
		this.retailerId = retailerId;
	}

	public BigDecimal getServiceId() {
		return this.serviceId;
	}

	public void setServiceId(BigDecimal serviceId) {
		this.serviceId = serviceId;
	}

	public BigDecimal getServiceStatusId() {
		return this.serviceStatusId;
	}

	public void setServiceStatusId(BigDecimal serviceStatusId) {
		this.serviceStatusId = serviceStatusId;
	}

	public String getSponsorFlag() {
		return this.sponsorFlag;
	}

	public void setSponsorFlag(String sponsorFlag) {
		this.sponsorFlag = sponsorFlag;
	}

	public BigDecimal getSubacctNumId() {
		return this.subacctNumId;
	}

	public void setSubacctNumId(BigDecimal subacctNumId) {
		this.subacctNumId = subacctNumId;
	}

	public List<TSohAccountChargeDetail> getTSohAccountChargeDetails() {
		return this.TSohAccountChargeDetails;
	}

	public void setTSohAccountChargeDetails(List<TSohAccountChargeDetail> TSohAccountChargeDetails) {
		this.TSohAccountChargeDetails = TSohAccountChargeDetails;
	}

	public TSohAccountChargeDetail addTSohAccountChargeDetail(TSohAccountChargeDetail TSohAccountChargeDetail) {
		getTSohAccountChargeDetails().add(TSohAccountChargeDetail);
		TSohAccountChargeDetail.setTSohAccountServiceDetail(this);

		return TSohAccountChargeDetail;
	}

	public TSohAccountChargeDetail removeTSohAccountChargeDetail(TSohAccountChargeDetail TSohAccountChargeDetail) {
		getTSohAccountChargeDetails().remove(TSohAccountChargeDetail);
		TSohAccountChargeDetail.setTSohAccountServiceDetail(null);

		return TSohAccountChargeDetail;
	}

	public List<TSohAccountInstanceDetail> getTSohAccountInstanceDetails() {
		return this.TSohAccountInstanceDetails;
	}

	public void setTSohAccountInstanceDetails(List<TSohAccountInstanceDetail> TSohAccountInstanceDetails) {
		this.TSohAccountInstanceDetails = TSohAccountInstanceDetails;
	}

	public TSohAccountInstanceDetail addTSohAccountInstanceDetail(TSohAccountInstanceDetail TSohAccountInstanceDetail) {
		getTSohAccountInstanceDetails().add(TSohAccountInstanceDetail);
		TSohAccountInstanceDetail.setTSohAccountServiceDetail(this);

		return TSohAccountInstanceDetail;
	}

	public TSohAccountInstanceDetail removeTSohAccountInstanceDetail(TSohAccountInstanceDetail TSohAccountInstanceDetail) {
		getTSohAccountInstanceDetails().remove(TSohAccountInstanceDetail);
		TSohAccountInstanceDetail.setTSohAccountServiceDetail(null);

		return TSohAccountInstanceDetail;
	}

	public List<TSohAcctTransactionDetail> getTSohAcctTransactionDetails() {
		return this.TSohAcctTransactionDetails;
	}

	public void setTSohAcctTransactionDetails(List<TSohAcctTransactionDetail> TSohAcctTransactionDetails) {
		this.TSohAcctTransactionDetails = TSohAcctTransactionDetails;
	}

	public TSohAcctTransactionDetail addTSohAcctTransactionDetail(TSohAcctTransactionDetail TSohAcctTransactionDetail) {
		getTSohAcctTransactionDetails().add(TSohAcctTransactionDetail);
		TSohAcctTransactionDetail.setTSohAccountServiceDetail(this);

		return TSohAcctTransactionDetail;
	}

	public TSohAcctTransactionDetail removeTSohAcctTransactionDetail(TSohAcctTransactionDetail TSohAcctTransactionDetail) {
		getTSohAcctTransactionDetails().remove(TSohAcctTransactionDetail);
		TSohAcctTransactionDetail.setTSohAccountServiceDetail(null);

		return TSohAcctTransactionDetail;
	}

	public List<TSohSubscriptionRateplnDtl> getTSohSubscriptionRateplnDtls() {
		return this.TSohSubscriptionRateplnDtls;
	}

	public void setTSohSubscriptionRateplnDtls(List<TSohSubscriptionRateplnDtl> TSohSubscriptionRateplnDtls) {
		this.TSohSubscriptionRateplnDtls = TSohSubscriptionRateplnDtls;
	}

	public TSohSubscriptionRateplnDtl addTSohSubscriptionRateplnDtl(TSohSubscriptionRateplnDtl TSohSubscriptionRateplnDtl) {
		getTSohSubscriptionRateplnDtls().add(TSohSubscriptionRateplnDtl);
		TSohSubscriptionRateplnDtl.setTSohAccountServiceDetail(this);

		return TSohSubscriptionRateplnDtl;
	}

	public TSohSubscriptionRateplnDtl removeTSohSubscriptionRateplnDtl(TSohSubscriptionRateplnDtl TSohSubscriptionRateplnDtl) {
		getTSohSubscriptionRateplnDtls().remove(TSohSubscriptionRateplnDtl);
		TSohSubscriptionRateplnDtl.setTSohAccountServiceDetail(null);

		return TSohSubscriptionRateplnDtl;
	}

}