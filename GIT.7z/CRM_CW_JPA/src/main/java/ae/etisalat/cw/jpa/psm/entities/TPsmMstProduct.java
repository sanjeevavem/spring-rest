package ae.etisalat.cw.jpa.psm.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the T_PSM_MST_PRODUCT database table.
 * 
 */
@Entity
@Table(name="T_PSM_MST_PRODUCT")
@NamedQueries(value = {@NamedQuery(name="TPsmMstProduct.findAll", query="SELECT t FROM TPsmMstProduct t"),
	@NamedQuery(name="TPsmMstProduct.findByCode",query ="from TPsmMstProduct a where a.productCode = :productCode and a.deletionStatus =:deletionStatus")
	})
public class TPsmMstProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_PSM_MST_PRODUCT_PRODUCTID_GENERATOR", sequenceName="SQ_T_PSM_MST_PRODUCT")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_PSM_MST_PRODUCT_PRODUCTID_GENERATOR")
	@Column(name="PRODUCT_ID")
	private long productId;

	@Column(name="CCB_PRODUCT_CODE")
	private String ccbProductCode;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="PAYMENT_PRIORITY")
	private BigDecimal paymentPriority;

	@Temporal(TemporalType.DATE)
	@Column(name="PRODUCT_CLOSURE_DATE")
	private Date productClosureDate;

	@Column(name="PRODUCT_CODE")
	private String productCode;

	@Column(name="PRODUCT_DESC")
	private String productDesc;

	@Column(name="PRODUCT_GROUP_ID")
	private BigDecimal productGroupId;

	@Column(name="PRODUCT_OWNER")
	private BigDecimal productOwner;

	public TPsmMstProduct() {
	}

	public long getProductId() {
		return this.productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public String getCcbProductCode() {
		return this.ccbProductCode;
	}

	public void setCcbProductCode(String ccbProductCode) {
		this.ccbProductCode = ccbProductCode;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getPaymentPriority() {
		return this.paymentPriority;
	}

	public void setPaymentPriority(BigDecimal paymentPriority) {
		this.paymentPriority = paymentPriority;
	}

	public Date getProductClosureDate() {
		return this.productClosureDate;
	}

	public void setProductClosureDate(Date productClosureDate) {
		this.productClosureDate = productClosureDate;
	}

	public String getProductCode() {
		return this.productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductDesc() {
		return this.productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public BigDecimal getProductGroupId() {
		return this.productGroupId;
	}

	public void setProductGroupId(BigDecimal productGroupId) {
		this.productGroupId = productGroupId;
	}

	public BigDecimal getProductOwner() {
		return this.productOwner;
	}

	public void setProductOwner(BigDecimal productOwner) {
		this.productOwner = productOwner;
	}

}