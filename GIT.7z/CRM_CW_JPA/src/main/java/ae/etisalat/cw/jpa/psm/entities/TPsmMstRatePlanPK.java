package ae.etisalat.cw.jpa.psm.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the T_PSM_MST_RATE_PLAN database table.
 * 
 */
@Embeddable
public class TPsmMstRatePlanPK implements Serializable {
    // default serial version id, required for serializable classes.
    private static final long serialVersionUID = 1L;

    @Column(name = "RATE_PLAN_ID")
    private long ratePlanId;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "EFFECTIVE_FROM_DATE")
    private java.util.Date effectiveFromDate;

    public TPsmMstRatePlanPK() {
    }

    public long getRatePlanId() {
        return this.ratePlanId;
    }

    public void setRatePlanId(long ratePlanId) {
        this.ratePlanId = ratePlanId;
    }

    public java.util.Date getEffectiveFromDate() {
        return this.effectiveFromDate;
    }

    public void setEffectiveFromDate(java.util.Date effectiveFromDate) {
        this.effectiveFromDate = effectiveFromDate;
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof TPsmMstRatePlanPK)) {
            return false;
        }
        TPsmMstRatePlanPK castOther = (TPsmMstRatePlanPK) other;
        return (this.ratePlanId == castOther.ratePlanId) && this.effectiveFromDate.equals(castOther.effectiveFromDate);
    }

    public int hashCode() {
        final int prime = 31;
        int hash = 17;
        hash = hash * prime + ((int) (this.ratePlanId ^ (this.ratePlanId >>> 32)));
        hash = hash * prime + this.effectiveFromDate.hashCode();

        return hash;
    }

    @Override
    public String toString() {
        return "TPsmMstRatePlanPK [ratePlanId=" + ratePlanId + ", effectiveFromDate=" + effectiveFromDate + "]";
    }

}