package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the T_SOH_SUBREQ_DQINFO database table.
 * 
 */
@Entity
@Table(name="T_SOH_SUBREQ_DQINFO")
@NamedQuery(name="TSohSubreqDqinfo.findAll", query="SELECT t FROM TSohSubreqDqinfo t")
public class TSohSubreqDqinfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SUBREQ_DQ_ID")
	private long subreqDqId;

	@Column(name="COMPANYNAMEINARABIC")
	private String companynameinarabic;

	@Column(name="COMPANYNAMEINENGLISH")
	private String companynameinenglish;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DIRECTORY_CODE")
	private java.math.BigDecimal directoryCode;

	@Column(name="FAVOURITENAMEINARABIC")
	private String favouritenameinarabic;

	@Column(name="FAVOURITENAMEINENGLISH")
	private String favouritenameinenglish;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="SUBREQUEST_ID")
	private java.math.BigDecimal subrequestId;

	public TSohSubreqDqinfo() {
	}

	public long getSubreqDqId() {
		return this.subreqDqId;
	}

	public void setSubreqDqId(long subreqDqId) {
		this.subreqDqId = subreqDqId;
	}

	public String getCompanynameinarabic() {
		return this.companynameinarabic;
	}

	public void setCompanynameinarabic(String companynameinarabic) {
		this.companynameinarabic = companynameinarabic;
	}

	public String getCompanynameinenglish() {
		return this.companynameinenglish;
	}

	public void setCompanynameinenglish(String companynameinenglish) {
		this.companynameinenglish = companynameinenglish;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public java.math.BigDecimal getDirectoryCode() {
		return this.directoryCode;
	}

	public void setDirectoryCode(java.math.BigDecimal directoryCode) {
		this.directoryCode = directoryCode;
	}

	public String getFavouritenameinarabic() {
		return this.favouritenameinarabic;
	}

	public void setFavouritenameinarabic(String favouritenameinarabic) {
		this.favouritenameinarabic = favouritenameinarabic;
	}

	public String getFavouritenameinenglish() {
		return this.favouritenameinenglish;
	}

	public void setFavouritenameinenglish(String favouritenameinenglish) {
		this.favouritenameinenglish = favouritenameinenglish;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public java.math.BigDecimal getSubrequestId() {
		return this.subrequestId;
	}

	public void setSubrequestId(java.math.BigDecimal subrequestId) {
		this.subrequestId = subrequestId;
	}

}