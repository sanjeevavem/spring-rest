package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The primary key class for the T_SOH_ACCT_LINKED_INST_ADDR database table.
 * 
 */
@Embeddable
public class TSohAcctLinkedInstAddrPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="ACCOUNT_ADDRESS_ID", insertable=false, updatable=false)
	private long accountAddressId;

	@Column(name="ACCOUNT_ID", insertable=false, updatable=false)
	private long accountId;

	public TSohAcctLinkedInstAddrPK() {
	}
	public long getAccountAddressId() {
		return this.accountAddressId;
	}
	public void setAccountAddressId(long accountAddressId) {
		this.accountAddressId = accountAddressId;
	}
	public long getAccountId() {
		return this.accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TSohAcctLinkedInstAddrPK)) {
			return false;
		}
		TSohAcctLinkedInstAddrPK castOther = (TSohAcctLinkedInstAddrPK)other;
		return 
			(this.accountAddressId == castOther.accountAddressId)
			&& (this.accountId == castOther.accountId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.accountAddressId ^ (this.accountAddressId >>> 32)));
		hash = hash * prime + ((int) (this.accountId ^ (this.accountId >>> 32)));
		
		return hash;
	}
}