package ae.etisalat.cw.jpa.cms.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the T_CMS_DTL_PARTY_IDENTITY database table.
 * 
 */
@Entity
@Table(name="T_CMS_DTL_PARTY_IDENTITY")
@NamedQuery(name="TCmsDtlPartyIdentity.findAll", query="SELECT t FROM TCmsDtlPartyIdentity t")
public class TCmsDtlPartyIdentity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_CMS_DTL_PARTY_IDENTITY_IDENTITYID_GENERATOR", sequenceName="SQ_CMS_DOCUMENT")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_CMS_DTL_PARTY_IDENTITY_IDENTITYID_GENERATOR")
	@Column(name="IDENTITY_ID")
	private long identityId;

	@Column(name="CDMS_REFERENCE")
	private BigDecimal cdmsReference;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Lob
	@Column(name="DOC_SCAN_DATA")
	private byte[] docScanData;

	@Temporal(TemporalType.DATE)
	@Column(name="DOCUMENT_DATE")
	private Date documentDate;

	@Column(name="DOCUMENT_OCR_RESULT")
	private String documentOcrResult;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_FROM")
	private Date effectiveFrom;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_TILL")
	private Date effectiveTill;

	@Column(name="ESTABLISHMENT_NAME")
	private String establishmentName;

	@Column(name="IDENTITY_CODE")
	private String identityCode;

	@Column(name="IDENTITY_TYPE_ID")
	private BigDecimal identityTypeId;

	@Column(name="IDENTITY_VAL_NO")
	private BigDecimal identityValNo;

	@Column(name="IDENTITY_VALUE")
	private String identityValue;

	@Column(name="INTERACTION_ID")
	private BigDecimal interactionId;

	@Column(name="IS_DOCUMENT_MANUALLY_VERIFIED")
	private String isDocumentManuallyVerified;

	@Column(name="IS_ELECTRONIC_READ")
	private String isElectronicRead;

	@Column(name="IS_MANUAL_ENTRY")
	private String isManualEntry;

	@Column(name="IS_OCR_SCANUPLOAD")
	private String isOcrScanupload;

	@Column(name="ISSUING_AUTHORITY")
	private String issuingAuthority;

	@Column(name="MESSAGE_ID")
	private BigDecimal messageId;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="OCR_DOC_FILENAME")
	private String ocrDocFilename;

	@Column(name="PARTY_ID")
	private BigDecimal partyId;

	@Column(name="PROFILE_ID")
	private BigDecimal profileId;

	@Column(name="READER_BYPASS_USER_ID")
	private String readerBypassUserId;

	@Column(name="SCANNED_FROM_READER")
	private String scannedFromReader;

	@Column(name="SOURCE_SYSTEM")
	private BigDecimal sourceSystem;

	@Column(name="TRADE_NAME")
	private String tradeName;

	@Column(name="UNIFIED_NUMBER")
	private BigDecimal unifiedNumber;

	@Column(name="UNIVERSITY_NAME")
	private String universityName;

	public TCmsDtlPartyIdentity() {
	}

	public long getIdentityId() {
		return this.identityId;
	}

	public void setIdentityId(long identityId) {
		this.identityId = identityId;
	}

	public BigDecimal getCdmsReference() {
		return this.cdmsReference;
	}

	public void setCdmsReference(BigDecimal cdmsReference) {
		this.cdmsReference = cdmsReference;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public byte[] getDocScanData() {
		return this.docScanData;
	}

	public void setDocScanData(byte[] docScanData) {
		this.docScanData = docScanData;
	}

	public Date getDocumentDate() {
		return this.documentDate;
	}

	public void setDocumentDate(Date documentDate) {
		this.documentDate = documentDate;
	}

	public String getDocumentOcrResult() {
		return this.documentOcrResult;
	}

	public void setDocumentOcrResult(String documentOcrResult) {
		this.documentOcrResult = documentOcrResult;
	}

	public Date getEffectiveFrom() {
		return this.effectiveFrom;
	}

	public void setEffectiveFrom(Date effectiveFrom) {
		this.effectiveFrom = effectiveFrom;
	}

	public Date getEffectiveTill() {
		return this.effectiveTill;
	}

	public void setEffectiveTill(Date effectiveTill) {
		this.effectiveTill = effectiveTill;
	}

	public String getEstablishmentName() {
		return this.establishmentName;
	}

	public void setEstablishmentName(String establishmentName) {
		this.establishmentName = establishmentName;
	}

	public String getIdentityCode() {
		return this.identityCode;
	}

	public void setIdentityCode(String identityCode) {
		this.identityCode = identityCode;
	}

	public BigDecimal getIdentityTypeId() {
		return this.identityTypeId;
	}

	public void setIdentityTypeId(BigDecimal identityTypeId) {
		this.identityTypeId = identityTypeId;
	}

	public BigDecimal getIdentityValNo() {
		return this.identityValNo;
	}

	public void setIdentityValNo(BigDecimal identityValNo) {
		this.identityValNo = identityValNo;
	}

	public String getIdentityValue() {
		return this.identityValue;
	}

	public void setIdentityValue(String identityValue) {
		this.identityValue = identityValue;
	}

	public BigDecimal getInteractionId() {
		return this.interactionId;
	}

	public void setInteractionId(BigDecimal interactionId) {
		this.interactionId = interactionId;
	}

	public String getIsDocumentManuallyVerified() {
		return this.isDocumentManuallyVerified;
	}

	public void setIsDocumentManuallyVerified(String isDocumentManuallyVerified) {
		this.isDocumentManuallyVerified = isDocumentManuallyVerified;
	}

	public String getIsElectronicRead() {
		return this.isElectronicRead;
	}

	public void setIsElectronicRead(String isElectronicRead) {
		this.isElectronicRead = isElectronicRead;
	}

	public String getIsManualEntry() {
		return this.isManualEntry;
	}

	public void setIsManualEntry(String isManualEntry) {
		this.isManualEntry = isManualEntry;
	}

	public String getIsOcrScanupload() {
		return this.isOcrScanupload;
	}

	public void setIsOcrScanupload(String isOcrScanupload) {
		this.isOcrScanupload = isOcrScanupload;
	}

	public String getIssuingAuthority() {
		return this.issuingAuthority;
	}

	public void setIssuingAuthority(String issuingAuthority) {
		this.issuingAuthority = issuingAuthority;
	}

	public BigDecimal getMessageId() {
		return this.messageId;
	}

	public void setMessageId(BigDecimal messageId) {
		this.messageId = messageId;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getOcrDocFilename() {
		return this.ocrDocFilename;
	}

	public void setOcrDocFilename(String ocrDocFilename) {
		this.ocrDocFilename = ocrDocFilename;
	}

	public BigDecimal getPartyId() {
		return this.partyId;
	}

	public void setPartyId(BigDecimal partyId) {
		this.partyId = partyId;
	}

	public BigDecimal getProfileId() {
		return this.profileId;
	}

	public void setProfileId(BigDecimal profileId) {
		this.profileId = profileId;
	}

	public String getReaderBypassUserId() {
		return this.readerBypassUserId;
	}

	public void setReaderBypassUserId(String readerBypassUserId) {
		this.readerBypassUserId = readerBypassUserId;
	}

	public String getScannedFromReader() {
		return this.scannedFromReader;
	}

	public void setScannedFromReader(String scannedFromReader) {
		this.scannedFromReader = scannedFromReader;
	}

	public BigDecimal getSourceSystem() {
		return this.sourceSystem;
	}

	public void setSourceSystem(BigDecimal sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public String getTradeName() {
		return this.tradeName;
	}

	public void setTradeName(String tradeName) {
		this.tradeName = tradeName;
	}

	public BigDecimal getUnifiedNumber() {
		return this.unifiedNumber;
	}

	public void setUnifiedNumber(BigDecimal unifiedNumber) {
		this.unifiedNumber = unifiedNumber;
	}

	public String getUniversityName() {
		return this.universityName;
	}

	public void setUniversityName(String universityName) {
		this.universityName = universityName;
	}

}