package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the T_SOH_HST_ACCT_CURRENCY database table.
 * 
 */
@Entity
@Table(name="T_SOH_HST_ACCT_CURRENCY")
@NamedQuery(name="TSohHstAcctCurrency.findAll", query="SELECT t FROM TSohHstAcctCurrency t")
public class TSohHstAcctCurrency implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_SOH_HST_ACCT_CURRENCY_ACCTCURRENCYID_GENERATOR", sequenceName="SQ_T_SOH_HST_ACCT_CURRENCY",allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_SOH_HST_ACCT_CURRENCY_ACCTCURRENCYID_GENERATOR")
	@Column(name="ACCT_CURRENCY_ID")
	private long acctCurrencyId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="CURRENCY_ID")
	private java.math.BigDecimal currencyId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="EFF_FROM")
	private Timestamp effFrom;

	@Column(name="EFF_TILL")
	private Timestamp effTill;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="OLD_CURRENCY_ID")
	private java.math.BigDecimal oldCurrencyId;

	//bi-directional many-to-one association to TSohAccount
	@ManyToOne
	@JoinColumn(name="ACCOUNT_ID")
	private TSohAccount TSohAccount;

	public TSohHstAcctCurrency() {
	}

	public long getAcctCurrencyId() {
		return this.acctCurrencyId;
	}

	public void setAcctCurrencyId(long acctCurrencyId) {
		this.acctCurrencyId = acctCurrencyId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public java.math.BigDecimal getCurrencyId() {
		return this.currencyId;
	}

	public void setCurrencyId(java.math.BigDecimal currencyId) {
		this.currencyId = currencyId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getEffFrom() {
		return this.effFrom;
	}

	public void setEffFrom(Timestamp effFrom) {
		this.effFrom = effFrom;
	}

	public Timestamp getEffTill() {
		return this.effTill;
	}

	public void setEffTill(Timestamp effTill) {
		this.effTill = effTill;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public java.math.BigDecimal getOldCurrencyId() {
		return this.oldCurrencyId;
	}

	public void setOldCurrencyId(java.math.BigDecimal oldCurrencyId) {
		this.oldCurrencyId = oldCurrencyId;
	}

	public TSohAccount getTSohAccount() {
		return this.TSohAccount;
	}

	public void setTSohAccount(TSohAccount TSohAccount) {
		this.TSohAccount = TSohAccount;
	}

}