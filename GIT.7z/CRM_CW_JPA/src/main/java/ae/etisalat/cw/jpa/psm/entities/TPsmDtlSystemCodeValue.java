package ae.etisalat.cw.jpa.psm.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the T_PSM_DTL_SYSTEM_CODE_VALUES database table.
 * 
 */
@Entity
@Table(name="T_PSM_DTL_SYSTEM_CODE_VALUES")
@NamedQuery(name="TPsmDtlSystemCodeValue.findAll", query="SELECT t FROM TPsmDtlSystemCodeValue t")
public class TPsmDtlSystemCodeValue implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="SYSTEM_CODE_VALUE_ID")
	private long systemCodeValueId;

	private String code;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="SYSTEM_CODE_ID")
	private BigDecimal systemCodeId;

	@Column(name="\"VALUE\"")
	private String value;

	//bi-directional many-to-one association to TPsmMstRatePlan
	@OneToMany(mappedBy="TPsmDtlSystemCodeValue")
	private List<TPsmMstRatePlan> TPsmMstRatePlans;

	//bi-directional many-to-one association to TPsmMstRecurrChrgType
	@OneToMany(mappedBy="TPsmDtlSystemCodeValue")
	private List<TPsmMstRecurrChrgType> TPsmMstRecurrChrgTypes;

	//bi-directional many-to-one association to TPsmMstSrvc
	@OneToMany(mappedBy="TPsmDtlSystemCodeValue1")
	private List<TPsmMstSrvc> TPsmMstSrvcs1;

	//bi-directional many-to-one association to TPsmMstSrvc
	@OneToMany(mappedBy="TPsmDtlSystemCodeValue2")
	private List<TPsmMstSrvc> TPsmMstSrvcs2;

	public TPsmDtlSystemCodeValue() {
	}

	public long getSystemCodeValueId() {
		return this.systemCodeValueId;
	}

	public void setSystemCodeValueId(long systemCodeValueId) {
		this.systemCodeValueId = systemCodeValueId;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getSystemCodeId() {
		return this.systemCodeId;
	}

	public void setSystemCodeId(BigDecimal systemCodeId) {
		this.systemCodeId = systemCodeId;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public List<TPsmMstRatePlan> getTPsmMstRatePlans() {
		return this.TPsmMstRatePlans;
	}

	public void setTPsmMstRatePlans(List<TPsmMstRatePlan> TPsmMstRatePlans) {
		this.TPsmMstRatePlans = TPsmMstRatePlans;
	}

	public TPsmMstRatePlan addTPsmMstRatePlan(TPsmMstRatePlan TPsmMstRatePlan) {
		getTPsmMstRatePlans().add(TPsmMstRatePlan);
		TPsmMstRatePlan.setTPsmDtlSystemCodeValue(this);

		return TPsmMstRatePlan;
	}

	public TPsmMstRatePlan removeTPsmMstRatePlan(TPsmMstRatePlan TPsmMstRatePlan) {
		getTPsmMstRatePlans().remove(TPsmMstRatePlan);
		TPsmMstRatePlan.setTPsmDtlSystemCodeValue(null);

		return TPsmMstRatePlan;
	}

	public List<TPsmMstRecurrChrgType> getTPsmMstRecurrChrgTypes() {
		return this.TPsmMstRecurrChrgTypes;
	}

	public void setTPsmMstRecurrChrgTypes(List<TPsmMstRecurrChrgType> TPsmMstRecurrChrgTypes) {
		this.TPsmMstRecurrChrgTypes = TPsmMstRecurrChrgTypes;
	}

	public TPsmMstRecurrChrgType addTPsmMstRecurrChrgType(TPsmMstRecurrChrgType TPsmMstRecurrChrgType) {
		getTPsmMstRecurrChrgTypes().add(TPsmMstRecurrChrgType);
		TPsmMstRecurrChrgType.setTPsmDtlSystemCodeValue(this);

		return TPsmMstRecurrChrgType;
	}

	public TPsmMstRecurrChrgType removeTPsmMstRecurrChrgType(TPsmMstRecurrChrgType TPsmMstRecurrChrgType) {
		getTPsmMstRecurrChrgTypes().remove(TPsmMstRecurrChrgType);
		TPsmMstRecurrChrgType.setTPsmDtlSystemCodeValue(null);

		return TPsmMstRecurrChrgType;
	}

	public List<TPsmMstSrvc> getTPsmMstSrvcs1() {
		return this.TPsmMstSrvcs1;
	}

	public void setTPsmMstSrvcs1(List<TPsmMstSrvc> TPsmMstSrvcs1) {
		this.TPsmMstSrvcs1 = TPsmMstSrvcs1;
	}

	public TPsmMstSrvc addTPsmMstSrvcs1(TPsmMstSrvc TPsmMstSrvcs1) {
		getTPsmMstSrvcs1().add(TPsmMstSrvcs1);
		TPsmMstSrvcs1.setTPsmDtlSystemCodeValue1(this);

		return TPsmMstSrvcs1;
	}

	public TPsmMstSrvc removeTPsmMstSrvcs1(TPsmMstSrvc TPsmMstSrvcs1) {
		getTPsmMstSrvcs1().remove(TPsmMstSrvcs1);
		TPsmMstSrvcs1.setTPsmDtlSystemCodeValue1(null);

		return TPsmMstSrvcs1;
	}

	public List<TPsmMstSrvc> getTPsmMstSrvcs2() {
		return this.TPsmMstSrvcs2;
	}

	public void setTPsmMstSrvcs2(List<TPsmMstSrvc> TPsmMstSrvcs2) {
		this.TPsmMstSrvcs2 = TPsmMstSrvcs2;
	}

	public TPsmMstSrvc addTPsmMstSrvcs2(TPsmMstSrvc TPsmMstSrvcs2) {
		getTPsmMstSrvcs2().add(TPsmMstSrvcs2);
		TPsmMstSrvcs2.setTPsmDtlSystemCodeValue2(this);

		return TPsmMstSrvcs2;
	}

	public TPsmMstSrvc removeTPsmMstSrvcs2(TPsmMstSrvc TPsmMstSrvcs2) {
		getTPsmMstSrvcs2().remove(TPsmMstSrvcs2);
		TPsmMstSrvcs2.setTPsmDtlSystemCodeValue2(null);

		return TPsmMstSrvcs2;
	}

}