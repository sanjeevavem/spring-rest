package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;


/**
 * The persistent class for the T_SOH_SRT_ACTION_SERVICE database table.
 * 
 */
@Entity
@Table(name="T_SOH_SRT_ACTION_SERVICE")
@NamedQuery(name="TSohSrtActionService.findAll", query="SELECT t FROM TSohSrtActionService t")
public class TSohSrtActionService implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SRT_SRV_ACTION_ID")
	private long srtSrvActionId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MICE_RATE_PLAN_ID")
	private BigDecimal miceRatePlanId;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="ONETIME_CRG_TYPE_ID")
	private BigDecimal onetimeCrgTypeId;

	@Column(name="SRV_ACTION_ID")
	private BigDecimal srvActionId;

	public TSohSrtActionService() {
	}

	public long getSrtSrvActionId() {
		return this.srtSrvActionId;
	}

	public void setSrtSrvActionId(long srtSrvActionId) {
		this.srtSrvActionId = srtSrvActionId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public BigDecimal getMiceRatePlanId() {
		return this.miceRatePlanId;
	}

	public void setMiceRatePlanId(BigDecimal miceRatePlanId) {
		this.miceRatePlanId = miceRatePlanId;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getOnetimeCrgTypeId() {
		return this.onetimeCrgTypeId;
	}

	public void setOnetimeCrgTypeId(BigDecimal onetimeCrgTypeId) {
		this.onetimeCrgTypeId = onetimeCrgTypeId;
	}

	public BigDecimal getSrvActionId() {
		return this.srvActionId;
	}

	public void setSrvActionId(BigDecimal srvActionId) {
		this.srvActionId = srvActionId;
	}

}