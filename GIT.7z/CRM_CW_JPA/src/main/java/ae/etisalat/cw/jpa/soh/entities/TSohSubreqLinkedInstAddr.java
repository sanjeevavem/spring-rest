package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the T_SOH_SUBREQ_LINKED_INST_ADDR database table.
 * 
 */
@Entity
@Table(name="T_SOH_SUBREQ_LINKED_INST_ADDR")
@NamedQuery(name="TSohSubreqLinkedInstAddr.findAll", query="SELECT t FROM TSohSubreqLinkedInstAddr t")
public class TSohSubreqLinkedInstAddr implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TSohSubreqLinkedInstAddrPK id;

	@Column(name="CIRCUIT_POINT")
	private BigDecimal circuitPoint;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;
	
	@ManyToOne
	@JoinColumn(name="SUBREQUEST_ID",insertable=false,updatable=false)
	private TSohSubrequest TSohSubrequest;

	public TSohSubreqLinkedInstAddr() {
	}

	public TSohSubreqLinkedInstAddrPK getId() {
		return this.id;
	}

	public void setId(TSohSubreqLinkedInstAddrPK id) {
		this.id = id;
	}

	public BigDecimal getCircuitPoint() {
		return this.circuitPoint;
	}

	public void setCircuitPoint(BigDecimal circuitPoint) {
		this.circuitPoint = circuitPoint;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}
	
	public TSohSubrequest getTSohSubrequest() {
		return this.TSohSubrequest;
	}

	public void setTSohSubrequest(TSohSubrequest TSohSubrequest) {
		this.TSohSubrequest = TSohSubrequest;
	}

}