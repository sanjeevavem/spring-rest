package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import ae.etisalat.cw.jpa.adm.entities.TAdmMstRegion;


/**
 * The persistent class for the T_SOH_REQUEST database table.
 * 
 */
@Entity
@Table(name="T_SOH_REQUEST")
@NamedNativeQueries({
	@NamedNativeQuery(name="TSohRequest.findAll",query="SELECT * FROM T_SOH_REQUEST t where t.DELETION_STATUS='N'",resultClass=TSohRequest.class),
	@NamedNativeQuery(name="TSohRequest.findById",query="SELECT * FROM T_SOH_REQUEST t where t.DELETION_STATUS='N' AND T.REQUEST_ID=:REQUEST_ID",resultClass=TSohRequest.class),
	@NamedNativeQuery(name="TSohRequest.findByIdAndNotInStatus",query="SELECT * FROM T_SOH_REQUEST t where t.DELETION_STATUS='N' AND T.REQUEST_ID=:REQUEST_ID AND STATUS NOT IN :REQSTATUSES ",resultClass=TSohRequest.class)
})
public class TSohRequest implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_SOH_REQUEST_REQUESTID_GENERATOR", sequenceName="SQ_SOH_REQUEST" , allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_SOH_REQUEST_REQUESTID_GENERATOR")
	@Column(name="REQUEST_ID")
	private long requestId;

	@Column(name="AUTO_REQUEST_FLAG")
	private String autoRequestFlag;

	@Temporal(TemporalType.DATE)
	@Column(name="CANCELLATION_DATE")
	private Date cancellationDate;

	@Column(name="CHANNEL_PARTNER_ID")
	private BigDecimal channelPartnerId;

	@Temporal(TemporalType.DATE)
	@Column(name="CLOSED_DATE")
	private Date closedDate;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Temporal(TemporalType.DATE)
	@Column(name="DISPATCH_DATE")
	private Date dispatchDate;

	@Column(name="DISPATCH_MEDIA")
	private BigDecimal dispatchMedia;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="NOTES")
	private String notes;

	@Column(name="ORGANIZATION_UNIT_ID")
	private BigDecimal organizationUnitId;

	@Column(name="PARTY_GROUP_ID")
	private BigDecimal partyGroupId;

	@Column(name="PARTY_ID")
	private BigDecimal partyId;

	@Column(name="PARTY_PROFILE_ID")
	private BigDecimal partyProfileId;

	@Column(name="PHYSICAL_ORGUNIT_ID")
	private BigDecimal physicalOrgunitId;

	@Column(name="REQUEST_TYPE_ID")
	private BigDecimal requestTypeId;

	@Column(name="SERVING_PRIORITY")
	private BigDecimal servingPriority;

	@Column(name="SUBSCRIPTION_ID")
	private BigDecimal subscriptionId;

	@Column(name="TRANSFER_FLAG")
	private String transferFlag;

	//bi-directional many-to-one association to TAdmMstRegion
	@ManyToOne
	@JoinColumn(name="REGD_REGION_ID")
	private TAdmMstRegion TAdmMstRegion;

	//bi-directional many-to-one association to TSohAccount
	@ManyToOne
	@JoinColumn(name="ACCOUNT_FOR_PREPMT")
	private TSohAccount TSohAccount1;

	//bi-directional many-to-one association to TSohAccount
	@ManyToOne
	@JoinColumn(name="DEFAULT_TO_ACCOUNT")
	private TSohAccount TSohAccount2;

	//bi-directional many-to-one association to TSohDtlSystemCodeValue
	@ManyToOne
	@JoinColumn(name="CHANNEL_ID")
	private TSohDtlSystemCodeValue TSohDtlSystemCodeValue1;

	//bi-directional many-to-one association to TSohDtlSystemCodeValue
	@ManyToOne
	@JoinColumn(name="REASON_ID")
	private TSohDtlSystemCodeValue TSohDtlSystemCodeValue2;

	//bi-directional many-to-one association to TSohDtlSystemCodeValue
	@ManyToOne
	@JoinColumn(name="STATUS")
	private TSohDtlSystemCodeValue TSohDtlSystemCodeValue3;

	//bi-directional many-to-one association to TSohRequirement
	@OneToMany(mappedBy="TSohRequest")
	private List<TSohRequirement> TSohRequirements;

	//bi-directional many-to-one association to TSohSubrequest
	@OneToMany(mappedBy="TSohRequest", cascade = {CascadeType.MERGE, CascadeType.PERSIST},fetch=FetchType.EAGER)
	private List<TSohSubrequest> TSohSubrequests;

	public TSohRequest() {
	}

	public long getRequestId() {
		return this.requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public String getAutoRequestFlag() {
		return this.autoRequestFlag;
	}

	public void setAutoRequestFlag(String autoRequestFlag) {
		this.autoRequestFlag = autoRequestFlag;
	}

	public Date getCancellationDate() {
		return this.cancellationDate;
	}

	public void setCancellationDate(Date cancellationDate) {
		this.cancellationDate = cancellationDate;
	}

	public BigDecimal getChannelPartnerId() {
		return this.channelPartnerId;
	}

	public void setChannelPartnerId(BigDecimal channelPartnerId) {
		this.channelPartnerId = channelPartnerId;
	}

	public Date getClosedDate() {
		return this.closedDate;
	}

	public void setClosedDate(Date closedDate) {
		this.closedDate = closedDate;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Date getDispatchDate() {
		return this.dispatchDate;
	}

	public void setDispatchDate(Date dispatchDate) {
		this.dispatchDate = dispatchDate;
	}

	public BigDecimal getDispatchMedia() {
		return this.dispatchMedia;
	}

	public void setDispatchMedia(BigDecimal dispatchMedia) {
		this.dispatchMedia = dispatchMedia;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getNotes() {
		return this.notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public BigDecimal getOrganizationUnitId() {
		return this.organizationUnitId;
	}

	public void setOrganizationUnitId(BigDecimal organizationUnitId) {
		this.organizationUnitId = organizationUnitId;
	}

	public BigDecimal getPartyGroupId() {
		return this.partyGroupId;
	}

	public void setPartyGroupId(BigDecimal partyGroupId) {
		this.partyGroupId = partyGroupId;
	}

	public BigDecimal getPartyId() {
		return this.partyId;
	}

	public void setPartyId(BigDecimal partyId) {
		this.partyId = partyId;
	}

	public BigDecimal getPartyProfileId() {
		return this.partyProfileId;
	}

	public void setPartyProfileId(BigDecimal partyProfileId) {
		this.partyProfileId = partyProfileId;
	}

	public BigDecimal getPhysicalOrgunitId() {
		return this.physicalOrgunitId;
	}

	public void setPhysicalOrgunitId(BigDecimal physicalOrgunitId) {
		this.physicalOrgunitId = physicalOrgunitId;
	}

	public BigDecimal getRequestTypeId() {
		return this.requestTypeId;
	}

	public void setRequestTypeId(BigDecimal requestTypeId) {
		this.requestTypeId = requestTypeId;
	}

	public BigDecimal getServingPriority() {
		return this.servingPriority;
	}

	public void setServingPriority(BigDecimal servingPriority) {
		this.servingPriority = servingPriority;
	}

	public BigDecimal getSubscriptionId() {
		return this.subscriptionId;
	}

	public void setSubscriptionId(BigDecimal subscriptionId) {
		this.subscriptionId = subscriptionId;
	}

	public String getTransferFlag() {
		return this.transferFlag;
	}

	public void setTransferFlag(String transferFlag) {
		this.transferFlag = transferFlag;
	}

	public TAdmMstRegion getTAdmMstRegion() {
		return this.TAdmMstRegion;
	}

	public void setTAdmMstRegion(TAdmMstRegion TAdmMstRegion) {
		this.TAdmMstRegion = TAdmMstRegion;
	}

	public TSohAccount getTSohAccount1() {
		return this.TSohAccount1;
	}

	public void setTSohAccount1(TSohAccount TSohAccount1) {
		this.TSohAccount1 = TSohAccount1;
	}

	public TSohAccount getTSohAccount2() {
		return this.TSohAccount2;
	}

	public void setTSohAccount2(TSohAccount TSohAccount2) {
		this.TSohAccount2 = TSohAccount2;
	}

	public TSohDtlSystemCodeValue getTSohDtlSystemCodeValue1() {
		return this.TSohDtlSystemCodeValue1;
	}

	public void setTSohDtlSystemCodeValue1(TSohDtlSystemCodeValue TSohDtlSystemCodeValue1) {
		this.TSohDtlSystemCodeValue1 = TSohDtlSystemCodeValue1;
	}

	public TSohDtlSystemCodeValue getTSohDtlSystemCodeValue2() {
		return this.TSohDtlSystemCodeValue2;
	}

	public void setTSohDtlSystemCodeValue2(TSohDtlSystemCodeValue TSohDtlSystemCodeValue2) {
		this.TSohDtlSystemCodeValue2 = TSohDtlSystemCodeValue2;
	}

	public TSohDtlSystemCodeValue getTSohDtlSystemCodeValue3() {
		return this.TSohDtlSystemCodeValue3;
	}

	public void setTSohDtlSystemCodeValue3(TSohDtlSystemCodeValue TSohDtlSystemCodeValue3) {
		this.TSohDtlSystemCodeValue3 = TSohDtlSystemCodeValue3;
	}

	public List<TSohRequirement> getTSohRequirements() {
		return this.TSohRequirements;
	}

	public void setTSohRequirements(List<TSohRequirement> TSohRequirements) {
		this.TSohRequirements = TSohRequirements;
	}

	public TSohRequirement addTSohRequirement(TSohRequirement TSohRequirement) {
		getTSohRequirements().add(TSohRequirement);
		TSohRequirement.setTSohRequest(this);

		return TSohRequirement;
	}

	public TSohRequirement removeTSohRequirement(TSohRequirement TSohRequirement) {
		getTSohRequirements().remove(TSohRequirement);
		TSohRequirement.setTSohRequest(null);

		return TSohRequirement;
	}

	public List<TSohSubrequest> getTSohSubrequests() {
		return this.TSohSubrequests;
	}

	public void setTSohSubrequests(List<TSohSubrequest> TSohSubrequests) {
		this.TSohSubrequests = TSohSubrequests;
	}

	public TSohSubrequest addTSohSubrequest(TSohSubrequest TSohSubrequest) {
		getTSohSubrequests().add(TSohSubrequest);
		TSohSubrequest.setTSohRequest(this);

		return TSohSubrequest;
	}

	public TSohSubrequest removeTSohSubrequest(TSohSubrequest TSohSubrequest) {
		getTSohSubrequests().remove(TSohSubrequest);
		TSohSubrequest.setTSohRequest(null);

		return TSohSubrequest;
	}

}