package ae.etisalat.cw.jpa.soh.daos;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import ae.etisalat.cw.comm.util.Util;
import ae.etisalat.cw.jpa.psm.entities.TBilBillingPeriod;
import ae.etisalat.cw.jpa.psm.entities.TPsmMstOnetmChrgType;
import ae.etisalat.cw.jpa.psm.entities.TPsmOnetimeInflRate;
import ae.etisalat.cw.jpa.psm.entities.TPsmRpOnetimeMap;
import ae.etisalat.cw.jpa.psm.entities.TPsmRpRecurringMap;
import ae.etisalat.cw.jpa.soh.entities.TSohAccount;
import ae.etisalat.cw.jpa.soh.entities.TSohAccountChargeDetail;
import ae.etisalat.cw.jpa.soh.entities.TSohAccountServiceDetail;
import ae.etisalat.cw.jpa.soh.entities.TSohAcctTransactionDetail;
import ae.etisalat.cw.jpa.soh.entities.TSohSrtActionService;

@Repository
@Transactional
public class AccountTransCreationDao {
	
	private static final Logger logger = LogManager.getLogger(AccountTransCreationDao.class);
	
	@PersistenceContext
    private EntityManager em;
	
	public boolean addBillTransaction(TSohAccount tSohAccount,Long accountServiceId,Long billCycleId, Date billCycleStartDate,
			Long chargeTypeId,String createdUserId, Date nextDueDate,Long ratePlanId,String subrequestId,
			BigDecimal transactionAmount, String transactionType,Date transFromDate, Date transToDate, 
			boolean persistAcctChargeDtls, BigDecimal deviceRatePlanId){
		long start = System.currentTimeMillis();
		boolean done = false;
		if (createdUserId == null) {
			createdUserId = "SYSTEM";
		}
		try{
			
			TSohAcctTransactionDetail sohTransactionDetail = new TSohAcctTransactionDetail();
			sohTransactionDetail.setAccountId(new BigDecimal(tSohAccount.getAccountId()));
			TSohAccountServiceDetail tSohAccountServiceDetail = em.find(TSohAccountServiceDetail.class, accountServiceId);
			sohTransactionDetail.setTSohAccountServiceDetail(tSohAccountServiceDetail);
			sohTransactionDetail.setActivationDate(new Timestamp(System.currentTimeMillis()));
			sohTransactionDetail.setBillCycleId(new BigDecimal(billCycleId));
			sohTransactionDetail.setBillCycleStartDate(billCycleStartDate);
			sohTransactionDetail.setChargeTypeId((new BigDecimal(chargeTypeId)));
			sohTransactionDetail.setCreatedDate(new Timestamp(System.currentTimeMillis()));
			sohTransactionDetail.setCreatedUserId(createdUserId);
			sohTransactionDetail.setDeletionStatus("N");
			sohTransactionDetail.setModifiedDate(new Timestamp(System.currentTimeMillis()));
			sohTransactionDetail.setModifiedUserId(createdUserId);
			sohTransactionDetail.setNextDueDate(nextDueDate);
			sohTransactionDetail.setRatePlanId(new BigDecimal(ratePlanId));
			sohTransactionDetail.setSubrequestId(new BigDecimal(subrequestId));
			sohTransactionDetail.setTransactionAmount((transactionAmount));
			sohTransactionDetail.setTransactionDate(new Timestamp(System.currentTimeMillis()));
			sohTransactionDetail.setTransactionType(transactionType);
			sohTransactionDetail.setTransFromDate(transFromDate);
			sohTransactionDetail.setTransToDate(transToDate);
			sohTransactionDetail.setDeviceContractRp(deviceRatePlanId);
			em.persist(sohTransactionDetail);
			logger.info("Succesfully Posted bill for transactionType["+transactionType+"] transactionAmount["+transactionAmount+"] for the subscription of ["+ratePlanId+"] done for accountId["+tSohAccount.getAccountId()+"] in ["+(System.currentTimeMillis()-start)+"]milliseconds");
			done = true;
			if (persistAcctChargeDtls) {
				done = persistAcctChargeDtls(sohTransactionDetail, transactionType,tSohAccount);
			}
		}catch(Exception e){
			logger.error("Failed to post bill for accountId:[" + tSohAccount.getAccountId() + "] transactionType[" + transactionType
					+ "] transactionAmount[" + transactionAmount + "] for the subscription of [" + ratePlanId + "]", e);
		}
		return done;
	}
	
	public boolean persistAcctChargeDtls(TSohAcctTransactionDetail acctTransactionDetail, String transactionType,TSohAccount tSohAccount) {
		boolean persisted = false;
		if (acctTransactionDetail == null) {
			return persisted;
		}
		try {
			logger.debug("Persisting Account charge details.");
			TSohAccountChargeDetail acctChargeDtl = accountChargeDtl(acctTransactionDetail, transactionType,tSohAccount);
			em.persist(acctChargeDtl);
			persisted = true;
			logger.debug("Persisted account charge details successfully.");
		} catch (Exception e) {
			logger.error("Error in updating Account Web TV details.", e);
		}
		return persisted;
	}
	
	private TSohAccountChargeDetail accountChargeDtl(TSohAcctTransactionDetail acctTransactionDetail, String transactionType,TSohAccount tSohAccount) {
		
		TSohAccountChargeDetail acctChargeDtl = new TSohAccountChargeDetail();
		if (tSohAccount != null) {
			acctChargeDtl.setAccountId(BigDecimal.valueOf(tSohAccount.getAccountId()));
			acctChargeDtl.setTSohAccountServiceDetail(acctTransactionDetail.getTSohAccountServiceDetail());
		}
		Date transToDate = acctTransactionDetail.getTransToDate();
		if (transToDate != null) {
			acctChargeDtl.setBilledUpToDate(new Timestamp(transToDate.getTime()));
		}
		acctChargeDtl.setChargeTypeFlag(transactionType);
		acctChargeDtl.setChargeTypeId(acctTransactionDetail.getChargeTypeId());
		acctChargeDtl.setCreatedDate(new Timestamp(new Date().getTime()));
		acctChargeDtl.setCreatedUserId("SYSTEM");
		acctChargeDtl.setDeletionStatus("N");
		acctChargeDtl.setModifiedDate(new Timestamp(new Date().getTime()));
		acctChargeDtl.setModifiedUserId("SYSTEM");
		acctChargeDtl.setNumberOfInstallments(BigDecimal.valueOf(0));
		acctChargeDtl.setOffsetDate(null);
		acctChargeDtl.setPresetDate(null);
		acctChargeDtl.setRatePlanId(acctTransactionDetail.getRatePlanId());
		return acctChargeDtl;
	}
	
	 public TBilBillingPeriod getCurrentBillPeriod(Long billCycleId){
	    	long start = System.currentTimeMillis();
	    	TBilBillingPeriod tBilBillingPeriod =null;
	    	try{
	    		Query getCurrentBillPeriodQuery = em.createQuery("select a from TBilBillingPeriod a " 
								+ "where a.billingCycleId = :billingCycleId  and a.status='0'  ");
				logger.debug(getCurrentBillPeriodQuery.toString() + " Parameters are billCycleId:" + billCycleId);				
				getCurrentBillPeriodQuery.setParameter("billingCycleId", billCycleId);
				tBilBillingPeriod= getFirstObjectFromList(getCurrentBillPeriodQuery.getResultList());				
				logger.debug("tBilBillingPeriod is " + tBilBillingPeriod);
				logger.info("tBilBillingPeriod fetched in " + (System.currentTimeMillis() - start) + " milliseconds");

	    	}catch(Exception e){
	    		logger.error("Failed to get the billing period.",e);
	    	}
	    	return tBilBillingPeriod;
	    }
	 
	 public TPsmRpOnetimeMap getOneTimeCharges(Long ratePlanId) {
	        long start = System.currentTimeMillis();
	        TPsmRpOnetimeMap tPsmRpOnetimeMap = null;
	        try {
	            Query getOneTimeChargesQuery = em.createQuery("select a from TPsmRpOnetimeMap a "
	                + "where a.deletionStatus='N' and a.TPsmMstRatePlan.effectiveTillDate = null and  a.TPsmMstRatePlan.id.ratePlanId=:ratePlanId ");

	            logger.debug(getOneTimeChargesQuery.toString() + " Parameters are TPsmMstRatePlan.id.ratePlanId:" + ratePlanId);

	            getOneTimeChargesQuery.setParameter("ratePlanId", ratePlanId);
	            tPsmRpOnetimeMap = getFirstObjectFromList(getOneTimeChargesQuery.getResultList());
	            logger.debug("tPsmRpOnetimeMap is " + tPsmRpOnetimeMap);
	            logger.info("tPsmRpOnetimeMap fetched in " + (System.currentTimeMillis() - start) + " milliseconds");

	        }
	        catch (Exception e) {
	            logger.error("Failed to get the OneTimeCharges.", e);
	        }
	        return tPsmRpOnetimeMap;
	    }
	 
	 @SuppressWarnings("unchecked")
	public List<TPsmOnetimeInflRate> getInfluenceRate(Long onetimeChargeTypeId, String queryField, Long subTypeId) {
			long start = System.currentTimeMillis();
			List<TPsmOnetimeInflRate> tPsmOnetimeInflRateList = null;

			try {
				Query getDiscountChargesQuery = em.createQuery("select a from TPsmOnetimeInflRate a " + "where "
						+ "a.effectiveFromDate < CURRENT_TIMESTAMP and a.onetimeChargeTypeId=:onetimeChargeTypeId "
						+ "and a." + queryField + "=:subTypeId");
				getDiscountChargesQuery.setParameter("onetimeChargeTypeId", onetimeChargeTypeId);
				getDiscountChargesQuery.setParameter(queryField, subTypeId);
				tPsmOnetimeInflRateList =  getDiscountChargesQuery.getResultList();
				logger.debug("tPsmOnetimeInflRateList is " + tPsmOnetimeInflRateList);
				logger.info("tPsmRpOnetimeMap fetched in " + (System.currentTimeMillis() - start) + " milliseconds");
			} catch (Exception e) {
				logger.error("Exception", e);
			} finally {
			}
			return tPsmOnetimeInflRateList;
		}
	 
	 @SuppressWarnings("unchecked")
	public TPsmRpRecurringMap getRecurringCharges(long ratePlanId){
	    	long start = System.currentTimeMillis();
	    	List<TPsmRpRecurringMap> tPsmRpRecurringMap =null;
	    	try{
	    		Query getRecurringChargesQuery = em
						.createQuery("select a from TPsmRpRecurringMap a " 
								+ "where a.deletionStatus='N' and a.TPsmMstRatePlan.effectiveTillDate = null and  a.TPsmMstRatePlan.id.ratePlanId=:ratePlanId");
				
				
				logger.debug(getRecurringChargesQuery.toString() + " Parameters are TPsmMstRatePlan.id.ratePlanId:" + ratePlanId);
				
				getRecurringChargesQuery.setParameter("ratePlanId", ratePlanId);
				tPsmRpRecurringMap=  getRecurringChargesQuery.getResultList();
				
				logger.debug("tPsmRpRecurringMap is " + tPsmRpRecurringMap);
				
				if (tPsmRpRecurringMap != null && tPsmRpRecurringMap.size()>0) {
					logger.debug("tPsmRpRecurringMap SIZE :: " + tPsmRpRecurringMap.size());
					
					if(tPsmRpRecurringMap.size()==1) {
						return tPsmRpRecurringMap.get(0);
					} else {
						 Collections.sort(tPsmRpRecurringMap, new Comparator<TPsmRpRecurringMap>() {
							 public int compare(TPsmRpRecurringMap tPsmRpRecurringMapOne, TPsmRpRecurringMap tPsmRpRecurringMapanother) {
					                return String.valueOf(tPsmRpRecurringMapOne.getTPsmMstRecurrChrgType().getPresetPeriod()).compareToIgnoreCase(String.valueOf(tPsmRpRecurringMapanother.getTPsmMstRecurrChrgType().getPresetPeriod()));
					            }
					        });
					}				
					return tPsmRpRecurringMap.get(tPsmRpRecurringMap.size()-1);
				}
				logger.info("tPsmRpRecurringMap fetched in " + (System.currentTimeMillis() - start) + " milliseconds");

	    	}catch(Exception e){
	    		logger.error("Failed to get the Recurring Charges.",e);
	    	}
	    	return null;
	    }
	 
	 @SuppressWarnings({ "unchecked", "rawtypes" })
	public static <T> T getFirstObjectFromList(List list){
	        if(list != null && !list.isEmpty()){
	        	return (T) list.get(0);
	        }
			return null;
		}
	 
	 public TSohSrtActionService getOneTimeChrgTypeBySrtMiscChrgId(BigDecimal srtMiscChargeId){	        
	        long start = System.currentTimeMillis();
	        TSohSrtActionService srtActionService = null;	        
	        try{    
	            logger.debug("srtMiscChargeId is ["+srtMiscChargeId+"]");
	            TypedQuery<TSohSrtActionService> query=em.createQuery("select a from TSohSrtActionService a where a.srtSrvActionId = :srtSrvActionId",TSohSrtActionService.class);
	            query.setParameter("srtSrvActionId", srtMiscChargeId);
	            logger.debug("query is ["+query.toString()+"] and parameters is srtMiscChargeId = ["+srtMiscChargeId+"]");
	            query.setMaxResults(1);
	            List<TSohSrtActionService> resultList =  query.getResultList();
	            if(Util.isValidateCollection(resultList)){
	            	srtActionService = (TSohSrtActionService) resultList.get(0);
	            }
	        } catch (Exception e) {
	            logger.error("Execption in getOneTimeChrgTypeBySrtMiscChrgId: "+e.getMessage());
	        } finally {
	            logger.info("getOneTimeChrgTypeBySrtMiscChrgId done in "+ (System.currentTimeMillis() - start) + " milliseconds");
	        }
	        return srtActionService;
	    }
	 
	 public TPsmMstOnetmChrgType getOneTimeRate(long onetimeChargeTypeId) {
			long start = System.currentTimeMillis();
			TPsmMstOnetmChrgType tPsmMstOnetmChrgType = null;
			try {
				Query getOneTimeChargesQuery = em.createQuery("select a from TPsmMstOnetmChrgType a where a.deletionStatus='N' and "
				    + "(a.effectiveTillDate IS NULL or a.effectiveTillDate > CURRENT_TIMESTAMP) and  a.id.onetimeChargeTypeId=:onetimeChargeTypeId ");
				logger.debug(getOneTimeChargesQuery.toString() + " Parameters are onetimeChargeTypeId:" + onetimeChargeTypeId);
				getOneTimeChargesQuery.setParameter("onetimeChargeTypeId", onetimeChargeTypeId);
				tPsmMstOnetmChrgType = Util.getFirstObjectFromList(getOneTimeChargesQuery.getResultList());
				logger.debug("TPsmMstOnetmChrgType is " + tPsmMstOnetmChrgType);
				if (tPsmMstOnetmChrgType != null)			
					return tPsmMstOnetmChrgType;
				else
					logger.error("Failed to get the OneTimeCharges.");
				logger.info("tPsmRpOnetimeMap fetched in " + (System.currentTimeMillis() - start) + " milliseconds");
			} catch (Exception e) {
				logger.error("Failed to get the OneTimeCharges.", e);
			}
			return null;
		}
}
