package ae.etisalat.cw.jpa.psm.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the T_PSM_MST_PACKAGE database table.
 * 
 */
@Embeddable
public class TPsmMstPackagePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="PACKAGE_ID")
	private long packageId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="EFFECTIVE_FROM_DATE")
	private java.util.Date effectiveFromDate;

	public TPsmMstPackagePK() {
	}
	public long getPackageId() {
		return this.packageId;
	}
	public void setPackageId(long packageId) {
		this.packageId = packageId;
	}
	public java.util.Date getEffectiveFromDate() {
		return this.effectiveFromDate;
	}
	public void setEffectiveFromDate(java.util.Date effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TPsmMstPackagePK)) {
			return false;
		}
		TPsmMstPackagePK castOther = (TPsmMstPackagePK)other;
		return 
			(this.packageId == castOther.packageId)
			&& this.effectiveFromDate.equals(castOther.effectiveFromDate);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.packageId ^ (this.packageId >>> 32)));
		hash = hash * prime + this.effectiveFromDate.hashCode();
		
		return hash;
	}
}