package ae.etisalat.cw.jpa.cms.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the T_CMS_DTL_PARTY_CONTACT database table.
 * 
 */
@Entity
@Table(name="T_CMS_DTL_PARTY_CONTACT")
@NamedQuery(name="TCmsDtlPartyContact.findAll", query="SELECT t FROM TCmsDtlPartyContact t")
public class TCmsDtlPartyContact implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_CMS_DTL_PARTY_CONTACT_CONTACTID_GENERATOR", sequenceName="SQ_CMS_CONTACT")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_CMS_DTL_PARTY_CONTACT_CONTACTID_GENERATOR")
	@Column(name="CONTACT_ID")
	private long contactId;

	@Column(name="CONTACT_PERSON")
	private String contactPerson;

	@Column(name="CONTACT_TYPE_ID")
	private BigDecimal contactTypeId;

	@Column(name="CONTACT_VALUE")
	private String contactValue;

	@Temporal(TemporalType.DATE)
	@Column(name="CREATED_DATE")
	private Date createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	private String designation;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_FROM")
	private Date effectiveFrom;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_TILL")
	private Date effectiveTill;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="PARTY_ID")
	private BigDecimal partyId;

	@Column(name="PREFERRED_LANGUAGE")
	private BigDecimal preferredLanguage;

	private BigDecimal priority;

	@Column(name="PROFILE_ID")
	private BigDecimal profileId;

	@Column(name="SPOC_PARTY_ID")
	private BigDecimal spocPartyId;

	private BigDecimal telemarketing;
	
	@Transient
	private String action;

	public TCmsDtlPartyContact() {
	}

	public long getContactId() {
		return this.contactId;
	}

	public void setContactId(long contactId) {
		this.contactId = contactId;
	}

	public String getContactPerson() {
		return this.contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public BigDecimal getContactTypeId() {
		return this.contactTypeId;
	}

	public void setContactTypeId(BigDecimal contactTypeId) {
		this.contactTypeId = contactTypeId;
	}

	public String getContactValue() {
		return this.contactValue;
	}

	public void setContactValue(String contactValue) {
		this.contactValue = contactValue;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public String getDesignation() {
		return this.designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Date getEffectiveFrom() {
		return this.effectiveFrom;
	}

	public void setEffectiveFrom(Date effectiveFrom) {
		this.effectiveFrom = effectiveFrom;
	}

	public Date getEffectiveTill() {
		return this.effectiveTill;
	}

	public void setEffectiveTill(Date effectiveTill) {
		this.effectiveTill = effectiveTill;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getPartyId() {
		return this.partyId;
	}

	public void setPartyId(BigDecimal partyId) {
		this.partyId = partyId;
	}

	public BigDecimal getPreferredLanguage() {
		return this.preferredLanguage;
	}

	public void setPreferredLanguage(BigDecimal preferredLanguage) {
		this.preferredLanguage = preferredLanguage;
	}

	public BigDecimal getPriority() {
		return this.priority;
	}

	public void setPriority(BigDecimal priority) {
		this.priority = priority;
	}

	public BigDecimal getProfileId() {
		return this.profileId;
	}

	public void setProfileId(BigDecimal profileId) {
		this.profileId = profileId;
	}

	public BigDecimal getSpocPartyId() {
		return this.spocPartyId;
	}

	public void setSpocPartyId(BigDecimal spocPartyId) {
		this.spocPartyId = spocPartyId;
	}

	public BigDecimal getTelemarketing() {
		return this.telemarketing;
	}

	public void setTelemarketing(BigDecimal telemarketing) {
		this.telemarketing = telemarketing;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

}