package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;

import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


/**
 * The persistent class for the T_SOH_SUBREQ_SERVICE_DETAILS database table.
 * 
 */
@Entity
@Table(name="T_SOH_SUBREQ_SERVICE_DETAILS")
@NamedQueries({
	@NamedQuery(name="TSohSubreqServiceDetail.findAll", query="SELECT t FROM TSohSubreqServiceDetail t"),
	@NamedQuery(name="TSohSubreqServiceDetail.findByPartyIdAndReqStatusAndPackageId", query="SELECT t FROM TSohSubreqServiceDetail t WHERE t.TSohSubrequest.TSohRequest.partyId=:partyId and t.TSohSubrequest.TSohRequest.TSohDtlSystemCodeValue3.systemCodeValueId not in :reqStatuses and t.packageId in :packageIds and t.deletionStatus=:deletionStatus and t.TSohSubrequest.TSohRequest.deletionStatus=:deletionStatus and t.TSohSubrequest.deletionStatus=:deletionStatus")	
})

public class TSohSubreqServiceDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="SQ_SOH_SUBREQ_SERVICE_ID", sequenceName="SQ_SOH_SUBREQ_SERVICE_ID", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SQ_SOH_SUBREQ_SERVICE_ID")
	@Column(name="SUBREQ_SERV_ID")
	private long subreqServId;

	@Column(name="ACCOUNT_SERVICE_ID")
	private BigDecimal accountServiceId;

	@Column(name="ASSOCIATION_LEVEL")
	private BigDecimal associationLevel;

	@Column(name="BUNDLE_ID")
	private BigDecimal bundleId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="DEPENDENT_SERVICE")
	private BigDecimal dependentService;

	@Column(name="DEPOSIT_AFTER_WAIVER")
	private BigDecimal depositAfterWaiver;

	@Column(name="DEPOSIT_AMT")
	private BigDecimal depositAmt;

	@Column(name="DEPOSIT_PAID")
	private BigDecimal depositPaid;

	@Column(name="DEPOSIT_POLICY")
	private BigDecimal depositPolicy;

	@Column(name="IS_PRIMARY_SERVICE_FLAG")
	private String isPrimaryServiceFlag;

	@Column(name="MDI_REPLY_RECEIVED")
	private String mdiReplyReceived;

	@Column(name="MDI_REPLY_STATUS")
	private BigDecimal mdiReplyStatus;

	@Column(name="MDI_REPLY_UPDATED")
	private BigDecimal mdiReplyUpdated;

	@Column(name="MISC_CHARGE_TYPE")
	private BigDecimal miscChargeType;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="NO_OF_INSTANCES")
	private BigDecimal noOfInstances;

	@Column(name="OLD_BUNDLE_ID")
	private BigDecimal oldBundleId;

	@Column(name="OLD_PACKAGE_ID")
	private BigDecimal oldPackageId;

	@Column(name="OLD_RATE_PLAN_ID")
	private BigDecimal oldRatePlanId;

	@Column(name="PACKAGE_ID")
	private BigDecimal packageId;

	@Column(name="PREPAYMENT_AMT")
	private BigDecimal prepaymentAmt;

	@Column(name="PREPAYMENT_OVERRIDE")
	private String prepaymentOverride;

	@Column(name="PREPAYMENT_PAID")
	private BigDecimal prepaymentPaid;

	@Column(name="RATE_PLAN_ID")
	private BigDecimal ratePlanId;

	@Column(name="RETAILER_ID")
	private BigDecimal retailerId;

	@Column(name="SERVICE_ID")
	private BigDecimal serviceId;

	@Column(name="SERVICE_STATUS_DATE")
	private Timestamp serviceStatusDate;

	@Column(name="SUBREQ_SERVICE_PRIORITY")
	private BigDecimal subreqServicePriority;

	//bi-directional many-to-one association to TSohSubreqInstanceDetail
	@OneToMany(mappedBy="TSohSubreqServiceDetail", cascade = {CascadeType.MERGE, CascadeType.PERSIST})
	private List<TSohSubreqInstanceDetail> TSohSubreqInstanceDetails = new ArrayList<TSohSubreqInstanceDetail>();

	//bi-directional many-to-one association to TSohAccount
	@ManyToOne
	@JoinColumn(name="ASSOCIATED_ACCOUNT_ID")
	private TSohAccount TSohAccount1;

	//bi-directional many-to-one association to TSohAccount
	@ManyToOne
	@JoinColumn(name="ACCOUNT_FOR_PRE_PMNT")
	private TSohAccount TSohAccount2;

	//bi-directional many-to-one association to TSohDtlSystemCodeValue
	@ManyToOne
	@JoinColumn(name="REASON_ID")
	private TSohDtlSystemCodeValue TSohDtlSystemCodeValue1;

	//bi-directional many-to-one association to TSohDtlSystemCodeValue
	@ManyToOne
	@JoinColumn(name="STATUS")
	private TSohDtlSystemCodeValue TSohDtlSystemCodeValue2;

	//bi-directional many-to-one association to TSohRequirement
	@ManyToOne
	@JoinColumn(name="REQUIREMENT_ID")
	private TSohRequirement TSohRequirement;

	//bi-directional many-to-one association to TSohSubrequest
	@ManyToOne(cascade = {CascadeType.MERGE, CascadeType.PERSIST})
	@JoinColumn(name="SUBREQUEST_ID")
	private TSohSubrequest TSohSubrequest;

	//bi-directional many-to-one association to TSohSubreqServiceDetail
	@ManyToOne
	@JoinColumn(name="ASSOCIATED_SUBREQ_SERV_ID")
	private TSohSubreqServiceDetail TSohSubreqServiceDetail;

	//bi-directional many-to-one association to TSohSubreqServiceDetail
	@OneToMany(mappedBy="TSohSubreqServiceDetail")
	private List<TSohSubreqServiceDetail> TSohSubreqServiceDetails;
	
	//bi-directional many-to-one association to TSohSubreqServiceTaxDtl
	@OneToMany(mappedBy="TSohSubreqServiceDetail")
	private List<TSohSubreqServiceTaxDtl> TSohSubreqServiceTaxDtls;
		
	public TSohSubreqServiceDetail() {
	}

	public long getSubreqServId() {
		return this.subreqServId;
	}

	public void setSubreqServId(long subreqServId) {
		this.subreqServId = subreqServId;
	}

	public BigDecimal getAccountServiceId() {
		return this.accountServiceId;
	}

	public void setAccountServiceId(BigDecimal accountServiceId) {
		this.accountServiceId = accountServiceId;
	}

	public BigDecimal getAssociationLevel() {
		return this.associationLevel;
	}

	public void setAssociationLevel(BigDecimal associationLevel) {
		this.associationLevel = associationLevel;
	}

	public BigDecimal getBundleId() {
		return this.bundleId;
	}

	public void setBundleId(BigDecimal bundleId) {
		this.bundleId = bundleId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public BigDecimal getDependentService() {
		return this.dependentService;
	}

	public void setDependentService(BigDecimal dependentService) {
		this.dependentService = dependentService;
	}

	public BigDecimal getDepositAfterWaiver() {
		return this.depositAfterWaiver;
	}

	public void setDepositAfterWaiver(BigDecimal depositAfterWaiver) {
		this.depositAfterWaiver = depositAfterWaiver;
	}

	public BigDecimal getDepositAmt() {
		return this.depositAmt;
	}

	public void setDepositAmt(BigDecimal depositAmt) {
		this.depositAmt = depositAmt;
	}

	public BigDecimal getDepositPaid() {
		return this.depositPaid;
	}

	public void setDepositPaid(BigDecimal depositPaid) {
		this.depositPaid = depositPaid;
	}

	public BigDecimal getDepositPolicy() {
		return this.depositPolicy;
	}

	public void setDepositPolicy(BigDecimal depositPolicy) {
		this.depositPolicy = depositPolicy;
	}

	public String getIsPrimaryServiceFlag() {
		return this.isPrimaryServiceFlag;
	}

	public void setIsPrimaryServiceFlag(String isPrimaryServiceFlag) {
		this.isPrimaryServiceFlag = isPrimaryServiceFlag;
	}

	public String getMdiReplyReceived() {
		return this.mdiReplyReceived;
	}

	public void setMdiReplyReceived(String mdiReplyReceived) {
		this.mdiReplyReceived = mdiReplyReceived;
	}

	public BigDecimal getMdiReplyStatus() {
		return this.mdiReplyStatus;
	}

	public void setMdiReplyStatus(BigDecimal mdiReplyStatus) {
		this.mdiReplyStatus = mdiReplyStatus;
	}

	public BigDecimal getMdiReplyUpdated() {
		return this.mdiReplyUpdated;
	}

	public void setMdiReplyUpdated(BigDecimal mdiReplyUpdated) {
		this.mdiReplyUpdated = mdiReplyUpdated;
	}

	public BigDecimal getMiscChargeType() {
		return this.miscChargeType;
	}

	public void setMiscChargeType(BigDecimal miscChargeType) {
		this.miscChargeType = miscChargeType;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getNoOfInstances() {
		return this.noOfInstances;
	}

	public void setNoOfInstances(BigDecimal noOfInstances) {
		this.noOfInstances = noOfInstances;
	}

	public BigDecimal getOldBundleId() {
		return this.oldBundleId;
	}

	public void setOldBundleId(BigDecimal oldBundleId) {
		this.oldBundleId = oldBundleId;
	}

	public BigDecimal getOldPackageId() {
		return this.oldPackageId;
	}

	public void setOldPackageId(BigDecimal oldPackageId) {
		this.oldPackageId = oldPackageId;
	}

	public BigDecimal getOldRatePlanId() {
		return this.oldRatePlanId;
	}

	public void setOldRatePlanId(BigDecimal oldRatePlanId) {
		this.oldRatePlanId = oldRatePlanId;
	}

	public BigDecimal getPackageId() {
		return this.packageId;
	}

	public void setPackageId(BigDecimal packageId) {
		this.packageId = packageId;
	}

	public BigDecimal getPrepaymentAmt() {
		return this.prepaymentAmt;
	}

	public void setPrepaymentAmt(BigDecimal prepaymentAmt) {
		this.prepaymentAmt = prepaymentAmt;
	}

	public String getPrepaymentOverride() {
		return this.prepaymentOverride;
	}

	public void setPrepaymentOverride(String prepaymentOverride) {
		this.prepaymentOverride = prepaymentOverride;
	}

	public BigDecimal getPrepaymentPaid() {
		return this.prepaymentPaid;
	}

	public void setPrepaymentPaid(BigDecimal prepaymentPaid) {
		this.prepaymentPaid = prepaymentPaid;
	}

	public BigDecimal getRatePlanId() {
		return this.ratePlanId;
	}

	public void setRatePlanId(BigDecimal ratePlanId) {
		this.ratePlanId = ratePlanId;
	}

	public BigDecimal getRetailerId() {
		return this.retailerId;
	}

	public void setRetailerId(BigDecimal retailerId) {
		this.retailerId = retailerId;
	}

	public BigDecimal getServiceId() {
		return this.serviceId;
	}

	public void setServiceId(BigDecimal serviceId) {
		this.serviceId = serviceId;
	}

	public Timestamp getServiceStatusDate() {
		return this.serviceStatusDate;
	}

	public void setServiceStatusDate(Timestamp serviceStatusDate) {
		this.serviceStatusDate = serviceStatusDate;
	}

	public BigDecimal getSubreqServicePriority() {
		return this.subreqServicePriority;
	}

	public void setSubreqServicePriority(BigDecimal subreqServicePriority) {
		this.subreqServicePriority = subreqServicePriority;
	}

	public List<TSohSubreqInstanceDetail> getTSohSubreqInstanceDetails() {
		return this.TSohSubreqInstanceDetails;
	}

	public void setTSohSubreqInstanceDetails(List<TSohSubreqInstanceDetail> TSohSubreqInstanceDetails) {
		this.TSohSubreqInstanceDetails = TSohSubreqInstanceDetails;
	}


	public TSohAccount getTSohAccount1() {
		return this.TSohAccount1;
	}

	public void setTSohAccount1(TSohAccount TSohAccount1) {
		this.TSohAccount1 = TSohAccount1;
	}

	public TSohAccount getTSohAccount2() {
		return this.TSohAccount2;
	}

	public void setTSohAccount2(TSohAccount TSohAccount2) {
		this.TSohAccount2 = TSohAccount2;
	}

	public TSohDtlSystemCodeValue getTSohDtlSystemCodeValue1() {
		return this.TSohDtlSystemCodeValue1;
	}

	public void setTSohDtlSystemCodeValue1(TSohDtlSystemCodeValue TSohDtlSystemCodeValue1) {
		this.TSohDtlSystemCodeValue1 = TSohDtlSystemCodeValue1;
	}

	public TSohDtlSystemCodeValue getTSohDtlSystemCodeValue2() {
		return this.TSohDtlSystemCodeValue2;
	}

	public void setTSohDtlSystemCodeValue2(TSohDtlSystemCodeValue TSohDtlSystemCodeValue2) {
		this.TSohDtlSystemCodeValue2 = TSohDtlSystemCodeValue2;
	}

	public TSohRequirement getTSohRequirement() {
		return this.TSohRequirement;
	}

	public void setTSohRequirement(TSohRequirement TSohRequirement) {
		this.TSohRequirement = TSohRequirement;
	}

	public TSohSubrequest getTSohSubrequest() {
		return this.TSohSubrequest;
	}

	public void setTSohSubrequest(TSohSubrequest TSohSubrequest) {
		this.TSohSubrequest = TSohSubrequest;
	}

	public TSohSubreqServiceDetail getTSohSubreqServiceDetail() {
		return this.TSohSubreqServiceDetail;
	}

	public void setTSohSubreqServiceDetail(TSohSubreqServiceDetail TSohSubreqServiceDetail) {
		this.TSohSubreqServiceDetail = TSohSubreqServiceDetail;
	}

	public List<TSohSubreqServiceDetail> getTSohSubreqServiceDetails() {
		return this.TSohSubreqServiceDetails;
	}

	public void setTSohSubreqServiceDetails(List<TSohSubreqServiceDetail> TSohSubreqServiceDetails) {
		this.TSohSubreqServiceDetails = TSohSubreqServiceDetails;
	}

	public TSohSubreqServiceDetail addTSohSubreqServiceDetail(TSohSubreqServiceDetail TSohSubreqServiceDetail) {
		getTSohSubreqServiceDetails().add(TSohSubreqServiceDetail);
		TSohSubreqServiceDetail.setTSohSubreqServiceDetail(this);

		return TSohSubreqServiceDetail;
	}

	public TSohSubreqServiceDetail removeTSohSubreqServiceDetail(TSohSubreqServiceDetail TSohSubreqServiceDetail) {
		getTSohSubreqServiceDetails().remove(TSohSubreqServiceDetail);
		TSohSubreqServiceDetail.setTSohSubreqServiceDetail(null);

		return TSohSubreqServiceDetail;
	}

	public List<TSohSubreqServiceTaxDtl> getTSohSubreqServiceTaxDtls() {
		return TSohSubreqServiceTaxDtls;
	}

	public void setTSohSubreqServiceTaxDtls(List<TSohSubreqServiceTaxDtl> tSohSubreqServiceTaxDtls) {
		TSohSubreqServiceTaxDtls = tSohSubreqServiceTaxDtls;
	}

}