package ae.etisalat.cw.jpa.soh.daos;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import ae.etisalat.cw.comm.util.DateUtils;
import ae.etisalat.cw.comm.util.Util;
import ae.etisalat.cw.jpa.adm.entities.TAdmMstCurrency;
import ae.etisalat.cw.jpa.bill.entities.TBilBillingCycle;
import ae.etisalat.cw.jpa.cms.entities.TCmsMstPartySubtype;
import ae.etisalat.cw.jpa.soh.entities.TSohCustRequirement;
import ae.etisalat.cw.jpa.soh.entities.TSohDtlSubreqInvAttrInfo;
import ae.etisalat.cw.jpa.soh.entities.TSohDtlSubreqInvoiceInfo;
import ae.etisalat.cw.jpa.soh.entities.TSohDtlSystemCodeValue;
import ae.etisalat.cw.jpa.soh.entities.TSohMstSubRequestType;
import ae.etisalat.cw.jpa.soh.entities.TSohMstSubreqAccinfo;
import ae.etisalat.cw.jpa.soh.entities.TSohMstSubreqInvoiceInfo;
import ae.etisalat.cw.jpa.soh.entities.TSohRequest;
import ae.etisalat.cw.jpa.soh.entities.TSohRequirement;
import ae.etisalat.cw.jpa.soh.entities.TSohSubreqDqinfo;
import ae.etisalat.cw.jpa.soh.entities.TSohSubreqInstanceDetail;
import ae.etisalat.cw.jpa.soh.entities.TSohSubreqPaymentinfo;
import ae.etisalat.cw.jpa.soh.entities.TSohSubreqServiceDetail;
import ae.etisalat.cw.jpa.soh.entities.TSohSubrequest;
import ae.etisalat.cw.restws.clients.AccountInfo;
import ae.etisalat.cw.restws.clients.DqResellerInfo;
import ae.etisalat.cw.restws.clients.InvoiceDetails;
import ae.etisalat.cw.restws.clients.OfferingDetailsList;
import ae.etisalat.cw.restws.clients.OrderInfo;
import ae.etisalat.cw.restws.clients.PaymentTypeInfo;
import ae.etisalat.cw.restws.clients.PaymentTypeInfoList;

@Repository
@Transactional
public class SubReqCreationDao {
	
	private static final Logger logger = LogManager.getLogger(SubReqCreationDao.class);
	private static final String DD_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
	
	AccountDao acctDao=new AccountDao();
	AccountCreationDao accountCreationDao=new AccountCreationDao();
	AccountServiceCreationDao accountSrvcdao=new AccountServiceCreationDao();
	AccountPaymentInfoDao payDao=new AccountPaymentInfoDao();
	
	@PersistenceContext
    private EntityManager em;
	
	public TSohRequest createRequest(OrderInfo orderInfo,AccountInfo accountInfo) {

		long start = System.currentTimeMillis();
		TSohRequest tSohRequest = null;
		try {
			TSohDtlSystemCodeValue tSohDtlSystemCodeValue = em.find(TSohDtlSystemCodeValue.class, acctDao.getSystemcodeIdByValue("REQUEST_STATUS", "OPEN"));
			tSohRequest = new TSohRequest();
			tSohRequest.setRequestTypeId(BigDecimal.valueOf(accountCreationDao.getSubrequestTypeId(orderInfo.getOrderType())));
			tSohRequest.setPartyId(new BigDecimal(accountInfo.getPartyId()));
			tSohRequest.setPartyProfileId(new BigDecimal(accountInfo.getPartyProfileId()));
			tSohRequest.setTSohDtlSystemCodeValue3(tSohDtlSystemCodeValue);
			tSohRequest.setCreatedDate(new Timestamp(new Date().getTime()));
			tSohRequest.setModifiedDate(new Timestamp(new Date().getTime()));
			tSohRequest.setDeletionStatus("N");
			tSohRequest.setModifiedUserId(orderInfo.getUserId());
			tSohRequest.setCreatedUserId(orderInfo.getUserId());
			/*if(orderInfo.getre!=null && request.getRetailer_id()!=0L)
			tSohRequest.setPhysicalOrgunitId(BigDecimal.valueOf(request.getRetailer_id())); need clarification*/
			TSohDtlSystemCodeValue cbcmChannelCodeValue= em.find(TSohDtlSystemCodeValue.class, acctDao.getSystemcodeIdByValue("CHANNEL_TYPE",orderInfo.getChannel()));
            tSohRequest.setTSohDtlSystemCodeValue1(cbcmChannelCodeValue);
           /* if(null!=request.getRequestNotes() && request.getRequestNotes().isEmpty()==false){
            	tSohRequest.setNotes(request.getRequestNotes());
            }need clarification*/
            em.persist(tSohRequest);
            em.flush();
			logger.info("Request has been inserted within " + (System.currentTimeMillis() - start) + " milliseconds");
			return tSohRequest;
		} catch (Exception e) {
			logger.error("Exception", e);
			e.printStackTrace();
		} finally {
		}
		return null;
	}
	
	public TSohRequirement createRequirement(TSohRequest tSohRequest,OrderInfo orderInfo) {

		long start = System.currentTimeMillis();
		TSohRequirement req = new TSohRequirement();
		try {
			TSohDtlSystemCodeValue tSohDtlSystemCodeValue = em.find(TSohDtlSystemCodeValue.class, acctDao.getSystemcodeIdByValue("REQUIREMENT_STATUS", "Open"));
			TSohMstSubRequestType tSohMstSubRequestType = em.find(TSohMstSubRequestType.class, tSohRequest.getRequestTypeId().longValue());
			req = new TSohRequirement();
			req.setServiceRequiredDate(DateUtils.parseDate(orderInfo.getRecievedTime(), DD_DATE_FORMAT));
			req.setWebRequirementId(BigDecimal.valueOf(-1));
			req.setDeletionStatus("N");
			req.setTSohDtlSystemCodeValue2(tSohDtlSystemCodeValue);
			req.setCreatedDate(new Timestamp(new Date().getTime()));
			req.setModifiedDate(new Timestamp(new Date().getTime()));
			req.setCreatedUserId(orderInfo.getUserId());
			req.setModifiedUserId(orderInfo.getUserId());
			req.setTSohMstSubRequestType(tSohMstSubRequestType);
			req.setTSohRequest(tSohRequest);
			em.persist(req);
			em.flush();
			logger.info("Requirement has been inserted within " + (System.currentTimeMillis() - start) + " milliseconds");
			return req;
		} catch (Exception e) {
			logger.error("Exception", e);
			e.printStackTrace();
		} finally {
		}
		return null;
	}
	
	public TSohSubrequest createSubRequest(TSohRequest tSohRequest, TSohRequirement tSohRequirement, OrderInfo orderInfo,AccountInfo accountInfo) {

		Long start = System.currentTimeMillis();
		TSohSubrequest subReq = new TSohSubrequest();
		try {
			subReq.setAmendmentCount(BigDecimal.valueOf(0));
			subReq.setAmendCancelAg(BigDecimal.valueOf(0));
			subReq.setAccountNumber(accountInfo.getAccountNumber());
			subReq.setPrepaymentAmt(BigDecimal.valueOf(0.0));
			subReq.setProductNumber(new BigDecimal(accountInfo.getProductNumber()));
			if(null != accountInfo.getAccountSuffix())
				subReq.setAccountSuffix(new BigDecimal(accountInfo.getAccountSuffix()));
			subReq.setPrepaymentPaid(BigDecimal.valueOf(0.0));
			subReq.setDepositAmt(BigDecimal.valueOf(0.0));
			subReq.setDepositPaid(BigDecimal.valueOf(0.0));
			subReq.setPriority(BigDecimal.valueOf(1));
			subReq.setServiceRequiredDate(new Timestamp(new Date().getTime()));
			subReq.setCancellationFlag(BigDecimal.valueOf(0));
			subReq.setAddDeleteStatus(BigDecimal.valueOf(0));
			subReq.setDeletionStatus("N");
			subReq.setAreaCode(accountInfo.getAreaCode());
			subReq.setWfAddDeleteStatus(BigDecimal.valueOf(1));
			subReq.setAmendcancelActionTaken(BigDecimal.valueOf(0));
			subReq.setCreatedDate(new Timestamp(new Date().getTime()));
			subReq.setModifiedDate(new Timestamp(new Date().getTime()));
			subReq.setModifiedUserId(orderInfo.getUserId());
			subReq.setCreatedUserId(orderInfo.getUserId());
			subReq.setTSohRequirement(tSohRequirement);
			subReq.setEmirateId(new BigDecimal(acctDao.getEmiratesByCode(orderInfo.getEmirate()).getEmirateId()));
			TSohMstSubRequestType tSohMstSubRequestType = em.find(TSohMstSubRequestType.class, tSohRequest.getRequestTypeId().longValue());
			subReq.setTSohMstSubRequestType(tSohMstSubRequestType);
			subReq.setTAdmMstRegion(acctDao.getRegionByCode(orderInfo.getRegionName()));
			subReq.setTSohRequest(tSohRequest);
			subReq.setProductGroupId(accountCreationDao.getProductGroupIdByCode(orderInfo.getProductGroupCode()));
			subReq.setProductId(accountCreationDao.getProductId(orderInfo.getProductCode()));
			TCmsMstPartySubtype partySUbType=em.find(TCmsMstPartySubtype.class, Long.parseLong(accountInfo.getSubTypeId()));
			subReq.setTCmsMstPartySubtype(partySUbType);
			TSohDtlSystemCodeValue dtlSystemCodeValue = em.find(TSohDtlSystemCodeValue.class, acctDao.getSystemcodeIdByValue("SUB_REQUEST_STATUS", "OPEN"));
			subReq.setTSohDtlSystemCodeValue1(dtlSystemCodeValue);
			logger.info("subRequest has been inserted within " + (System.currentTimeMillis() - start) + " milliseconds");
			em.persist(subReq);
			em.flush();
			insertMstSubreqAttr(subReq.getSubrequestId(), 0, "ORDER_FULFILLMENT_SYSTEM", "CRM_GateWay",orderInfo.getUserId());
			return subReq;
		} catch (Exception e) {
			logger.error("Exception", e);
			e.printStackTrace();
		} finally {
		}
		return null;
	}
	
	public boolean insertMstSubreqAttr(long subrequestId, long accountId, String key, String value, String userId){		
		logger.info("Entering insertMstSubreqAttr with key[",key,"] value[",value,"]");
		boolean inserted = false;
		try{
			String sql = StringUtils.join("insert into T_SOH_MST_SUBREQ_ATTR(SUBREQ_ATTR_ID,SUBREQ_ID,KEY,VALUE,CREATED_DATE,MODIFIED_DATE,CREATED_USER_ID,",
					 "MODIFIED_USER_ID,DELETION_STATUS,ACCOUNT_ID,IFL_SUSBCRIPTION_FLAG) values(SQ_SOH_MST_SUBREQ_ATTR.nextval,?,?,?",
					 ",sysdate,sysdate,?,?,'N',?,'N')");
			Query nativeQuery = em.createNativeQuery(sql);
	        nativeQuery.setParameter(1, subrequestId);
	        nativeQuery.setParameter(2, key);
	        nativeQuery.setParameter(3, value);
	        nativeQuery.setParameter(4, userId);
	        nativeQuery.setParameter(5, userId);
	        nativeQuery.setParameter(6, accountId);

	        int noOfRows = nativeQuery.executeUpdate();
	        if (noOfRows > 0){
	        	inserted = true;
	        }
	        logger.info(" Insert into T_SOH_MST_SUBREQ_ATTR , result[",inserted+"]");
		}catch (Exception e){
			logger.info("Exception while inserting T_SOH_MST_SUBREQ_ATTR");
		}

		return inserted;
	}
	
	public List<PkgRpAcctSrvcInstMapping> createServiceDtls(TSohSubrequest subRequest,TSohRequirement tSohRequirement,TSohRequest request,
			List<OfferingDetailsList> offeringDetailsLists) throws Exception {
		List<PkgRpAcctSrvcInstMapping> rpSrvcMappingList=new ArrayList<>();
		TSohSubreqServiceDetail tSohSubreqServiceDetail=null;
		try{
			rpSrvcMappingList=accountSrvcdao.constructPkgRpAcctSrvcInstList(offeringDetailsLists);
			if(rpSrvcMappingList!=null && rpSrvcMappingList.size()>0){
				for(PkgRpAcctSrvcInstMapping rpSrvc:rpSrvcMappingList){
					// BigDecimal prepaymentAmt=new  BigDecimal("0.0");
					tSohSubreqServiceDetail = new TSohSubreqServiceDetail();
					/*boolean isDeviceContract = isRatePlanDeviceContract(subRequest.getSubrequestId(), 0L, rpSrvc.getRatePlanId());
					if (isDeviceContract) {
						prepaymentAmt = getPrepaymentForDeviceRP(request, subrequestId, ratePlanId,	prepaymentAmt);
					}
					tSohSubreqServiceDetail.setPrepaymentAmt(prepaymentAmt);*/
					tSohSubreqServiceDetail.setMdiReplyStatus(BigDecimal.valueOf(0));
					tSohSubreqServiceDetail.setPrepaymentOverride("0");
					tSohSubreqServiceDetail.setMdiReplyUpdated(BigDecimal.valueOf(0));
					tSohSubreqServiceDetail.setDepositAmt(BigDecimal.valueOf(0));
					tSohSubreqServiceDetail.setNoOfInstances(BigDecimal.valueOf(1));
					tSohSubreqServiceDetail.setPrepaymentPaid(BigDecimal.valueOf(0));
					tSohSubreqServiceDetail.setMdiReplyReceived("N");
					tSohSubreqServiceDetail.setDeletionStatus("N");
					tSohSubreqServiceDetail.setDepositAfterWaiver(BigDecimal.valueOf(0));
					if (rpSrvc.getSrvcCategoryId()==9) 
						tSohSubreqServiceDetail.setIsPrimaryServiceFlag("0");
					else
						tSohSubreqServiceDetail.setIsPrimaryServiceFlag("1");
					tSohSubreqServiceDetail.setDepositPaid(BigDecimal.valueOf(0));
					tSohSubreqServiceDetail.setSubreqServicePriority(BigDecimal.valueOf(1));
					TSohDtlSystemCodeValue tSohDtlSystemCodeValue = em.find(TSohDtlSystemCodeValue.class, acctDao.getSystemcodeIdByValue("SUBREQ_SRVC_STATUS","OPEN"));
					tSohSubreqServiceDetail.setTSohDtlSystemCodeValue2(tSohDtlSystemCodeValue);
					tSohSubreqServiceDetail.setTSohSubrequest(subRequest);
					tSohSubreqServiceDetail.setTSohRequirement(tSohRequirement);
					if (null !=request.getPhysicalOrgunitId())
						tSohSubreqServiceDetail.setRetailerId(request.getPhysicalOrgunitId());
					else
						tSohSubreqServiceDetail.setRetailerId(null);
					tSohSubreqServiceDetail.setRatePlanId(BigDecimal.valueOf(rpSrvc.getRatePlanId()));
					tSohSubreqServiceDetail.setServiceId(BigDecimal.valueOf(rpSrvc.getSrvcId()));
					tSohSubreqServiceDetail.setPackageId(BigDecimal.valueOf(rpSrvc.getPackageId()));
					tSohSubreqServiceDetail.setCreatedDate(new Timestamp(new Date().getTime()));
					tSohSubreqServiceDetail.setModifiedDate(new Timestamp(new Date().getTime()));
					tSohSubreqServiceDetail.setCreatedUserId(request.getCreatedUserId());
					tSohSubreqServiceDetail.setModifiedUserId(request.getCreatedUserId());
					if ("0".equals(tSohSubreqServiceDetail.getIsPrimaryServiceFlag()))
						tSohSubreqServiceDetail.setAssociationLevel(null);
					else
						tSohSubreqServiceDetail.setAssociationLevel(BigDecimal.valueOf(2));					
					em.persist(tSohSubreqServiceDetail);
					em.flush();
					BigDecimal quantity=new BigDecimal(rpSrvc.getQuantity());
					List<Long> srvcInstList=new ArrayList<Long>();
					for (int j = 0; j < quantity.intValue(); j++) {
						TSohSubreqInstanceDetail tSohSubreqInstanceDetail = createSubReqInstanceDetails(tSohSubreqServiceDetail, request);
						em.persist(tSohSubreqInstanceDetail);
						srvcInstList.add(tSohSubreqInstanceDetail.getSrServInstanceId());						
					}
					rpSrvc.setSubReqSrvcId(tSohSubreqServiceDetail.getSubreqServId());
					rpSrvc.setAcctSrvcInstanceId(srvcInstList);
				}
			}
		}catch (Exception e) {
			logger.error("Exception while performing createServiceDetails", e);
			rpSrvcMappingList=null;
			throw e;
		}
		return rpSrvcMappingList;
	}
	
	public TSohSubreqInstanceDetail createSubReqInstanceDetails(TSohSubreqServiceDetail tSohSubreqServiceDetail, TSohRequest request) {

		long start = System.currentTimeMillis();
		TSohSubreqInstanceDetail tSohSubreqInstanceDetail = null;
		try {
			tSohSubreqInstanceDetail = new TSohSubreqInstanceDetail();
			tSohSubreqInstanceDetail.setCurrentDp(BigDecimal.valueOf(0));
			tSohSubreqInstanceDetail.setTSohSubreqServiceDetail(tSohSubreqServiceDetail);
			tSohSubreqInstanceDetail.setOldDp(BigDecimal.valueOf(0));
			tSohSubreqInstanceDetail.setAmendmentCounter(BigDecimal.valueOf(0));
			tSohSubreqInstanceDetail.setDeletionStatus("N");
			tSohSubreqInstanceDetail.setOldNumber(BigDecimal.valueOf(0));
			if (!"0".equals(tSohSubreqServiceDetail.getIsPrimaryServiceFlag()))
				tSohSubreqInstanceDetail.setAmendmentType("S");
			tSohSubreqInstanceDetail.setCurrentNumber(BigDecimal.valueOf(0));
			tSohSubreqInstanceDetail.setCreatedDate(new Timestamp(new Date().getTime()));
			tSohSubreqInstanceDetail.setModifiedDate(new Timestamp(new Date().getTime()));
			tSohSubreqInstanceDetail.setCreatedUserId(request.getCreatedUserId());
			tSohSubreqInstanceDetail.setModifiedUserId(request.getModifiedUserId());
			logger.info("TSohSubreqInstanceDetail has been inserted within " + (System.currentTimeMillis() - start) + " milliseconds");
			em.persist(tSohSubreqInstanceDetail);
			em.flush();
			return tSohSubreqInstanceDetail;
		} catch (Exception e) {
			logger.error("Exception", e);
			e.printStackTrace();
		} finally {
		}
		return null;
	}
	
	public TSohCustRequirement createCustRequirement(TSohRequest tSohRequest, TSohRequirement cReq,PkgRpAcctSrvcInstMapping rpSrvc,TSohSubrequest subReq) {
		TSohCustRequirement custReq = new TSohCustRequirement();
		long start = System.currentTimeMillis();
		try {
			custReq.setQuantity(BigDecimal.valueOf(1));
			custReq.setServcRequiredTillDate(null);
			custReq.setTAdmMstRegion(tSohRequest.getTAdmMstRegion());
			if(null!=tSohRequest.getPhysicalOrgunitId())
				custReq.setRetailerId(tSohRequest.getPhysicalOrgunitId());
			custReq.setRequirementId(cReq.getRequirementId());
			custReq.setTCmsMstPartySubtype(subReq.getTCmsMstPartySubtype());
			if(rpSrvc.getPackageId()!=0)
				custReq.setPackageId(BigDecimal.valueOf(rpSrvc.getPackageId()));
			custReq.setRatePlanId(BigDecimal.valueOf(rpSrvc.getRatePlanId()));
			custReq.setTSohRequirement(cReq);
			custReq.setEmirateId(subReq.getEmirateId());
			em.persist(custReq);
			em.flush();
			logger.info("Customer Requirment has been inserted within " + (System.currentTimeMillis() - start) + " milliseconds");
			return custReq;
		} catch (Exception e) {
			logger.error("Exception", e);
			e.printStackTrace();
		} finally {
		}
		return null;
	}
	
	public TSohMstSubreqAccinfo createAccountInfo(OrderInfo orderInfo,AccountInfo accountInfo,TSohRequest tSohRequest,  TSohSubrequest tSohSubrequest) throws Exception {
		TSohMstSubreqAccinfo tSohMstSubreqAccinfo = new TSohMstSubreqAccinfo();
		tSohMstSubreqAccinfo.setAccBillingCycleType(BigDecimal.valueOf(2));
		tSohMstSubreqAccinfo.setTCmsMstPartySubtype(tSohSubrequest.getTCmsMstPartySubtype());
		tSohMstSubreqAccinfo.setDeletionStatus("N");
		tSohMstSubreqAccinfo.setSubreqAccNameEng(accountInfo.getACCOUNTFULLNAMEENG());
		tSohMstSubreqAccinfo.setSubreqAccNameArabic(accountInfo.getACCOUNTFULLNAMEARABIC());
		tSohMstSubreqAccinfo.setAccCurrencyId(BigDecimal.valueOf(getCurrencyByCode("AED").getCurrencyId()));
		tSohMstSubreqAccinfo.setAccBillingcycleId(BigDecimal.valueOf(1));
		TSohDtlSystemCodeValue dtlSystemCodeValue = em.find(TSohDtlSystemCodeValue.class, acctDao.getSystemcodeIdByValue("MAINTENANCE_PRIORITY","High"));
		tSohMstSubreqAccinfo.setAccMaintainancePriority(BigDecimal.valueOf(dtlSystemCodeValue.getSystemCodeValueId()));
		tSohMstSubreqAccinfo.setSubrequestId(BigDecimal.valueOf(tSohSubrequest.getSubrequestId()));
		tSohMstSubreqAccinfo.setCreatedDate(new Timestamp(new Date().getTime()));
		tSohMstSubreqAccinfo.setModifiedDate(new Timestamp(new Date().getTime()));
		tSohMstSubreqAccinfo.setModifiedUserId(orderInfo.getUserId());
		tSohMstSubreqAccinfo.setCreatedUserId(orderInfo.getUserId());
		TSohDtlSystemCodeValue dtlSystemCodeValue2 = em.find(TSohDtlSystemCodeValue.class, acctDao.getSystemcodeIdByValue("ACCOUNT_TYPE","Service Provision"));
		tSohMstSubreqAccinfo.setAccountType(BigDecimal.valueOf(dtlSystemCodeValue2.getSystemCodeValueId()));
		tSohMstSubreqAccinfo.setInetUserId(null);
		TBilBillingCycle billingCycle = getBillingCycle(tSohMstSubreqAccinfo.getAccBillingcycleId().longValue());
		if(Util.isValidObject(billingCycle))
			tSohMstSubreqAccinfo.setBillingCycleDate(billingCycle.getEffectiveFromDate());
		tSohMstSubreqAccinfo.setAccessFlag("Normal");
		em.persist(tSohMstSubreqAccinfo);
		em.flush();
		return tSohMstSubreqAccinfo;
	}
	
	
	public void createInvoiceInfo(InvoiceDetails invoiceDetails, TSohSubrequest tSohSubrequest,OrderInfo orderInfo,AccountInfo accountInfo,TSohRequest tSohRequest) {
		TSohMstSubreqInvoiceInfo tSohMstSubreqInvoiceInfo = new TSohMstSubreqInvoiceInfo();
		tSohMstSubreqInvoiceInfo.setInvoiceRequiredFlag("N");
		tSohMstSubreqInvoiceInfo.setInvoiceNameEng(invoiceDetails.getInvoiceNameEng());
		tSohMstSubreqInvoiceInfo.setInvoiceNameArabic(invoiceDetails.getInvoiceNameArabic());
		tSohMstSubreqInvoiceInfo.setInvoiceTypeId(invoiceDetails.getInvoiceType());
		tSohMstSubreqInvoiceInfo.setDeletionStatus("N");
		tSohMstSubreqInvoiceInfo.setCreatedUserId(orderInfo.getUserId());
		tSohMstSubreqInvoiceInfo.setCreatedDate(new Timestamp(new Date().getTime()));
		tSohMstSubreqInvoiceInfo.setModifiedUserId(orderInfo.getUserId());
		tSohMstSubreqInvoiceInfo.setModifiedDate(new Timestamp(new Date().getTime()));
		tSohMstSubreqInvoiceInfo.setPreferedDeliveryMode(new BigDecimal(invoiceDetails.getPreferedDeliveryMode()));
		tSohMstSubreqInvoiceInfo.setInvoiceRequiredFlag(invoiceDetails.getInvoiceRequiredFlag());
		tSohMstSubreqInvoiceInfo.setEmailId(invoiceDetails.getEmailId());
		em.persist(tSohMstSubreqInvoiceInfo);
		em.flush();
		TSohDtlSubreqInvAttrInfo tSohDtlSubreqInvAttrInfo = new TSohDtlSubreqInvAttrInfo();
		tSohDtlSubreqInvAttrInfo.setDeletionStatus("N");
		tSohDtlSubreqInvAttrInfo.setDetailsInvoiceFlag(invoiceDetails.getDetailsInvoiceFlag());
		tSohDtlSubreqInvAttrInfo.setHideNameFlag(invoiceDetails.getHideNameFlag());
		tSohDtlSubreqInvAttrInfo.setCreatedUserId(orderInfo.getUserId());
		tSohDtlSubreqInvAttrInfo.setCreatedDate(new Timestamp(new Date().getTime()));
		tSohDtlSubreqInvAttrInfo.setModifiedUserId(orderInfo.getUserId());
		tSohDtlSubreqInvAttrInfo.setModifiedDate(new Timestamp(new Date().getTime()));
		tSohDtlSubreqInvAttrInfo.setLanguageId(new BigDecimal(invoiceDetails.getLanguageId()));
		tSohDtlSubreqInvAttrInfo.setInvoiceTemplateId(new BigDecimal(invoiceDetails.getInvoiceTemplate()));
		tSohDtlSubreqInvAttrInfo.setInvoiceMediaId(new BigDecimal(invoiceDetails.getInvoiceMedia()));
		tSohDtlSubreqInvAttrInfo.setTSohMstSubreqInvoiceInfo(tSohMstSubreqInvoiceInfo);
		tSohDtlSubreqInvAttrInfo.setDeliveryAddressId(new BigDecimal(invoiceDetails.getDeliveryAddressId()));
		em.persist(tSohDtlSubreqInvAttrInfo);
		em.flush();
		TSohDtlSubreqInvoiceInfo tSohDtlSubreqInvoiceInfo = new TSohDtlSubreqInvoiceInfo();
		tSohDtlSubreqInvoiceInfo.setDeletionStatus("N");
		tSohDtlSubreqInvoiceInfo.setSubrequestId(BigDecimal.valueOf(tSohSubrequest.getSubrequestId()));
		tSohDtlSubreqInvoiceInfo.setCreatedUserId(orderInfo.getUserId());
		tSohDtlSubreqInvoiceInfo.setCreatedDate(new Timestamp(new Date().getTime()));
		tSohDtlSubreqInvoiceInfo.setModifiedUserId(orderInfo.getUserId());
		tSohDtlSubreqInvoiceInfo.setModifiedDate(new Timestamp(new Date().getTime()));
		tSohDtlSubreqInvoiceInfo.setSubreqInvoiceId(BigDecimal.valueOf(tSohMstSubreqInvoiceInfo.getSubreqInvoiceId()));
		em.persist(tSohDtlSubreqInvoiceInfo);
		em.flush();
	}
	
	@SuppressWarnings("deprecation")
	public void createPaymentInfo(PaymentTypeInfo paymentTypeInfo, TSohSubrequest tSohSubrequest,AccountInfo accountInfo) {
		BigDecimal modeOfPaymentId = new BigDecimal("0.0");
		if(Util.isValidObject(paymentTypeInfo.getPaymentType()))
			modeOfPaymentId = payDao.fetchPaymentTypeId("PAYMENT_TYPE",paymentTypeInfo.getPaymentType());
		else
			modeOfPaymentId = payDao.fetchPaymentTypeId("PAYMENT_TYPE","Cash");
		TSohSubreqPaymentinfo tSohSubreqPaymentinfo = new TSohSubreqPaymentinfo();
		tSohSubreqPaymentinfo.setDeletionStatus("N");
		tSohSubreqPaymentinfo.setCreatedUserId(tSohSubrequest.getCreatedUserId());
		tSohSubreqPaymentinfo.setCreatedDate(new Timestamp(new Date().getTime()));
		tSohSubreqPaymentinfo.setModifiedUserId(tSohSubrequest.getModifiedUserId());
		tSohSubreqPaymentinfo.setModifiedDate(new Timestamp(new Date().getTime()));
		tSohSubreqPaymentinfo.setPayTypeModeId(modeOfPaymentId);
		tSohSubreqPaymentinfo.setSubrequestId(BigDecimal.valueOf(tSohSubrequest.getSubrequestId()));
		if(paymentTypeInfo.getPaymentTypeInfoList()!=null && paymentTypeInfo.getPaymentTypeInfoList().size()>0){
			for(PaymentTypeInfoList payTypeInfo:paymentTypeInfo.getPaymentTypeInfoList()){
				if(payTypeInfo.getInfoKey()!=null && payTypeInfo.getInfoKey().trim().length()>0
						&& payTypeInfo.getInfoValue()!=null && payTypeInfo.getInfoValue().trim().length()>0){
					if(payTypeInfo.getInfoKey().equalsIgnoreCase("epgStatus"))
						tSohSubreqPaymentinfo.setEpgStatus(payTypeInfo.getInfoValue());
					if(payTypeInfo.getInfoKey().equalsIgnoreCase("ddStartDate"))
						tSohSubreqPaymentinfo.setDdStartDate(new Date(payTypeInfo.getInfoValue()));
					if(payTypeInfo.getInfoKey().equalsIgnoreCase("ddExpiryDate"))
						tSohSubreqPaymentinfo.setDdExpiryDate(new Date(payTypeInfo.getInfoValue()));
					if(payTypeInfo.getInfoKey().equalsIgnoreCase("ddRegistrationStatus"))
						tSohSubreqPaymentinfo.setDdRegistrationStatus(payTypeInfo.getInfoValue());
					if(payTypeInfo.getInfoKey().equalsIgnoreCase("mobileContact"))
						tSohSubreqPaymentinfo.setMobileContact(payTypeInfo.getInfoValue());
					if(payTypeInfo.getInfoKey().equalsIgnoreCase("paymentAmount"))
						tSohSubreqPaymentinfo.setPaymentAmount(new BigDecimal(payTypeInfo.getInfoValue()));
					if(payTypeInfo.getInfoKey().equalsIgnoreCase("paymentOption"))
						tSohSubreqPaymentinfo.setPaymentOption(payTypeInfo.getInfoValue());
					if(payTypeInfo.getInfoKey().equalsIgnoreCase("cardExpiryDate"))
						tSohSubreqPaymentinfo.setCardExpiryDate(new Date(payTypeInfo.getInfoValue()));
				}
			}
		}
        tSohSubreqPaymentinfo.setAccountNumber(accountInfo.getAccountNumber());	
		em.persist(tSohSubreqPaymentinfo);
		em.flush();
	}
	
	public void createDqInfo(DqResellerInfo dqResellerInfo, TSohSubrequest tSohSubrequest,AccountInfo accountInfo) throws Exception{
		long directoryCodeId = 0;
		if (dqResellerInfo==null || (dqResellerInfo!=null && dqResellerInfo.getDirectoryCode()==null))
			directoryCodeId = Long.parseLong(acctDao.getSystemcodeIdByValue("DIRECTORY_CODE", "1"));
		else
			directoryCodeId =Long.parseLong(acctDao.getSystemcodeIdByValue("DIRECTORY_CODE", dqResellerInfo.getDirectoryCode()));		
		TSohSubreqDqinfo tSohSubreqDqinfo = new TSohSubreqDqinfo();
		tSohSubreqDqinfo.setFavouritenameinenglish("");
		tSohSubreqDqinfo.setCompanynameinarabic(accountInfo.getACCOUNTFULLNAMEARABIC());
		tSohSubreqDqinfo.setFavouritenameinarabic("");
		tSohSubreqDqinfo.setCompanynameinenglish(accountInfo.getACCOUNTFULLNAMEENG());
		tSohSubreqDqinfo.setDirectoryCode(BigDecimal.valueOf(directoryCodeId));
		tSohSubreqDqinfo.setCreatedUserId(tSohSubrequest.getCreatedUserId());
		tSohSubreqDqinfo.setCreatedDate(new Timestamp(new Date().getTime()));
		tSohSubreqDqinfo.setModifiedUserId(tSohSubrequest.getModifiedUserId());
		tSohSubreqDqinfo.setModifiedDate(new Timestamp(new Date().getTime()));
		tSohSubreqDqinfo.setSubrequestId(BigDecimal.valueOf(tSohSubrequest.getSubrequestId()));
		em.persist(tSohSubreqDqinfo);
		em.flush();
	}
	
	
	public TAdmMstCurrency getCurrencyByCode(String code) {
		long start = System.currentTimeMillis();
		try {
			Query query = em.createQuery("select a from TAdmMstCurrency a where a.code = :code and a.deletionStatus ='N'");
			logger.debug(query.toString() + " Parameters are " + code);
			query.setParameter("code", code);
			TAdmMstCurrency tAdmMstCurrency = Util.getFirstObjectFromList(query.getResultList());
			if (tAdmMstCurrency != null) {
				logger.info("tAdmMstCurrency record has been fetched in " + (System.currentTimeMillis() - start) + " milliseconds");
				return tAdmMstCurrency;
			}
		} finally {
		}
		return null;
	}
	
	public TBilBillingCycle getBillingCycle(long billingCycleId){			
			long start = System.currentTimeMillis();
			TBilBillingCycle billingCycle = null;
			try{	
				logger.debug("billingCycleId is ["+billingCycleId+"]");
				TypedQuery<TBilBillingCycle> query=em.createQuery("SELECT t FROM TBilBillingCycle t "
						+ "where t.deletionStatus = :deletionStatus and t.billingCycleId = :billingCycleId",TBilBillingCycle.class);				
				query.setParameter("deletionStatus", 'N');
				query.setParameter("billingCycleId", billingCycleId);	
				logger.debug("query is ["+query.toString()+"] and parameters is billingCycleId = ["+billingCycleId+"]");
				billingCycle = Util.getFirstObjectFromList(query.getResultList());	
				logger.debug("returned rows count is ["+billingCycle+"]");
			} catch (Exception e) {	
				logger.error("Execption in getBillingCycle: "+e.getMessage());	
			} finally {
				logger.info("getBillingCycle done in "
						+ (System.currentTimeMillis() - start) + " milliseconds");
			}	
			return billingCycle;
		}
	
	}
