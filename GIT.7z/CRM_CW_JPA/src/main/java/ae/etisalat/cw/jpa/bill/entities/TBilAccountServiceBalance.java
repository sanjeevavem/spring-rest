package ae.etisalat.cw.jpa.bill.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the T_BIL_ACCOUNT_SERVICE_BALANCE database table.
 * 
 */
@Entity
@Table(name="T_BIL_ACCOUNT_SERVICE_BALANCE")
@NamedQuery(name="TBilAccountServiceBalance.findAll", query="SELECT t FROM TBilAccountServiceBalance t")
public class TBilAccountServiceBalance implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TBilAccountServiceBalancePK id;

	@Column(name="CLOSING_BAL_BKG_CURRENCY")
	private BigDecimal closingBalBkgCurrency;

	@Column(name="CLOSING_BALANCE")
	private BigDecimal closingBalance;

	@Column(name="CLOSING_BALANCE_ALT_CURRENCY")
	private BigDecimal closingBalanceAltCurrency;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="CURRENT_MONTH_CHARGES")
	private BigDecimal currentMonthCharges;

	@Column(name="CURRENT_MTH_CHRGS_ALT_CURRENCY")
	private BigDecimal currentMthChrgsAltCurrency;

	@Column(name="CURRENT_MTH_CHRGS_BKG_CURRENCY")
	private BigDecimal currentMthChrgsBkgCurrency;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="INVOICED_FLAG")
	private BigDecimal invoicedFlag;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="OPENING_BALANCE")
	private BigDecimal openingBalance;

	@Column(name="OPENING_BALANCE_ALT_CURRENCY")
	private BigDecimal openingBalanceAltCurrency;

	@Column(name="OPENING_BALANCE_BKG_CURRENCY")
	private BigDecimal openingBalanceBkgCurrency;

	@Column(name="OUTSTANDING_BAL_ALT_CURRENCY")
	private BigDecimal outstandingBalAltCurrency;

	@Column(name="OUTSTANDING_BAL_BKG_CURRENCY")
	private BigDecimal outstandingBalBkgCurrency;

	@Column(name="OUTSTANDING_BALANCE")
	private BigDecimal outstandingBalance;

	@Column(name="WRITTEN_OFF_AMOUNT")
	private BigDecimal writtenOffAmount;

	@Column(name="WRITTEN_OFF_AMT_ALT_CURRENCY")
	private BigDecimal writtenOffAmtAltCurrency;

	@Column(name="WRITTEN_OFF_AMT_BKG_CURRENCY")
	private BigDecimal writtenOffAmtBkgCurrency;

	public TBilAccountServiceBalance() {
	}

	public TBilAccountServiceBalancePK getId() {
		return this.id;
	}

	public void setId(TBilAccountServiceBalancePK id) {
		this.id = id;
	}

	public BigDecimal getClosingBalBkgCurrency() {
		return this.closingBalBkgCurrency;
	}

	public void setClosingBalBkgCurrency(BigDecimal closingBalBkgCurrency) {
		this.closingBalBkgCurrency = closingBalBkgCurrency;
	}

	public BigDecimal getClosingBalance() {
		return this.closingBalance;
	}

	public void setClosingBalance(BigDecimal closingBalance) {
		this.closingBalance = closingBalance;
	}

	public BigDecimal getClosingBalanceAltCurrency() {
		return this.closingBalanceAltCurrency;
	}

	public void setClosingBalanceAltCurrency(BigDecimal closingBalanceAltCurrency) {
		this.closingBalanceAltCurrency = closingBalanceAltCurrency;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public BigDecimal getCurrentMonthCharges() {
		return this.currentMonthCharges;
	}

	public void setCurrentMonthCharges(BigDecimal currentMonthCharges) {
		this.currentMonthCharges = currentMonthCharges;
	}

	public BigDecimal getCurrentMthChrgsAltCurrency() {
		return this.currentMthChrgsAltCurrency;
	}

	public void setCurrentMthChrgsAltCurrency(BigDecimal currentMthChrgsAltCurrency) {
		this.currentMthChrgsAltCurrency = currentMthChrgsAltCurrency;
	}

	public BigDecimal getCurrentMthChrgsBkgCurrency() {
		return this.currentMthChrgsBkgCurrency;
	}

	public void setCurrentMthChrgsBkgCurrency(BigDecimal currentMthChrgsBkgCurrency) {
		this.currentMthChrgsBkgCurrency = currentMthChrgsBkgCurrency;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public BigDecimal getInvoicedFlag() {
		return this.invoicedFlag;
	}

	public void setInvoicedFlag(BigDecimal invoicedFlag) {
		this.invoicedFlag = invoicedFlag;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getOpeningBalance() {
		return this.openingBalance;
	}

	public void setOpeningBalance(BigDecimal openingBalance) {
		this.openingBalance = openingBalance;
	}

	public BigDecimal getOpeningBalanceAltCurrency() {
		return this.openingBalanceAltCurrency;
	}

	public void setOpeningBalanceAltCurrency(BigDecimal openingBalanceAltCurrency) {
		this.openingBalanceAltCurrency = openingBalanceAltCurrency;
	}

	public BigDecimal getOpeningBalanceBkgCurrency() {
		return this.openingBalanceBkgCurrency;
	}

	public void setOpeningBalanceBkgCurrency(BigDecimal openingBalanceBkgCurrency) {
		this.openingBalanceBkgCurrency = openingBalanceBkgCurrency;
	}

	public BigDecimal getOutstandingBalAltCurrency() {
		return this.outstandingBalAltCurrency;
	}

	public void setOutstandingBalAltCurrency(BigDecimal outstandingBalAltCurrency) {
		this.outstandingBalAltCurrency = outstandingBalAltCurrency;
	}

	public BigDecimal getOutstandingBalBkgCurrency() {
		return this.outstandingBalBkgCurrency;
	}

	public void setOutstandingBalBkgCurrency(BigDecimal outstandingBalBkgCurrency) {
		this.outstandingBalBkgCurrency = outstandingBalBkgCurrency;
	}

	public BigDecimal getOutstandingBalance() {
		return this.outstandingBalance;
	}

	public void setOutstandingBalance(BigDecimal outstandingBalance) {
		this.outstandingBalance = outstandingBalance;
	}

	public BigDecimal getWrittenOffAmount() {
		return this.writtenOffAmount;
	}

	public void setWrittenOffAmount(BigDecimal writtenOffAmount) {
		this.writtenOffAmount = writtenOffAmount;
	}

	public BigDecimal getWrittenOffAmtAltCurrency() {
		return this.writtenOffAmtAltCurrency;
	}

	public void setWrittenOffAmtAltCurrency(BigDecimal writtenOffAmtAltCurrency) {
		this.writtenOffAmtAltCurrency = writtenOffAmtAltCurrency;
	}

	public BigDecimal getWrittenOffAmtBkgCurrency() {
		return this.writtenOffAmtBkgCurrency;
	}

	public void setWrittenOffAmtBkgCurrency(BigDecimal writtenOffAmtBkgCurrency) {
		this.writtenOffAmtBkgCurrency = writtenOffAmtBkgCurrency;
	}

}