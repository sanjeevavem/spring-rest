package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the T_SOH_SUBREQ_INSTANCE_DETAILS database table.
 * 
 */
@Entity
@Table(name="T_SOH_SUBREQ_INSTANCE_DETAILS")
@NamedQuery(name="TSohSubreqInstanceDetail.findAll", query="SELECT t FROM TSohSubreqInstanceDetail t")
public class TSohSubreqInstanceDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SR_SERV_INSTANCE_ID")
	private long srServInstanceId;

	@Column(name="AMENDMENT_COUNTER")
	private BigDecimal amendmentCounter;

	@Column(name="AMENDMENT_TYPE")
	private String amendmentType;

	@Column(name="ASSOCIATED_INSTANCE_ID")
	private BigDecimal associatedInstanceId;

	@Column(name="ASSOCIATION_INDICATOR")
	private String associationIndicator;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="CURRENT_DP")
	private BigDecimal currentDp;

	@Column(name="CURRENT_MDF")
	private String currentMdf;

	@Column(name="CURRENT_NUMBER")
	private BigDecimal currentNumber;

	@Column(name="CURRENT_OTHER_RESOURCE")
	private String currentOtherResource;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="OLD_DP")
	private BigDecimal oldDp;

	@Column(name="OLD_INSTANCE_ID")
	private BigDecimal oldInstanceId;

	@Column(name="OLD_MDF")
	private String oldMdf;

	@Column(name="OLD_NUMBER")
	private BigDecimal oldNumber;

	@Column(name="OLD_OTHER_RESOURCE")
	private String oldOtherResource;


	//bi-directional many-to-one association to TSohGsmNumberPool
	@OneToMany(mappedBy="TSohSubreqInstanceDetail")
	private List<TSohGsmNumberPool> TSohGsmNumberPools;
	
	//bi-directional many-to-one association to TSohSubreqServiceDetail
	@ManyToOne
	@JoinColumn(name="SUBREQ_SERV_ID")
	private TSohSubreqServiceDetail TSohSubreqServiceDetail;

	public TSohSubreqInstanceDetail() {
	}

	public long getSrServInstanceId() {
		return this.srServInstanceId;
	}

	public void setSrServInstanceId(long srServInstanceId) {
		this.srServInstanceId = srServInstanceId;
	}

	public BigDecimal getAmendmentCounter() {
		return this.amendmentCounter;
	}

	public void setAmendmentCounter(BigDecimal amendmentCounter) {
		this.amendmentCounter = amendmentCounter;
	}

	public String getAmendmentType() {
		return this.amendmentType;
	}

	public void setAmendmentType(String amendmentType) {
		this.amendmentType = amendmentType;
	}

	public BigDecimal getAssociatedInstanceId() {
		return this.associatedInstanceId;
	}

	public void setAssociatedInstanceId(BigDecimal associatedInstanceId) {
		this.associatedInstanceId = associatedInstanceId;
	}

	public String getAssociationIndicator() {
		return this.associationIndicator;
	}

	public void setAssociationIndicator(String associationIndicator) {
		this.associationIndicator = associationIndicator;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public BigDecimal getCurrentDp() {
		return this.currentDp;
	}

	public void setCurrentDp(BigDecimal currentDp) {
		this.currentDp = currentDp;
	}

	public String getCurrentMdf() {
		return this.currentMdf;
	}

	public void setCurrentMdf(String currentMdf) {
		this.currentMdf = currentMdf;
	}

	public BigDecimal getCurrentNumber() {
		return this.currentNumber;
	}

	public void setCurrentNumber(BigDecimal currentNumber) {
		this.currentNumber = currentNumber;
	}

	public String getCurrentOtherResource() {
		return this.currentOtherResource;
	}

	public void setCurrentOtherResource(String currentOtherResource) {
		this.currentOtherResource = currentOtherResource;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getOldDp() {
		return this.oldDp;
	}

	public void setOldDp(BigDecimal oldDp) {
		this.oldDp = oldDp;
	}

	public BigDecimal getOldInstanceId() {
		return this.oldInstanceId;
	}

	public void setOldInstanceId(BigDecimal oldInstanceId) {
		this.oldInstanceId = oldInstanceId;
	}

	public String getOldMdf() {
		return this.oldMdf;
	}

	public void setOldMdf(String oldMdf) {
		this.oldMdf = oldMdf;
	}

	public BigDecimal getOldNumber() {
		return this.oldNumber;
	}

	public void setOldNumber(BigDecimal oldNumber) {
		this.oldNumber = oldNumber;
	}

	public String getOldOtherResource() {
		return this.oldOtherResource;
	}

	public void setOldOtherResource(String oldOtherResource) {
		this.oldOtherResource = oldOtherResource;
	}

	public List<TSohGsmNumberPool> getTSohGsmNumberPools() {
		return this.TSohGsmNumberPools;
	}

	public void setTSohGsmNumberPools(List<TSohGsmNumberPool> TSohGsmNumberPools) {
		this.TSohGsmNumberPools = TSohGsmNumberPools;
	}

	public TSohGsmNumberPool addTSohGsmNumberPool(TSohGsmNumberPool TSohGsmNumberPool) {
		getTSohGsmNumberPools().add(TSohGsmNumberPool);
		TSohGsmNumberPool.setTSohSubreqInstanceDetail(this);

		return TSohGsmNumberPool;
	}

	public TSohGsmNumberPool removeTSohGsmNumberPool(TSohGsmNumberPool TSohGsmNumberPool) {
		getTSohGsmNumberPools().remove(TSohGsmNumberPool);
		TSohGsmNumberPool.setTSohSubreqInstanceDetail(null);

		return TSohGsmNumberPool;
	}
	
	public TSohSubreqServiceDetail getTSohSubreqServiceDetail() {
		return this.TSohSubreqServiceDetail;
	}

	public void setTSohSubreqServiceDetail(TSohSubreqServiceDetail TSohSubreqServiceDetail) {
		this.TSohSubreqServiceDetail = TSohSubreqServiceDetail;
	}

}