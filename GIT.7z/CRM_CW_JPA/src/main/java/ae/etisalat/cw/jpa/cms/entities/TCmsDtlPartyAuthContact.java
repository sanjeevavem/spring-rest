package ae.etisalat.cw.jpa.cms.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;


/**
 * The persistent class for the T_CMS_DTL_PARTY_AUTH_CONTACT database table.
 * 
 */
@Entity
@Table(name="T_CMS_DTL_PARTY_AUTH_CONTACT")
public class TCmsDtlPartyAuthContact implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="AL_UPLOAD_STATUS")
	private String alUploadStatus;

	@Column(name="AUTHORIZATION_LETTER_FILE")
	private String authorizationLetterFile;

	@Id
	@Column(name="AUTHORIZED_CONTACT_ID")
	private BigDecimal authorizedContactId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	private String designation;

	@Column(name="DIRECT_NO")
	private String directNo;

	private String email;

	@Column(name="ID_CARD_FILE")
	private String idCardFile;

	@Column(name="ID_UPLOAD_STATUS")
	private String idUploadStatus;

	@Column(name="IS_PRIMARY_CONTACT")
	private String isPrimaryContact;

	private String mobile;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="OTHER_CONTACT_NUM")
	private String otherContactNum;

	@Column(name="PARTY_ID")
	private BigDecimal partyId;

	@Column(name="PERSON_NAME")
	private String personName;

	@Transient
	private String action;
	
	public TCmsDtlPartyAuthContact() {
	}

	public String getAlUploadStatus() {
		return this.alUploadStatus;
	}

	public void setAlUploadStatus(String alUploadStatus) {
		this.alUploadStatus = alUploadStatus;
	}

	public String getAuthorizationLetterFile() {
		return this.authorizationLetterFile;
	}

	public void setAuthorizationLetterFile(String authorizationLetterFile) {
		this.authorizationLetterFile = authorizationLetterFile;
	}

	public BigDecimal getAuthorizedContactId() {
		return this.authorizedContactId;
	}

	public void setAuthorizedContactId(BigDecimal authorizedContactId) {
		this.authorizedContactId = authorizedContactId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public String getDesignation() {
		return this.designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getDirectNo() {
		return this.directNo;
	}

	public void setDirectNo(String directNo) {
		this.directNo = directNo;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getIdCardFile() {
		return this.idCardFile;
	}

	public void setIdCardFile(String idCardFile) {
		this.idCardFile = idCardFile;
	}

	public String getIdUploadStatus() {
		return this.idUploadStatus;
	}

	public void setIdUploadStatus(String idUploadStatus) {
		this.idUploadStatus = idUploadStatus;
	}

	public String getIsPrimaryContact() {
		return this.isPrimaryContact;
	}

	public void setIsPrimaryContact(String isPrimaryContact) {
		this.isPrimaryContact = isPrimaryContact;
	}

	public String getMobile() {
		return this.mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getOtherContactNum() {
		return this.otherContactNum;
	}

	public void setOtherContactNum(String otherContactNum) {
		this.otherContactNum = otherContactNum;
	}

	public BigDecimal getPartyId() {
		return this.partyId;
	}

	public void setPartyId(BigDecimal partyId) {
		this.partyId = partyId;
	}

	public String getPersonName() {
		return this.personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

}