package ae.etisalat.cw.jpa.cms.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the T_CMS_DTL_PARTY_PROFILE database table.
 * 
 */
@Entity
@Table(name="T_CMS_DTL_PARTY_PROFILE")
@NamedQuery(name="TCmsDtlPartyProfile.findAll", query="SELECT t FROM TCmsDtlPartyProfile t")
public class TCmsDtlPartyProfile implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_CMS_DTL_PARTY_PROFILE_PROFILEID_GENERATOR", sequenceName="SQ_CMS_PROFILE")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_CMS_DTL_PARTY_PROFILE_PROFILEID_GENERATOR")
	@Column(name="PROFILE_ID")
	private long profileId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="EBILL_EMAIL")
	private String ebillEmail;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_FROM")
	private Date effectiveFrom;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_TILL")
	private Date effectiveTill;

	@Column(name="GROUP_ID")
	private BigDecimal groupId;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="NO_BILL_FLAG")
	private String noBillFlag;

	@Column(name="PARTY_ID")
	private BigDecimal partyId;

	@Column(name="PARTY_PRECHECK_STRING")
	private String partyPrecheckString;

	@Column(name="PARTY_TYPE_ID")
	private BigDecimal partyTypeId;

	private String potential;

	@Column(name="RULE_ID")
	private BigDecimal ruleId;

	@Column(name="SUB_TYPE_ID")
	private BigDecimal subTypeId;

	@Column(name="TRA_FLAG")
	private String traFlag;

	public TCmsDtlPartyProfile() {
	}

	public long getProfileId() {
		return this.profileId;
	}

	public void setProfileId(long profileId) {
		this.profileId = profileId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public String getEbillEmail() {
		return this.ebillEmail;
	}

	public void setEbillEmail(String ebillEmail) {
		this.ebillEmail = ebillEmail;
	}

	public Date getEffectiveFrom() {
		return this.effectiveFrom;
	}

	public void setEffectiveFrom(Date effectiveFrom) {
		this.effectiveFrom = effectiveFrom;
	}

	public Date getEffectiveTill() {
		return this.effectiveTill;
	}

	public void setEffectiveTill(Date effectiveTill) {
		this.effectiveTill = effectiveTill;
	}

	public BigDecimal getGroupId() {
		return this.groupId;
	}

	public void setGroupId(BigDecimal groupId) {
		this.groupId = groupId;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getNoBillFlag() {
		return this.noBillFlag;
	}

	public void setNoBillFlag(String noBillFlag) {
		this.noBillFlag = noBillFlag;
	}

	public BigDecimal getPartyId() {
		return this.partyId;
	}

	public void setPartyId(BigDecimal partyId) {
		this.partyId = partyId;
	}

	public String getPartyPrecheckString() {
		return this.partyPrecheckString;
	}

	public void setPartyPrecheckString(String partyPrecheckString) {
		this.partyPrecheckString = partyPrecheckString;
	}

	public BigDecimal getPartyTypeId() {
		return this.partyTypeId;
	}

	public void setPartyTypeId(BigDecimal partyTypeId) {
		this.partyTypeId = partyTypeId;
	}

	public String getPotential() {
		return this.potential;
	}

	public void setPotential(String potential) {
		this.potential = potential;
	}

	public BigDecimal getRuleId() {
		return this.ruleId;
	}

	public void setRuleId(BigDecimal ruleId) {
		this.ruleId = ruleId;
	}

	public BigDecimal getSubTypeId() {
		return this.subTypeId;
	}

	public void setSubTypeId(BigDecimal subTypeId) {
		this.subTypeId = subTypeId;
	}

	public String getTraFlag() {
		return this.traFlag;
	}

	public void setTraFlag(String traFlag) {
		this.traFlag = traFlag;
	}

}