package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the T_SOH_MST_ACCOUNT_INVOICE_INFO database table.
 * 
 */
@Entity
@Table(name="T_SOH_MST_ACCOUNT_INVOICE_INFO")
@NamedQuery(name="TSohMstAccountInvoiceInfo.findAll", query="SELECT t FROM TSohMstAccountInvoiceInfo t")
public class TSohMstAccountInvoiceInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_SOH_MST_ACCOUNT_INVOICE_INFO_ACCINVOICEID_GENERATOR", sequenceName="SQ_T_SOH_MST_ACCOUNT_INV_INFO",allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_SOH_MST_ACCOUNT_INVOICE_INFO_ACCINVOICEID_GENERATOR")
	@Column(name="ACC_INVOICE_ID")
	private long accInvoiceId;

	@Column(name="BILL_FLAG")
	private String billFlag;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="EMAIL_ID")
	private String emailId;

	@Column(name="EMAIL_VERIFY_STATUS")
	private BigDecimal emailVerifyStatus;

	@Column(name="INVOICE_NAME_ARABIC")
	private String invoiceNameArabic;

	@Column(name="INVOICE_NAME_ENG")
	private String invoiceNameEng;

	@Column(name="INVOICE_REQUIRED_FLAG")
	private String invoiceRequiredFlag;

	@Column(name="INVOICE_TYPE_ID")
	private String invoiceTypeId;

	private String mobile;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="NO_BILL_REQUIRED_FLAG")
	private String noBillRequiredFlag;

	@Column(name="PREFERED_DELIVERY_MODE")
	private BigDecimal preferedDeliveryMode;

	@Column(name="USAGE_CLASSIFICATION")
	private BigDecimal usageClassification;

	//bi-directional many-to-one association to TSohDtlAccountInvoiceInfo
	@OneToMany(mappedBy="TSohMstAccountInvoiceInfo")
	private List<TSohDtlAccountInvoiceInfo> TSohDtlAccountInvoiceInfos;

	//bi-directional many-to-one association to TSohDtlAcctInvAttrInfo
	@OneToMany(mappedBy="TSohMstAccountInvoiceInfo")
	private List<TSohDtlAcctInvAttrInfo> TSohDtlAcctInvAttrInfos;

	public TSohMstAccountInvoiceInfo() {
	}

	public long getAccInvoiceId() {
		return this.accInvoiceId;
	}

	public void setAccInvoiceId(long accInvoiceId) {
		this.accInvoiceId = accInvoiceId;
	}

	public String getBillFlag() {
		return this.billFlag;
	}

	public void setBillFlag(String billFlag) {
		this.billFlag = billFlag;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public String getEmailId() {
		return this.emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public BigDecimal getEmailVerifyStatus() {
		return this.emailVerifyStatus;
	}

	public void setEmailVerifyStatus(BigDecimal emailVerifyStatus) {
		this.emailVerifyStatus = emailVerifyStatus;
	}

	public String getInvoiceNameArabic() {
		return this.invoiceNameArabic;
	}

	public void setInvoiceNameArabic(String invoiceNameArabic) {
		this.invoiceNameArabic = invoiceNameArabic;
	}

	public String getInvoiceNameEng() {
		return this.invoiceNameEng;
	}

	public void setInvoiceNameEng(String invoiceNameEng) {
		this.invoiceNameEng = invoiceNameEng;
	}

	public String getInvoiceRequiredFlag() {
		return this.invoiceRequiredFlag;
	}

	public void setInvoiceRequiredFlag(String invoiceRequiredFlag) {
		this.invoiceRequiredFlag = invoiceRequiredFlag;
	}

	public String getInvoiceTypeId() {
		return this.invoiceTypeId;
	}

	public void setInvoiceTypeId(String invoiceTypeId) {
		this.invoiceTypeId = invoiceTypeId;
	}

	public String getMobile() {
		return this.mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getNoBillRequiredFlag() {
		return this.noBillRequiredFlag;
	}

	public void setNoBillRequiredFlag(String noBillRequiredFlag) {
		this.noBillRequiredFlag = noBillRequiredFlag;
	}

	public BigDecimal getPreferedDeliveryMode() {
		return this.preferedDeliveryMode;
	}

	public void setPreferedDeliveryMode(BigDecimal preferedDeliveryMode) {
		this.preferedDeliveryMode = preferedDeliveryMode;
	}

	public BigDecimal getUsageClassification() {
		return this.usageClassification;
	}

	public void setUsageClassification(BigDecimal usageClassification) {
		this.usageClassification = usageClassification;
	}

	public List<TSohDtlAccountInvoiceInfo> getTSohDtlAccountInvoiceInfos() {
		return this.TSohDtlAccountInvoiceInfos;
	}

	public void setTSohDtlAccountInvoiceInfos(List<TSohDtlAccountInvoiceInfo> TSohDtlAccountInvoiceInfos) {
		this.TSohDtlAccountInvoiceInfos = TSohDtlAccountInvoiceInfos;
	}

	public TSohDtlAccountInvoiceInfo addTSohDtlAccountInvoiceInfo(TSohDtlAccountInvoiceInfo TSohDtlAccountInvoiceInfo) {
		getTSohDtlAccountInvoiceInfos().add(TSohDtlAccountInvoiceInfo);
		TSohDtlAccountInvoiceInfo.setTSohMstAccountInvoiceInfo(this);

		return TSohDtlAccountInvoiceInfo;
	}

	public TSohDtlAccountInvoiceInfo removeTSohDtlAccountInvoiceInfo(TSohDtlAccountInvoiceInfo TSohDtlAccountInvoiceInfo) {
		getTSohDtlAccountInvoiceInfos().remove(TSohDtlAccountInvoiceInfo);
		TSohDtlAccountInvoiceInfo.setTSohMstAccountInvoiceInfo(null);

		return TSohDtlAccountInvoiceInfo;
	}

	public List<TSohDtlAcctInvAttrInfo> getTSohDtlAcctInvAttrInfos() {
		return this.TSohDtlAcctInvAttrInfos;
	}

	public void setTSohDtlAcctInvAttrInfos(List<TSohDtlAcctInvAttrInfo> TSohDtlAcctInvAttrInfos) {
		this.TSohDtlAcctInvAttrInfos = TSohDtlAcctInvAttrInfos;
	}

	public TSohDtlAcctInvAttrInfo addTSohDtlAcctInvAttrInfo(TSohDtlAcctInvAttrInfo TSohDtlAcctInvAttrInfo) {
		getTSohDtlAcctInvAttrInfos().add(TSohDtlAcctInvAttrInfo);
		TSohDtlAcctInvAttrInfo.setTSohMstAccountInvoiceInfo(this);

		return TSohDtlAcctInvAttrInfo;
	}

	public TSohDtlAcctInvAttrInfo removeTSohDtlAcctInvAttrInfo(TSohDtlAcctInvAttrInfo TSohDtlAcctInvAttrInfo) {
		getTSohDtlAcctInvAttrInfos().remove(TSohDtlAcctInvAttrInfo);
		TSohDtlAcctInvAttrInfo.setTSohMstAccountInvoiceInfo(null);

		return TSohDtlAcctInvAttrInfo;
	}

}