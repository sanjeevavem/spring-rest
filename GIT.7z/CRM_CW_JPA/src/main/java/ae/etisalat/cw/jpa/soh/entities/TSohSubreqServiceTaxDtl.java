package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the T_SOH_SUBREQ_SERVICE_TAX_DTLS database table.
 * 
 */
@Entity
@Table(name="T_SOH_SUBREQ_SERVICE_TAX_DTLS")
@NamedQuery(name="TSohSubreqServiceTaxDtl.findAll", query="SELECT t FROM TSohSubreqServiceTaxDtl t")
public class TSohSubreqServiceTaxDtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SUBREQ_SERV_TAX_ID")
	private long subreqServTaxId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="TAX_AMOUNT")
	private BigDecimal taxAmount;

	@Column(name="TAX_CODE")
	private String taxCode;

	@Column(name="TAX_RATIO")
	private String taxRatio;

	@Column(name="TOTAL_PREPAYMENT_AMOUNT")
	private BigDecimal totalPrepaymentAmount;
	
	//bi-directional many-to-one association to TSohSubreqServiceDetail
	@ManyToOne
	@JoinColumn(name="SUBREQ_SERV_ID")
	private TSohSubreqServiceDetail TSohSubreqServiceDetail;

	public TSohSubreqServiceTaxDtl() {
	}

	public long getSubreqServTaxId() {
		return this.subreqServTaxId;
	}

	public void setSubreqServTaxId(long subreqServTaxId) {
		this.subreqServTaxId = subreqServTaxId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getTaxAmount() {
		return this.taxAmount;
	}

	public void setTaxAmount(BigDecimal taxAmount) {
		this.taxAmount = taxAmount;
	}

	public String getTaxCode() {
		return this.taxCode;
	}

	public void setTaxCode(String taxCode) {
		this.taxCode = taxCode;
	}

	public String getTaxRatio() {
		return this.taxRatio;
	}

	public void setTaxRatio(String taxRatio) {
		this.taxRatio = taxRatio;
	}

	public BigDecimal getTotalPrepaymentAmount() {
		return this.totalPrepaymentAmount;
	}

	public void setTotalPrepaymentAmount(BigDecimal totalPrepaymentAmount) {
		this.totalPrepaymentAmount = totalPrepaymentAmount;
	}
	
	public TSohSubreqServiceDetail getTSohSubreqServiceDetail() {
		return this.TSohSubreqServiceDetail;
	}

	public void setTSohSubreqServiceDetail(TSohSubreqServiceDetail TSohSubreqServiceDetail) {
		this.TSohSubreqServiceDetail = TSohSubreqServiceDetail;
	}

}