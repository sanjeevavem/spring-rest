package ae.etisalat.cw.jpa.cms.entities;

import java.io.Serializable;

import javax.persistence.*;

import java.math.BigDecimal;
import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the T_CMS_PARTY_ADDRESS database table.
 * 
 */
@Entity
@Table(name="T_CMS_PARTY_ADDRESS")
@NamedQuery(name="TCmsPartyAddress.findAll", query="SELECT t FROM TCmsPartyAddress t")
public class TCmsPartyAddress implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ADDRESS_ID")
	private BigDecimal addressId;

	@Column(name="ADDRESS_LINE1")
	private String addressLine1;

	@Column(name="ADDRESS_LINE2")
	private String addressLine2;

	@Column(name="ADDRESS_TYPE_ID")
	private String addressTypeId;

	@Column(name="ARABIC_ADDRESS_L1")
	private String arabicAddressL1;

	@Column(name="ARABIC_ADDRESS_L2")
	private String arabicAddressL2;

	private String area;

	@Column(name="BUILDING_ID")
	private BigDecimal buildingId;

	private String city;

	@Column(name="COMMUNITY_ID")
	private BigDecimal communityId;

	private BigDecimal country;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="DWELLING_UNIT_ID")
	private BigDecimal dwellingUnitId;

	private String emirate;

	@Temporal(TemporalType.DATE)
	@Column(name="EXPIRY_DATE")
	private Date expiryDate;

	@Column(name="INTL_CITY")
	private String intlCity;

	@Column(name="INTL_FLAT_NO")
	private BigDecimal intlFlatNo;

	@Column(name="INTL_STREET_NAME")
	private String intlStreetName;

	@Column(name="INTL_STREET_NO")
	private BigDecimal intlStreetNo;

	@Column(name="IS_LOCAL")
	private String isLocal;

	private BigDecimal mandatory;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="PARTY_ID")
	private BigDecimal partyId;

	@Column(name="PO_BOX")
	private String poBox;

	@Column(name="POBOX_NO")
	private BigDecimal poboxNo;

	@Column(name="\"PRIMARY\"")
	private String primary;

	@Column(name="PROFILE_ID")
	private BigDecimal profileId;

	@Column(name="REGION_ID")
	private BigDecimal regionId;

	private String remarks;

	@Column(name="\"STATE\"")
	private String state;

	private String street;

	@Column(name="STREET_ID")
	private BigDecimal streetId;

	@Column(name="ZIP_CODE")
	private BigDecimal zipCode;

	@Column(name="ZONE_ID")
	private BigDecimal zoneId;
	
	@Transient
	private String action;

	public TCmsPartyAddress() {
	}

	public BigDecimal getAddressId() {
		return this.addressId;
	}

	public void setAddressId(BigDecimal addressId) {
		this.addressId = addressId;
	}

	public String getAddressLine1() {
		return this.addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return this.addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getAddressTypeId() {
		return this.addressTypeId;
	}

	public void setAddressTypeId(String addressTypeId) {
		this.addressTypeId = addressTypeId;
	}

	public String getArabicAddressL1() {
		return this.arabicAddressL1;
	}

	public void setArabicAddressL1(String arabicAddressL1) {
		this.arabicAddressL1 = arabicAddressL1;
	}

	public String getArabicAddressL2() {
		return this.arabicAddressL2;
	}

	public void setArabicAddressL2(String arabicAddressL2) {
		this.arabicAddressL2 = arabicAddressL2;
	}

	public String getArea() {
		return this.area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public BigDecimal getBuildingId() {
		return this.buildingId;
	}

	public void setBuildingId(BigDecimal buildingId) {
		this.buildingId = buildingId;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public BigDecimal getCommunityId() {
		return this.communityId;
	}

	public void setCommunityId(BigDecimal communityId) {
		this.communityId = communityId;
	}

	public BigDecimal getCountry() {
		return this.country;
	}

	public void setCountry(BigDecimal country) {
		this.country = country;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public BigDecimal getDwellingUnitId() {
		return this.dwellingUnitId;
	}

	public void setDwellingUnitId(BigDecimal dwellingUnitId) {
		this.dwellingUnitId = dwellingUnitId;
	}

	public String getEmirate() {
		return this.emirate;
	}

	public void setEmirate(String emirate) {
		this.emirate = emirate;
	}

	public Date getExpiryDate() {
		return this.expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getIntlCity() {
		return this.intlCity;
	}

	public void setIntlCity(String intlCity) {
		this.intlCity = intlCity;
	}

	public BigDecimal getIntlFlatNo() {
		return this.intlFlatNo;
	}

	public void setIntlFlatNo(BigDecimal intlFlatNo) {
		this.intlFlatNo = intlFlatNo;
	}

	public String getIntlStreetName() {
		return this.intlStreetName;
	}

	public void setIntlStreetName(String intlStreetName) {
		this.intlStreetName = intlStreetName;
	}

	public BigDecimal getIntlStreetNo() {
		return this.intlStreetNo;
	}

	public void setIntlStreetNo(BigDecimal intlStreetNo) {
		this.intlStreetNo = intlStreetNo;
	}

	public String getIsLocal() {
		return this.isLocal;
	}

	public void setIsLocal(String isLocal) {
		this.isLocal = isLocal;
	}

	public BigDecimal getMandatory() {
		return this.mandatory;
	}

	public void setMandatory(BigDecimal mandatory) {
		this.mandatory = mandatory;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getPartyId() {
		return this.partyId;
	}

	public void setPartyId(BigDecimal partyId) {
		this.partyId = partyId;
	}

	public String getPoBox() {
		return this.poBox;
	}

	public void setPoBox(String poBox) {
		this.poBox = poBox;
	}

	public BigDecimal getPoboxNo() {
		return this.poboxNo;
	}

	public void setPoboxNo(BigDecimal poboxNo) {
		this.poboxNo = poboxNo;
	}

	public String getPrimary() {
		return this.primary;
	}

	public void setPrimary(String primary) {
		this.primary = primary;
	}

	public BigDecimal getProfileId() {
		return this.profileId;
	}

	public void setProfileId(BigDecimal profileId) {
		this.profileId = profileId;
	}

	public BigDecimal getRegionId() {
		return this.regionId;
	}

	public void setRegionId(BigDecimal regionId) {
		this.regionId = regionId;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getStreet() {
		return this.street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public BigDecimal getStreetId() {
		return this.streetId;
	}

	public void setStreetId(BigDecimal streetId) {
		this.streetId = streetId;
	}

	public BigDecimal getZipCode() {
		return this.zipCode;
	}

	public void setZipCode(BigDecimal zipCode) {
		this.zipCode = zipCode;
	}

	public BigDecimal getZoneId() {
		return this.zoneId;
	}

	public void setZoneId(BigDecimal zoneId) {
		this.zoneId = zoneId;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

}