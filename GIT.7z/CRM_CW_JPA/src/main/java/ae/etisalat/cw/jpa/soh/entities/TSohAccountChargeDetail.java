package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the T_SOH_ACCOUNT_CHARGE_DETAILS database table.
 * 
 */
@Entity
@Table(name="T_SOH_ACCOUNT_CHARGE_DETAILS")
@NamedQuery(name="TSohAccountChargeDetail.findAll", query="SELECT t FROM TSohAccountChargeDetail t")
public class TSohAccountChargeDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_SOH_ACCOUNT_CHARGE_DETAILS_ACCOUNTCHARGEID_GENERATOR", sequenceName="SQ_T_SOH_ACCOUNT_CHARGE_DTL",allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_SOH_ACCOUNT_CHARGE_DETAILS_ACCOUNTCHARGEID_GENERATOR")
	@Column(name="ACCOUNT_CHARGE_ID")
	private long accountChargeId;

	@Column(name="ACCOUNT_ID")
	private BigDecimal accountId;

	@Column(name="BILLED_UP_TO_DATE")
	private Timestamp billedUpToDate;

	@Column(name="CHARGE_TYPE_FLAG")
	private String chargeTypeFlag;

	@Column(name="CHARGE_TYPE_ID")
	private BigDecimal chargeTypeId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="NUMBER_OF_INSTALLMENTS")
	private BigDecimal numberOfInstallments;

	@Temporal(TemporalType.DATE)
	@Column(name="OFFSET_DATE")
	private Date offsetDate;

	@Temporal(TemporalType.DATE)
	@Column(name="PRESET_DATE")
	private Date presetDate;

	@Column(name="RATE_PLAN_ID")
	private BigDecimal ratePlanId;

	//bi-directional many-to-one association to TSohAccountServiceDetail
	@ManyToOne
	@JoinColumn(name="ACCOUNT_SERVICE_ID")
	private TSohAccountServiceDetail TSohAccountServiceDetail;

	public TSohAccountChargeDetail() {
	}

	public long getAccountChargeId() {
		return this.accountChargeId;
	}

	public void setAccountChargeId(long accountChargeId) {
		this.accountChargeId = accountChargeId;
	}

	public BigDecimal getAccountId() {
		return this.accountId;
	}

	public void setAccountId(BigDecimal accountId) {
		this.accountId = accountId;
	}

	public Timestamp getBilledUpToDate() {
		return this.billedUpToDate;
	}

	public void setBilledUpToDate(Timestamp billedUpToDate) {
		this.billedUpToDate = billedUpToDate;
	}

	public String getChargeTypeFlag() {
		return this.chargeTypeFlag;
	}

	public void setChargeTypeFlag(String chargeTypeFlag) {
		this.chargeTypeFlag = chargeTypeFlag;
	}

	public BigDecimal getChargeTypeId() {
		return this.chargeTypeId;
	}

	public void setChargeTypeId(BigDecimal chargeTypeId) {
		this.chargeTypeId = chargeTypeId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getNumberOfInstallments() {
		return this.numberOfInstallments;
	}

	public void setNumberOfInstallments(BigDecimal numberOfInstallments) {
		this.numberOfInstallments = numberOfInstallments;
	}

	public Date getOffsetDate() {
		return this.offsetDate;
	}

	public void setOffsetDate(Date offsetDate) {
		this.offsetDate = offsetDate;
	}

	public Date getPresetDate() {
		return this.presetDate;
	}

	public void setPresetDate(Date presetDate) {
		this.presetDate = presetDate;
	}

	public BigDecimal getRatePlanId() {
		return this.ratePlanId;
	}

	public void setRatePlanId(BigDecimal ratePlanId) {
		this.ratePlanId = ratePlanId;
	}

	public TSohAccountServiceDetail getTSohAccountServiceDetail() {
		return this.TSohAccountServiceDetail;
	}

	public void setTSohAccountServiceDetail(TSohAccountServiceDetail TSohAccountServiceDetail) {
		this.TSohAccountServiceDetail = TSohAccountServiceDetail;
	}

}