package ae.etisalat.cw.jpa.soh.daos;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import ae.etisalat.cw.jpa.psm.entities.TPsmMstPackage;
import ae.etisalat.cw.jpa.psm.entities.TPsmMstRatePlan;
import ae.etisalat.cw.jpa.psm.entities.TPsmPkgExitPolicy;
import ae.etisalat.cw.jpa.psm.entities.TPsmRpExitPolicy;
import ae.etisalat.cw.jpa.soh.entities.TSohAccount;
import ae.etisalat.cw.jpa.soh.entities.TSohAccountInstanceDetail;
import ae.etisalat.cw.jpa.soh.entities.TSohAccountServiceDetail;
import ae.etisalat.cw.jpa.soh.entities.TSohAccountStatusSrtMap;
import ae.etisalat.cw.jpa.soh.entities.TSohElifeOcvOfferMap;
import ae.etisalat.cw.jpa.soh.entities.TSohSubscriptionPackageDtl;
import ae.etisalat.cw.jpa.soh.entities.TSohSubscriptionRateplnDtl;
import ae.etisalat.cw.restws.clients.OfferingDetailsList;

@Repository
@Transactional
public class AccountServiceCreationDao{

	private static final Logger logger = LogManager.getLogger(AccountServiceCreationDao.class);

	@PersistenceContext
	private EntityManager em;

	public List<PkgRpAcctSrvcInstMapping> createAccountServiceDtls(Long subRequestTypeId,TSohAccount account,
			List<OfferingDetailsList> offeringDetailsLists) throws Exception {
		List<PkgRpAcctSrvcInstMapping> rpSrvcMappingList=new ArrayList<>();
		try{
			rpSrvcMappingList=constructPkgRpAcctSrvcInstList(offeringDetailsLists);
			TSohSubscriptionPackageDtl packageDtl=null;
			if(rpSrvcMappingList!=null && rpSrvcMappingList.size()>0){
				TSohAccountStatusSrtMap tSohAccountStatusSrtMap = (TSohAccountStatusSrtMap) em.createNamedQuery("TSohAccountStatusSrtMap.findBySubreqTypeId")
						.setParameter("subRequestTypeId", subRequestTypeId).setParameter("deletionStatus", "N").getSingleResult();
				for(PkgRpAcctSrvcInstMapping rpSrvc:rpSrvcMappingList){	 
					if( rpSrvc.getSrvcCategoryId() != null && rpSrvc.getSrvcCategoryId()==9)
						packageDtl=persistPkgDetails(account,rpSrvc);
				}
				for(PkgRpAcctSrvcInstMapping rpSrvc:rpSrvcMappingList){					
					TSohAccountServiceDetail tSohAccountServiceDetail = new TSohAccountServiceDetail();
					if(rpSrvc.getSrvcCategoryId()==9)
						tSohAccountServiceDetail.setIsPrimaryServiceFlag("0");
					else
						tSohAccountServiceDetail.setIsPrimaryServiceFlag("1");
					tSohAccountServiceDetail.setEffectiveFromDate(new Timestamp(new Date().getTime()));
					tSohAccountServiceDetail.setServiceId(new BigDecimal(rpSrvc.getSrvcId()));
					tSohAccountServiceDetail.setAccountId(new BigDecimal(account.getAccountId()));
					//tSohAccountServiceDetail.setRetailerId(accoun t.getre); need clarification
					//tSohAccountServiceDetail.setSponsorFlag(tSohSubrequest.getSponsorFlag());
					tSohAccountServiceDetail.setBadDebtFlag("N");
					tSohAccountServiceDetail.setNoOfInstances(new BigDecimal(rpSrvc.getQuantity()));
					tSohAccountServiceDetail.setCreditStatusId(BigDecimal.valueOf(54));
					tSohAccountServiceDetail.setDateAcctStat(new Timestamp(new Date().getTime()));					
					tSohAccountServiceDetail.setServiceStatusId(new BigDecimal(tSohAccountStatusSrtMap.getTSohDtlSystemCodeValue2().getSystemCodeValueId()));	
					tSohAccountServiceDetail.setProductType("POSTPAID");
					tSohAccountServiceDetail.setCreatedUserId(account.getCreatedUserId());
					tSohAccountServiceDetail.setCreatedDate(new Timestamp(new Date().getTime()));
					tSohAccountServiceDetail.setModifiedUserId(account.getModifiedUserId());
					tSohAccountServiceDetail.setModifiedDate(new Timestamp(new Date().getTime()));
					tSohAccountServiceDetail.setDeletionStatus("N");
					tSohAccountServiceDetail.setNoOfInstances(new BigDecimal(rpSrvc.getQuantity()));
					em.persist(tSohAccountServiceDetail);
					BigDecimal quantity=new BigDecimal(rpSrvc.getQuantity());
					List<Long> acctInstList=new ArrayList<Long>();
					for (int j = 0; j < quantity.intValue(); j++) {
						TSohAccountInstanceDetail acctInst=constructAcctInstDtl(account.getCreatedUserId(), tSohAccountServiceDetail);
						em.persist(acctInst);
						acctInstList.add(acctInst.getAccServInstanceId());						
					}
					persistRatePlanDetails(tSohAccountServiceDetail,account,rpSrvc,packageDtl);
					rpSrvc.setAcctSrvcId(tSohAccountServiceDetail.getAccountServiceId());
					rpSrvc.setAcctSrvcInstanceId(acctInstList);
				}
			}

		}catch (Exception e) {
			logger.error("Exception while performing createServiceDetails", e);
			rpSrvcMappingList=null;
			throw e;
		}
		return rpSrvcMappingList;
	}

	public List<PkgRpAcctSrvcInstMapping> constructPkgRpAcctSrvcInstList(List<OfferingDetailsList> offeringDetailsLists) throws Exception{		
		List<PkgRpAcctSrvcInstMapping> rpAcctSrvcInstMappings=new ArrayList<PkgRpAcctSrvcInstMapping>();
		if(offeringDetailsLists!=null && offeringDetailsLists.size()>0){
			for(OfferingDetailsList offerDtl:offeringDetailsLists){
				PkgRpAcctSrvcInstMapping pkgRpDtl=new PkgRpAcctSrvcInstMapping();
				if(offerDtl.isMainOffer()){
					pkgRpDtl.setPackageCode(getOcvCBCMMappingCode(null,offerDtl.getPOCODE(), offerDtl.getCPOPCODE()));
					List<Object[]> pkgRpDtlList=fetchPkgDetails(pkgRpDtl.getPackageCode());
					if(pkgRpDtlList != null && !pkgRpDtlList.isEmpty()){
						for(Object[] pkgRpInfo:pkgRpDtlList){
							PkgRpAcctSrvcInstMapping pkgRp=new PkgRpAcctSrvcInstMapping();
							pkgRp.setPackageCode(pkgRpDtl.getPackageCode());
							if(((Object[])pkgRpInfo)[0]!=null)
								pkgRp.setRatePlanId(((BigDecimal)((Object[])pkgRpInfo)[0]).longValue());
							pkgRp.setRatePlanCode((String)((Object[])pkgRpInfo)[1]);
							if(((Object[])pkgRpInfo)[2]!=null)
								pkgRp.setSrvcCategoryId(((BigDecimal)((Object[])pkgRpInfo)[2]).longValue());
							if(((Object[])pkgRpInfo)[3]!=null)
								pkgRp.setSrvcId(((BigDecimal)((Object[])pkgRpInfo)[3]).longValue());
							if(((Object[])pkgRpInfo)[4]!=null)
								pkgRp.setPackageId(((BigDecimal)((Object[])pkgRpInfo)[4]).longValue());
							pkgRp.setQuantity(offerDtl.getQuantity());
							if(pkgRp.getPackageId()!=null) 
								rpAcctSrvcInstMappings.add(pkgRp);
						}
					}
				}else{
					pkgRpDtl.setRatePlanCode(getOcvCBCMMappingCode(null,offerDtl.getPOCODE(), offerDtl.getCPOPCODE()));
					List<Object[]> ratePlanDtls= fetchRatePlanDetails(pkgRpDtl.getRatePlanCode());
					if(ratePlanDtls != null && !ratePlanDtls.isEmpty()){
						if(((Object[])ratePlanDtls.get(0))[0]!=null)
							pkgRpDtl.setRatePlanId(((BigDecimal)((Object[])ratePlanDtls.get(0))[0]).longValue());
						if(((Object[])ratePlanDtls.get(0))[1]!=null)
							pkgRpDtl.setSrvcCategoryId(((BigDecimal)((Object[])ratePlanDtls.get(0))[1]).longValue());
						if(((Object[])ratePlanDtls.get(0))[2]!=null)
							pkgRpDtl.setSrvcId(((BigDecimal)((Object[])ratePlanDtls.get(0))[2]).longValue());
						pkgRpDtl.setQuantity(offerDtl.getQuantity());
						if(pkgRpDtl.getPackageId()==null || (pkgRpDtl.getPackageId()!=null && pkgRpDtl.getPackageId()==0) && pkgRpDtl.getRatePlanId() != null)
							rpAcctSrvcInstMappings.add(pkgRpDtl);
					}

				}
			}
		}
		return rpAcctSrvcInstMappings;

	}

	@SuppressWarnings({ "unchecked"})
	public String getOcvCBCMMappingCode(String cbcmRp,String ocvPoCode, String cpopCode)throws Exception{
		String mappingCode=null;
		List<String> mappingCodeList=new ArrayList<String>();
		List<TSohElifeOcvOfferMap> offerList=new ArrayList<TSohElifeOcvOfferMap>();
		try{
			if(cbcmRp!=null && cbcmRp.trim().length()>0){
				mappingCodeList=(List<String>)em.createQuery("select t.ocvOffercode from TSohElifeOcvOfferMap t where t.cbcmRatePlanCode = :cbcmRp")
						.setParameter("cbcmRp", cbcmRp).getResultList();
				if(mappingCodeList==null || (mappingCodeList!=null && mappingCodeList.size()==0))
					mappingCodeList=(List<String>)em.createQuery("select t.ocvOffercode from TSohElifeOcvOfferMap t where t.cbcmPackageCode = :cbcmRp")
					.setParameter("cbcmRp", cbcmRp).getResultList();
				if(mappingCodeList==null || (mappingCodeList!=null && mappingCodeList.size()==0))
					mappingCodeList=(List<String>)em.createQuery("select t.ocvOffercode from TSohElifeOcvOfferMap t where t.cbcmBundleCode = :cbcmRp")
					.setParameter("cbcmRp", cbcmRp).getResultList();
			}
			if(ocvPoCode!=null && ocvPoCode.trim().length()>0 ){
				String SQL = "SELECT  t from TSohElifeOcvOfferMap t WHERE t.ocvOffercode = :ocvRp ";
				if(cpopCode != null && cpopCode.trim().length() != 0){
					SQL += "AND t.ocvCpopCode    = :cpopCode";
					offerList=(List<TSohElifeOcvOfferMap>)em.createQuery(SQL).setParameter("ocvRp", ocvPoCode).setParameter("cpopCode", cpopCode).getResultList();
				}else
					offerList=(List<TSohElifeOcvOfferMap>)em.createQuery(SQL).setParameter("ocvRp", ocvPoCode).getResultList();
			}
			if(offerList!=null && offerList.size()>0){
				if(offerList.get(0).getCbcmBundleCode()!=null && offerList.get(0).getCbcmBundleCode().trim().length()>0)
					return  mappingCode=offerList.get(0).getCbcmBundleCode();
				else if (offerList.get(0).getCbcmPackageCode()!=null && offerList.get(0).getCbcmPackageCode().trim().length()>0)
					return  mappingCode=offerList.get(0).getCbcmPackageCode();
				else if (offerList.get(0).getCbcmRatePlanCode()!=null && offerList.get(0).getCbcmRatePlanCode().trim().length()>0)
					return  mappingCode=offerList.get(0).getCbcmRatePlanCode();
			}
			if(mappingCodeList!=null && mappingCodeList.size()>0)
				mappingCode=mappingCodeList.get(0);
			
			System.out.println(mappingCode);
		}catch(Exception e){e.printStackTrace();}
		return mappingCode;
	}

	protected TSohAccountInstanceDetail constructAcctInstDtl(String userId, TSohAccountServiceDetail acctSrvceDtl) {
		TSohAccountInstanceDetail accInstDtl = new TSohAccountInstanceDetail();
		accInstDtl.setTSohAccountServiceDetail(acctSrvceDtl);
		accInstDtl.setCreatedUserId(userId);
		accInstDtl.setCreatedDate(new Timestamp(new Date().getTime()));
		accInstDtl.setModifiedUserId(userId);
		accInstDtl.setModifiedDate(new Timestamp(new Date().getTime()));
		accInstDtl.setDeletionStatus("N");
		return accInstDtl;
	}

	protected TSohSubscriptionPackageDtl persistPkgDetails(TSohAccount tSohAccount,PkgRpAcctSrvcInstMapping pkgRpDtls){
		TSohSubscriptionPackageDtl tSohSubscriptionPackageDtl =new TSohSubscriptionPackageDtl();
		tSohSubscriptionPackageDtl.setPackageId(new BigDecimal(pkgRpDtls.getPackageId()));
		tSohSubscriptionPackageDtl.setAccountId(new BigDecimal(tSohAccount.getAccountId()));
		tSohSubscriptionPackageDtl.setEffectiveFromDate(new Timestamp(new Date().getTime()));
		TPsmMstPackage mstPackage = getMstPackageDtl(pkgRpDtls.getPackageId(),false);
		List<TPsmPkgExitPolicy> exitpckPolicy = getExitPolicyforPck(pkgRpDtls.getPackageId(), mstPackage.getId().getEffectiveFromDate());

		long exitpckPolicyId = 0;
		if (exitpckPolicy != null && exitpckPolicy.size() > 0) {
			exitpckPolicyId = exitpckPolicy.get(0).getId().getExitCriteriaId();
		}
		if (exitpckPolicyId > 0) {
			tSohSubscriptionPackageDtl.setExitPlcyFlag("Y");
			tSohSubscriptionPackageDtl.setExitPlcyId(BigDecimal.valueOf(exitpckPolicyId));
		} else {
			tSohSubscriptionPackageDtl.setExitPlcyFlag("N");
			tSohSubscriptionPackageDtl.setExitPlcyId(BigDecimal.valueOf(0));
			tSohSubscriptionPackageDtl.setSubscriptionRenewalDate(null);
		}
		tSohSubscriptionPackageDtl.setAutoRenewalFlag("N");
		tSohSubscriptionPackageDtl.setCreatedUserId(tSohAccount.getCreatedUserId());
		tSohSubscriptionPackageDtl.setCreatedDate(new Timestamp(new Date().getTime()));
		tSohSubscriptionPackageDtl.setModifiedUserId(tSohAccount.getModifiedUserId());
		tSohSubscriptionPackageDtl.setModifiedDate(new Timestamp(new Date().getTime()));
		tSohSubscriptionPackageDtl.setDeletionStatus("N");
		em.persist(tSohSubscriptionPackageDtl);
		em.flush();
		return tSohSubscriptionPackageDtl;
	}

	protected void persistRatePlanDetails(TSohAccountServiceDetail tSohAccountServiceDetail,TSohAccount tSohAccount,PkgRpAcctSrvcInstMapping pkgRpDtls,TSohSubscriptionPackageDtl packageDtl){
		TSohSubscriptionRateplnDtl tSohSubscriptionRateplnDtl = new TSohSubscriptionRateplnDtl();		
		tSohSubscriptionRateplnDtl.setAccountId(BigDecimal.valueOf(tSohAccount.getAccountId()));
		tSohSubscriptionRateplnDtl.setTSohAccountServiceDetail(tSohAccountServiceDetail);
		tSohSubscriptionRateplnDtl.setBillingRegionId(tSohAccount.getRegionId());
		tSohSubscriptionRateplnDtl.setEffectiveFromDate(new Timestamp(new Date().getTime()));
		tSohSubscriptionRateplnDtl.setEffectiveTillDate(null);
		tSohSubscriptionRateplnDtl.setRatePlanId(BigDecimal.valueOf(pkgRpDtls.getRatePlanId()));		
		if (pkgRpDtls.getPackageId()!=null && pkgRpDtls.getPackageId() != 0){
			System.out.println("here");
			tSohSubscriptionRateplnDtl.setTSohSubscriptionPackageDtl(packageDtl);
		}
		tSohSubscriptionRateplnDtl.setAutoRenewalFlag("N");
		tSohSubscriptionRateplnDtl.setCreatedUserId(tSohAccount.getCreatedUserId());
		tSohSubscriptionRateplnDtl.setCreatedDate(new Timestamp(new Date().getTime()));
		tSohSubscriptionRateplnDtl.setModifiedUserId(tSohAccount.getModifiedUserId());
		tSohSubscriptionRateplnDtl.setModifiedDate(new Timestamp(new Date().getTime()));
		tSohSubscriptionRateplnDtl.setDeletionStatus("N");
		TPsmMstRatePlan mstRatePlan = getMstRatePlanDtl(pkgRpDtls.getRatePlanId());
		List<TPsmRpExitPolicy> exitRPPolicy = null;
		if (mstRatePlan != null) {
			logger.info("+++++++++++++++++++++++++ RATE PLANE ENTITY >>>>>" + mstRatePlan != null ? mstRatePlan.getRatePlanCode() : mstRatePlan);
			exitRPPolicy = getExitPolicyforRP(pkgRpDtls.getRatePlanId(), mstRatePlan.getId().getEffectiveFromDate());
			if (exitRPPolicy != null) {
				logger.info("++++++++++++++++++++++++++++++++++++++++++>" + exitRPPolicy != null && exitRPPolicy.size() > 0 ? exitRPPolicy.get(0).getId().getExitCriteriaId() : exitRPPolicy);
			}
		}

		long exitRPPolicyId = 0;
		if (exitRPPolicy != null && exitRPPolicy.size() > 0) {
			exitRPPolicyId = exitRPPolicy.get(0).getId().getExitCriteriaId();
		}

		if (exitRPPolicyId > 0) {
			tSohSubscriptionRateplnDtl.setExitPlcyFlag("Y");
			tSohSubscriptionRateplnDtl.setExitPlcyId(BigDecimal.valueOf(exitRPPolicyId));
		} else {
			tSohSubscriptionRateplnDtl.setExitPlcyFlag("N");
			tSohSubscriptionRateplnDtl.setExitPlcyId(BigDecimal.valueOf(0));
			tSohSubscriptionRateplnDtl.setSubscriptionRenewalDate(null);
		}
		em.persist(tSohSubscriptionRateplnDtl);
	}

	public TPsmMstPackage getMstPackageDtl(Long packageId,boolean isbyPassTillDateAllowed) {
		long start = System.currentTimeMillis();
		try {
			String queryStr = "select a from TPsmMstPackage a where a.id.packageId= :packageId ";
			if(! isbyPassTillDateAllowed){	
				queryStr+= "and a.deletionStatus =:deletionStatus "
						+ "and (a.effectiveTillDate > CURRENT_TIMESTAMP or  a.effectiveTillDate IS NULL) "
						+ "and (a.offerFromDate < CURRENT_TIMESTAMP)";
			}
			Query query = em.createQuery(queryStr);
			logger.debug(query.toString() + " Parameters are " + packageId);
			query.setParameter("packageId", packageId);
			if(! isbyPassTillDateAllowed){
				query.setParameter("deletionStatus", "N");
			}
			query.setMaxResults(1);
			TPsmMstPackage tPsmMstPackage = getFirstObjectFromList(query.getResultList());
			if (tPsmMstPackage != null) {
				logger.info("TPsmMstPackage has been fetched in " + (System.currentTimeMillis() - start) + " milliseconds");
				return tPsmMstPackage;
			}
		} catch (Exception e) {
			logger.error("Exception", e);
		} finally {
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public List<TPsmPkgExitPolicy> getExitPolicyforPck(Long packageId, Date effectiveFromDate) {

		logger.debug(" Entering into getExitPolicyforPck -packageId ::" + packageId + "packageId ::" + packageId);
		long start = System.currentTimeMillis();
		try {
			Query query = em.createQuery("select a from TPsmPkgExitPolicy a where a.id.packageId= :packageId and a.deletionStatus =:deletionStatus and a.id.effectiveFromDate = :effectiveFromDate");
			logger.debug(query.toString() + " Parameters are " + packageId);
			query.setParameter("packageId", packageId);
			query.setParameter("deletionStatus", "N");
			query.setParameter("effectiveFromDate", effectiveFromDate);
			List<TPsmPkgExitPolicy> tPsmPkgExitPolicy = query.getResultList();
			if (tPsmPkgExitPolicy != null) {
				logger.info("TPsmRpExitPolicy has been fetched in " + (System.currentTimeMillis() - start) + " milliseconds");
				return tPsmPkgExitPolicy;
			}
		} catch (Exception e) {
			logger.error("Exception", e);
		} finally {
		}
		return null;
	}

	public TPsmMstRatePlan getMstRatePlanDtl(Long ratePlanId) {

		logger.debug(" Entering into getMstRatePalnDtl -ratePlanId ::" + ratePlanId + "accountId ::" + ratePlanId);
		long start = System.currentTimeMillis();
		try {
			Query query = em.createQuery("select a from TPsmMstRatePlan a where a.id.ratePlanId= :ratePlanId and a.deletionStatus =:deletionStatus and (a.effectiveTillDate > CURRENT_TIMESTAMP or  a.effectiveTillDate IS NULL) and (a.offerFromDate < CURRENT_TIMESTAMP)");
			logger.debug(query.toString() + " Parameters are " + ratePlanId);
			query.setParameter("ratePlanId", ratePlanId);
			query.setParameter("deletionStatus", "N");
			TPsmMstRatePlan tPsmMstRatePlan = getFirstObjectFromList(query.getResultList());
			if (tPsmMstRatePlan != null) {
				logger.info("TPsmMstRatePlan has been fetched in " + (System.currentTimeMillis() - start) + " milliseconds");
				return tPsmMstRatePlan;
			}
		} catch (Exception e) {
			logger.error("Exception", e);
		} finally {
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public List<TPsmRpExitPolicy> getExitPolicyforRP(Long ratePlanId, Date effectiveFromDate) {

		logger.debug(" Entering into getExitPolicyforRP -ratePlanId ::" + ratePlanId + "accountId ::" + ratePlanId);
		long start = System.currentTimeMillis();
		try {
			String qry = "select * from T_Psm_Rp_Exit_Policy a where a.rate_Plan_Id= :ratePlanId and a.deletion_Status =:deletionStatus and a.effective_From_Date = :effectiveFromDate";
			Query query = em.createNativeQuery(qry);
			logger.debug(query.toString() + " Parameters are " + ratePlanId);
			query.setParameter("ratePlanId", ratePlanId);
			query.setParameter("deletionStatus", "N");
			query.setParameter("effectiveFromDate", effectiveFromDate);
			List<TPsmRpExitPolicy> tPsmRpExitPolicy = query.getResultList();
			if (tPsmRpExitPolicy != null) {
				logger.info("TPsmRpExitPolicy has been fetched in " + (System.currentTimeMillis() - start) + " milliseconds");
				return tPsmRpExitPolicy;
			}
		} catch (Exception e) {
			logger.error("Exception", e);
		} finally {
		}
		return null;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static <T> T getFirstObjectFromList(List list){
		if(list != null && !list.isEmpty()){
			return (T) list.get(0);
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public List<Object[]> fetchRatePlanDetails(String ratePlanCode){
		List<Object[]> ratePlanDtlList =new ArrayList<Object[]>();
		ratePlanDtlList=(List<Object[]>)em.createNativeQuery("SELECT RP.RATE_PLAN_ID,SRVC.SRVC_CATEGORY_ID,SRVC.SRVC_ID FROM T_PSM_MST_RATE_PLAN RP,"
				+ "T_PSM_MST_SRVC SRVC,T_PSM_MST_SYSTEM_CODE MST,T_PSM_DTL_SYSTEM_CODE_VALUES DTL WHERE MST.SYSTEM_CODE_TYPE='SERVICECATEGORY' AND"
				+ " MST.SYSTEM_CODE_ID=DTL.SYSTEM_CODE_ID AND DTL.SYSTEM_CODE_VALUE_ID=SRVC.SRVC_CATEGORY_ID AND SRVC.EFFECTIVE_TILL_DATE IS NULL AND"
				+ " SRVC.DELETION_STATUS='N' AND MST.DELETION_STATUS='N' AND DTL.DELETION_STATUS='N' AND SRVC.SRVC_ID=RP.SRVC_ID AND"
				+ " RP.EFFECTIVE_TILL_DATE IS NULL AND RP.RATE_PLAN_CODE=?").setParameter(1, ratePlanCode).getResultList();
		return ratePlanDtlList;		
	}

	@SuppressWarnings("unchecked")
	public List<Object[]> fetchPkgDetails(String pkgCode){
		List<Object[]> pkgDtlList =new ArrayList<Object[]>();
		pkgDtlList=(List<Object[]>)em.createNativeQuery("SELECT RP.RATE_PLAN_ID,RP.RATE_PLAN_CODE,SRVC.SRVC_CATEGORY_ID,SRVC.SRVC_ID,PACK.PACKAGE_ID FROM T_PSM_MST_PACKAGE PACK,"
				+ "T_PSM_DTL_PACKAGE DPACK,T_PSM_MST_RATE_PLAN RP,T_PSM_MST_SRVC SRVC WHERE PACK.PACKAGE_ID=DPACK.PACKAGE_ID AND "
				+ "PACK.EFFECTIVE_FROM_DATE=DPACK.RP_EFFECTIVE_FROM_DATE AND PACK.EFFECTIVE_TILL_DATE IS NULL AND DPACK.RATE_PLAN_ID=RP.RATE_PLAN_ID"
				+ " AND RP.EFFECTIVE_TILL_DATE IS NULL AND RP.SRVC_ID=SRVC.SRVC_ID AND SRVC.EFFECTIVE_TILL_DATE IS NULL AND PACK.PACKAGE_CODE=?")
				.setParameter(1, pkgCode).getResultList();
		return pkgDtlList;	
	}


}
