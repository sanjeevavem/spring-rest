package ae.etisalat.cw.jpa.psm.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the T_PSM_MST_PACKAGE database table.
 * 
 */
@Entity
@Table(name="T_PSM_MST_PACKAGE")
@NamedQueries({
	@NamedQuery(name="TPsmMstPackage.findAll", query="SELECT t FROM TPsmMstPackage t"),
	@NamedQuery(name="TPsmMstPackage.findByPackageCode" ,query="SELECT t FROM TPsmMstPackage t where t.packageCode in :packageCodes and t.effectiveTillDate is null and t.deletionStatus=:deletionStatus"),
	@NamedQuery(name="TPsmMstPackage.findByCustomerType" ,query="SELECT t FROM TPsmMstPackage t where t.customerType = :customerType and t.effectiveTillDate is null and t.deletionStatus=:deletionStatus"),
	@NamedQuery(name="TPsmMstPackage.findByPackageIds",query="SELECT t FROM TPsmMstPackage t where t.id.packageId in :packageIds and t.effectiveTillDate is null and t.deletionStatus=:deletionStatus")
})
public class TPsmMstPackage implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TPsmMstPackagePK id;

	@Column(name="APPLY_PARAMETER")
	private BigDecimal applyParameter;

	@Column(name="CLASSIFICATION_ID")
	private BigDecimal classificationId;

	@Column(name="COM_NAME_ID")
	private BigDecimal comNameId;

	@Column(name="COM_SUBTYPE_ID")
	private BigDecimal comSubtypeId;

	@Column(name="CONCESSION_FLAG")
	private BigDecimal concessionFlag;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="DESCRIPTION_ID")
	private BigDecimal descriptionId;

	@Column(name="EFFECTIVE_TILL_DATE")
	private Timestamp effectiveTillDate;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="OFFER_FROM_DATE")
	private Timestamp offerFromDate;

	@Column(name="OFFER_TILL_DATE")
	private Timestamp offerTillDate;

	@Column(name="PACKAGE_CODE")
	private String packageCode;

	@Column(name="PACKAGE_REDUCTION")
	private BigDecimal packageReduction;

	@Column(name="PACKAGE_VERSION")
	private BigDecimal packageVersion;

	@Column(name="REDUCTION_INDICATOR_FLAG")
	private BigDecimal reductionIndicatorFlag;

	@Column(name="REDUCTION_MAX_LIMIT")
	private BigDecimal reductionMaxLimit;

	@Column(name="REDUCTION_PERCENTAGE")
	private BigDecimal reductionPercentage;

	private String remarks;

	private BigDecimal status;

	@Column(name="TERMS_AND_CONDS_ID")
	private BigDecimal termsAndCondsId;
	
	@Column(name="CUSTOMER_TYPE")
	private BigDecimal customerType;
	
	@Column(name="SPLIT_BILLING_FLAG")
	private String splitBillingFlag ;

	public String getSplitBillingFlag() {
		return splitBillingFlag;
	}

	public void setSplitBillingFlag(String splitBillingFlag) {
		this.splitBillingFlag = splitBillingFlag;
	}

	//bi-directional many-to-one association to TPsmDtlPackage
	@OneToMany(mappedBy="TPsmMstPackage")
	private List<TPsmDtlPackage> TPsmDtlPackages;

	public TPsmMstPackage() {
	}

	public TPsmMstPackagePK getId() {
		return this.id;
	}

	public void setId(TPsmMstPackagePK id) {
		this.id = id;
	}

	public BigDecimal getApplyParameter() {
		return this.applyParameter;
	}

	public void setApplyParameter(BigDecimal applyParameter) {
		this.applyParameter = applyParameter;
	}

	public BigDecimal getClassificationId() {
		return this.classificationId;
	}

	public void setClassificationId(BigDecimal classificationId) {
		this.classificationId = classificationId;
	}

	public BigDecimal getComNameId() {
		return this.comNameId;
	}

	public void setComNameId(BigDecimal comNameId) {
		this.comNameId = comNameId;
	}

	public BigDecimal getComSubtypeId() {
		return this.comSubtypeId;
	}

	public void setComSubtypeId(BigDecimal comSubtypeId) {
		this.comSubtypeId = comSubtypeId;
	}

	public BigDecimal getConcessionFlag() {
		return this.concessionFlag;
	}

	public void setConcessionFlag(BigDecimal concessionFlag) {
		this.concessionFlag = concessionFlag;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public BigDecimal getDescriptionId() {
		return this.descriptionId;
	}

	public void setDescriptionId(BigDecimal descriptionId) {
		this.descriptionId = descriptionId;
	}

	public Timestamp getEffectiveTillDate() {
		return this.effectiveTillDate;
	}

	public void setEffectiveTillDate(Timestamp effectiveTillDate) {
		this.effectiveTillDate = effectiveTillDate;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public Timestamp getOfferFromDate() {
		return this.offerFromDate;
	}

	public void setOfferFromDate(Timestamp offerFromDate) {
		this.offerFromDate = offerFromDate;
	}

	public Timestamp getOfferTillDate() {
		return this.offerTillDate;
	}

	public void setOfferTillDate(Timestamp offerTillDate) {
		this.offerTillDate = offerTillDate;
	}

	public String getPackageCode() {
		return this.packageCode;
	}

	public void setPackageCode(String packageCode) {
		this.packageCode = packageCode;
	}

	public BigDecimal getPackageReduction() {
		return this.packageReduction;
	}

	public void setPackageReduction(BigDecimal packageReduction) {
		this.packageReduction = packageReduction;
	}

	public BigDecimal getPackageVersion() {
		return this.packageVersion;
	}

	public void setPackageVersion(BigDecimal packageVersion) {
		this.packageVersion = packageVersion;
	}

	public BigDecimal getReductionIndicatorFlag() {
		return this.reductionIndicatorFlag;
	}

	public void setReductionIndicatorFlag(BigDecimal reductionIndicatorFlag) {
		this.reductionIndicatorFlag = reductionIndicatorFlag;
	}

	public BigDecimal getReductionMaxLimit() {
		return this.reductionMaxLimit;
	}

	public void setReductionMaxLimit(BigDecimal reductionMaxLimit) {
		this.reductionMaxLimit = reductionMaxLimit;
	}

	public BigDecimal getReductionPercentage() {
		return this.reductionPercentage;
	}

	public void setReductionPercentage(BigDecimal reductionPercentage) {
		this.reductionPercentage = reductionPercentage;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public BigDecimal getStatus() {
		return this.status;
	}

	public void setStatus(BigDecimal status) {
		this.status = status;
	}

	public BigDecimal getTermsAndCondsId() {
		return this.termsAndCondsId;
	}

	public void setTermsAndCondsId(BigDecimal termsAndCondsId) {
		this.termsAndCondsId = termsAndCondsId;
	}

	public List<TPsmDtlPackage> getTPsmDtlPackages() {
		return this.TPsmDtlPackages;
	}

	public void setTPsmDtlPackages(List<TPsmDtlPackage> TPsmDtlPackages) {
		this.TPsmDtlPackages = TPsmDtlPackages;
	}

	public TPsmDtlPackage addTPsmDtlPackage(TPsmDtlPackage TPsmDtlPackage) {
		getTPsmDtlPackages().add(TPsmDtlPackage);
		TPsmDtlPackage.setTPsmMstPackage(this);

		return TPsmDtlPackage;
	}

	public TPsmDtlPackage removeTPsmDtlPackage(TPsmDtlPackage TPsmDtlPackage) {
		getTPsmDtlPackages().remove(TPsmDtlPackage);
		TPsmDtlPackage.setTPsmMstPackage(null);

		return TPsmDtlPackage;
	}

	public BigDecimal getCustomerType() {
		return customerType;
	}

	public void setCustomerType(BigDecimal customerType) {
		this.customerType = customerType;
	}

	@Override
	public String toString() {
		return "TPsmMstPackage [id=" + id + ", descriptionId=" + descriptionId + ", effectiveTillDate=" + effectiveTillDate
				+ ", offerFromDate=" + offerFromDate + ", offerTillDate=" + offerTillDate + ", packageCode=" + packageCode
				+ ", packageReduction=" + packageReduction + ", packageVersion=" + packageVersion + ", status=" + status
				+ ", splitBillingFlag=" + splitBillingFlag + "]";
	}

}