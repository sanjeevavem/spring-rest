package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the T_SOH_ACCOUNT_INSTANCE_DETAILS database table.
 * 
 */
@Entity
@Table(name="T_SOH_ACCOUNT_INSTANCE_DETAILS")
@NamedQuery(name="TSohAccountInstanceDetail.findAll", query="SELECT t FROM TSohAccountInstanceDetail t")
public class TSohAccountInstanceDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_SOH_ACCOUNT_INSTANCE_DETAILS_ACCSERVINSTANCEID_GENERATOR", sequenceName="SQ_T_SOH_ACCOUNT_INSTANCE_DTL",allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_SOH_ACCOUNT_INSTANCE_DETAILS_ACCSERVINSTANCEID_GENERATOR")
	@Column(name="ACC_SERV_INSTANCE_ID")
	private long accServInstanceId;

	@Column(name="ASSOCIATED_INSTANCE_ID")
	private BigDecimal associatedInstanceId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	//bi-directional many-to-one association to TSohAccountServiceDetail
	@ManyToOne
	@JoinColumn(name="ACCOUNT_SERVICE_ID")
	private TSohAccountServiceDetail TSohAccountServiceDetail;

	public TSohAccountInstanceDetail() {
	}

	public long getAccServInstanceId() {
		return this.accServInstanceId;
	}

	public void setAccServInstanceId(long accServInstanceId) {
		this.accServInstanceId = accServInstanceId;
	}

	public BigDecimal getAssociatedInstanceId() {
		return this.associatedInstanceId;
	}

	public void setAssociatedInstanceId(BigDecimal associatedInstanceId) {
		this.associatedInstanceId = associatedInstanceId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public TSohAccountServiceDetail getTSohAccountServiceDetail() {
		return this.TSohAccountServiceDetail;
	}

	public void setTSohAccountServiceDetail(TSohAccountServiceDetail TSohAccountServiceDetail) {
		this.TSohAccountServiceDetail = TSohAccountServiceDetail;
	}

}