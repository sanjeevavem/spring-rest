package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="T_SOH_DTL_SYSTEM_CODE_VALUES")
@NamedQueries({
	@NamedQuery(name="TSohDtlSystemCodeValue.findAll", query="SELECT t FROM TSohDtlSystemCodeValue t"),
	@NamedQuery(name="TSohDtlSystemCodeValue.findByvalueCodeandSystemCodeType",query="SELECT t FROM TSohDtlSystemCodeValue t where t.valueCode=:valueCode and t.TSohMstSystemCode.systemCodeType=:systemCodeType and t.deletionStatus=:deletionStatus and t.TSohMstSystemCode.deletionStatus=:deletionStatus"),
	@NamedQuery(name="TSohDtlSystemCodeValue.findBySystemCodeType",query="SELECT t FROM TSohDtlSystemCodeValue t where t.TSohMstSystemCode.systemCodeType=:systemCodeType")
	
})


public class TSohDtlSystemCodeValue implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SYSTEM_CODE_VALUE_ID")
	private long systemCodeValueId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="VALUE")
	private String value;

	@Column(name="VALUE_CODE")
	private String valueCode;
	
	@ManyToOne
	@JoinColumn(name="SYSTEM_CODE_ID")
	private TSohMstSystemCode TSohMstSystemCode;


	public TSohDtlSystemCodeValue() {
	}

	public long getSystemCodeValueId() {
		return this.systemCodeValueId;
	}

	public void setSystemCodeValueId(long systemCodeValueId) {
		this.systemCodeValueId = systemCodeValueId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getValueCode() {
		return this.valueCode;
	}

	public void setValueCode(String valueCode) {
		this.valueCode = valueCode;
	}
	
	public TSohMstSystemCode getTSohMstSystemCode() {
		return this.TSohMstSystemCode;
	}

	public void setTSohMstSystemCode(TSohMstSystemCode TSohMstSystemCode) {
		this.TSohMstSystemCode = TSohMstSystemCode;
	}


	public String toString() {
		return "systemCodeValueId:"+systemCodeValueId;
	}
}