package ae.etisalat.cw.jpa.soh.daos;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import ae.etisalat.cw.jpa.soh.entities.TSohAccount;
import ae.etisalat.cw.jpa.soh.entities.TSohAccountPaymentinfo;
import ae.etisalat.cw.restws.clients.PaymentTypeInfo;
import ae.etisalat.cw.restws.clients.PaymentTypeInfoList;

@Repository
@Transactional
public class AccountPaymentInfoDao {
	
	private static final Logger logger = LogManager.getLogger(AccountPaymentInfoDao.class);
	
	@PersistenceContext
    private EntityManager em;
	
	@SuppressWarnings("deprecation")
	public boolean processPaymentInfo(TSohAccount account, long subrequestId,PaymentTypeInfo paymentTypeInfo,String acctNumber) {
		TSohAccountPaymentinfo accountPaymentinfo = new TSohAccountPaymentinfo();
		try {
			accountPaymentinfo.setDeletionStatus("N");
			accountPaymentinfo.setCreatedDate(new Timestamp(new Date().getTime()));
			accountPaymentinfo.setCreatedUserId(account.getCreatedUserId());
			accountPaymentinfo.setModifiedDate(new Timestamp(new Date().getTime()));
			accountPaymentinfo.setModifiedUserId(account.getModifiedUserId());
			accountPaymentinfo.setAccountId(new BigDecimal(account.getAccountId()));
			accountPaymentinfo.setPayTypeId(fetchPaymentTypeId("PAYMENT_TYPE",paymentTypeInfo.getPaymentType()));
			accountPaymentinfo.setAccountNumber(acctNumber);
			accountPaymentinfo.setEffectiveFromDate(new Timestamp(new Date().getTime()));
			accountPaymentinfo.setSubrequestId("" + subrequestId);
			
			if(paymentTypeInfo.getPaymentTypeInfoList()!=null && paymentTypeInfo.getPaymentTypeInfoList().size()>0){
				for(PaymentTypeInfoList payTypeInfo:paymentTypeInfo.getPaymentTypeInfoList()){
					if(payTypeInfo.getInfoKey()!=null && payTypeInfo.getInfoKey().trim().length()>0
							&& payTypeInfo.getInfoValue()!=null && payTypeInfo.getInfoValue().trim().length()>0){
							if(payTypeInfo.getInfoKey().equalsIgnoreCase("bankAccNumber"))
								accountPaymentinfo.setBankAccNumber(payTypeInfo.getInfoValue());
							if(payTypeInfo.getInfoKey().equalsIgnoreCase("bankBranchId"))
								accountPaymentinfo.setBankBranchId(new BigDecimal(payTypeInfo.getInfoValue()));
							if(payTypeInfo.getInfoKey().equalsIgnoreCase("bankId"))
								accountPaymentinfo.setBankId(new BigDecimal(payTypeInfo.getInfoValue()));
							if(payTypeInfo.getInfoKey().equalsIgnoreCase("cardExpiryDate"))
								accountPaymentinfo.setCardExpiryDate(new Date(payTypeInfo.getInfoValue()));
							if(payTypeInfo.getInfoKey().equalsIgnoreCase("cardNumber"))
								accountPaymentinfo.setCardNumber(payTypeInfo.getInfoValue());
							if(payTypeInfo.getInfoKey().equalsIgnoreCase("cardTypeId"))
								accountPaymentinfo.setCardTypeId(new BigDecimal(payTypeInfo.getInfoValue()));
							if(payTypeInfo.getInfoKey().equalsIgnoreCase("creditcardCompanyId"))
								accountPaymentinfo.setCreditcardCompanyId(new BigDecimal(payTypeInfo.getInfoValue()));
							if(payTypeInfo.getInfoKey().equalsIgnoreCase("cvvNumber"))
								accountPaymentinfo.setCvvNumber(payTypeInfo.getInfoValue());
							if(payTypeInfo.getInfoKey().equalsIgnoreCase("nameOnCard"))
								accountPaymentinfo.setNameOnCard(payTypeInfo.getInfoValue());							
							if(payTypeInfo.getInfoKey().equalsIgnoreCase("paymentFrequency"))
								accountPaymentinfo.setPaymentFrequency(payTypeInfo.getInfoValue());
							if(payTypeInfo.getInfoKey().equalsIgnoreCase("paymentDay"))
								accountPaymentinfo.setPaymentDay(new BigDecimal(payTypeInfo.getInfoValue()));
							if(payTypeInfo.getInfoKey().equalsIgnoreCase("paymentOption"))
								accountPaymentinfo.setPaymentOption(payTypeInfo.getInfoValue());
							if(payTypeInfo.getInfoKey().equalsIgnoreCase("paymentAmount"))
								accountPaymentinfo.setPaymentAmount(new BigDecimal(payTypeInfo.getInfoValue()));
							if(payTypeInfo.getInfoKey().equalsIgnoreCase("mobileContact"))
								accountPaymentinfo.setMobileContact(payTypeInfo.getInfoValue());
							if(payTypeInfo.getInfoKey().equalsIgnoreCase("ddStartDate"))
								accountPaymentinfo.setDdStartDate(new Date(payTypeInfo.getInfoValue()));
							if(payTypeInfo.getInfoKey().equalsIgnoreCase("ddExpiryDate"))
								accountPaymentinfo.setDdExpiryDate(new Date(payTypeInfo.getInfoValue()));
							if(payTypeInfo.getInfoKey().equalsIgnoreCase("epgStatus"))
								accountPaymentinfo.setEpgStatus(payTypeInfo.getInfoValue());
							if(payTypeInfo.getInfoKey().equalsIgnoreCase("ddRegistrationStatus"))
								accountPaymentinfo.setDdRegistrationStatus(payTypeInfo.getInfoValue());
					}
				}
			}
			
			em.persist(accountPaymentinfo);
			em.flush();
		} catch (Exception e) {
			logger.error("Exception", e);
			return false;
		} finally {
		}
		return true;
	}
	
	public BigDecimal fetchPaymentTypeId(String key,String value){
		BigDecimal payTypeID=(BigDecimal)em.createQuery("select dtl.systemCodeValueId from TPayMstSystemCode mst , TPayDtlSystemCodeValue dtl "
				+ "where dtl.systemCodeId=mst.systemCodeId  and mst.deletionStatus='N' and  dtl.deletionStatus='N' and dtl.code=:value and mst.systemCode=:key")
				.setParameter("key", key).setParameter("value", value).getSingleResult();		
			return payTypeID;		
	}
}
