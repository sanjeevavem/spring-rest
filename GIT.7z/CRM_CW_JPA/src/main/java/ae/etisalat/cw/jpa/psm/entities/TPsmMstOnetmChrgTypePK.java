package ae.etisalat.cw.jpa.psm.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the T_PSM_MST_ONETM_CHRG_TYPE database table.
 * 
 */
@Embeddable
public class TPsmMstOnetmChrgTypePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="ONETIME_CHARGE_TYPE_ID")
	private long onetimeChargeTypeId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="EFFECTIVE_FROM_DATE")
	private java.util.Date effectiveFromDate;

	public TPsmMstOnetmChrgTypePK() {
	}
	public long getOnetimeChargeTypeId() {
		return this.onetimeChargeTypeId;
	}
	public void setOnetimeChargeTypeId(long onetimeChargeTypeId) {
		this.onetimeChargeTypeId = onetimeChargeTypeId;
	}
	public java.util.Date getEffectiveFromDate() {
		return this.effectiveFromDate;
	}
	public void setEffectiveFromDate(java.util.Date effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TPsmMstOnetmChrgTypePK)) {
			return false;
		}
		TPsmMstOnetmChrgTypePK castOther = (TPsmMstOnetmChrgTypePK)other;
		return 
			(this.onetimeChargeTypeId == castOther.onetimeChargeTypeId)
			&& this.effectiveFromDate.equals(castOther.effectiveFromDate);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.onetimeChargeTypeId ^ (this.onetimeChargeTypeId >>> 32)));
		hash = hash * prime + this.effectiveFromDate.hashCode();
		
		return hash;
	}
}