package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import javax.persistence.*;

import ae.etisalat.cw.jpa.cms.entities.TCmsMstPartySubtype;

import java.math.BigDecimal;
import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the T_SOH_MST_SUBREQ_ACCINFO database table.
 * 
 */
@Entity
@Table(name="T_SOH_MST_SUBREQ_ACCINFO")
@NamedQuery(name="TSohMstSubreqAccinfo.findAll", query="SELECT t FROM TSohMstSubreqAccinfo t")
public class TSohMstSubreqAccinfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SUBREQ_ACC_INFO_ID")
	private long subreqAccInfoId;

	@Column(name="ACC_BILLING_CYCLE_TYPE")
	private BigDecimal accBillingCycleType;

	@Column(name="ACC_BILLINGCYCLE_ID")
	private BigDecimal accBillingcycleId;

	@Column(name="ACC_CURRENCY_ID")
	private BigDecimal accCurrencyId;

	@Column(name="ACC_MAINTAINANCE_PRIORITY")
	private BigDecimal accMaintainancePriority;

	@Column(name="ACC_MANAGER_EMAIL")
	private String accManagerEmail;

	@Column(name="ACC_SECURITY_LEVEL_ID")
	private BigDecimal accSecurityLevelId;

	@Column(name="ACCESS_FLAG")
	private String accessFlag;

	@Column(name="ACCOUNT_TYPE")
	private BigDecimal accountType;

	@Column(name="ATG_USER_NAME")
	private String atgUserName;

	@Column(name="ATG_USER_NAME_FLAG")
	private String atgUserNameFlag;

	@Column(name="AUTH_PERSON_ID")
	private String authPersonId;

	@Column(name="AUTH_PERSON_NAME")
	private String authPersonName;

	@Temporal(TemporalType.DATE)
	@Column(name="BILLING_CYCLE_DATE")
	private Date billingCycleDate;

	@Column(name="CBCM_CATEGORY_ID")
	private BigDecimal cbcmCategoryId;

	@Column(name="CHILD_GROUP_ID")
	private BigDecimal childGroupId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="DOMAIN_NAME")
	private String domainName;

	@Column(name="GROUP_ID")
	private BigDecimal groupId;

	@Column(name="INET_USER_ID")
	private String inetUserId;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="SLA_REQUIRED_FLAG")
	private String slaRequiredFlag;

	@Column(name="SUBREQ_ACC_NAME_ARABIC")
	private String subreqAccNameArabic;

	@Column(name="SUBREQ_ACC_NAME_ENG")
	private String subreqAccNameEng;

	@Column(name="SUBREQUEST_ID")
	private BigDecimal subrequestId;

	@Column(name="SWH_LOGIN_ID")
	private String swhLoginId;

	@Column(name="VB_FLAG")
	private String vbFlag;

	//bi-directional many-to-one association to TCmsMstPartySubtype
	@ManyToOne
	@JoinColumn(name="ACC_CATEGORY_ID")
	private TCmsMstPartySubtype TCmsMstPartySubtype;

	public TSohMstSubreqAccinfo() {
	}

	public long getSubreqAccInfoId() {
		return this.subreqAccInfoId;
	}

	public void setSubreqAccInfoId(long subreqAccInfoId) {
		this.subreqAccInfoId = subreqAccInfoId;
	}

	public BigDecimal getAccBillingCycleType() {
		return this.accBillingCycleType;
	}

	public void setAccBillingCycleType(BigDecimal accBillingCycleType) {
		this.accBillingCycleType = accBillingCycleType;
	}

	public BigDecimal getAccBillingcycleId() {
		return this.accBillingcycleId;
	}

	public void setAccBillingcycleId(BigDecimal accBillingcycleId) {
		this.accBillingcycleId = accBillingcycleId;
	}

	public BigDecimal getAccCurrencyId() {
		return this.accCurrencyId;
	}

	public void setAccCurrencyId(BigDecimal accCurrencyId) {
		this.accCurrencyId = accCurrencyId;
	}

	public BigDecimal getAccMaintainancePriority() {
		return this.accMaintainancePriority;
	}

	public void setAccMaintainancePriority(BigDecimal accMaintainancePriority) {
		this.accMaintainancePriority = accMaintainancePriority;
	}

	public String getAccManagerEmail() {
		return this.accManagerEmail;
	}

	public void setAccManagerEmail(String accManagerEmail) {
		this.accManagerEmail = accManagerEmail;
	}

	public BigDecimal getAccSecurityLevelId() {
		return this.accSecurityLevelId;
	}

	public void setAccSecurityLevelId(BigDecimal accSecurityLevelId) {
		this.accSecurityLevelId = accSecurityLevelId;
	}

	public String getAccessFlag() {
		return this.accessFlag;
	}

	public void setAccessFlag(String accessFlag) {
		this.accessFlag = accessFlag;
	}

	public BigDecimal getAccountType() {
		return this.accountType;
	}

	public void setAccountType(BigDecimal accountType) {
		this.accountType = accountType;
	}

	public String getAtgUserName() {
		return this.atgUserName;
	}

	public void setAtgUserName(String atgUserName) {
		this.atgUserName = atgUserName;
	}

	public String getAtgUserNameFlag() {
		return this.atgUserNameFlag;
	}

	public void setAtgUserNameFlag(String atgUserNameFlag) {
		this.atgUserNameFlag = atgUserNameFlag;
	}

	public String getAuthPersonId() {
		return this.authPersonId;
	}

	public void setAuthPersonId(String authPersonId) {
		this.authPersonId = authPersonId;
	}

	public String getAuthPersonName() {
		return this.authPersonName;
	}

	public void setAuthPersonName(String authPersonName) {
		this.authPersonName = authPersonName;
	}

	public Date getBillingCycleDate() {
		return this.billingCycleDate;
	}

	public void setBillingCycleDate(Date billingCycleDate) {
		this.billingCycleDate = billingCycleDate;
	}

	public BigDecimal getCbcmCategoryId() {
		return this.cbcmCategoryId;
	}

	public void setCbcmCategoryId(BigDecimal cbcmCategoryId) {
		this.cbcmCategoryId = cbcmCategoryId;
	}

	public BigDecimal getChildGroupId() {
		return this.childGroupId;
	}

	public void setChildGroupId(BigDecimal childGroupId) {
		this.childGroupId = childGroupId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public String getDomainName() {
		return this.domainName;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	public BigDecimal getGroupId() {
		return this.groupId;
	}

	public void setGroupId(BigDecimal groupId) {
		this.groupId = groupId;
	}

	public String getInetUserId() {
		return this.inetUserId;
	}

	public void setInetUserId(String inetUserId) {
		this.inetUserId = inetUserId;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getSlaRequiredFlag() {
		return this.slaRequiredFlag;
	}

	public void setSlaRequiredFlag(String slaRequiredFlag) {
		this.slaRequiredFlag = slaRequiredFlag;
	}

	public String getSubreqAccNameArabic() {
		return this.subreqAccNameArabic;
	}

	public void setSubreqAccNameArabic(String subreqAccNameArabic) {
		this.subreqAccNameArabic = subreqAccNameArabic;
	}

	public String getSubreqAccNameEng() {
		return this.subreqAccNameEng;
	}

	public void setSubreqAccNameEng(String subreqAccNameEng) {
		this.subreqAccNameEng = subreqAccNameEng;
	}

	public BigDecimal getSubrequestId() {
		return this.subrequestId;
	}

	public void setSubrequestId(BigDecimal subrequestId) {
		this.subrequestId = subrequestId;
	}

	public String getSwhLoginId() {
		return this.swhLoginId;
	}

	public void setSwhLoginId(String swhLoginId) {
		this.swhLoginId = swhLoginId;
	}

	public String getVbFlag() {
		return this.vbFlag;
	}

	public void setVbFlag(String vbFlag) {
		this.vbFlag = vbFlag;
	}

	public TCmsMstPartySubtype getTCmsMstPartySubtype() {
		return this.TCmsMstPartySubtype;
	}

	public void setTCmsMstPartySubtype(TCmsMstPartySubtype TCmsMstPartySubtype) {
		this.TCmsMstPartySubtype = TCmsMstPartySubtype;
	}

}