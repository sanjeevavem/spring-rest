package ae.etisalat.cw.jpa.bill.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the T_BIL_ACCOUNT_SERVICE_BALANCE database table.
 * 
 */
@Embeddable
public class TBilAccountServiceBalancePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="ACCOUNT_ID")
	private long accountId;

	@Column(name="SUBSCRIPTION_SERVICE_ID")
	private long subscriptionServiceId;

	public TBilAccountServiceBalancePK() {
	}
	public long getAccountId() {
		return this.accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public long getSubscriptionServiceId() {
		return this.subscriptionServiceId;
	}
	public void setSubscriptionServiceId(long subscriptionServiceId) {
		this.subscriptionServiceId = subscriptionServiceId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TBilAccountServiceBalancePK)) {
			return false;
		}
		TBilAccountServiceBalancePK castOther = (TBilAccountServiceBalancePK)other;
		return 
			(this.accountId == castOther.accountId)
			&& (this.subscriptionServiceId == castOther.subscriptionServiceId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.accountId ^ (this.accountId >>> 32)));
		hash = hash * prime + ((int) (this.subscriptionServiceId ^ (this.subscriptionServiceId >>> 32)));
		
		return hash;
	}
}