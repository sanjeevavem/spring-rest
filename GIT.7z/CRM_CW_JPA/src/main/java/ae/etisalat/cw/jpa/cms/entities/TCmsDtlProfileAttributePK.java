package ae.etisalat.cw.jpa.cms.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the T_CMS_DTL_PROFILE_ATTRIBUTE database table.
 * 
 */
@Embeddable
public class TCmsDtlProfileAttributePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="ATTRIBUTE_ID")
	private long attributeId;

	@Column(name="PROFILE_ID")
	private long profileId;

	@Column(name="SCREEN_ID")
	private long screenId;

	public TCmsDtlProfileAttributePK() {
	}
	public long getAttributeId() {
		return this.attributeId;
	}
	public void setAttributeId(long attributeId) {
		this.attributeId = attributeId;
	}
	public long getProfileId() {
		return this.profileId;
	}
	public void setProfileId(long profileId) {
		this.profileId = profileId;
	}
	public long getScreenId() {
		return this.screenId;
	}
	public void setScreenId(long screenId) {
		this.screenId = screenId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TCmsDtlProfileAttributePK)) {
			return false;
		}
		TCmsDtlProfileAttributePK castOther = (TCmsDtlProfileAttributePK)other;
		return 
			(this.attributeId == castOther.attributeId)
			&& (this.profileId == castOther.profileId)
			&& (this.screenId == castOther.screenId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.attributeId ^ (this.attributeId >>> 32)));
		hash = hash * prime + ((int) (this.profileId ^ (this.profileId >>> 32)));
		hash = hash * prime + ((int) (this.screenId ^ (this.screenId >>> 32)));
		
		return hash;
	}
}