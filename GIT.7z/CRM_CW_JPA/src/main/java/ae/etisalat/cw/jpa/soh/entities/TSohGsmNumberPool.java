package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import ae.etisalat.cw.jpa.adm.entities.TAdmMstRegion;


/**
 * The persistent class for the T_SOH_GSM_NUMBER_POOL database table.
 * 
 */
@Entity
@Table(name="T_SOH_GSM_NUMBER_POOL")
@NamedQuery(name="TSohGsmNumberPool.findAll", query="SELECT t FROM TSohGsmNumberPool t")
public class TSohGsmNumberPool implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="GSM_NUMBER_POOL_ID")
	private long gsmNumberPoolId;

	@Column(name="ACC_SERV_INSTANCE_ID")
	private BigDecimal accServInstanceId;

	@Column(name="ACCOUNT_ID")
	private BigDecimal accountId;

	@Column(name="ACCOUNT_SUFFIX")
	private BigDecimal accountSuffix;

	@Column(name="ALLOC_SUBREQ_ID")
	private BigDecimal allocSubreqId;

	@Column(name="AREA_CODE")
	private String areaCode;

	@Column(name="CESSATION_IND")
	private BigDecimal cessationInd;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_FROM_DATE")
	private Date effectiveFromDate;

	@Temporal(TemporalType.DATE)
	@Column(name="EXPIRY_DATE")
	private Date expiryDate;

	@Column(name="FALCON_REFERENCE_NO")
	private String falconReferenceNo;

	@Column(name="LOCATION_CODE")
	private String locationCode;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="NETWORK_ELEMENT_ID")
	private BigDecimal networkElementId;

	private String notes;

	@Column(name="NUMBER_CATEGORY")
	private BigDecimal numberCategory;

	@Column(name="ORG_UNIT_ID")
	private BigDecimal orgUnitId;

	@Column(name="PREPAID_FLAG")
	private BigDecimal prepaidFlag;

	@Column(name="PRODUCT_GROUP_ID")
	private BigDecimal productGroupId;

	@Column(name="PRODUCT_ID")
	private BigDecimal productId;

	@Column(name="PRODUCT_NUMBER")
	private BigDecimal productNumber;

	@Column(name="PRODUCT_NUMBER_STATUS")
	private BigDecimal productNumberStatus;

	@Column(name="RESERVED_BY")
	private BigDecimal reservedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="RESERVED_TILL_DATE")
	private Date reservedTillDate;

	@Column(name="RETAILER_PARTY_PROFILE_ID")
	private BigDecimal retailerPartyProfileId;

	@Column(name="SERVICE_ID")
	private BigDecimal serviceId;

	@Column(name="STATUS_TO")
	private BigDecimal statusTo;

	@Column(name="STATUS_TO_FLAG")
	private String statusToFlag;

	@Column(name="SUBREQUEST_ID")
	private BigDecimal subrequestId;

	//bi-directional many-to-one association to TAdmMstRegion
	@ManyToOne
	@JoinColumn(name="REGION_ID")
	private TAdmMstRegion TAdmMstRegion;

	//bi-directional many-to-one association to TSohSubreqInstanceDetail
	@ManyToOne
	@JoinColumn(name="SR_SERV_INSTANCE_ID")
	private TSohSubreqInstanceDetail TSohSubreqInstanceDetail;

	public TSohGsmNumberPool() {
	}

	public long getGsmNumberPoolId() {
		return this.gsmNumberPoolId;
	}

	public void setGsmNumberPoolId(long gsmNumberPoolId) {
		this.gsmNumberPoolId = gsmNumberPoolId;
	}

	public BigDecimal getAccServInstanceId() {
		return this.accServInstanceId;
	}

	public void setAccServInstanceId(BigDecimal accServInstanceId) {
		this.accServInstanceId = accServInstanceId;
	}

	public BigDecimal getAccountId() {
		return this.accountId;
	}

	public void setAccountId(BigDecimal accountId) {
		this.accountId = accountId;
	}

	public BigDecimal getAccountSuffix() {
		return this.accountSuffix;
	}

	public void setAccountSuffix(BigDecimal accountSuffix) {
		this.accountSuffix = accountSuffix;
	}

	public BigDecimal getAllocSubreqId() {
		return this.allocSubreqId;
	}

	public void setAllocSubreqId(BigDecimal allocSubreqId) {
		this.allocSubreqId = allocSubreqId;
	}

	public String getAreaCode() {
		return this.areaCode;
	}

	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

	public BigDecimal getCessationInd() {
		return this.cessationInd;
	}

	public void setCessationInd(BigDecimal cessationInd) {
		this.cessationInd = cessationInd;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public Date getEffectiveFromDate() {
		return this.effectiveFromDate;
	}

	public void setEffectiveFromDate(Date effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}

	public Date getExpiryDate() {
		return this.expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getFalconReferenceNo() {
		return this.falconReferenceNo;
	}

	public void setFalconReferenceNo(String falconReferenceNo) {
		this.falconReferenceNo = falconReferenceNo;
	}

	public String getLocationCode() {
		return this.locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getNetworkElementId() {
		return this.networkElementId;
	}

	public void setNetworkElementId(BigDecimal networkElementId) {
		this.networkElementId = networkElementId;
	}

	public String getNotes() {
		return this.notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public BigDecimal getNumberCategory() {
		return this.numberCategory;
	}

	public void setNumberCategory(BigDecimal numberCategory) {
		this.numberCategory = numberCategory;
	}

	public BigDecimal getOrgUnitId() {
		return this.orgUnitId;
	}

	public void setOrgUnitId(BigDecimal orgUnitId) {
		this.orgUnitId = orgUnitId;
	}

	public BigDecimal getPrepaidFlag() {
		return this.prepaidFlag;
	}

	public void setPrepaidFlag(BigDecimal prepaidFlag) {
		this.prepaidFlag = prepaidFlag;
	}

	public BigDecimal getProductGroupId() {
		return this.productGroupId;
	}

	public void setProductGroupId(BigDecimal productGroupId) {
		this.productGroupId = productGroupId;
	}

	public BigDecimal getProductId() {
		return this.productId;
	}

	public void setProductId(BigDecimal productId) {
		this.productId = productId;
	}

	public BigDecimal getProductNumber() {
		return this.productNumber;
	}

	public void setProductNumber(BigDecimal productNumber) {
		this.productNumber = productNumber;
	}

	public BigDecimal getProductNumberStatus() {
		return this.productNumberStatus;
	}

	public void setProductNumberStatus(BigDecimal productNumberStatus) {
		this.productNumberStatus = productNumberStatus;
	}

	public BigDecimal getReservedBy() {
		return this.reservedBy;
	}

	public void setReservedBy(BigDecimal reservedBy) {
		this.reservedBy = reservedBy;
	}

	public Date getReservedTillDate() {
		return this.reservedTillDate;
	}

	public void setReservedTillDate(Date reservedTillDate) {
		this.reservedTillDate = reservedTillDate;
	}

	public BigDecimal getRetailerPartyProfileId() {
		return this.retailerPartyProfileId;
	}

	public void setRetailerPartyProfileId(BigDecimal retailerPartyProfileId) {
		this.retailerPartyProfileId = retailerPartyProfileId;
	}

	public BigDecimal getServiceId() {
		return this.serviceId;
	}

	public void setServiceId(BigDecimal serviceId) {
		this.serviceId = serviceId;
	}

	public BigDecimal getStatusTo() {
		return this.statusTo;
	}

	public void setStatusTo(BigDecimal statusTo) {
		this.statusTo = statusTo;
	}

	public String getStatusToFlag() {
		return this.statusToFlag;
	}

	public void setStatusToFlag(String statusToFlag) {
		this.statusToFlag = statusToFlag;
	}

	public BigDecimal getSubrequestId() {
		return this.subrequestId;
	}

	public void setSubrequestId(BigDecimal subrequestId) {
		this.subrequestId = subrequestId;
	}

	public TAdmMstRegion getTAdmMstRegion() {
		return this.TAdmMstRegion;
	}

	public void setTAdmMstRegion(TAdmMstRegion TAdmMstRegion) {
		this.TAdmMstRegion = TAdmMstRegion;
	}

	public TSohSubreqInstanceDetail getTSohSubreqInstanceDetail() {
		return this.TSohSubreqInstanceDetail;
	}

	public void setTSohSubreqInstanceDetail(TSohSubreqInstanceDetail TSohSubreqInstanceDetail) {
		this.TSohSubreqInstanceDetail = TSohSubreqInstanceDetail;
	}

}