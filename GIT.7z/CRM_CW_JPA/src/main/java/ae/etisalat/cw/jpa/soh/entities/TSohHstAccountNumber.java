package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the T_SOH_HST_ACCOUNT_NUMBER database table.
 * 
 */
@Entity
@Table(name="T_SOH_HST_ACCOUNT_NUMBER")
@NamedQuery(name="TSohHstAccountNumber.findAll", query="SELECT t FROM TSohHstAccountNumber t")
public class TSohHstAccountNumber implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_SOH_HST_ACCOUNT_NUMBER_ACCNUMBERID_GENERATOR", sequenceName="SQ_T_SOH_HST_ACCOUNT_NUMBER",allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_SOH_HST_ACCOUNT_NUMBER_ACCNUMBERID_GENERATOR")
	@Column(name="ACC_NUMBER_ID")
	private long accNumberId;

	@Column(name="ACCOUNT_NUMBER")
	private String accountNumber;

	@Column(name="ACCOUNT_SUFFIX")
	private BigDecimal accountSuffix;

	@Column(name="AREA_CODE")
	private String areaCode;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="EFF_FROM")
	private Timestamp effFrom;

	@Column(name="EFF_TILL")
	private Timestamp effTill;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="OLD_ACCOUNT_NUMBER")
	private String oldAccountNumber;

	@Column(name="PRODUCT_NUMBER")
	private BigDecimal productNumber;

	@Column(name="SHORT_FLAG")
	private String shortFlag;

	//bi-directional many-to-one association to TSohAccount
	@ManyToOne
	@JoinColumn(name="ACCOUNT_ID")
	private TSohAccount TSohAccount;

	public TSohHstAccountNumber() {
	}

	public long getAccNumberId() {
		return this.accNumberId;
	}

	public void setAccNumberId(long accNumberId) {
		this.accNumberId = accNumberId;
	}

	public String getAccountNumber() {
		return this.accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public BigDecimal getAccountSuffix() {
		return this.accountSuffix;
	}

	public void setAccountSuffix(BigDecimal accountSuffix) {
		this.accountSuffix = accountSuffix;
	}

	public String getAreaCode() {
		return this.areaCode;
	}

	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getEffFrom() {
		return this.effFrom;
	}

	public void setEffFrom(Timestamp effFrom) {
		this.effFrom = effFrom;
	}

	public Timestamp getEffTill() {
		return this.effTill;
	}

	public void setEffTill(Timestamp effTill) {
		this.effTill = effTill;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getOldAccountNumber() {
		return this.oldAccountNumber;
	}

	public void setOldAccountNumber(String oldAccountNumber) {
		this.oldAccountNumber = oldAccountNumber;
	}

	public BigDecimal getProductNumber() {
		return this.productNumber;
	}

	public void setProductNumber(BigDecimal productNumber) {
		this.productNumber = productNumber;
	}

	public String getShortFlag() {
		return this.shortFlag;
	}

	public void setShortFlag(String shortFlag) {
		this.shortFlag = shortFlag;
	}

	public TSohAccount getTSohAccount() {
		return this.TSohAccount;
	}

	public void setTSohAccount(TSohAccount TSohAccount) {
		this.TSohAccount = TSohAccount;
	}

}