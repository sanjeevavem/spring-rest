package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the T_SOH_DTL_SUBREQ_INVOICE_INFO database table.
 * 
 */
@Entity
@Table(name="T_SOH_DTL_SUBREQ_INVOICE_INFO")
@NamedQuery(name="TSohDtlSubreqInvoiceInfo.findAll", query="SELECT t FROM TSohDtlSubreqInvoiceInfo t")
public class TSohDtlSubreqInvoiceInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="INVOICE_SUBREQ_ID")
	private long invoiceSubreqId;

	@Column(name="ACC_INVOICE_ID")
	private BigDecimal accInvoiceId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="SUBREQ_INVOICE_ID")
	private BigDecimal subreqInvoiceId;

	@Column(name="SUBREQUEST_ID")
	private BigDecimal subrequestId;

	public TSohDtlSubreqInvoiceInfo() {
	}

	public long getInvoiceSubreqId() {
		return this.invoiceSubreqId;
	}

	public void setInvoiceSubreqId(long invoiceSubreqId) {
		this.invoiceSubreqId = invoiceSubreqId;
	}

	public BigDecimal getAccInvoiceId() {
		return this.accInvoiceId;
	}

	public void setAccInvoiceId(BigDecimal accInvoiceId) {
		this.accInvoiceId = accInvoiceId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getSubreqInvoiceId() {
		return this.subreqInvoiceId;
	}

	public void setSubreqInvoiceId(BigDecimal subreqInvoiceId) {
		this.subreqInvoiceId = subreqInvoiceId;
	}

	public BigDecimal getSubrequestId() {
		return this.subrequestId;
	}

	public void setSubrequestId(BigDecimal subrequestId) {
		this.subrequestId = subrequestId;
	}

}