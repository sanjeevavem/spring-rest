package ae.etisalat.cw.jpa.soh.daos;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import ae.etisalat.cw.comm.util.Util;
import ae.etisalat.cw.jpa.adm.entities.TAdmMstEmirate;
import ae.etisalat.cw.jpa.adm.entities.TAdmMstRegion;
import ae.etisalat.cw.jpa.soh.entities.TSohAccAccountNumber;
import ae.etisalat.cw.jpa.soh.entities.TSohAccount;
import ae.etisalat.cw.jpa.soh.entities.TSohAccountServiceDetail;
import ae.etisalat.cw.jpa.soh.entities.TSohDtlSystemCodeValue;
import ae.etisalat.cw.jpa.soh.entities.TSohHstAccountStatus;
import ae.etisalat.cw.jpa.soh.entities.TSohSubrequest;

@Repository
@Transactional
public class AccountDao {

	
	private static final Logger logger = LogManager.getLogger(AccountDao.class);
	
	@PersistenceContext
    private EntityManager em;
	
	
	public boolean updateAccountStatus(String userId, TSohAccount account, String statusToBeUpdated) throws Exception {
        account.setModifiedUserId(userId);
        account.setModifiedDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
        // If status is active(1), set the cesation date to null.
        if ("ACTIVE".equalsIgnoreCase(statusToBeUpdated)) {
            account.setCessationDate(null);
        }
        String accountStatus=getSystemcodeIdByValue("ACCOUNT_STATUS", statusToBeUpdated);
        if(accountStatus!=null)
        	account.setAccountStatusId(new BigDecimal(accountStatus));
        em.merge(account);
        return true;
        
    }
	
	public String getSystemcodeIdByValue(String systemCodeType, String systemCodeValue) throws Exception {
		String value = "";
		try {
			String select = "select vh.system_code_value_id from t_soh_mst_system_code ms,t_soh_dtl_system_code_values vh "
					+ " where ms.system_code_id = vh.system_code_id "
					+ " and vh.deletion_status='N' and ms.deletion_status='N' " + " and ms.system_code_type = ? "
					+ " and  vh.value = ? ";
			value = em.createNativeQuery(select).setParameter(1, systemCodeType).setParameter(2, systemCodeValue)
					.getSingleResult().toString();

		} catch (Exception e) {
			e.printStackTrace();
			logger.info("EXCEPTION MSG -getSystemcodeIdByValue----->>>" + e.getMessage());
		}
		return value;
	}
	
	public boolean deleteTSohHstAccountStatus(TSohHstAccountStatus hstAccountStatus, String userId) {
        hstAccountStatus.setEffTill(new Timestamp(Calendar.getInstance().getTimeInMillis()));
        hstAccountStatus.setModifiedDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
        hstAccountStatus.setModifiedUserId(userId);
        hstAccountStatus.setDeletionStatus("Y");
        em.merge(hstAccountStatus);
        return true;
    }
	
	public TSohHstAccountStatus newHstAccountStatus(String userId, TSohHstAccountStatus lastHstAccountStatus,TSohAccount account, String statusToBeUpdated) throws Exception {

        TSohHstAccountStatus hstAccountStatus = new TSohHstAccountStatus();
        hstAccountStatus.setTSohAccount(account);
        hstAccountStatus.setEffFrom(new Timestamp(Calendar.getInstance().getTimeInMillis()));
        hstAccountStatus.setEffTill(null);
        String accountStatus=getSystemcodeIdByValue("ACCOUNT_STATUS", statusToBeUpdated);
        if(accountStatus!=null)
        hstAccountStatus.setAccountStatusId(new BigDecimal(accountStatus));
        if(lastHstAccountStatus!=null){
        	hstAccountStatus.setAccountStatusId(lastHstAccountStatus.getAccountStatusId());
            hstAccountStatus.setCrdtStatusId(lastHstAccountStatus.getCrdtStatusId());
            hstAccountStatus.setOldCrdtStatusId(lastHstAccountStatus.getCrdtStatusId());
        } else {
        	hstAccountStatus.setCrdtStatusId(account.getCreditStatusId());
        	logger.info( "Credit status ID[",account.getCreditStatusId()+"] loaded from account");
        }
        hstAccountStatus.setCreatedUserId(userId);
        hstAccountStatus.setModifiedUserId(userId);
        hstAccountStatus.setCreatedDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
        hstAccountStatus.setModifiedDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
        hstAccountStatus.setDeletionStatus("N");
        return hstAccountStatus;
    }
	
	@SuppressWarnings("unchecked")
	public TSohHstAccountStatus getLatestTSohHstAccountStatusByAccId(Long accountId){
		long start = System.currentTimeMillis();
		TSohHstAccountStatus tSohHstAccountStatus = null;
		Query query = em.createQuery("select a from TSohHstAccountStatus a where a.TSohAccount.accountId = :accountId "
				+ "and a.accStsId = (select max(h.accStsId) from  TSohHstAccountStatus h where h.TSohAccount.accountId = :accountId)");
		logger.debug(query.toString() + " Parameters are accountId:" + accountId);
		query.setParameter("accountId", accountId);

		List<TSohHstAccountStatus> accStatusList = (List<TSohHstAccountStatus>)query.getResultList();
		if (!CollectionUtils.isEmpty(accStatusList)){
			tSohHstAccountStatus = accStatusList.get(0);
			logger.info("tSohHstAccountStatus id[", tSohHstAccountStatus.getAccStsId()+"]");
		}
		if (tSohHstAccountStatus != null) {
			logger.info("Account has been fetched in "+ (System.currentTimeMillis() - start) + " milliseconds");
			return tSohHstAccountStatus;
		}
		logger.info("Account History not found for accountId ["+ accountId +"]");
		return null;
	}
	
	public TSohAccAccountNumber getAccountIdFromAccnum(String accountNumber)throws Exception{
		TSohAccAccountNumber accountNumberDtls = null;
		try{
			accountNumberDtls =	(TSohAccAccountNumber) em.createNamedQuery("TSohAccAccountNumber.findAccountByAccountNumber").
					setParameter("accountNumber", accountNumber).setParameter("accountNumber", accountNumber).getSingleResult();		
		}catch(Exception e){
			logger.info( "EXCEPTION MSG ------>>>" +e.getMessage(),e);
		}				
		return accountNumberDtls;
	}
	
	public TSohSubrequest getsubRequestBySubrequestId(Long subRequestId){
        TSohSubrequest tSohSubrequest = em.find(TSohSubrequest.class, subRequestId);
        return tSohSubrequest;
    }
	
	 public TSohDtlSystemCodeValue getSystemCodeValue(String code) {
	        long start = System.currentTimeMillis();
	        try {
	            Query accountStatusQuery = em.createQuery("select a from TSohDtlSystemCodeValue a where a.systemCodeValueId = :code");
	            accountStatusQuery.setParameter("code", Integer.parseInt(code));
	            TSohDtlSystemCodeValue tSohDtlSystemCodeValue = Util.getFirstObjectFromList(accountStatusQuery.getResultList());
	            if (tSohDtlSystemCodeValue != null) {
	                logger.info("Account status fetched in "+ (System.currentTimeMillis() - start)+ " milliseconds");
	                return tSohDtlSystemCodeValue;
	            }
	        } catch (Exception e) {
	            logger.error("Exception", e);
	            e.printStackTrace();
	        } 
	        return null;
	    }
	 
	 public <T> boolean merge(T entity) throws DataAccessException {
			boolean merged = false;
			try {
				logger.info("Merging the entity: " + entity);
				em.merge(entity);
				merged = true;
				logger.info( "Merged the entity successfully");
			} catch (Exception e) {
				logger.info( "Error in merging the entity with the database. and message: "+ e.getMessage());
			}
			return merged;
		}
	 
	 @SuppressWarnings("unchecked")
	public List<TSohAccountServiceDetail> fetchServiceDtlbyAcctId(Long acctId){
		 List<TSohAccountServiceDetail> accountSrvcDtl=new ArrayList<TSohAccountServiceDetail>();
		 accountSrvcDtl=(List<TSohAccountServiceDetail>)em.createQuery("select t from TSohAccountServiceDetail t where t.accountId= :accountId "
		 		+ "and (t.effectiveTillDate is null OR t.effectiveTillDate>SYSTIMESTAMP)")
				 .setParameter("accountId", new BigDecimal(acctId)).getResultList();
		 return accountSrvcDtl;
	 }
	 
	 public TAdmMstRegion getRegionByCode(String regionCode) {
			long start = System.currentTimeMillis();
			try {
				Query query = em.createQuery("select a from TAdmMstRegion a where a.regionCode = :regionCode and a.deletionStatus =:deletionStatus");
				logger.debug(query.toString() + " Parameters are " + regionCode);
				query.setParameter("regionCode", regionCode);
				query.setParameter("deletionStatus", "N");
				TAdmMstRegion tAdmMstRegion = Util.getFirstObjectFromList(query.getResultList());//CBCMCOMS-4753
				if (tAdmMstRegion != null) {
					logger.info("TAdmMstEmirate record has been fetched in " + (System.currentTimeMillis() - start) + " milliseconds");
					return tAdmMstRegion;
				}
			} catch (Exception e) {
				logger.error("Exception", e);
			} finally {
			}
			return null;
		}
	 
	 public TAdmMstEmirate getEmiratesByCode(String code) {
			long start = System.currentTimeMillis();
			try {
				Query query = em.createQuery("select a from TAdmMstEmirate a where a.code = :code and a.deletionStatus ='N'");
				logger.info(query.toString() + " Parameters are " + code);
				query.setParameter("code", code);
				TAdmMstEmirate tAdmMstEmirate = Util.getFirstObjectFromList(query.getResultList());//CBCMCOMS-4753
				if (tAdmMstEmirate != null) {
					logger.info("TAdmMstEmirate record has been fetched in " + (System.currentTimeMillis() - start) + " milliseconds");
					return tAdmMstEmirate;
				}
			} catch (Exception e) {	
				logger.info("Exception: getEmiratesByCode()");
			} finally {
			}
			return null;
	}
}
