package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import ae.etisalat.cw.jpa.adm.entities.TAdmMstRegion;


/**
 * The persistent class for the T_SOH_GSM_RESOURCE_POOL database table.
 * 
 */
@Entity
@Table(name="T_SOH_GSM_RESOURCE_POOL")
@NamedQuery(name="TSohGsmResourcePool.findAll", query="SELECT t FROM TSohGsmResourcePool t")
public class TSohGsmResourcePool implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="GSM_RESOURCE_POOL_ID")
	private long gsmResourcePoolId;

	@Column(name="ACC_SERV_INSTANCE_ID")
	private BigDecimal accServInstanceId;

	@Column(name="ACCOUNT_ID")
	private BigDecimal accountId;

	@Column(name="ALLOC_SUBREQ_ID")
	private BigDecimal allocSubreqId;

	@Column(name="BATCH_NO")
	private BigDecimal batchNo;

	@Column(name="CARD_TYPE")
	private BigDecimal cardType;

	@Column(name="CESSATION_IND")
	private BigDecimal cessationInd;

	@Temporal(TemporalType.DATE)
	@Column(name="CREATED_DATE")
	private Date createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_FROM_DATE")
	private Date effectiveFromDate;

	@Column(name="EFFECTIVE_TILL_DATE")
	private Timestamp effectiveTillDate;

	@Column(name="EQUIPMENT_SERIAL_NO")
	private String equipmentSerialNo;

	@Column(name="ESIM_EID")
	private String esimEid;

	@Column(name="ESIM_FLAG")
	private String esimFlag;

	@Column(name="ESIM_IS_VOLTE_REQUIRED")
	private String esimIsVolteRequired;

	@Column(name="ESIM_OEM")
	private String esimOem;

	@Column(name="FALCON_REFERENCE_NO")
	private String falconReferenceNo;

	@Column(name="FNR_INDICATOR")
	private String fnrIndicator;

	@Temporal(TemporalType.DATE)
	@Column(name="GUARANTEED_UNTIL")
	private Date guaranteedUntil;

	@Column(name="ICCID_NO")
	private String iccidNo;

	@Column(name="IMSI_NO")
	private String imsiNo;

	@Column(name="MANUFACTURER_CODE")
	private String manufacturerCode;

	@Temporal(TemporalType.DATE)
	@Column(name="MODIFIED_DATE")
	private Date modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	private String notes1;

	private String notes2;

	private String notes3;

	@Column(name="ORG_UNIT_ID")
	private BigDecimal orgUnitId;

	@Column(name="PIN_NO")
	private BigDecimal pinNo;

	@Column(name="PUK_NO")
	private BigDecimal pukNo;

	@Temporal(TemporalType.DATE)
	@Column(name="RESERVED_TIL_DATE")
	private Date reservedTilDate;

	@Column(name="RETAILER_PARTY_PROFILE_ID")
	private BigDecimal retailerPartyProfileId;

	@Column(name="SIM_CARD_STATUS")
	private BigDecimal simCardStatus;

	@Column(name="SIM_REASON_CODE")
	private BigDecimal simReasonCode;

	@Column(name="SR_SERV_INSTANCE_ID")
	private BigDecimal srServInstanceId;

	@Column(name="STATUS_TO")
	private BigDecimal statusTo;

	@Column(name="STATUS_TO_FLAG")
	private String statusToFlag;

	@Column(name="STYLE_CODE")
	private String styleCode;

	@Column(name="SUBREQUEST_ID")
	private BigDecimal subrequestId;

	@Column(name="THREEG_CLASSIFICATION")
	private BigDecimal threegClassification;

	@Column(name="TYPE_APP_CODE")
	private String typeAppCode;

	//bi-directional many-to-one association to TAdmMstRegion
	@ManyToOne
	@JoinColumn(name="REGION_ID")
	private TAdmMstRegion TAdmMstRegion;

	public TSohGsmResourcePool() {
	}

	public long getGsmResourcePoolId() {
		return this.gsmResourcePoolId;
	}

	public void setGsmResourcePoolId(long gsmResourcePoolId) {
		this.gsmResourcePoolId = gsmResourcePoolId;
	}

	public BigDecimal getAccServInstanceId() {
		return this.accServInstanceId;
	}

	public void setAccServInstanceId(BigDecimal accServInstanceId) {
		this.accServInstanceId = accServInstanceId;
	}

	public BigDecimal getAccountId() {
		return this.accountId;
	}

	public void setAccountId(BigDecimal accountId) {
		this.accountId = accountId;
	}

	public BigDecimal getAllocSubreqId() {
		return this.allocSubreqId;
	}

	public void setAllocSubreqId(BigDecimal allocSubreqId) {
		this.allocSubreqId = allocSubreqId;
	}

	public BigDecimal getBatchNo() {
		return this.batchNo;
	}

	public void setBatchNo(BigDecimal batchNo) {
		this.batchNo = batchNo;
	}

	public BigDecimal getCardType() {
		return this.cardType;
	}

	public void setCardType(BigDecimal cardType) {
		this.cardType = cardType;
	}

	public BigDecimal getCessationInd() {
		return this.cessationInd;
	}

	public void setCessationInd(BigDecimal cessationInd) {
		this.cessationInd = cessationInd;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public Date getEffectiveFromDate() {
		return this.effectiveFromDate;
	}

	public void setEffectiveFromDate(Date effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}

	public Timestamp getEffectiveTillDate() {
		return this.effectiveTillDate;
	}

	public void setEffectiveTillDate(Timestamp effectiveTillDate) {
		this.effectiveTillDate = effectiveTillDate;
	}

	public String getEquipmentSerialNo() {
		return this.equipmentSerialNo;
	}

	public void setEquipmentSerialNo(String equipmentSerialNo) {
		this.equipmentSerialNo = equipmentSerialNo;
	}

	public String getEsimEid() {
		return this.esimEid;
	}

	public void setEsimEid(String esimEid) {
		this.esimEid = esimEid;
	}

	public String getEsimFlag() {
		return this.esimFlag;
	}

	public void setEsimFlag(String esimFlag) {
		this.esimFlag = esimFlag;
	}

	public String getEsimIsVolteRequired() {
		return this.esimIsVolteRequired;
	}

	public void setEsimIsVolteRequired(String esimIsVolteRequired) {
		this.esimIsVolteRequired = esimIsVolteRequired;
	}

	public String getEsimOem() {
		return this.esimOem;
	}

	public void setEsimOem(String esimOem) {
		this.esimOem = esimOem;
	}

	public String getFalconReferenceNo() {
		return this.falconReferenceNo;
	}

	public void setFalconReferenceNo(String falconReferenceNo) {
		this.falconReferenceNo = falconReferenceNo;
	}

	public String getFnrIndicator() {
		return this.fnrIndicator;
	}

	public void setFnrIndicator(String fnrIndicator) {
		this.fnrIndicator = fnrIndicator;
	}

	public Date getGuaranteedUntil() {
		return this.guaranteedUntil;
	}

	public void setGuaranteedUntil(Date guaranteedUntil) {
		this.guaranteedUntil = guaranteedUntil;
	}

	public String getIccidNo() {
		return this.iccidNo;
	}

	public void setIccidNo(String iccidNo) {
		this.iccidNo = iccidNo;
	}

	public String getImsiNo() {
		return this.imsiNo;
	}

	public void setImsiNo(String imsiNo) {
		this.imsiNo = imsiNo;
	}

	public String getManufacturerCode() {
		return this.manufacturerCode;
	}

	public void setManufacturerCode(String manufacturerCode) {
		this.manufacturerCode = manufacturerCode;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getNotes1() {
		return this.notes1;
	}

	public void setNotes1(String notes1) {
		this.notes1 = notes1;
	}

	public String getNotes2() {
		return this.notes2;
	}

	public void setNotes2(String notes2) {
		this.notes2 = notes2;
	}

	public String getNotes3() {
		return this.notes3;
	}

	public void setNotes3(String notes3) {
		this.notes3 = notes3;
	}

	public BigDecimal getOrgUnitId() {
		return this.orgUnitId;
	}

	public void setOrgUnitId(BigDecimal orgUnitId) {
		this.orgUnitId = orgUnitId;
	}

	public BigDecimal getPinNo() {
		return this.pinNo;
	}

	public void setPinNo(BigDecimal pinNo) {
		this.pinNo = pinNo;
	}

	public BigDecimal getPukNo() {
		return this.pukNo;
	}

	public void setPukNo(BigDecimal pukNo) {
		this.pukNo = pukNo;
	}

	public Date getReservedTilDate() {
		return this.reservedTilDate;
	}

	public void setReservedTilDate(Date reservedTilDate) {
		this.reservedTilDate = reservedTilDate;
	}

	public BigDecimal getRetailerPartyProfileId() {
		return this.retailerPartyProfileId;
	}

	public void setRetailerPartyProfileId(BigDecimal retailerPartyProfileId) {
		this.retailerPartyProfileId = retailerPartyProfileId;
	}

	public BigDecimal getSimCardStatus() {
		return this.simCardStatus;
	}

	public void setSimCardStatus(BigDecimal simCardStatus) {
		this.simCardStatus = simCardStatus;
	}

	public BigDecimal getSimReasonCode() {
		return this.simReasonCode;
	}

	public void setSimReasonCode(BigDecimal simReasonCode) {
		this.simReasonCode = simReasonCode;
	}

	public BigDecimal getSrServInstanceId() {
		return this.srServInstanceId;
	}

	public void setSrServInstanceId(BigDecimal srServInstanceId) {
		this.srServInstanceId = srServInstanceId;
	}

	public BigDecimal getStatusTo() {
		return this.statusTo;
	}

	public void setStatusTo(BigDecimal statusTo) {
		this.statusTo = statusTo;
	}

	public String getStatusToFlag() {
		return this.statusToFlag;
	}

	public void setStatusToFlag(String statusToFlag) {
		this.statusToFlag = statusToFlag;
	}

	public String getStyleCode() {
		return this.styleCode;
	}

	public void setStyleCode(String styleCode) {
		this.styleCode = styleCode;
	}

	public BigDecimal getSubrequestId() {
		return this.subrequestId;
	}

	public void setSubrequestId(BigDecimal subrequestId) {
		this.subrequestId = subrequestId;
	}

	public BigDecimal getThreegClassification() {
		return this.threegClassification;
	}

	public void setThreegClassification(BigDecimal threegClassification) {
		this.threegClassification = threegClassification;
	}

	public String getTypeAppCode() {
		return this.typeAppCode;
	}

	public void setTypeAppCode(String typeAppCode) {
		this.typeAppCode = typeAppCode;
	}

	public TAdmMstRegion getTAdmMstRegion() {
		return this.TAdmMstRegion;
	}

	public void setTAdmMstRegion(TAdmMstRegion TAdmMstRegion) {
		this.TAdmMstRegion = TAdmMstRegion;
	}

}