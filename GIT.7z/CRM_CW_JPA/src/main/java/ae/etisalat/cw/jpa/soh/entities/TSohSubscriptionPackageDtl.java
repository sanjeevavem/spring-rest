package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the T_SOH_SUBSCRIPTION_PACKAGE_DTL database table.
 * 
 */
@Entity
@Table(name="T_SOH_SUBSCRIPTION_PACKAGE_DTL")
@NamedQuery(name="TSohSubscriptionPackageDtl.findAll", query="SELECT t FROM TSohSubscriptionPackageDtl t")
public class TSohSubscriptionPackageDtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_SOH_SUBSCRIPTION_PACKAGE_DTL_PACKAGESUBSCRIPTIONID_GENERATOR", sequenceName="SQ_T_SOH_SUBSCRIPTION_PKG_DTL",allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_SOH_SUBSCRIPTION_PACKAGE_DTL_PACKAGESUBSCRIPTIONID_GENERATOR")
	@Column(name="PACKAGE_SUBSCRIPTION_ID")
	private long packageSubscriptionId;

	@Column(name="ACCOUNT_ID")
	private BigDecimal accountId;

	@Column(name="AUTO_RENEWAL_FLAG")
	private String autoRenewalFlag;

	@Column(name="BUNDLE_SUBSCRIPTION_ID")
	private BigDecimal bundleSubscriptionId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_FROM_DATE")
	private Date effectiveFromDate;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_TILL_DATE")
	private Date effectiveTillDate;

	@Temporal(TemporalType.DATE)
	@Column(name="EXIT_PLCY_END_DATE")
	private Date exitPlcyEndDate;

	@Column(name="EXIT_PLCY_FLAG")
	private String exitPlcyFlag;

	@Column(name="EXIT_PLCY_ID")
	private BigDecimal exitPlcyId;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="PACKAGE_ID")
	private BigDecimal packageId;

	@Column(name="SUBSCRIPTION_RENEWAL_DATE")
	private Timestamp subscriptionRenewalDate;

	//bi-directional many-to-one association to TSohSubscriptionRateplnDtl
	@OneToMany(mappedBy="TSohSubscriptionPackageDtl")
	private List<TSohSubscriptionRateplnDtl> TSohSubscriptionRateplnDtls;

	public TSohSubscriptionPackageDtl() {
	}

	public long getPackageSubscriptionId() {
		return this.packageSubscriptionId;
	}

	public void setPackageSubscriptionId(long packageSubscriptionId) {
		this.packageSubscriptionId = packageSubscriptionId;
	}

	public BigDecimal getAccountId() {
		return this.accountId;
	}

	public void setAccountId(BigDecimal accountId) {
		this.accountId = accountId;
	}

	public String getAutoRenewalFlag() {
		return this.autoRenewalFlag;
	}

	public void setAutoRenewalFlag(String autoRenewalFlag) {
		this.autoRenewalFlag = autoRenewalFlag;
	}

	public BigDecimal getBundleSubscriptionId() {
		return this.bundleSubscriptionId;
	}

	public void setBundleSubscriptionId(BigDecimal bundleSubscriptionId) {
		this.bundleSubscriptionId = bundleSubscriptionId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Date getEffectiveFromDate() {
		return this.effectiveFromDate;
	}

	public void setEffectiveFromDate(Date effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}

	public Date getEffectiveTillDate() {
		return this.effectiveTillDate;
	}

	public void setEffectiveTillDate(Date effectiveTillDate) {
		this.effectiveTillDate = effectiveTillDate;
	}

	public Date getExitPlcyEndDate() {
		return this.exitPlcyEndDate;
	}

	public void setExitPlcyEndDate(Date exitPlcyEndDate) {
		this.exitPlcyEndDate = exitPlcyEndDate;
	}

	public String getExitPlcyFlag() {
		return this.exitPlcyFlag;
	}

	public void setExitPlcyFlag(String exitPlcyFlag) {
		this.exitPlcyFlag = exitPlcyFlag;
	}

	public BigDecimal getExitPlcyId() {
		return this.exitPlcyId;
	}

	public void setExitPlcyId(BigDecimal exitPlcyId) {
		this.exitPlcyId = exitPlcyId;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getPackageId() {
		return this.packageId;
	}

	public void setPackageId(BigDecimal packageId) {
		this.packageId = packageId;
	}

	public Timestamp getSubscriptionRenewalDate() {
		return this.subscriptionRenewalDate;
	}

	public void setSubscriptionRenewalDate(Timestamp subscriptionRenewalDate) {
		this.subscriptionRenewalDate = subscriptionRenewalDate;
	}

	public List<TSohSubscriptionRateplnDtl> getTSohSubscriptionRateplnDtls() {
		return this.TSohSubscriptionRateplnDtls;
	}

	public void setTSohSubscriptionRateplnDtls(List<TSohSubscriptionRateplnDtl> TSohSubscriptionRateplnDtls) {
		this.TSohSubscriptionRateplnDtls = TSohSubscriptionRateplnDtls;
	}

	public TSohSubscriptionRateplnDtl addTSohSubscriptionRateplnDtl(TSohSubscriptionRateplnDtl TSohSubscriptionRateplnDtl) {
		getTSohSubscriptionRateplnDtls().add(TSohSubscriptionRateplnDtl);
		TSohSubscriptionRateplnDtl.setTSohSubscriptionPackageDtl(this);

		return TSohSubscriptionRateplnDtl;
	}

	public TSohSubscriptionRateplnDtl removeTSohSubscriptionRateplnDtl(TSohSubscriptionRateplnDtl TSohSubscriptionRateplnDtl) {
		getTSohSubscriptionRateplnDtls().remove(TSohSubscriptionRateplnDtl);
		TSohSubscriptionRateplnDtl.setTSohSubscriptionPackageDtl(null);

		return TSohSubscriptionRateplnDtl;
	}

}