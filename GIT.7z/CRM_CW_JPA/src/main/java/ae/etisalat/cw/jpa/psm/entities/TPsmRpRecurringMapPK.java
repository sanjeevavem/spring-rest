package ae.etisalat.cw.jpa.psm.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the T_PSM_RP_RECURRING_MAP database table.
 * 
 */
@Embeddable
public class TPsmRpRecurringMapPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="RECURR_CHARGE_TYPE_ID", insertable=false, updatable=false)
	private long recurrChargeTypeId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="RP_EFFECTIVE_FROM_DATE", insertable=false, updatable=false)
	private java.util.Date rpEffectiveFromDate;

	@Column(name="RATE_PLAN_ID", insertable=false, updatable=false)
	private long ratePlanId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="EFFECTIVE_FROM_DATE", insertable=false, updatable=false)
	private java.util.Date effectiveFromDate;

	public TPsmRpRecurringMapPK() {
	}
	public long getRecurrChargeTypeId() {
		return this.recurrChargeTypeId;
	}
	public void setRecurrChargeTypeId(long recurrChargeTypeId) {
		this.recurrChargeTypeId = recurrChargeTypeId;
	}
	public java.util.Date getRpEffectiveFromDate() {
		return this.rpEffectiveFromDate;
	}
	public void setRpEffectiveFromDate(java.util.Date rpEffectiveFromDate) {
		this.rpEffectiveFromDate = rpEffectiveFromDate;
	}
	public long getRatePlanId() {
		return this.ratePlanId;
	}
	public void setRatePlanId(long ratePlanId) {
		this.ratePlanId = ratePlanId;
	}
	public java.util.Date getEffectiveFromDate() {
		return this.effectiveFromDate;
	}
	public void setEffectiveFromDate(java.util.Date effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TPsmRpRecurringMapPK)) {
			return false;
		}
		TPsmRpRecurringMapPK castOther = (TPsmRpRecurringMapPK)other;
		return 
			(this.recurrChargeTypeId == castOther.recurrChargeTypeId)
			&& this.rpEffectiveFromDate.equals(castOther.rpEffectiveFromDate)
			&& (this.ratePlanId == castOther.ratePlanId)
			&& this.effectiveFromDate.equals(castOther.effectiveFromDate);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.recurrChargeTypeId ^ (this.recurrChargeTypeId >>> 32)));
		hash = hash * prime + this.rpEffectiveFromDate.hashCode();
		hash = hash * prime + ((int) (this.ratePlanId ^ (this.ratePlanId >>> 32)));
		hash = hash * prime + this.effectiveFromDate.hashCode();
		
		return hash;
	}
}