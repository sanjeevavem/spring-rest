package ae.etisalat.cw.jpa.psm.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the T_PSM_MST_RECURR_CHRG_TYPE database table.
 * 
 */
@Entity
@Table(name="T_PSM_MST_RECURR_CHRG_TYPE")
@NamedQuery(name="TPsmMstRecurrChrgType.findAll", query="SELECT t FROM TPsmMstRecurrChrgType t")
public class TPsmMstRecurrChrgType implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TPsmMstRecurrChrgTypePK id;

	@Column(name="ACCOUNT_CATEGORY_FLAG")
	private BigDecimal accountCategoryFlag;

	@Column(name="ACCOUNT_REGION_FLAG")
	private BigDecimal accountRegionFlag;

	@Column(name="COMPANY_TYPE_FLAG")
	private BigDecimal companyTypeFlag;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="CURRENCY_ID")
	private BigDecimal currencyId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="DESCRIPTION_ID")
	private BigDecimal descriptionId;

	@Column(name="EFFECTIVE_TILL_DATE")
	private Timestamp effectiveTillDate;

	@Column(name="EMIRATE_FLAG")
	private BigDecimal emirateFlag;

	@Column(name="INDUSTRY_TYPE_FLAG")
	private BigDecimal industryTypeFlag;

	@Column(name="MARKET_SEGMENT_FLAG")
	private BigDecimal marketSegmentFlag;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="NATIONALITY_FLAG")
	private BigDecimal nationalityFlag;

	@Column(name="OFFER_FROM_DATE")
	private Timestamp offerFromDate;

	@Column(name="OFFER_TILL_DATE")
	private Timestamp offerTillDate;

	@Column(name="OFFSET_PERIOD")
	private BigDecimal offsetPeriod;

	@Column(name="PARTY_AGE_FLAG")
	private BigDecimal partyAgeFlag;

	@Column(name="PARTY_NAME_FLAG")
	private BigDecimal partyNameFlag;

	@Column(name="PARTY_SUBTYPE_FLAG")
	private BigDecimal partySubtypeFlag;

	@Column(name="PARTY_TYPE_FLAG")
	private BigDecimal partyTypeFlag;

	private BigDecimal percentage;

	@Column(name="PRESET_PERIOD")
	private BigDecimal presetPeriod;

	@Column(name="PROFESSION_FLAG")
	private BigDecimal professionFlag;

	@Column(name="PRORATING_INDICATOR")
	private BigDecimal proratingIndicator;

	private BigDecimal rate;

	@Column(name="RATE_FREQUENCY")
	private BigDecimal rateFrequency;

	@Column(name="RATE_INDICATOR")
	private BigDecimal rateIndicator;

	@Column(name="RATE_TYPE")
	private BigDecimal rateType;

	@Column(name="RECURR_CHARGE_TYPE_CODE")
	private String recurrChargeTypeCode;

	@Column(name="RECURR_CHARGE_TYPE_VER")
	private BigDecimal recurrChargeTypeVer;

	@Column(name="RECURR_RATE_MTRX_ID")
	private BigDecimal recurrRateMtrxId;

	@Column(name="RECURTMTRX_EFFECTIVE_FROM_DATE")
	private Timestamp recurtmtrxEffectiveFromDate;

	@Column(name="REDUCTION_AMOUNT")
	private BigDecimal reductionAmount;

	@Column(name="REDUCTION_RATE")
	private BigDecimal reductionRate;

	@Column(name="REDUCTION_TYPE")
	private BigDecimal reductionType;

	private String remarks;

	@Column(name="SERVICE_QUANTITY_FLAG")
	private BigDecimal serviceQuantityFlag;

	@Column(name="SUBSCRIPTION_PERIOD_FLAG")
	private BigDecimal subscriptionPeriodFlag;

	//bi-directional many-to-one association to TPsmDtlSystemCodeValue
	@ManyToOne
	@JoinColumn(name="STATUS_ID")
	private TPsmDtlSystemCodeValue TPsmDtlSystemCodeValue;

	//bi-directional many-to-one association to TPsmMstSrvc
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="SRVC_EFFECTIVE_FROM_DATE", referencedColumnName="EFFECTIVE_FROM_DATE"),
		@JoinColumn(name="SRVC_ID", referencedColumnName="SRVC_ID")
		})
	private TPsmMstSrvc TPsmMstSrvc;

	//bi-directional many-to-one association to TPsmRpRecurringMap
	@OneToMany(mappedBy="TPsmMstRecurrChrgType")
	private List<TPsmRpRecurringMap> TPsmRpRecurringMaps;

	public TPsmMstRecurrChrgType() {
	}

	public TPsmMstRecurrChrgTypePK getId() {
		return this.id;
	}

	public void setId(TPsmMstRecurrChrgTypePK id) {
		this.id = id;
	}

	public BigDecimal getAccountCategoryFlag() {
		return this.accountCategoryFlag;
	}

	public void setAccountCategoryFlag(BigDecimal accountCategoryFlag) {
		this.accountCategoryFlag = accountCategoryFlag;
	}

	public BigDecimal getAccountRegionFlag() {
		return this.accountRegionFlag;
	}

	public void setAccountRegionFlag(BigDecimal accountRegionFlag) {
		this.accountRegionFlag = accountRegionFlag;
	}

	public BigDecimal getCompanyTypeFlag() {
		return this.companyTypeFlag;
	}

	public void setCompanyTypeFlag(BigDecimal companyTypeFlag) {
		this.companyTypeFlag = companyTypeFlag;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public BigDecimal getCurrencyId() {
		return this.currencyId;
	}

	public void setCurrencyId(BigDecimal currencyId) {
		this.currencyId = currencyId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public BigDecimal getDescriptionId() {
		return this.descriptionId;
	}

	public void setDescriptionId(BigDecimal descriptionId) {
		this.descriptionId = descriptionId;
	}

	public Timestamp getEffectiveTillDate() {
		return this.effectiveTillDate;
	}

	public void setEffectiveTillDate(Timestamp effectiveTillDate) {
		this.effectiveTillDate = effectiveTillDate;
	}

	public BigDecimal getEmirateFlag() {
		return this.emirateFlag;
	}

	public void setEmirateFlag(BigDecimal emirateFlag) {
		this.emirateFlag = emirateFlag;
	}

	public BigDecimal getIndustryTypeFlag() {
		return this.industryTypeFlag;
	}

	public void setIndustryTypeFlag(BigDecimal industryTypeFlag) {
		this.industryTypeFlag = industryTypeFlag;
	}

	public BigDecimal getMarketSegmentFlag() {
		return this.marketSegmentFlag;
	}

	public void setMarketSegmentFlag(BigDecimal marketSegmentFlag) {
		this.marketSegmentFlag = marketSegmentFlag;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getNationalityFlag() {
		return this.nationalityFlag;
	}

	public void setNationalityFlag(BigDecimal nationalityFlag) {
		this.nationalityFlag = nationalityFlag;
	}

	public Timestamp getOfferFromDate() {
		return this.offerFromDate;
	}

	public void setOfferFromDate(Timestamp offerFromDate) {
		this.offerFromDate = offerFromDate;
	}

	public Timestamp getOfferTillDate() {
		return this.offerTillDate;
	}

	public void setOfferTillDate(Timestamp offerTillDate) {
		this.offerTillDate = offerTillDate;
	}

	public BigDecimal getOffsetPeriod() {
		return this.offsetPeriod;
	}

	public void setOffsetPeriod(BigDecimal offsetPeriod) {
		this.offsetPeriod = offsetPeriod;
	}

	public BigDecimal getPartyAgeFlag() {
		return this.partyAgeFlag;
	}

	public void setPartyAgeFlag(BigDecimal partyAgeFlag) {
		this.partyAgeFlag = partyAgeFlag;
	}

	public BigDecimal getPartyNameFlag() {
		return this.partyNameFlag;
	}

	public void setPartyNameFlag(BigDecimal partyNameFlag) {
		this.partyNameFlag = partyNameFlag;
	}

	public BigDecimal getPartySubtypeFlag() {
		return this.partySubtypeFlag;
	}

	public void setPartySubtypeFlag(BigDecimal partySubtypeFlag) {
		this.partySubtypeFlag = partySubtypeFlag;
	}

	public BigDecimal getPartyTypeFlag() {
		return this.partyTypeFlag;
	}

	public void setPartyTypeFlag(BigDecimal partyTypeFlag) {
		this.partyTypeFlag = partyTypeFlag;
	}

	public BigDecimal getPercentage() {
		return this.percentage;
	}

	public void setPercentage(BigDecimal percentage) {
		this.percentage = percentage;
	}

	public BigDecimal getPresetPeriod() {
		return this.presetPeriod;
	}

	public void setPresetPeriod(BigDecimal presetPeriod) {
		this.presetPeriod = presetPeriod;
	}

	public BigDecimal getProfessionFlag() {
		return this.professionFlag;
	}

	public void setProfessionFlag(BigDecimal professionFlag) {
		this.professionFlag = professionFlag;
	}

	public BigDecimal getProratingIndicator() {
		return this.proratingIndicator;
	}

	public void setProratingIndicator(BigDecimal proratingIndicator) {
		this.proratingIndicator = proratingIndicator;
	}

	public BigDecimal getRate() {
		return this.rate;
	}

	public void setRate(BigDecimal rate) {
		this.rate = rate;
	}

	public BigDecimal getRateFrequency() {
		return this.rateFrequency;
	}

	public void setRateFrequency(BigDecimal rateFrequency) {
		this.rateFrequency = rateFrequency;
	}

	public BigDecimal getRateIndicator() {
		return this.rateIndicator;
	}

	public void setRateIndicator(BigDecimal rateIndicator) {
		this.rateIndicator = rateIndicator;
	}

	public BigDecimal getRateType() {
		return this.rateType;
	}

	public void setRateType(BigDecimal rateType) {
		this.rateType = rateType;
	}

	public String getRecurrChargeTypeCode() {
		return this.recurrChargeTypeCode;
	}

	public void setRecurrChargeTypeCode(String recurrChargeTypeCode) {
		this.recurrChargeTypeCode = recurrChargeTypeCode;
	}

	public BigDecimal getRecurrChargeTypeVer() {
		return this.recurrChargeTypeVer;
	}

	public void setRecurrChargeTypeVer(BigDecimal recurrChargeTypeVer) {
		this.recurrChargeTypeVer = recurrChargeTypeVer;
	}

	public BigDecimal getRecurrRateMtrxId() {
		return this.recurrRateMtrxId;
	}

	public void setRecurrRateMtrxId(BigDecimal recurrRateMtrxId) {
		this.recurrRateMtrxId = recurrRateMtrxId;
	}

	public Timestamp getRecurtmtrxEffectiveFromDate() {
		return this.recurtmtrxEffectiveFromDate;
	}

	public void setRecurtmtrxEffectiveFromDate(Timestamp recurtmtrxEffectiveFromDate) {
		this.recurtmtrxEffectiveFromDate = recurtmtrxEffectiveFromDate;
	}

	public BigDecimal getReductionAmount() {
		return this.reductionAmount;
	}

	public void setReductionAmount(BigDecimal reductionAmount) {
		this.reductionAmount = reductionAmount;
	}

	public BigDecimal getReductionRate() {
		return this.reductionRate;
	}

	public void setReductionRate(BigDecimal reductionRate) {
		this.reductionRate = reductionRate;
	}

	public BigDecimal getReductionType() {
		return this.reductionType;
	}

	public void setReductionType(BigDecimal reductionType) {
		this.reductionType = reductionType;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public BigDecimal getServiceQuantityFlag() {
		return this.serviceQuantityFlag;
	}

	public void setServiceQuantityFlag(BigDecimal serviceQuantityFlag) {
		this.serviceQuantityFlag = serviceQuantityFlag;
	}

	public BigDecimal getSubscriptionPeriodFlag() {
		return this.subscriptionPeriodFlag;
	}

	public void setSubscriptionPeriodFlag(BigDecimal subscriptionPeriodFlag) {
		this.subscriptionPeriodFlag = subscriptionPeriodFlag;
	}

	public TPsmDtlSystemCodeValue getTPsmDtlSystemCodeValue() {
		return this.TPsmDtlSystemCodeValue;
	}

	public void setTPsmDtlSystemCodeValue(TPsmDtlSystemCodeValue TPsmDtlSystemCodeValue) {
		this.TPsmDtlSystemCodeValue = TPsmDtlSystemCodeValue;
	}

	public TPsmMstSrvc getTPsmMstSrvc() {
		return this.TPsmMstSrvc;
	}

	public void setTPsmMstSrvc(TPsmMstSrvc TPsmMstSrvc) {
		this.TPsmMstSrvc = TPsmMstSrvc;
	}

	public List<TPsmRpRecurringMap> getTPsmRpRecurringMaps() {
		return this.TPsmRpRecurringMaps;
	}

	public void setTPsmRpRecurringMaps(List<TPsmRpRecurringMap> TPsmRpRecurringMaps) {
		this.TPsmRpRecurringMaps = TPsmRpRecurringMaps;
	}

	public TPsmRpRecurringMap addTPsmRpRecurringMap(TPsmRpRecurringMap TPsmRpRecurringMap) {
		getTPsmRpRecurringMaps().add(TPsmRpRecurringMap);
		TPsmRpRecurringMap.setTPsmMstRecurrChrgType(this);

		return TPsmRpRecurringMap;
	}

	public TPsmRpRecurringMap removeTPsmRpRecurringMap(TPsmRpRecurringMap TPsmRpRecurringMap) {
		getTPsmRpRecurringMaps().remove(TPsmRpRecurringMap);
		TPsmRpRecurringMap.setTPsmMstRecurrChrgType(null);

		return TPsmRpRecurringMap;
	}

}