package ae.etisalat.cw.jpa.psm.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the T_PSM_MST_ONETM_CHRG_TYPE database table.
 * 
 */
@Entity
@Table(name="T_PSM_MST_ONETM_CHRG_TYPE")
@NamedQuery(name="TPsmMstOnetmChrgType.findAll", query="SELECT t FROM TPsmMstOnetmChrgType t")
public class TPsmMstOnetmChrgType implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TPsmMstOnetmChrgTypePK id;

	@Column(name="ACCOUNT_CATEGORY_FLAG")
	private BigDecimal accountCategoryFlag;

	@Column(name="ACCOUNT_REGION_FLAG")
	private BigDecimal accountRegionFlag;

	@Column(name="CLASSIFICATION_ID")
	private BigDecimal classificationId;

	@Column(name="COMPANY_TYPE_FLAG")
	private BigDecimal companyTypeFlag;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="CURRENCY_ID")
	private BigDecimal currencyId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="DESC_ID")
	private BigDecimal descId;

	@Column(name="DOWN_PAYMENT_AMT")
	private BigDecimal downPaymentAmt;

	@Column(name="EFFECTIVE_TILL_DATE")
	private Timestamp effectiveTillDate;

	@Column(name="EMIRATE_FLAG")
	private BigDecimal emirateFlag;

	@Column(name="INDUSTRY_TYPE_FLAG")
	private BigDecimal industryTypeFlag;

	@Column(name="INSTALLMENT_INDICATOR_FLAG")
	private BigDecimal installmentIndicatorFlag;

	@Column(name="INSTALLMENT_TYPE_FLAG")
	private BigDecimal installmentTypeFlag;

	@Column(name="MARKET_SEGMENT_FLAG")
	private BigDecimal marketSegmentFlag;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="NATIONALITY_FLAG")
	private BigDecimal nationalityFlag;

	@Column(name="OFFER_FROM_DATE")
	private Timestamp offerFromDate;

	@Column(name="OFFER_TILL_DATE")
	private Timestamp offerTillDate;

	@Column(name="ONETIME_CHARGE_TYPE_CODE")
	private String onetimeChargeTypeCode;

	@Column(name="ONETIME_CHARGE_TYPE_VERSION")
	private BigDecimal onetimeChargeTypeVersion;

	@Column(name="ONETIME_RATE_MTRX_ID")
	private BigDecimal onetimeRateMtrxId;

	@Column(name="OT_RTMTRX_EFFECTIVE_FROM_DATE")
	private Timestamp otRtmtrxEffectiveFromDate;

	@Column(name="PARTY_AGE_FLAG")
	private BigDecimal partyAgeFlag;

	@Column(name="PARTY_NAME_FLAG")
	private BigDecimal partyNameFlag;

	@Column(name="PARTY_SUBTYPE_FLAG")
	private BigDecimal partySubtypeFlag;

	@Column(name="PARTY_TYPE_FLAG")
	private BigDecimal partyTypeFlag;

	@Column(name="PROFESSION_FLAG")
	private BigDecimal professionFlag;

	private BigDecimal rate;

	@Column(name="RATE_INDICATOR_FLAG")
	private BigDecimal rateIndicatorFlag;

	@Column(name="REDUCTION_INDICATOR_FLAG")
	private BigDecimal reductionIndicatorFlag;

	@Column(name="REDUCTION_MAX_LIMIT")
	private BigDecimal reductionMaxLimit;

	@Column(name="REDUCTION_PERCENTAGE")
	private BigDecimal reductionPercentage;

	@Column(name="REDUCTION_RATE")
	private BigDecimal reductionRate;

	private String remarks;

	@Column(name="SRVC_QUANTITY_FLAG")
	private BigDecimal srvcQuantityFlag;

	@Column(name="STATUS_ID")
	private BigDecimal statusId;

	@Column(name="SUBCRIPTION_PERIOD_FLAG")
	private BigDecimal subcriptionPeriodFlag;

	@Column(name="TOTAL_AMOUNT")
	private BigDecimal totalAmount;

	//bi-directional many-to-one association to TPsmRpOnetimeMap
	@OneToMany(mappedBy="TPsmMstOnetmChrgType")
	private List<TPsmRpOnetimeMap> TPsmRpOnetimeMaps;

	//bi-directional many-to-one association to TPsmMstSrvc
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="SRVC_EFFECTIVE_FROM_DATE", referencedColumnName="EFFECTIVE_FROM_DATE"),
		@JoinColumn(name="SRVC_ID", referencedColumnName="SRVC_ID")
		})
	private TPsmMstSrvc TPsmMstSrvc;

	public TPsmMstOnetmChrgType() {
	}

	public TPsmMstOnetmChrgTypePK getId() {
		return this.id;
	}

	public void setId(TPsmMstOnetmChrgTypePK id) {
		this.id = id;
	}

	public BigDecimal getAccountCategoryFlag() {
		return this.accountCategoryFlag;
	}

	public void setAccountCategoryFlag(BigDecimal accountCategoryFlag) {
		this.accountCategoryFlag = accountCategoryFlag;
	}

	public BigDecimal getAccountRegionFlag() {
		return this.accountRegionFlag;
	}

	public void setAccountRegionFlag(BigDecimal accountRegionFlag) {
		this.accountRegionFlag = accountRegionFlag;
	}

	public BigDecimal getClassificationId() {
		return this.classificationId;
	}

	public void setClassificationId(BigDecimal classificationId) {
		this.classificationId = classificationId;
	}

	public BigDecimal getCompanyTypeFlag() {
		return this.companyTypeFlag;
	}

	public void setCompanyTypeFlag(BigDecimal companyTypeFlag) {
		this.companyTypeFlag = companyTypeFlag;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public BigDecimal getCurrencyId() {
		return this.currencyId;
	}

	public void setCurrencyId(BigDecimal currencyId) {
		this.currencyId = currencyId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public BigDecimal getDescId() {
		return this.descId;
	}

	public void setDescId(BigDecimal descId) {
		this.descId = descId;
	}

	public BigDecimal getDownPaymentAmt() {
		return this.downPaymentAmt;
	}

	public void setDownPaymentAmt(BigDecimal downPaymentAmt) {
		this.downPaymentAmt = downPaymentAmt;
	}

	public Timestamp getEffectiveTillDate() {
		return this.effectiveTillDate;
	}

	public void setEffectiveTillDate(Timestamp effectiveTillDate) {
		this.effectiveTillDate = effectiveTillDate;
	}

	public BigDecimal getEmirateFlag() {
		return this.emirateFlag;
	}

	public void setEmirateFlag(BigDecimal emirateFlag) {
		this.emirateFlag = emirateFlag;
	}

	public BigDecimal getIndustryTypeFlag() {
		return this.industryTypeFlag;
	}

	public void setIndustryTypeFlag(BigDecimal industryTypeFlag) {
		this.industryTypeFlag = industryTypeFlag;
	}

	public BigDecimal getInstallmentIndicatorFlag() {
		return this.installmentIndicatorFlag;
	}

	public void setInstallmentIndicatorFlag(BigDecimal installmentIndicatorFlag) {
		this.installmentIndicatorFlag = installmentIndicatorFlag;
	}

	public BigDecimal getInstallmentTypeFlag() {
		return this.installmentTypeFlag;
	}

	public void setInstallmentTypeFlag(BigDecimal installmentTypeFlag) {
		this.installmentTypeFlag = installmentTypeFlag;
	}

	public BigDecimal getMarketSegmentFlag() {
		return this.marketSegmentFlag;
	}

	public void setMarketSegmentFlag(BigDecimal marketSegmentFlag) {
		this.marketSegmentFlag = marketSegmentFlag;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getNationalityFlag() {
		return this.nationalityFlag;
	}

	public void setNationalityFlag(BigDecimal nationalityFlag) {
		this.nationalityFlag = nationalityFlag;
	}

	public Timestamp getOfferFromDate() {
		return this.offerFromDate;
	}

	public void setOfferFromDate(Timestamp offerFromDate) {
		this.offerFromDate = offerFromDate;
	}

	public Timestamp getOfferTillDate() {
		return this.offerTillDate;
	}

	public void setOfferTillDate(Timestamp offerTillDate) {
		this.offerTillDate = offerTillDate;
	}

	public String getOnetimeChargeTypeCode() {
		return this.onetimeChargeTypeCode;
	}

	public void setOnetimeChargeTypeCode(String onetimeChargeTypeCode) {
		this.onetimeChargeTypeCode = onetimeChargeTypeCode;
	}

	public BigDecimal getOnetimeChargeTypeVersion() {
		return this.onetimeChargeTypeVersion;
	}

	public void setOnetimeChargeTypeVersion(BigDecimal onetimeChargeTypeVersion) {
		this.onetimeChargeTypeVersion = onetimeChargeTypeVersion;
	}

	public BigDecimal getOnetimeRateMtrxId() {
		return this.onetimeRateMtrxId;
	}

	public void setOnetimeRateMtrxId(BigDecimal onetimeRateMtrxId) {
		this.onetimeRateMtrxId = onetimeRateMtrxId;
	}

	public Timestamp getOtRtmtrxEffectiveFromDate() {
		return this.otRtmtrxEffectiveFromDate;
	}

	public void setOtRtmtrxEffectiveFromDate(Timestamp otRtmtrxEffectiveFromDate) {
		this.otRtmtrxEffectiveFromDate = otRtmtrxEffectiveFromDate;
	}

	public BigDecimal getPartyAgeFlag() {
		return this.partyAgeFlag;
	}

	public void setPartyAgeFlag(BigDecimal partyAgeFlag) {
		this.partyAgeFlag = partyAgeFlag;
	}

	public BigDecimal getPartyNameFlag() {
		return this.partyNameFlag;
	}

	public void setPartyNameFlag(BigDecimal partyNameFlag) {
		this.partyNameFlag = partyNameFlag;
	}

	public BigDecimal getPartySubtypeFlag() {
		return this.partySubtypeFlag;
	}

	public void setPartySubtypeFlag(BigDecimal partySubtypeFlag) {
		this.partySubtypeFlag = partySubtypeFlag;
	}

	public BigDecimal getPartyTypeFlag() {
		return this.partyTypeFlag;
	}

	public void setPartyTypeFlag(BigDecimal partyTypeFlag) {
		this.partyTypeFlag = partyTypeFlag;
	}

	public BigDecimal getProfessionFlag() {
		return this.professionFlag;
	}

	public void setProfessionFlag(BigDecimal professionFlag) {
		this.professionFlag = professionFlag;
	}

	public BigDecimal getRate() {
		return this.rate;
	}

	public void setRate(BigDecimal rate) {
		this.rate = rate;
	}

	public BigDecimal getRateIndicatorFlag() {
		return this.rateIndicatorFlag;
	}

	public void setRateIndicatorFlag(BigDecimal rateIndicatorFlag) {
		this.rateIndicatorFlag = rateIndicatorFlag;
	}

	public BigDecimal getReductionIndicatorFlag() {
		return this.reductionIndicatorFlag;
	}

	public void setReductionIndicatorFlag(BigDecimal reductionIndicatorFlag) {
		this.reductionIndicatorFlag = reductionIndicatorFlag;
	}

	public BigDecimal getReductionMaxLimit() {
		return this.reductionMaxLimit;
	}

	public void setReductionMaxLimit(BigDecimal reductionMaxLimit) {
		this.reductionMaxLimit = reductionMaxLimit;
	}

	public BigDecimal getReductionPercentage() {
		return this.reductionPercentage;
	}

	public void setReductionPercentage(BigDecimal reductionPercentage) {
		this.reductionPercentage = reductionPercentage;
	}

	public BigDecimal getReductionRate() {
		return this.reductionRate;
	}

	public void setReductionRate(BigDecimal reductionRate) {
		this.reductionRate = reductionRate;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public BigDecimal getSrvcQuantityFlag() {
		return this.srvcQuantityFlag;
	}

	public void setSrvcQuantityFlag(BigDecimal srvcQuantityFlag) {
		this.srvcQuantityFlag = srvcQuantityFlag;
	}

	public BigDecimal getStatusId() {
		return this.statusId;
	}

	public void setStatusId(BigDecimal statusId) {
		this.statusId = statusId;
	}

	public BigDecimal getSubcriptionPeriodFlag() {
		return this.subcriptionPeriodFlag;
	}

	public void setSubcriptionPeriodFlag(BigDecimal subcriptionPeriodFlag) {
		this.subcriptionPeriodFlag = subcriptionPeriodFlag;
	}

	public BigDecimal getTotalAmount() {
		return this.totalAmount;
	}

	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}

	public List<TPsmRpOnetimeMap> getTPsmRpOnetimeMaps() {
		return this.TPsmRpOnetimeMaps;
	}

	public void setTPsmRpOnetimeMaps(List<TPsmRpOnetimeMap> TPsmRpOnetimeMaps) {
		this.TPsmRpOnetimeMaps = TPsmRpOnetimeMaps;
	}

	public TPsmRpOnetimeMap addTPsmRpOnetimeMap(TPsmRpOnetimeMap TPsmRpOnetimeMap) {
		getTPsmRpOnetimeMaps().add(TPsmRpOnetimeMap);
		TPsmRpOnetimeMap.setTPsmMstOnetmChrgType(this);

		return TPsmRpOnetimeMap;
	}

	public TPsmRpOnetimeMap removeTPsmRpOnetimeMap(TPsmRpOnetimeMap TPsmRpOnetimeMap) {
		getTPsmRpOnetimeMaps().remove(TPsmRpOnetimeMap);
		TPsmRpOnetimeMap.setTPsmMstOnetmChrgType(null);

		return TPsmRpOnetimeMap;
	}

	public TPsmMstSrvc getTPsmMstSrvc() {
		return this.TPsmMstSrvc;
	}

	public void setTPsmMstSrvc(TPsmMstSrvc TPsmMstSrvc) {
		this.TPsmMstSrvc = TPsmMstSrvc;
	}

}