package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the T_SOH_SUBREQ_ACCOUNT_INFO database table.
 * 
 */
@Entity
@Table(name="T_SOH_SUBREQ_ACCOUNT_INFO")
@NamedQuery(name="TSohSubreqAccountInfo.findAll", query="SELECT t FROM TSohSubreqAccountInfo t")
public class TSohSubreqAccountInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="ACCOUNT_ID")
	private BigDecimal accountId;

	@Column(name="ACCOUNT_NUMBER")
	private String accountNumber;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="SUBREQ_TYPE_ID")
	private BigDecimal subreqTypeId;

	@Id
	@Column(name="SUBREQACC_ID")
	private BigDecimal subreqaccId;

	public TSohSubreqAccountInfo() {
	}

	public BigDecimal getAccountId() {
		return this.accountId;
	}

	public void setAccountId(BigDecimal accountId) {
		this.accountId = accountId;
	}

	public String getAccountNumber() {
		return this.accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getSubreqTypeId() {
		return this.subreqTypeId;
	}

	public void setSubreqTypeId(BigDecimal subreqTypeId) {
		this.subreqTypeId = subreqTypeId;
	}

	public BigDecimal getSubreqaccId() {
		return this.subreqaccId;
	}

	public void setSubreqaccId(BigDecimal subreqaccId) {
		this.subreqaccId = subreqaccId;
	}

}