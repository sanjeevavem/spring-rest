package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the T_SOH_ACCT_INSTALLATION_ADDR database table.
 * 
 */
@Entity
@Table(name="T_SOH_ACCT_INSTALLATION_ADDR")
@NamedQuery(name="TSohAcctInstallationAddr.findAll", query="SELECT t FROM TSohAcctInstallationAddr t")
public class TSohAcctInstallationAddr implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_SOH_ACCT_INSTALLATION_ADDR_ACCOUNTADDRESSID_GENERATOR", sequenceName="SQ_SOH_ACCT_INST_ADDR")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_SOH_ACCT_INSTALLATION_ADDR_ACCOUNTADDRESSID_GENERATOR")
	@Column(name="ACCOUNT_ADDRESS_ID")
	private long accountAddressId;

	private String accommodationshared;

	private String accommodationtype;

	@Column(name="ADDRESS_LINE_1")
	private String addressLine1;

	@Column(name="ADDRESS_LINE_2")
	private String addressLine2;

	private String addressdesc;

	private String building;

	@Column(name="BUILDING_ID")
	private BigDecimal buildingId;

	@Column(name="BUILDING_NAME")
	private String buildingName;

	@Column(name="BUILDING_NUMBER")
	private String buildingNumber;

	@Column(name="CITY_TOWN_ID")
	private BigDecimal cityTownId;

	@Column(name="COMMUNITY_ID")
	private BigDecimal communityId;

	@Column(name="COUNTRY_CODE")
	private String countryCode;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="DWELLING_UNIT_ID")
	private BigDecimal dwellingUnitId;

	@Column(name="EMIRTAE_ID")
	private BigDecimal emirtaeId;

	@Column(name="FAMOUS_NAME")
	private String famousName;

	@Column(name="FLAT_HOUSE_NO")
	private String flatHouseNo;

	@Column(name="FLAT_NUMBER")
	private BigDecimal flatNumber;

	@Column(name="\"FLOOR\"")
	private String floor;

	@Column(name="\"MAP\"")
	private String map;

	@Column(name="MAP_NUMBER")
	private String mapNumber;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="PB_NO")
	private String pbNo;

	@Column(name="PLOT_NUMBER")
	private String plotNumber;

	private String sector;

	private String street;

	@Column(name="STREET_ID")
	private BigDecimal streetId;

	@Column(name="TOWN_CODE")
	private String townCode;

	private String villacompound;

	@Column(name="ZONE_CODE")
	private String zoneCode;

	@Column(name="ZONE_ID")
	private BigDecimal zoneId;

	//bi-directional many-to-one association to TSohAcctLinkedInstAddr
	@OneToMany(mappedBy="TSohAcctInstallationAddr")
	private List<TSohAcctLinkedInstAddr> TSohAcctLinkedInstAddrs;

	public TSohAcctInstallationAddr() {
	}

	public long getAccountAddressId() {
		return this.accountAddressId;
	}

	public void setAccountAddressId(long accountAddressId) {
		this.accountAddressId = accountAddressId;
	}

	public String getAccommodationshared() {
		return this.accommodationshared;
	}

	public void setAccommodationshared(String accommodationshared) {
		this.accommodationshared = accommodationshared;
	}

	public String getAccommodationtype() {
		return this.accommodationtype;
	}

	public void setAccommodationtype(String accommodationtype) {
		this.accommodationtype = accommodationtype;
	}

	public String getAddressLine1() {
		return this.addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return this.addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getAddressdesc() {
		return this.addressdesc;
	}

	public void setAddressdesc(String addressdesc) {
		this.addressdesc = addressdesc;
	}

	public String getBuilding() {
		return this.building;
	}

	public void setBuilding(String building) {
		this.building = building;
	}

	public BigDecimal getBuildingId() {
		return this.buildingId;
	}

	public void setBuildingId(BigDecimal buildingId) {
		this.buildingId = buildingId;
	}

	public String getBuildingName() {
		return this.buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getBuildingNumber() {
		return this.buildingNumber;
	}

	public void setBuildingNumber(String buildingNumber) {
		this.buildingNumber = buildingNumber;
	}

	public BigDecimal getCityTownId() {
		return this.cityTownId;
	}

	public void setCityTownId(BigDecimal cityTownId) {
		this.cityTownId = cityTownId;
	}

	public BigDecimal getCommunityId() {
		return this.communityId;
	}

	public void setCommunityId(BigDecimal communityId) {
		this.communityId = communityId;
	}

	public String getCountryCode() {
		return this.countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public BigDecimal getDwellingUnitId() {
		return this.dwellingUnitId;
	}

	public void setDwellingUnitId(BigDecimal dwellingUnitId) {
		this.dwellingUnitId = dwellingUnitId;
	}

	public BigDecimal getEmirtaeId() {
		return this.emirtaeId;
	}

	public void setEmirtaeId(BigDecimal emirtaeId) {
		this.emirtaeId = emirtaeId;
	}

	public String getFamousName() {
		return this.famousName;
	}

	public void setFamousName(String famousName) {
		this.famousName = famousName;
	}

	public String getFlatHouseNo() {
		return this.flatHouseNo;
	}

	public void setFlatHouseNo(String flatHouseNo) {
		this.flatHouseNo = flatHouseNo;
	}

	public BigDecimal getFlatNumber() {
		return this.flatNumber;
	}

	public void setFlatNumber(BigDecimal flatNumber) {
		this.flatNumber = flatNumber;
	}

	public String getFloor() {
		return this.floor;
	}

	public void setFloor(String floor) {
		this.floor = floor;
	}

	public String getMap() {
		return this.map;
	}

	public void setMap(String map) {
		this.map = map;
	}

	public String getMapNumber() {
		return this.mapNumber;
	}

	public void setMapNumber(String mapNumber) {
		this.mapNumber = mapNumber;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getPbNo() {
		return this.pbNo;
	}

	public void setPbNo(String pbNo) {
		this.pbNo = pbNo;
	}

	public String getPlotNumber() {
		return this.plotNumber;
	}

	public void setPlotNumber(String plotNumber) {
		this.plotNumber = plotNumber;
	}

	public String getSector() {
		return this.sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}

	public String getStreet() {
		return this.street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public BigDecimal getStreetId() {
		return this.streetId;
	}

	public void setStreetId(BigDecimal streetId) {
		this.streetId = streetId;
	}

	public String getTownCode() {
		return this.townCode;
	}

	public void setTownCode(String townCode) {
		this.townCode = townCode;
	}

	public String getVillacompound() {
		return this.villacompound;
	}

	public void setVillacompound(String villacompound) {
		this.villacompound = villacompound;
	}

	public String getZoneCode() {
		return this.zoneCode;
	}

	public void setZoneCode(String zoneCode) {
		this.zoneCode = zoneCode;
	}

	public BigDecimal getZoneId() {
		return this.zoneId;
	}

	public void setZoneId(BigDecimal zoneId) {
		this.zoneId = zoneId;
	}

	public List<TSohAcctLinkedInstAddr> getTSohAcctLinkedInstAddrs() {
		return this.TSohAcctLinkedInstAddrs;
	}

	public void setTSohAcctLinkedInstAddrs(List<TSohAcctLinkedInstAddr> TSohAcctLinkedInstAddrs) {
		this.TSohAcctLinkedInstAddrs = TSohAcctLinkedInstAddrs;
	}

	public TSohAcctLinkedInstAddr addTSohAcctLinkedInstAddr(TSohAcctLinkedInstAddr TSohAcctLinkedInstAddr) {
		getTSohAcctLinkedInstAddrs().add(TSohAcctLinkedInstAddr);
		TSohAcctLinkedInstAddr.setTSohAcctInstallationAddr(this);

		return TSohAcctLinkedInstAddr;
	}

	public TSohAcctLinkedInstAddr removeTSohAcctLinkedInstAddr(TSohAcctLinkedInstAddr TSohAcctLinkedInstAddr) {
		getTSohAcctLinkedInstAddrs().remove(TSohAcctLinkedInstAddr);
		TSohAcctLinkedInstAddr.setTSohAcctInstallationAddr(null);

		return TSohAcctLinkedInstAddr;
	}

}