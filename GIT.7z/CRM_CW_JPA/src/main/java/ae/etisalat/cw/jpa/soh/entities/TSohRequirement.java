package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the T_SOH_REQUIREMENTS database table.
 * 
 */
@Entity
@Table(name="T_SOH_REQUIREMENTS")
@NamedQuery(name="TSohRequirement.findAll", query="SELECT t FROM TSohRequirement t")
public class TSohRequirement implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="SQ_SOH_REQUIREMENTS", sequenceName="SQ_SOH_REQUIREMENTS", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SQ_SOH_REQUIREMENTS")
	@Column(name="REQUIREMENT_ID")
	private long requirementId;

	@Temporal(TemporalType.DATE)
	@Column(name="CESSATION_REQUIRED_DATE")
	private Date cessationRequiredDate;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MISC_CHARGE_TYPE")
	private BigDecimal miscChargeType;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="MSO_FLAG")
	private String msoFlag;

	@Column(name="PRIORITY_CODE")
	private String priorityCode;

	@Column(name="PRIORITY_ID")
	private BigDecimal priorityId;

	@Temporal(TemporalType.DATE)
	@Column(name="SERVICE_REQUIRED_DATE")
	private Date serviceRequiredDate;

	@Column(name="SRT_MISC_CHARGE_ID")
	private BigDecimal srtMiscChargeId;

	@Column(name="TRB_FLAG")
	private String trbFlag;

	@Column(name="WEB_REQUIREMENT_ID")
	private BigDecimal webRequirementId;

	//bi-directional one-to-one association to TSohCustRequirement
	@OneToOne(mappedBy="TSohRequirement")
	private TSohCustRequirement TSohCustRequirement;

	//bi-directional many-to-one association to TSohDtlSystemCodeValue
	@ManyToOne
	@JoinColumn(name="REQUIREMENT_REASON")
	private TSohDtlSystemCodeValue TSohDtlSystemCodeValue1;

	//bi-directional many-to-one association to TSohDtlSystemCodeValue
	@ManyToOne
	@JoinColumn(name="STATUS")
	private TSohDtlSystemCodeValue TSohDtlSystemCodeValue2;

	//bi-directional many-to-one association to TSohMstSubRequestType
	@ManyToOne
	@JoinColumn(name="SUB_REQUEST_TYPE_ID")
	private TSohMstSubRequestType TSohMstSubRequestType;

	//bi-directional many-to-one association to TSohRequest
	@ManyToOne
	@JoinColumn(name="REQUEST_ID")
	private TSohRequest TSohRequest;

	//bi-directional many-to-one association to TSohSubrequest
	@OneToMany(mappedBy="TSohRequirement")
	private List<TSohSubrequest> TSohSubrequests;

	//bi-directional many-to-one association to TSohSubreqServiceDetail
	@OneToMany(mappedBy="TSohRequirement")
	private List<TSohSubreqServiceDetail> TSohSubreqServiceDetails;
	
	@Column(name="PORTAL_REFERENCE_NUMBER")
	private String portalReferenceNumber;

	public TSohRequirement() {
	}

	public long getRequirementId() {
		return this.requirementId;
	}

	public void setRequirementId(long requirementId) {
		this.requirementId = requirementId;
	}

	public Date getCessationRequiredDate() {
		return this.cessationRequiredDate;
	}

	public void setCessationRequiredDate(Date cessationRequiredDate) {
		this.cessationRequiredDate = cessationRequiredDate;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public BigDecimal getMiscChargeType() {
		return this.miscChargeType;
	}

	public void setMiscChargeType(BigDecimal miscChargeType) {
		this.miscChargeType = miscChargeType;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getMsoFlag() {
		return this.msoFlag;
	}

	public void setMsoFlag(String msoFlag) {
		this.msoFlag = msoFlag;
	}

	public String getPriorityCode() {
		return this.priorityCode;
	}

	public void setPriorityCode(String priorityCode) {
		this.priorityCode = priorityCode;
	}

	public BigDecimal getPriorityId() {
		return this.priorityId;
	}

	public void setPriorityId(BigDecimal priorityId) {
		this.priorityId = priorityId;
	}

	public Date getServiceRequiredDate() {
		return this.serviceRequiredDate;
	}

	public void setServiceRequiredDate(Date serviceRequiredDate) {
		this.serviceRequiredDate = serviceRequiredDate;
	}

	public BigDecimal getSrtMiscChargeId() {
		return this.srtMiscChargeId;
	}

	public void setSrtMiscChargeId(BigDecimal srtMiscChargeId) {
		this.srtMiscChargeId = srtMiscChargeId;
	}

	public String getTrbFlag() {
		return this.trbFlag;
	}

	public void setTrbFlag(String trbFlag) {
		this.trbFlag = trbFlag;
	}

	public BigDecimal getWebRequirementId() {
		return this.webRequirementId;
	}

	public void setWebRequirementId(BigDecimal webRequirementId) {
		this.webRequirementId = webRequirementId;
	}

	public TSohCustRequirement getTSohCustRequirement() {
		return this.TSohCustRequirement;
	}

	public void setTSohCustRequirement(TSohCustRequirement TSohCustRequirement) {
		this.TSohCustRequirement = TSohCustRequirement;
	}

	public TSohDtlSystemCodeValue getTSohDtlSystemCodeValue1() {
		return this.TSohDtlSystemCodeValue1;
	}

	public void setTSohDtlSystemCodeValue1(TSohDtlSystemCodeValue TSohDtlSystemCodeValue1) {
		this.TSohDtlSystemCodeValue1 = TSohDtlSystemCodeValue1;
	}

	public TSohDtlSystemCodeValue getTSohDtlSystemCodeValue2() {
		return this.TSohDtlSystemCodeValue2;
	}

	public void setTSohDtlSystemCodeValue2(TSohDtlSystemCodeValue TSohDtlSystemCodeValue2) {
		this.TSohDtlSystemCodeValue2 = TSohDtlSystemCodeValue2;
	}

	public TSohMstSubRequestType getTSohMstSubRequestType() {
		return this.TSohMstSubRequestType;
	}

	public void setTSohMstSubRequestType(TSohMstSubRequestType TSohMstSubRequestType) {
		this.TSohMstSubRequestType = TSohMstSubRequestType;
	}

	public TSohRequest getTSohRequest() {
		return this.TSohRequest;
	}

	public void setTSohRequest(TSohRequest TSohRequest) {
		this.TSohRequest = TSohRequest;
	}

	public List<TSohSubrequest> getTSohSubrequests() {
		return this.TSohSubrequests;
	}

	public void setTSohSubrequests(List<TSohSubrequest> TSohSubrequests) {
		this.TSohSubrequests = TSohSubrequests;
	}

	public TSohSubrequest addTSohSubrequest(TSohSubrequest TSohSubrequest) {
		getTSohSubrequests().add(TSohSubrequest);
		TSohSubrequest.setTSohRequirement(this);

		return TSohSubrequest;
	}

	public TSohSubrequest removeTSohSubrequest(TSohSubrequest TSohSubrequest) {
		getTSohSubrequests().remove(TSohSubrequest);
		TSohSubrequest.setTSohRequirement(null);

		return TSohSubrequest;
	}

	public List<TSohSubreqServiceDetail> getTSohSubreqServiceDetails() {
		return this.TSohSubreqServiceDetails;
	}

	public void setTSohSubreqServiceDetails(List<TSohSubreqServiceDetail> TSohSubreqServiceDetails) {
		this.TSohSubreqServiceDetails = TSohSubreqServiceDetails;
	}

	public TSohSubreqServiceDetail addTSohSubreqServiceDetail(TSohSubreqServiceDetail TSohSubreqServiceDetail) {
		getTSohSubreqServiceDetails().add(TSohSubreqServiceDetail);
		TSohSubreqServiceDetail.setTSohRequirement(this);

		return TSohSubreqServiceDetail;
	}

	public TSohSubreqServiceDetail removeTSohSubreqServiceDetail(TSohSubreqServiceDetail TSohSubreqServiceDetail) {
		getTSohSubreqServiceDetails().remove(TSohSubreqServiceDetail);
		TSohSubreqServiceDetail.setTSohRequirement(null);

		return TSohSubreqServiceDetail;
	}
	
	public String getPortalReferenceNumber() {
		return portalReferenceNumber;
	}

	public void setPortalReferenceNumber(String portalReferenceNumber) {
		this.portalReferenceNumber = portalReferenceNumber;
	}

}