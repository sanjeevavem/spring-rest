package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the T_SOH_ACCOUNT_PAYMENTINFO database table.
 * 
 */
@Entity
@Table(name="T_SOH_ACCOUNT_PAYMENTINFO")
@NamedQuery(name="TSohAccountPaymentinfo.findAll", query="SELECT t FROM TSohAccountPaymentinfo t")
public class TSohAccountPaymentinfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_SOH_ACCOUNT_PAYMENTINFO_ACCPAYTYPEID_GENERATOR", sequenceName="SQ_SOH_ACCOUNT_PAYMENTINFO",allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_SOH_ACCOUNT_PAYMENTINFO_ACCPAYTYPEID_GENERATOR")
	@Column(name="ACC_PAY_TYPE_ID")
	private long accPayTypeId;

	@Column(name="ACCOUNT_ID")
	private BigDecimal accountId;

	@Column(name="ACCOUNT_NUMBER")
	private String accountNumber;

	@Column(name="AMOUNT_TO_RECHARGE")
	private BigDecimal amountToRecharge;

	@Column(name="AUTHROIZATION_CODE")
	private String authroizationCode;

	@Column(name="BANK_ACC_NUMBER")
	private String bankAccNumber;

	@Column(name="BANK_BRANCH_ID")
	private BigDecimal bankBranchId;

	@Column(name="BANK_ID")
	private BigDecimal bankId;

	@Temporal(TemporalType.DATE)
	@Column(name="CARD_EXPIRY_DATE")
	private Date cardExpiryDate;

	@Column(name="CARD_NUMBER")
	private String cardNumber;

	@Column(name="CARD_TYPE_ID")
	private BigDecimal cardTypeId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="CREDITCARD_COMPANY_ID")
	private BigDecimal creditcardCompanyId;

	@Column(name="CVV_NUMBER")
	private String cvvNumber;

	@Column(name="DD_BANK_REF_NO")
	private String ddBankRefNo;

	@Temporal(TemporalType.DATE)
	@Column(name="DD_EXPIRY_DATE")
	private Date ddExpiryDate;

	@Column(name="DD_REGISTRATION_STATUS")
	private String ddRegistrationStatus;

	@Temporal(TemporalType.DATE)
	@Column(name="DD_START_DATE")
	private Date ddStartDate;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_FROM_DATE")
	private Date effectiveFromDate;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_TILL_DATE")
	private Date effectiveTillDate;

	@Column(name="EMIRATESID_NO")
	private String emiratesidNo;

	@Column(name="EPG_STATUS")
	private String epgStatus;

	@Column(name="EPG_TRANS_ID")
	private String epgTransId;

	@Column(name="IF_BALANCE_IS")
	private BigDecimal ifBalanceIs;

	@Column(name="INSTALLAMENT_FLAG")
	private String installamentFlag;

	@Column(name="MOBILE_CONTACT")
	private String mobileContact;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="NAME_ON_CARD")
	private String nameOnCard;

	@Column(name="PAY_TYPE_ID")
	private BigDecimal payTypeId;

	@Column(name="PAYMENT_AMOUNT")
	private BigDecimal paymentAmount;

	@Column(name="PAYMENT_DAY")
	private BigDecimal paymentDay;

	@Column(name="PAYMENT_FREQUENCY")
	private String paymentFrequency;

	@Column(name="PAYMENT_OPTION")
	private String paymentOption;

	@Column(name="PAYMENT_REF_NUMBER")
	private String paymentRefNumber;

	private String remarks;

	@Column(name="SOURCE_CHANNEL")
	private String sourceChannel;

	@Column(name="SUBREQUEST_ID")
	private String subrequestId;

	public TSohAccountPaymentinfo() {
	}

	public long getAccPayTypeId() {
		return this.accPayTypeId;
	}

	public void setAccPayTypeId(long accPayTypeId) {
		this.accPayTypeId = accPayTypeId;
	}

	public BigDecimal getAccountId() {
		return this.accountId;
	}

	public void setAccountId(BigDecimal accountId) {
		this.accountId = accountId;
	}

	public String getAccountNumber() {
		return this.accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public BigDecimal getAmountToRecharge() {
		return this.amountToRecharge;
	}

	public void setAmountToRecharge(BigDecimal amountToRecharge) {
		this.amountToRecharge = amountToRecharge;
	}

	public String getAuthroizationCode() {
		return this.authroizationCode;
	}

	public void setAuthroizationCode(String authroizationCode) {
		this.authroizationCode = authroizationCode;
	}

	public String getBankAccNumber() {
		return this.bankAccNumber;
	}

	public void setBankAccNumber(String bankAccNumber) {
		this.bankAccNumber = bankAccNumber;
	}

	public BigDecimal getBankBranchId() {
		return this.bankBranchId;
	}

	public void setBankBranchId(BigDecimal bankBranchId) {
		this.bankBranchId = bankBranchId;
	}

	public BigDecimal getBankId() {
		return this.bankId;
	}

	public void setBankId(BigDecimal bankId) {
		this.bankId = bankId;
	}

	public Date getCardExpiryDate() {
		return this.cardExpiryDate;
	}

	public void setCardExpiryDate(Date cardExpiryDate) {
		this.cardExpiryDate = cardExpiryDate;
	}

	public String getCardNumber() {
		return this.cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public BigDecimal getCardTypeId() {
		return this.cardTypeId;
	}

	public void setCardTypeId(BigDecimal cardTypeId) {
		this.cardTypeId = cardTypeId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public BigDecimal getCreditcardCompanyId() {
		return this.creditcardCompanyId;
	}

	public void setCreditcardCompanyId(BigDecimal creditcardCompanyId) {
		this.creditcardCompanyId = creditcardCompanyId;
	}

	public String getCvvNumber() {
		return this.cvvNumber;
	}

	public void setCvvNumber(String cvvNumber) {
		this.cvvNumber = cvvNumber;
	}

	public String getDdBankRefNo() {
		return this.ddBankRefNo;
	}

	public void setDdBankRefNo(String ddBankRefNo) {
		this.ddBankRefNo = ddBankRefNo;
	}

	public Date getDdExpiryDate() {
		return this.ddExpiryDate;
	}

	public void setDdExpiryDate(Date ddExpiryDate) {
		this.ddExpiryDate = ddExpiryDate;
	}

	public String getDdRegistrationStatus() {
		return this.ddRegistrationStatus;
	}

	public void setDdRegistrationStatus(String ddRegistrationStatus) {
		this.ddRegistrationStatus = ddRegistrationStatus;
	}

	public Date getDdStartDate() {
		return this.ddStartDate;
	}

	public void setDdStartDate(Date ddStartDate) {
		this.ddStartDate = ddStartDate;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Date getEffectiveFromDate() {
		return this.effectiveFromDate;
	}

	public void setEffectiveFromDate(Date effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}

	public Date getEffectiveTillDate() {
		return this.effectiveTillDate;
	}

	public void setEffectiveTillDate(Date effectiveTillDate) {
		this.effectiveTillDate = effectiveTillDate;
	}

	public String getEmiratesidNo() {
		return this.emiratesidNo;
	}

	public void setEmiratesidNo(String emiratesidNo) {
		this.emiratesidNo = emiratesidNo;
	}

	public String getEpgStatus() {
		return this.epgStatus;
	}

	public void setEpgStatus(String epgStatus) {
		this.epgStatus = epgStatus;
	}

	public String getEpgTransId() {
		return this.epgTransId;
	}

	public void setEpgTransId(String epgTransId) {
		this.epgTransId = epgTransId;
	}

	public BigDecimal getIfBalanceIs() {
		return this.ifBalanceIs;
	}

	public void setIfBalanceIs(BigDecimal ifBalanceIs) {
		this.ifBalanceIs = ifBalanceIs;
	}

	public String getInstallamentFlag() {
		return this.installamentFlag;
	}

	public void setInstallamentFlag(String installamentFlag) {
		this.installamentFlag = installamentFlag;
	}

	public String getMobileContact() {
		return this.mobileContact;
	}

	public void setMobileContact(String mobileContact) {
		this.mobileContact = mobileContact;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getNameOnCard() {
		return this.nameOnCard;
	}

	public void setNameOnCard(String nameOnCard) {
		this.nameOnCard = nameOnCard;
	}

	public BigDecimal getPayTypeId() {
		return this.payTypeId;
	}

	public void setPayTypeId(BigDecimal payTypeId) {
		this.payTypeId = payTypeId;
	}

	public BigDecimal getPaymentAmount() {
		return this.paymentAmount;
	}

	public void setPaymentAmount(BigDecimal paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public BigDecimal getPaymentDay() {
		return this.paymentDay;
	}

	public void setPaymentDay(BigDecimal paymentDay) {
		this.paymentDay = paymentDay;
	}

	public String getPaymentFrequency() {
		return this.paymentFrequency;
	}

	public void setPaymentFrequency(String paymentFrequency) {
		this.paymentFrequency = paymentFrequency;
	}

	public String getPaymentOption() {
		return this.paymentOption;
	}

	public void setPaymentOption(String paymentOption) {
		this.paymentOption = paymentOption;
	}

	public String getPaymentRefNumber() {
		return this.paymentRefNumber;
	}

	public void setPaymentRefNumber(String paymentRefNumber) {
		this.paymentRefNumber = paymentRefNumber;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getSourceChannel() {
		return this.sourceChannel;
	}

	public void setSourceChannel(String sourceChannel) {
		this.sourceChannel = sourceChannel;
	}

	public String getSubrequestId() {
		return this.subrequestId;
	}

	public void setSubrequestId(String subrequestId) {
		this.subrequestId = subrequestId;
	}

}