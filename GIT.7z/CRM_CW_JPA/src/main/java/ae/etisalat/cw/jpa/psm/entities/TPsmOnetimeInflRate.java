package ae.etisalat.cw.jpa.psm.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the T_PSM_ONETIME_INFL_RATE database table.
 * 
 */
@Entity
@Table(name="T_PSM_ONETIME_INFL_RATE")
@NamedQuery(name="TPsmOnetimeInflRate.findAll", query="SELECT t FROM TPsmOnetimeInflRate t")
public class TPsmOnetimeInflRate implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ONETIME_INFL_RATE_ID")
	private long onetimeInflRateId;

	@Column(name="ACCOUNT_CATEGORY_ID")
	private BigDecimal accountCategoryId;

	@Column(name="ACCOUNT_REGION_ID")
	private BigDecimal accountRegionId;

	@Column(name="COMPANY_TYPE_ID")
	private BigDecimal companyTypeId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DOWN_PAYMENT_AMT")
	private BigDecimal downPaymentAmt;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_FROM_DATE")
	private Date effectiveFromDate;

	@Column(name="EMIRATE_ID")
	private BigDecimal emirateId;

	@Column(name="INDUSTRY_TYPE_ID")
	private BigDecimal industryTypeId;

	@Column(name="INSTALLMENT_INDICATOR_FLAG")
	private BigDecimal installmentIndicatorFlag;

	@Column(name="INSTALLMENT_TYPE_FLAG")
	private BigDecimal installmentTypeFlag;

	@Column(name="MARKET_SEGMENT_ID")
	private BigDecimal marketSegmentId;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="ONETIME_CHARGE_TYPE_ID")
	private BigDecimal onetimeChargeTypeId;

	@Column(name="ONETIME_RATE_MTRX_ID")
	private BigDecimal onetimeRateMtrxId;

	@Column(name="OTRTMTRX_EFFECTIVE_FROM_DATE")
	private Timestamp otrtmtrxEffectiveFromDate;

	@Column(name="PARTY_AGE_FROM")
	private BigDecimal partyAgeFrom;

	@Column(name="PARTY_AGE_TO")
	private BigDecimal partyAgeTo;

	@Column(name="PARTY_NAME")
	private String partyName;

	@Column(name="PARTY_TYPE_ID")
	private BigDecimal partyTypeId;

	@Column(name="PROFESSION_ID")
	private BigDecimal professionId;

	private BigDecimal rate;

	@Column(name="RATE_INDICATOR_FLAG")
	private BigDecimal rateIndicatorFlag;

	@Column(name="REDUCTION_INDICATOR_FLAG")
	private BigDecimal reductionIndicatorFlag;

	@Column(name="REDUCTION_MAX_LIMIT")
	private BigDecimal reductionMaxLimit;

	@Column(name="REDUCTION_PERCENTAGE")
	private BigDecimal reductionPercentage;

	@Column(name="REDUCTION_RATE")
	private BigDecimal reductionRate;

	@Column(name="SEGMENT_VALUE_ID")
	private BigDecimal segmentValueId;

	@Column(name="SERVICE_QUANTITY_FROM")
	private BigDecimal serviceQuantityFrom;

	@Column(name="SERVICE_QUANTITY_TO")
	private BigDecimal serviceQuantityTo;

	@Column(name="SUB_TYPE_ID")
	private BigDecimal subTypeId;

	@Column(name="SUBSCRIPTION_PERIOD_FROM")
	private BigDecimal subscriptionPeriodFrom;

	@Column(name="SUBSCRIPTION_PERIOD_TO")
	private BigDecimal subscriptionPeriodTo;

	@Column(name="TOTAL_AMOUNT")
	private BigDecimal totalAmount;

	public TPsmOnetimeInflRate() {
	}

	public long getOnetimeInflRateId() {
		return this.onetimeInflRateId;
	}

	public void setOnetimeInflRateId(long onetimeInflRateId) {
		this.onetimeInflRateId = onetimeInflRateId;
	}

	public BigDecimal getAccountCategoryId() {
		return this.accountCategoryId;
	}

	public void setAccountCategoryId(BigDecimal accountCategoryId) {
		this.accountCategoryId = accountCategoryId;
	}

	public BigDecimal getAccountRegionId() {
		return this.accountRegionId;
	}

	public void setAccountRegionId(BigDecimal accountRegionId) {
		this.accountRegionId = accountRegionId;
	}

	public BigDecimal getCompanyTypeId() {
		return this.companyTypeId;
	}

	public void setCompanyTypeId(BigDecimal companyTypeId) {
		this.companyTypeId = companyTypeId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public BigDecimal getDownPaymentAmt() {
		return this.downPaymentAmt;
	}

	public void setDownPaymentAmt(BigDecimal downPaymentAmt) {
		this.downPaymentAmt = downPaymentAmt;
	}

	public Date getEffectiveFromDate() {
		return this.effectiveFromDate;
	}

	public void setEffectiveFromDate(Date effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}

	public BigDecimal getEmirateId() {
		return this.emirateId;
	}

	public void setEmirateId(BigDecimal emirateId) {
		this.emirateId = emirateId;
	}

	public BigDecimal getIndustryTypeId() {
		return this.industryTypeId;
	}

	public void setIndustryTypeId(BigDecimal industryTypeId) {
		this.industryTypeId = industryTypeId;
	}

	public BigDecimal getInstallmentIndicatorFlag() {
		return this.installmentIndicatorFlag;
	}

	public void setInstallmentIndicatorFlag(BigDecimal installmentIndicatorFlag) {
		this.installmentIndicatorFlag = installmentIndicatorFlag;
	}

	public BigDecimal getInstallmentTypeFlag() {
		return this.installmentTypeFlag;
	}

	public void setInstallmentTypeFlag(BigDecimal installmentTypeFlag) {
		this.installmentTypeFlag = installmentTypeFlag;
	}

	public BigDecimal getMarketSegmentId() {
		return this.marketSegmentId;
	}

	public void setMarketSegmentId(BigDecimal marketSegmentId) {
		this.marketSegmentId = marketSegmentId;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getOnetimeChargeTypeId() {
		return this.onetimeChargeTypeId;
	}

	public void setOnetimeChargeTypeId(BigDecimal onetimeChargeTypeId) {
		this.onetimeChargeTypeId = onetimeChargeTypeId;
	}

	public BigDecimal getOnetimeRateMtrxId() {
		return this.onetimeRateMtrxId;
	}

	public void setOnetimeRateMtrxId(BigDecimal onetimeRateMtrxId) {
		this.onetimeRateMtrxId = onetimeRateMtrxId;
	}

	public Timestamp getOtrtmtrxEffectiveFromDate() {
		return this.otrtmtrxEffectiveFromDate;
	}

	public void setOtrtmtrxEffectiveFromDate(Timestamp otrtmtrxEffectiveFromDate) {
		this.otrtmtrxEffectiveFromDate = otrtmtrxEffectiveFromDate;
	}

	public BigDecimal getPartyAgeFrom() {
		return this.partyAgeFrom;
	}

	public void setPartyAgeFrom(BigDecimal partyAgeFrom) {
		this.partyAgeFrom = partyAgeFrom;
	}

	public BigDecimal getPartyAgeTo() {
		return this.partyAgeTo;
	}

	public void setPartyAgeTo(BigDecimal partyAgeTo) {
		this.partyAgeTo = partyAgeTo;
	}

	public String getPartyName() {
		return this.partyName;
	}

	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}

	public BigDecimal getPartyTypeId() {
		return this.partyTypeId;
	}

	public void setPartyTypeId(BigDecimal partyTypeId) {
		this.partyTypeId = partyTypeId;
	}

	public BigDecimal getProfessionId() {
		return this.professionId;
	}

	public void setProfessionId(BigDecimal professionId) {
		this.professionId = professionId;
	}

	public BigDecimal getRate() {
		return this.rate;
	}

	public void setRate(BigDecimal rate) {
		this.rate = rate;
	}

	public BigDecimal getRateIndicatorFlag() {
		return this.rateIndicatorFlag;
	}

	public void setRateIndicatorFlag(BigDecimal rateIndicatorFlag) {
		this.rateIndicatorFlag = rateIndicatorFlag;
	}

	public BigDecimal getReductionIndicatorFlag() {
		return this.reductionIndicatorFlag;
	}

	public void setReductionIndicatorFlag(BigDecimal reductionIndicatorFlag) {
		this.reductionIndicatorFlag = reductionIndicatorFlag;
	}

	public BigDecimal getReductionMaxLimit() {
		return this.reductionMaxLimit;
	}

	public void setReductionMaxLimit(BigDecimal reductionMaxLimit) {
		this.reductionMaxLimit = reductionMaxLimit;
	}

	public BigDecimal getReductionPercentage() {
		return this.reductionPercentage;
	}

	public void setReductionPercentage(BigDecimal reductionPercentage) {
		this.reductionPercentage = reductionPercentage;
	}

	public BigDecimal getReductionRate() {
		return this.reductionRate;
	}

	public void setReductionRate(BigDecimal reductionRate) {
		this.reductionRate = reductionRate;
	}

	public BigDecimal getSegmentValueId() {
		return this.segmentValueId;
	}

	public void setSegmentValueId(BigDecimal segmentValueId) {
		this.segmentValueId = segmentValueId;
	}

	public BigDecimal getServiceQuantityFrom() {
		return this.serviceQuantityFrom;
	}

	public void setServiceQuantityFrom(BigDecimal serviceQuantityFrom) {
		this.serviceQuantityFrom = serviceQuantityFrom;
	}

	public BigDecimal getServiceQuantityTo() {
		return this.serviceQuantityTo;
	}

	public void setServiceQuantityTo(BigDecimal serviceQuantityTo) {
		this.serviceQuantityTo = serviceQuantityTo;
	}

	public BigDecimal getSubTypeId() {
		return this.subTypeId;
	}

	public void setSubTypeId(BigDecimal subTypeId) {
		this.subTypeId = subTypeId;
	}

	public BigDecimal getSubscriptionPeriodFrom() {
		return this.subscriptionPeriodFrom;
	}

	public void setSubscriptionPeriodFrom(BigDecimal subscriptionPeriodFrom) {
		this.subscriptionPeriodFrom = subscriptionPeriodFrom;
	}

	public BigDecimal getSubscriptionPeriodTo() {
		return this.subscriptionPeriodTo;
	}

	public void setSubscriptionPeriodTo(BigDecimal subscriptionPeriodTo) {
		this.subscriptionPeriodTo = subscriptionPeriodTo;
	}

	public BigDecimal getTotalAmount() {
		return this.totalAmount;
	}

	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}

}