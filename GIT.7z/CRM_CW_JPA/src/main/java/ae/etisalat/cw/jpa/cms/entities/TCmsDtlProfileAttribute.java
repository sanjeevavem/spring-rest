package ae.etisalat.cw.jpa.cms.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the T_CMS_DTL_PROFILE_ATTRIBUTE database table.
 * 
 */
@Entity
@Table(name="T_CMS_DTL_PROFILE_ATTRIBUTE")
@NamedQuery(name="TCmsDtlProfileAttribute.findAll", query="SELECT t FROM TCmsDtlProfileAttribute t")
public class TCmsDtlProfileAttribute implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TCmsDtlProfileAttributePK id;

	@Column(name="ATTRIBUTE_VALUE")
	private String attributeValue;

	@Temporal(TemporalType.DATE)
	@Column(name="CREATED_DATE")
	private Date createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_FROM")
	private Date effectiveFrom;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_TILL")
	private Date effectiveTill;

	@Temporal(TemporalType.DATE)
	@Column(name="MODIFIED_DATE")
	private Date modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	public TCmsDtlProfileAttribute() {
	}

	public TCmsDtlProfileAttributePK getId() {
		return this.id;
	}

	public void setId(TCmsDtlProfileAttributePK id) {
		this.id = id;
	}

	public String getAttributeValue() {
		return this.attributeValue;
	}

	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public Date getEffectiveFrom() {
		return this.effectiveFrom;
	}

	public void setEffectiveFrom(Date effectiveFrom) {
		this.effectiveFrom = effectiveFrom;
	}

	public Date getEffectiveTill() {
		return this.effectiveTill;
	}

	public void setEffectiveTill(Date effectiveTill) {
		this.effectiveTill = effectiveTill;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

}