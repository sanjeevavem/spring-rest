package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the T_SOH_ELIFE_OCV_OFFER_MAP database table.
 * 
 */
@Entity
@Table(name="T_SOH_ELIFE_OCV_OFFER_MAP")
@NamedQuery(name="TSohElifeOcvOfferMap.findAll", query="SELECT t FROM TSohElifeOcvOfferMap t")
public class TSohElifeOcvOfferMap implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="CBCM_BUNDLE_CODE")
	private String cbcmBundleCode;  

	@Column(name="CBCM_PACKAGE_CODE")
	private String cbcmPackageCode;

	@Column(name="CBCM_RATE_PLAN_CODE")
	private String cbcmRatePlanCode;

	@Column(name="CREATED_BY")
	private String createdBy;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private BigDecimal id;

	@Column(name="MODIFIED_BY")
	private String modifiedBy;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="OCV_CPOP_CODE")
	private String ocvCpopCode;

	@Column(name="OCV_OFFERCODE")
	private String ocvOffercode;

	public TSohElifeOcvOfferMap() {
	}

	public String getCbcmBundleCode() {
		return cbcmBundleCode;
	}

	public void setCbcmBundleCode(String cbcmBundleCode) {
		this.cbcmBundleCode = cbcmBundleCode;
	}

	public String getCbcmPackageCode() {
		return cbcmPackageCode;
	}

	public void setCbcmPackageCode(String cbcmPackageCode) {
		this.cbcmPackageCode = cbcmPackageCode;
	}

	public String getCbcmRatePlanCode() {
		return cbcmRatePlanCode;
	}

	public void setCbcmRatePlanCode(String cbcmRatePlanCode) {
		this.cbcmRatePlanCode = cbcmRatePlanCode;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDeletionStatus() {
		return deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public BigDecimal getId() {
		return id;
	}

	public void setId(BigDecimal id) {
		this.id = id;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getOcvCpopCode() {
		return ocvCpopCode;
	}

	public void setOcvCpopCode(String ocvCpopCode) {
		this.ocvCpopCode = ocvCpopCode;
	}

	public String getOcvOffercode() {
		return ocvOffercode;
	}

	public void setOcvOffercode(String ocvOffercode) {
		this.ocvOffercode = ocvOffercode;
	}

}