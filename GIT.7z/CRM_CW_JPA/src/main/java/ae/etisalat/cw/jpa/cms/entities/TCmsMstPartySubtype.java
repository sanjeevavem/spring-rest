package ae.etisalat.cw.jpa.cms.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import ae.etisalat.cw.jpa.soh.entities.TSohCustRequirement;
import ae.etisalat.cw.jpa.soh.entities.TSohMstSubreqAccinfo;
import ae.etisalat.cw.jpa.soh.entities.TSohSubrequest;


/**
 * The persistent class for the T_CMS_MST_PARTY_SUBTYPE database table.
 * 
 */
@Entity
@Table(name="T_CMS_MST_PARTY_SUBTYPE")
@NamedQuery(name="TCmsMstPartySubtype.findAll", query="SELECT t FROM TCmsMstPartySubtype t")
public class TCmsMstPartySubtype implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="SUB_TYPE_ID")
	private long subTypeId;

	@Column(name="ALLOW_CREATING_ACCOUNTS")
	private BigDecimal allowCreatingAccounts;

	private BigDecimal confidentiality;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="CREDIT_STATUS_CHECK")
	private BigDecimal creditStatusCheck;

	@Column(name="DELIVERY_ADDRESS_OPTION")
	private BigDecimal deliveryAddressOption;

	@Temporal(TemporalType.DATE)
	@Column(name="EXPIRY_DATE")
	private Date expiryDate;

	@Column(name="HIGH_CONSUMPTION_CHECK")
	private BigDecimal highConsumptionCheck;

	@Column(name="LONG_DESCRIPTION")
	private String longDescription;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="PARTY_TYPE_ID")
	private BigDecimal partyTypeId;

	@Column(name="PROFILE_PRIORITY")
	private BigDecimal profilePriority;

	@Column(name="SERVING_PRIORITY")
	private BigDecimal servingPriority;

	@Column(name="SHORT_DESCRIPTION")
	private String shortDescription;

	private BigDecimal sponsor;

	@Column(name="SUB_TYPE_CODE")
	private String subTypeCode;

	@Column(name="SUBTYPE_CATEGORY_ID")
	private BigDecimal subtypeCategoryId;
	
	//bi-directional many-to-one association to TSohCustRequirement
	@OneToMany(mappedBy="TCmsMstPartySubtype")
	private List<TSohCustRequirement> TSohCustRequirements;

	//bi-directional many-to-one association to TSohMstSubreqAccinfo
	@OneToMany(mappedBy="TCmsMstPartySubtype")
	private List<TSohMstSubreqAccinfo> TSohMstSubreqAccinfos;

	//bi-directional many-to-one association to TSohSubrequest
	@OneToMany(mappedBy="TCmsMstPartySubtype")
	private List<TSohSubrequest> TSohSubrequests;

	public TCmsMstPartySubtype() {
	}

	public long getSubTypeId() {
		return this.subTypeId;
	}

	public void setSubTypeId(long subTypeId) {
		this.subTypeId = subTypeId;
	}

	public BigDecimal getAllowCreatingAccounts() {
		return this.allowCreatingAccounts;
	}

	public void setAllowCreatingAccounts(BigDecimal allowCreatingAccounts) {
		this.allowCreatingAccounts = allowCreatingAccounts;
	}

	public BigDecimal getConfidentiality() {
		return this.confidentiality;
	}

	public void setConfidentiality(BigDecimal confidentiality) {
		this.confidentiality = confidentiality;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public BigDecimal getCreditStatusCheck() {
		return this.creditStatusCheck;
	}

	public void setCreditStatusCheck(BigDecimal creditStatusCheck) {
		this.creditStatusCheck = creditStatusCheck;
	}

	public BigDecimal getDeliveryAddressOption() {
		return this.deliveryAddressOption;
	}

	public void setDeliveryAddressOption(BigDecimal deliveryAddressOption) {
		this.deliveryAddressOption = deliveryAddressOption;
	}

	public Date getExpiryDate() {
		return this.expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public BigDecimal getHighConsumptionCheck() {
		return this.highConsumptionCheck;
	}

	public void setHighConsumptionCheck(BigDecimal highConsumptionCheck) {
		this.highConsumptionCheck = highConsumptionCheck;
	}

	public String getLongDescription() {
		return this.longDescription;
	}

	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getPartyTypeId() {
		return this.partyTypeId;
	}

	public void setPartyTypeId(BigDecimal partyTypeId) {
		this.partyTypeId = partyTypeId;
	}

	public BigDecimal getProfilePriority() {
		return this.profilePriority;
	}

	public void setProfilePriority(BigDecimal profilePriority) {
		this.profilePriority = profilePriority;
	}

	public BigDecimal getServingPriority() {
		return this.servingPriority;
	}

	public void setServingPriority(BigDecimal servingPriority) {
		this.servingPriority = servingPriority;
	}

	public String getShortDescription() {
		return this.shortDescription;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	public BigDecimal getSponsor() {
		return this.sponsor;
	}

	public void setSponsor(BigDecimal sponsor) {
		this.sponsor = sponsor;
	}

	public String getSubTypeCode() {
		return this.subTypeCode;
	}

	public void setSubTypeCode(String subTypeCode) {
		this.subTypeCode = subTypeCode;
	}

	public BigDecimal getSubtypeCategoryId() {
		return this.subtypeCategoryId;
	}

	public void setSubtypeCategoryId(BigDecimal subtypeCategoryId) {
		this.subtypeCategoryId = subtypeCategoryId;
	}
	public List<TSohCustRequirement> getTSohCustRequirements() {
		return this.TSohCustRequirements;
	}

	public void setTSohCustRequirements(List<TSohCustRequirement> TSohCustRequirements) {
		this.TSohCustRequirements = TSohCustRequirements;
	}

	public TSohCustRequirement addTSohCustRequirement(TSohCustRequirement TSohCustRequirement) {
		getTSohCustRequirements().add(TSohCustRequirement);
		TSohCustRequirement.setTCmsMstPartySubtype(this);

		return TSohCustRequirement;
	}

	public TSohCustRequirement removeTSohCustRequirement(TSohCustRequirement TSohCustRequirement) {
		getTSohCustRequirements().remove(TSohCustRequirement);
		TSohCustRequirement.setTCmsMstPartySubtype(null);

		return TSohCustRequirement;
	}

	public List<TSohMstSubreqAccinfo> getTSohMstSubreqAccinfos() {
		return this.TSohMstSubreqAccinfos;
	}

	public void setTSohMstSubreqAccinfos(List<TSohMstSubreqAccinfo> TSohMstSubreqAccinfos) {
		this.TSohMstSubreqAccinfos = TSohMstSubreqAccinfos;
	}

	public TSohMstSubreqAccinfo addTSohMstSubreqAccinfo(TSohMstSubreqAccinfo TSohMstSubreqAccinfo) {
		getTSohMstSubreqAccinfos().add(TSohMstSubreqAccinfo);
		TSohMstSubreqAccinfo.setTCmsMstPartySubtype(this);

		return TSohMstSubreqAccinfo;
	}

	public TSohMstSubreqAccinfo removeTSohMstSubreqAccinfo(TSohMstSubreqAccinfo TSohMstSubreqAccinfo) {
		getTSohMstSubreqAccinfos().remove(TSohMstSubreqAccinfo);
		TSohMstSubreqAccinfo.setTCmsMstPartySubtype(null);

		return TSohMstSubreqAccinfo;
	}

	public List<TSohSubrequest> getTSohSubrequests() {
		return this.TSohSubrequests;
	}

	public void setTSohSubrequests(List<TSohSubrequest> TSohSubrequests) {
		this.TSohSubrequests = TSohSubrequests;
	}

	public TSohSubrequest addTSohSubrequest(TSohSubrequest TSohSubrequest) {
		getTSohSubrequests().add(TSohSubrequest);
		TSohSubrequest.setTCmsMstPartySubtype(this);

		return TSohSubrequest;
	}

	public TSohSubrequest removeTSohSubrequest(TSohSubrequest TSohSubrequest) {
		getTSohSubrequests().remove(TSohSubrequest);
		TSohSubrequest.setTCmsMstPartySubtype(null);

		return TSohSubrequest;
	}

}