package ae.etisalat.cw.jpa.psm.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the T_PSM_MST_SRVC database table.
 * 
 */
@Embeddable
public class TPsmMstSrvcPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="SRVC_ID")
	private long srvcId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="EFFECTIVE_FROM_DATE")
	private java.util.Date effectiveFromDate;

	public TPsmMstSrvcPK() {
	}
	public long getSrvcId() {
		return this.srvcId;
	}
	public void setSrvcId(long srvcId) {
		this.srvcId = srvcId;
	}
	public java.util.Date getEffectiveFromDate() {
		return this.effectiveFromDate;
	}
	public void setEffectiveFromDate(java.util.Date effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TPsmMstSrvcPK)) {
			return false;
		}
		TPsmMstSrvcPK castOther = (TPsmMstSrvcPK)other;
		return 
			(this.srvcId == castOther.srvcId)
			&& this.effectiveFromDate.equals(castOther.effectiveFromDate);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.srvcId ^ (this.srvcId >>> 32)));
		hash = hash * prime + this.effectiveFromDate.hashCode();
		
		return hash;
	}
}