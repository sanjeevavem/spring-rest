package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the T_SOH_MST_SYSTEM_CODE database table.
 * 
 */
@Entity
@Table(name="T_SOH_MST_SYSTEM_CODE")
@NamedQuery(name="TSohMstSystemCode.findAll", query="SELECT t FROM TSohMstSystemCode t")
@Cacheable(false)
public class TSohMstSystemCode implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SYSTEM_CODE_ID")
	private long systemCodeId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="SYSTEM_CODE_DESC")
	private String systemCodeDesc;

	@Column(name="SYSTEM_CODE_TYPE")
	private String systemCodeType;

	//bi-directional many-to-one association to TSohDtlSystemCodeValue
	@OneToMany(mappedBy="TSohMstSystemCode")
	private List<TSohDtlSystemCodeValue> TSohDtlSystemCodeValues;

	public TSohMstSystemCode() {
	}

	public long getSystemCodeId() {
		return this.systemCodeId;
	}

	public void setSystemCodeId(long systemCodeId) {
		this.systemCodeId = systemCodeId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getSystemCodeDesc() {
		return this.systemCodeDesc;
	}

	public void setSystemCodeDesc(String systemCodeDesc) {
		this.systemCodeDesc = systemCodeDesc;
	}

	public String getSystemCodeType() {
		return this.systemCodeType;
	}

	public void setSystemCodeType(String systemCodeType) {
		this.systemCodeType = systemCodeType;
	}

	public List<TSohDtlSystemCodeValue> getTSohDtlSystemCodeValues() {
		return this.TSohDtlSystemCodeValues;
	}

	public void setTSohDtlSystemCodeValues(List<TSohDtlSystemCodeValue> TSohDtlSystemCodeValues) {
		this.TSohDtlSystemCodeValues = TSohDtlSystemCodeValues;
	}

	public TSohDtlSystemCodeValue addTSohDtlSystemCodeValue(TSohDtlSystemCodeValue TSohDtlSystemCodeValue) {
		getTSohDtlSystemCodeValues().add(TSohDtlSystemCodeValue);
		TSohDtlSystemCodeValue.setTSohMstSystemCode(this);

		return TSohDtlSystemCodeValue;
	}

	public TSohDtlSystemCodeValue removeTSohDtlSystemCodeValue(TSohDtlSystemCodeValue TSohDtlSystemCodeValue) {
		getTSohDtlSystemCodeValues().remove(TSohDtlSystemCodeValue);
		TSohDtlSystemCodeValue.setTSohMstSystemCode(null);

		return TSohDtlSystemCodeValue;
	}

}