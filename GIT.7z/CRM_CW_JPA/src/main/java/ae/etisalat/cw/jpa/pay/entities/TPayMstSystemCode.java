package ae.etisalat.cw.jpa.pay.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the T_PAY_MST_SYSTEM_CODE database table.
 * 
 */
@Entity
@Table(name="T_PAY_MST_SYSTEM_CODE")
@NamedQuery(name="TPayMstSystemCode.findAll", query="SELECT t FROM TPayMstSystemCode t")
public class TPayMstSystemCode implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="SYSTEM_CODE_ID")
	private long systemCodeId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="SYSTEM_CODE")
	private String systemCode;

	@Column(name="SYSTEM_CODE_DESC")
	private String systemCodeDesc;

	public TPayMstSystemCode() {
	}

	public long getSystemCodeId() {
		return this.systemCodeId;
	}

	public void setSystemCodeId(long systemCodeId) {
		this.systemCodeId = systemCodeId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getSystemCode() {
		return this.systemCode;
	}

	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}

	public String getSystemCodeDesc() {
		return this.systemCodeDesc;
	}

	public void setSystemCodeDesc(String systemCodeDesc) {
		this.systemCodeDesc = systemCodeDesc;
	}

}