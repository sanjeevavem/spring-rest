package ae.etisalat.cw.jpa.cms.entities;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

public class TCMSParty implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id	
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SQ_CMS_PARTY")
	@SequenceGenerator(name="SQ_CMS_PARTY", sequenceName="SQ_CMS_PARTY", allocationSize=1)	
	@Column(name="PARTY_ID")
	private long partyId;

	@Column(name="FIRST_NAME")
	private String firstName;

	@Column(name="FIRST_NAME_ARABIC")
	private String firstNameArabic;
	
	@Column(name="LAST_NAME")
	private String lastName;

	@Column(name="LAST_NAME_ARABIC")
	private String lastNameArabic;

	@Column(name="FULL_NAME")
	private String fullName;

	@Column(name="FULL_NAME_ARABIC")
	private String fullNameArabic;
	
	@Column(name="MIDDLE_NAME")
	private String middleName;

	@Column(name="MIDDLE_NAME_ARABIC")
	private String middleNameArabic;
	
	@Column(name="TITLE")
	private BigDecimal title;

	@Column(name="TITLE_ARABIC")
	private BigDecimal titleArabic;
	
	@Column(name="PREFEERED_LANGUAGE")
	private String prefeeredLanguage;

	@Column(name="PREFEERED_NAME")
	private String prefeeredName;

	@Column(name="PREFEERED_NAME_ARABIC")
	private String prefeeredNameArabic;

	@Column(name="REGION_ID")
	private BigDecimal regionId;
	
	@Column(name="MOTHER_NAME")
	private String motherName;

}
