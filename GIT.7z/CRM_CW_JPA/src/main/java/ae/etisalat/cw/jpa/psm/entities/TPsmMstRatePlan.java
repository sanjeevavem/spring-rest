package ae.etisalat.cw.jpa.psm.entities;

import java.io.Serializable;

import javax.persistence.*;

import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the T_PSM_MST_RATE_PLAN database table.
 * 
 */
@Entity
@Table(name="T_PSM_MST_RATE_PLAN")
@NamedQueries({
	@NamedQuery(name="TPsmMstRatePlan.findAll", query="SELECT t FROM TPsmMstRatePlan t"),
	@NamedQuery(name="TPsmMstRatePlan.findByRatePlanIds" ,query="SELECT t FROM TPsmMstRatePlan t where t.deletionStatus=:deletionStatus and (t.effectiveTillDate is null or t.effectiveTillDate>current_timestamp) and t.id.ratePlanId in :ratePlanIds"),
	@NamedQuery(name="TPsmMstRatePlan.findByRatePlanCodes" ,query="SELECT t FROM TPsmMstRatePlan t where t.deletionStatus=:deletionStatus and (t.effectiveTillDate is null or t.effectiveTillDate>current_timestamp) and t.ratePlanCode in :ratePlanCodes")
})
public class TPsmMstRatePlan implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TPsmMstRatePlanPK id;

	@Column(name="ACCOUNT_CATEGORY_FLAG")
	private BigDecimal accountCategoryFlag;

	@Column(name="ACCOUNT_REGION_FLAG")
	private BigDecimal accountRegionFlag;

	@Lob
	@Column(name="APPROVAL_DOC1")
	private byte[] approvalDoc1;

	@Column(name="AUTO_DEDC_FREQ")
	private BigDecimal autoDedcFreq;

	@Column(name="BILLING_CYCLE_FREQUENCY")
	private BigDecimal billingCycleFrequency;

	@Column(name="COM_NAME_ID")
	private BigDecimal comNameId;

	@Column(name="COM_SUBTYPE_ID")
	private BigDecimal comSubtypeId;

	@Column(name="COMPANY_TYPE_FLAG")
	private BigDecimal companyTypeFlag;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DEFAULT_SRVC_FALG")
	private BigDecimal defaultSrvcFalg;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="DESCRIPTION_ID")
	private BigDecimal descriptionId;

	@Column(name="EFFECTIVE_TILL_DATE")
	private Timestamp effectiveTillDate;

	@Column(name="EMIRATE_FLAG")
	private BigDecimal emirateFlag;

	@Column(name="EQUIPMENT_RECOVERY_FLAG")
	private BigDecimal equipmentRecoveryFlag;

	@Column(name="FRIENDLY_SERVICE_ARABIC")
	private String friendlyServiceArabic;

	@Column(name="FRIENDLY_SERVICE_ENG")
	private String friendlyServiceEng;

	@Column(name="INDUSTRY_TYPE_FLAG")
	private BigDecimal industryTypeFlag;

	@Column(name="INSURANCE_FLAG")
	private BigDecimal insuranceFlag;

	@Column(name="MARKET_SEGMENT_FLAG")
	private BigDecimal marketSegmentFlag;

	@Column(name="MAX_QTY")
	private BigDecimal maxQty;

	@Column(name="MIN_QTY")
	private BigDecimal minQty;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="NATIONALITY_FLAG")
	private BigDecimal nationalityFlag;

	@Column(name="NO_BYPASS_PREPAYMENT")
	private BigDecimal noBypassPrepayment;

	@Column(name="NO_REFUND_FLAG")
	private BigDecimal noRefundFlag;

	@Column(name="NUMBER_CATEGORY_ID")
	private BigDecimal numberCategoryId;

	@Column(name="OFFER_FROM_DATE")
	private Timestamp offerFromDate;

	@Column(name="OFFER_TILL_DATE")
	private Timestamp offerTillDate;

	@Column(name="PARTY_AGE_FLAG")
	private BigDecimal partyAgeFlag;

	@Column(name="PARTY_NAME_FLAG")
	private BigDecimal partyNameFlag;

	@Column(name="PARTY_SUB_TYPE_FLAG")
	private BigDecimal partySubTypeFlag;

	@Column(name="PARTY_TYPE_FLAG")
	private BigDecimal partyTypeFlag;

	@Column(name="PKG_GRP_ID")
	private BigDecimal pkgGrpId;

	@Column(name="PREPAYMENT_AMOUNT")
	private BigDecimal prepaymentAmount;

	@Column(name="PROFESSION_FLAG")
	private BigDecimal professionFlag;

	@Column(name="RATE_PLAN_CODE")
	private String ratePlanCode;

	@Column(name="RATE_PLAN_VERSION")
	private BigDecimal ratePlanVersion;

	private String remarks;

	@Column(name="RENTAL_ID")
	private BigDecimal rentalId;

	@Column(name="SERVICE_TYPE")
	private BigDecimal serviceType;

	@Column(name="SIC_ID")
	private BigDecimal sicId;

	@Column(name="TARIFF_LETTER")
	private String tariffLetter;

	@Column(name="TERMS_AND_CONDS_ID")
	private BigDecimal termsAndCondsId;

	@Column(name="TOS_RATEPLAN")
	private BigDecimal tosRateplan;
	
	@Column(name="SPLIT_BILLING_FLAG")
	private String splitBillingFlag ;

	public String getSplitBillingFlag() {
		return splitBillingFlag;
	}

	public void setSplitBillingFlag(String splitBillingFlag) {
		this.splitBillingFlag = splitBillingFlag;
	}


	//bi-directional many-to-one association to TPsmMstSrvc
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="SRVC_EFFECTIVE_FROM_DATE", referencedColumnName="EFFECTIVE_FROM_DATE"),
		@JoinColumn(name="SRVC_ID", referencedColumnName="SRVC_ID")
		})
	private TPsmMstSrvc TPsmMstSrvc;

	//bi-directional many-to-one association to TPsmDtlSystemCodeValue
	@ManyToOne
	@JoinColumn(name="STATUS")
	private TPsmDtlSystemCodeValue TPsmDtlSystemCodeValue;

	//bi-directional many-to-one association to TPsmRpRecurringMap
	@OneToMany(mappedBy="TPsmMstRatePlan")
	private List<TPsmRpRecurringMap> TPsmRpRecurringMaps;
//bi-directional many-to-one association to TPsmRpOnetimeMap
	@OneToMany(mappedBy="TPsmMstRatePlan")
	private List<TPsmRpOnetimeMap> TPsmRpOnetimeMaps;
	
	@Column(name="WIFI_PKG_CODE")
	private String wifiPkgCode;
	
	@Column(name="WIFI_ELIGIBILITY")
	private String wifiEligibility;

	public TPsmMstRatePlan() {
	}

	public TPsmMstRatePlanPK getId() {
		return this.id;
	}

	public void setId(TPsmMstRatePlanPK id) {
		this.id = id;
	}

	public BigDecimal getAccountCategoryFlag() {
		return this.accountCategoryFlag;
	}

	public void setAccountCategoryFlag(BigDecimal accountCategoryFlag) {
		this.accountCategoryFlag = accountCategoryFlag;
	}

	public BigDecimal getAccountRegionFlag() {
		return this.accountRegionFlag;
	}

	public void setAccountRegionFlag(BigDecimal accountRegionFlag) {
		this.accountRegionFlag = accountRegionFlag;
	}

	public byte[] getApprovalDoc1() {
		return this.approvalDoc1;
	}

	public void setApprovalDoc1(byte[] approvalDoc1) {
		this.approvalDoc1 = approvalDoc1;
	}

	public BigDecimal getAutoDedcFreq() {
		return this.autoDedcFreq;
	}

	public void setAutoDedcFreq(BigDecimal autoDedcFreq) {
		this.autoDedcFreq = autoDedcFreq;
	}

	public BigDecimal getBillingCycleFrequency() {
		return this.billingCycleFrequency;
	}

	public void setBillingCycleFrequency(BigDecimal billingCycleFrequency) {
		this.billingCycleFrequency = billingCycleFrequency;
	}

	public BigDecimal getComNameId() {
		return this.comNameId;
	}

	public void setComNameId(BigDecimal comNameId) {
		this.comNameId = comNameId;
	}

	public BigDecimal getComSubtypeId() {
		return this.comSubtypeId;
	}

	public void setComSubtypeId(BigDecimal comSubtypeId) {
		this.comSubtypeId = comSubtypeId;
	}

	public BigDecimal getCompanyTypeFlag() {
		return this.companyTypeFlag;
	}

	public void setCompanyTypeFlag(BigDecimal companyTypeFlag) {
		this.companyTypeFlag = companyTypeFlag;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public BigDecimal getDefaultSrvcFalg() {
		return this.defaultSrvcFalg;
	}

	public void setDefaultSrvcFalg(BigDecimal defaultSrvcFalg) {
		this.defaultSrvcFalg = defaultSrvcFalg;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public BigDecimal getDescriptionId() {
		return this.descriptionId;
	}

	public void setDescriptionId(BigDecimal descriptionId) {
		this.descriptionId = descriptionId;
	}

	public Timestamp getEffectiveTillDate() {
		return this.effectiveTillDate;
	}

	public void setEffectiveTillDate(Timestamp effectiveTillDate) {
		this.effectiveTillDate = effectiveTillDate;
	}

	public BigDecimal getEmirateFlag() {
		return this.emirateFlag;
	}

	public void setEmirateFlag(BigDecimal emirateFlag) {
		this.emirateFlag = emirateFlag;
	}

	public BigDecimal getEquipmentRecoveryFlag() {
		return this.equipmentRecoveryFlag;
	}

	public void setEquipmentRecoveryFlag(BigDecimal equipmentRecoveryFlag) {
		this.equipmentRecoveryFlag = equipmentRecoveryFlag;
	}

	public String getFriendlyServiceArabic() {
		return this.friendlyServiceArabic;
	}

	public void setFriendlyServiceArabic(String friendlyServiceArabic) {
		this.friendlyServiceArabic = friendlyServiceArabic;
	}

	public String getFriendlyServiceEng() {
		return this.friendlyServiceEng;
	}

	public void setFriendlyServiceEng(String friendlyServiceEng) {
		this.friendlyServiceEng = friendlyServiceEng;
	}

	public BigDecimal getIndustryTypeFlag() {
		return this.industryTypeFlag;
	}

	public void setIndustryTypeFlag(BigDecimal industryTypeFlag) {
		this.industryTypeFlag = industryTypeFlag;
	}

	public BigDecimal getInsuranceFlag() {
		return this.insuranceFlag;
	}

	public void setInsuranceFlag(BigDecimal insuranceFlag) {
		this.insuranceFlag = insuranceFlag;
	}

	public BigDecimal getMarketSegmentFlag() {
		return this.marketSegmentFlag;
	}

	public void setMarketSegmentFlag(BigDecimal marketSegmentFlag) {
		this.marketSegmentFlag = marketSegmentFlag;
	}

	public BigDecimal getMaxQty() {
		return this.maxQty;
	}

	public void setMaxQty(BigDecimal maxQty) {
		this.maxQty = maxQty;
	}

	public BigDecimal getMinQty() {
		return this.minQty;
	}

	public void setMinQty(BigDecimal minQty) {
		this.minQty = minQty;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getNationalityFlag() {
		return this.nationalityFlag;
	}

	public void setNationalityFlag(BigDecimal nationalityFlag) {
		this.nationalityFlag = nationalityFlag;
	}

	public BigDecimal getNoBypassPrepayment() {
		return this.noBypassPrepayment;
	}

	public void setNoBypassPrepayment(BigDecimal noBypassPrepayment) {
		this.noBypassPrepayment = noBypassPrepayment;
	}

	public BigDecimal getNoRefundFlag() {
		return this.noRefundFlag;
	}

	public void setNoRefundFlag(BigDecimal noRefundFlag) {
		this.noRefundFlag = noRefundFlag;
	}

	public BigDecimal getNumberCategoryId() {
		return this.numberCategoryId;
	}

	public void setNumberCategoryId(BigDecimal numberCategoryId) {
		this.numberCategoryId = numberCategoryId;
	}

	public Timestamp getOfferFromDate() {
		return this.offerFromDate;
	}

	public void setOfferFromDate(Timestamp offerFromDate) {
		this.offerFromDate = offerFromDate;
	}

	public Timestamp getOfferTillDate() {
		return this.offerTillDate;
	}

	public void setOfferTillDate(Timestamp offerTillDate) {
		this.offerTillDate = offerTillDate;
	}

	public BigDecimal getPartyAgeFlag() {
		return this.partyAgeFlag;
	}

	public void setPartyAgeFlag(BigDecimal partyAgeFlag) {
		this.partyAgeFlag = partyAgeFlag;
	}

	public BigDecimal getPartyNameFlag() {
		return this.partyNameFlag;
	}

	public void setPartyNameFlag(BigDecimal partyNameFlag) {
		this.partyNameFlag = partyNameFlag;
	}

	public BigDecimal getPartySubTypeFlag() {
		return this.partySubTypeFlag;
	}

	public void setPartySubTypeFlag(BigDecimal partySubTypeFlag) {
		this.partySubTypeFlag = partySubTypeFlag;
	}

	public BigDecimal getPartyTypeFlag() {
		return this.partyTypeFlag;
	}

	public void setPartyTypeFlag(BigDecimal partyTypeFlag) {
		this.partyTypeFlag = partyTypeFlag;
	}

	public BigDecimal getPkgGrpId() {
		return this.pkgGrpId;
	}

	public void setPkgGrpId(BigDecimal pkgGrpId) {
		this.pkgGrpId = pkgGrpId;
	}

	public BigDecimal getPrepaymentAmount() {
		return this.prepaymentAmount;
	}

	public void setPrepaymentAmount(BigDecimal prepaymentAmount) {
		this.prepaymentAmount = prepaymentAmount;
	}

	public BigDecimal getProfessionFlag() {
		return this.professionFlag;
	}

	public void setProfessionFlag(BigDecimal professionFlag) {
		this.professionFlag = professionFlag;
	}

	public String getRatePlanCode() {
		return this.ratePlanCode;
	}

	public void setRatePlanCode(String ratePlanCode) {
		this.ratePlanCode = ratePlanCode;
	}

	public BigDecimal getRatePlanVersion() {
		return this.ratePlanVersion;
	}

	public void setRatePlanVersion(BigDecimal ratePlanVersion) {
		this.ratePlanVersion = ratePlanVersion;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public BigDecimal getRentalId() {
		return this.rentalId;
	}

	public void setRentalId(BigDecimal rentalId) {
		this.rentalId = rentalId;
	}

	public BigDecimal getServiceType() {
		return this.serviceType;
	}

	public void setServiceType(BigDecimal serviceType) {
		this.serviceType = serviceType;
	}

	public BigDecimal getSicId() {
		return this.sicId;
	}

	public void setSicId(BigDecimal sicId) {
		this.sicId = sicId;
	}

	public String getTariffLetter() {
		return this.tariffLetter;
	}

	public void setTariffLetter(String tariffLetter) {
		this.tariffLetter = tariffLetter;
	}

	public BigDecimal getTermsAndCondsId() {
		return this.termsAndCondsId;
	}

	public void setTermsAndCondsId(BigDecimal termsAndCondsId) {
		this.termsAndCondsId = termsAndCondsId;
	}

	public BigDecimal getTosRateplan() {
		return this.tosRateplan;
	}

	public void setTosRateplan(BigDecimal tosRateplan) {
		this.tosRateplan = tosRateplan;
	}

	public TPsmMstSrvc getTPsmMstSrvc() {
		return this.TPsmMstSrvc;
	}

	public void setTPsmMstSrvc(TPsmMstSrvc TPsmMstSrvc) {
		this.TPsmMstSrvc = TPsmMstSrvc;
	}

	public TPsmDtlSystemCodeValue getTPsmDtlSystemCodeValue() {
		return this.TPsmDtlSystemCodeValue;
	}

	public void setTPsmDtlSystemCodeValue(TPsmDtlSystemCodeValue TPsmDtlSystemCodeValue) {
		this.TPsmDtlSystemCodeValue = TPsmDtlSystemCodeValue;
	}

	public List<TPsmRpRecurringMap> getTPsmRpRecurringMaps() {
		return this.TPsmRpRecurringMaps;
	}

	public void setTPsmRpRecurringMaps(List<TPsmRpRecurringMap> TPsmRpRecurringMaps) {
		this.TPsmRpRecurringMaps = TPsmRpRecurringMaps;
	}

	public TPsmRpRecurringMap addTPsmRpRecurringMap(TPsmRpRecurringMap TPsmRpRecurringMap) {
		getTPsmRpRecurringMaps().add(TPsmRpRecurringMap);
		TPsmRpRecurringMap.setTPsmMstRatePlan(this);

		return TPsmRpRecurringMap;
	}

	public TPsmRpRecurringMap removeTPsmRpRecurringMap(TPsmRpRecurringMap TPsmRpRecurringMap) {
		getTPsmRpRecurringMaps().remove(TPsmRpRecurringMap);
		TPsmRpRecurringMap.setTPsmMstRatePlan(null);

		return TPsmRpRecurringMap;
	}
public List<TPsmRpOnetimeMap> getTPsmRpOnetimeMaps() {
		return this.TPsmRpOnetimeMaps;
	}

	public void setTPsmRpOnetimeMaps(List<TPsmRpOnetimeMap> TPsmRpOnetimeMaps) {
		this.TPsmRpOnetimeMaps = TPsmRpOnetimeMaps;
	}

	public TPsmRpOnetimeMap addTPsmRpOnetimeMap(TPsmRpOnetimeMap TPsmRpOnetimeMap) {
		getTPsmRpOnetimeMaps().add(TPsmRpOnetimeMap);
		TPsmRpOnetimeMap.setTPsmMstRatePlan(this);

		return TPsmRpOnetimeMap;
	}

	public TPsmRpOnetimeMap removeTPsmRpOnetimeMap(TPsmRpOnetimeMap TPsmRpOnetimeMap) {
		getTPsmRpOnetimeMaps().remove(TPsmRpOnetimeMap);
		TPsmRpOnetimeMap.setTPsmMstRatePlan(null);

		return TPsmRpOnetimeMap;
	}
	
	public String getWifiPkgCode() {
		return wifiPkgCode;
	}

	public void setWifiPkgCode(String wifiPkgCode) {
		this.wifiPkgCode = wifiPkgCode;
	}
	
	public String getWifiEligibility() {
		return wifiEligibility;
	}

	public void setWifiEligibility(String wifiEligibility) {
		this.wifiEligibility = wifiEligibility;
	}

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        TPsmMstRatePlan other = (TPsmMstRatePlan) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        }
        else if (!id.equals(other.id))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "TPsmMstRatePlan [id=" + id + ", effectiveTillDate=" + effectiveTillDate + ", ratePlanCode=" + ratePlanCode + "]";
    }
    
}