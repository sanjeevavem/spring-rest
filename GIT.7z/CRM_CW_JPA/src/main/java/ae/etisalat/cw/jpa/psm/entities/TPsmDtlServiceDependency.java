package ae.etisalat.cw.jpa.psm.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;


/**
 * The persistent class for the T_PSM_DTL_SERVICE_DEPENDENCY database table.
 * 
 */
@Entity
@Table(name="T_PSM_DTL_SERVICE_DEPENDENCY")
@NamedQuery(name="TPsmDtlServiceDependency.findAll", query="SELECT t FROM TPsmDtlServiceDependency t")
public class TPsmDtlServiceDependency implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="SERVICE_DEPENDENCY_DTL_ID")
	private long serviceDependencyDtlId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="EFFECTIVE_FROM_DATE")
	private Timestamp effectiveFromDate;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="PACKAGE_ID")
	private BigDecimal packageId;

	@Column(name="RATE_PLAN_ID")
	private BigDecimal ratePlanId;

	@Column(name="SRVC_ID")
	private BigDecimal srvcId;

	//bi-directional many-to-one association to TPsmMstServiceDependency
	@ManyToOne
	@JoinColumn(name="SERVICE_DEPENDENCY_ID")
	private TPsmMstServiceDependency TPsmMstServiceDependency;

	public TPsmDtlServiceDependency() {
	}

	public long getServiceDependencyDtlId() {
		return this.serviceDependencyDtlId;
	}

	public void setServiceDependencyDtlId(long serviceDependencyDtlId) {
		this.serviceDependencyDtlId = serviceDependencyDtlId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getEffectiveFromDate() {
		return this.effectiveFromDate;
	}

	public void setEffectiveFromDate(Timestamp effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getPackageId() {
		return this.packageId;
	}

	public void setPackageId(BigDecimal packageId) {
		this.packageId = packageId;
	}

	public BigDecimal getRatePlanId() {
		return this.ratePlanId;
	}

	public void setRatePlanId(BigDecimal ratePlanId) {
		this.ratePlanId = ratePlanId;
	}

	public BigDecimal getSrvcId() {
		return this.srvcId;
	}

	public void setSrvcId(BigDecimal srvcId) {
		this.srvcId = srvcId;
	}

	public TPsmMstServiceDependency getTPsmMstServiceDependency() {
		return this.TPsmMstServiceDependency;
	}

	public void setTPsmMstServiceDependency(TPsmMstServiceDependency TPsmMstServiceDependency) {
		this.TPsmMstServiceDependency = TPsmMstServiceDependency;
	}

}