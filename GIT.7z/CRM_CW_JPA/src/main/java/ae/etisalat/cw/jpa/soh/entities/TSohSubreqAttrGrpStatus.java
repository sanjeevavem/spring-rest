package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the T_SOH_SUBREQ_ATTR_GRP_STATUS database table.
 * 
 */
@Entity
@Table(name="T_SOH_SUBREQ_ATTR_GRP_STATUS")
@NamedQuery(name="TSohSubreqAttrGrpStatus.findAll", query="SELECT t FROM TSohSubreqAttrGrpStatus t")
public class TSohSubreqAttrGrpStatus implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SUBREQ_AG_ID")
	private long subreqAgId;

	@Column(name="ASSOCIATION_ID")
	private BigDecimal associationId;

	@Column(name="ATTRIBUTE_GROUP_ID")
	private BigDecimal attributeGroupId;

	@Temporal(TemporalType.DATE)
	@Column(name="CREATED_DATE")
	private Date createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_FROM_DATE")
	private Date effectiveFromDate;

	@Temporal(TemporalType.DATE)
	@Column(name="MODIFIED_DATE")
	private Date modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="PERFORM_STATUS")
	private BigDecimal performStatus;

	@Column(name="SUBREQUEST_ID")
	private BigDecimal subrequestId;

	public TSohSubreqAttrGrpStatus() {
	}

	public long getSubreqAgId() {
		return this.subreqAgId;
	}

	public void setSubreqAgId(long subreqAgId) {
		this.subreqAgId = subreqAgId;
	}

	public BigDecimal getAssociationId() {
		return this.associationId;
	}

	public void setAssociationId(BigDecimal associationId) {
		this.associationId = associationId;
	}

	public BigDecimal getAttributeGroupId() {
		return this.attributeGroupId;
	}

	public void setAttributeGroupId(BigDecimal attributeGroupId) {
		this.attributeGroupId = attributeGroupId;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Date getEffectiveFromDate() {
		return this.effectiveFromDate;
	}

	public void setEffectiveFromDate(Date effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getPerformStatus() {
		return this.performStatus;
	}

	public void setPerformStatus(BigDecimal performStatus) {
		this.performStatus = performStatus;
	}

	public BigDecimal getSubrequestId() {
		return this.subrequestId;
	}

	public void setSubrequestId(BigDecimal subrequestId) {
		this.subrequestId = subrequestId;
	}

}