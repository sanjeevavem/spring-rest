package ae.etisalat.cw.jpa.psm.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;


/**
 * The persistent class for the T_PSM_RP_RECURRING_MAP database table.
 * 
 */
@Entity
@Table(name="T_PSM_RP_RECURRING_MAP")
@NamedQuery(name="TPsmRpRecurringMap.findAll", query="SELECT t FROM TPsmRpRecurringMap t")
public class TPsmRpRecurringMap implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TPsmRpRecurringMapPK id;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="TAX_POLICY_ID")
	private BigDecimal taxPolicyId;

	//bi-directional many-to-one association to TPsmMstRatePlan
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="EFFECTIVE_FROM_DATE", referencedColumnName="EFFECTIVE_FROM_DATE", insertable=false, updatable=false),
		@JoinColumn(name="RATE_PLAN_ID", referencedColumnName="RATE_PLAN_ID", insertable=false, updatable=false)
		})
	private TPsmMstRatePlan TPsmMstRatePlan;

	//bi-directional many-to-one association to TPsmMstRecurrChrgType
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="RECURR_CHARGE_TYPE_ID", referencedColumnName="RECURR_CHARGE_TYPE_ID",insertable=false, updatable=false),
		@JoinColumn(name="RP_EFFECTIVE_FROM_DATE", referencedColumnName="EFFECTIVE_FROM_DATE", insertable=false, updatable=false)
		})
	private TPsmMstRecurrChrgType TPsmMstRecurrChrgType;

	public TPsmRpRecurringMap() {
	}

	public TPsmRpRecurringMapPK getId() {
		return this.id;
	}

	public void setId(TPsmRpRecurringMapPK id) {
		this.id = id;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getTaxPolicyId() {
		return this.taxPolicyId;
	}

	public void setTaxPolicyId(BigDecimal taxPolicyId) {
		this.taxPolicyId = taxPolicyId;
	}

	public TPsmMstRatePlan getTPsmMstRatePlan() {
		return this.TPsmMstRatePlan;
	}

	public void setTPsmMstRatePlan(TPsmMstRatePlan TPsmMstRatePlan) {
		this.TPsmMstRatePlan = TPsmMstRatePlan;
	}

	public TPsmMstRecurrChrgType getTPsmMstRecurrChrgType() {
		return this.TPsmMstRecurrChrgType;
	}

	public void setTPsmMstRecurrChrgType(TPsmMstRecurrChrgType TPsmMstRecurrChrgType) {
		this.TPsmMstRecurrChrgType = TPsmMstRecurrChrgType;
	}

}