package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the T_SOH_ACC_ACCOUNT_NUMBER database table.
 * 
 */
@Entity
@Table(name="T_SOH_ACC_ACCOUNT_NUMBER")
@NamedQueries({
	@NamedQuery(name="TSohAccAccountNumber.findAll", query="SELECT t FROM TSohAccAccountNumber t"),
	@NamedQuery(name="TSohAccAccountNumber.findAccountByAccountNumber",
	query="select a from TSohAccAccountNumber a where a.accountNumber = :accountNumber and a.accountSuffix= (select max(h.accountSuffix) from  TSohAccAccountNumber h where h.accountNumber = :accountNumber)")})
public class TSohAccAccountNumber implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_SOH_ACC_ACCOUNT_NUMBER_ACCACCOUNTNUMBERID_GENERATOR", sequenceName="SQ_T_SOH_ACC_ACCOUNT_NUMBER",allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_SOH_ACC_ACCOUNT_NUMBER_ACCACCOUNTNUMBERID_GENERATOR")
	@Column(name="ACC_ACCOUNT_NUMBER_ID")
	private long accAccountNumberId;

	@Column(name="ACCOUNT_NUMBER")
	private String accountNumber;

	@Column(name="ACCOUNT_SUFFIX")
	private BigDecimal accountSuffix;

	@Column(name="AREA_CODE")
	private String areaCode;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="PRODUCT_NUMBER")
	private BigDecimal productNumber;

	//bi-directional many-to-one association to TSohAccount
	@ManyToOne
	@JoinColumn(name="ACCOUNT_ID")
	private TSohAccount TSohAccount;

	public TSohAccAccountNumber() {
	}

	public long getAccAccountNumberId() {
		return this.accAccountNumberId;
	}

	public void setAccAccountNumberId(long accAccountNumberId) {
		this.accAccountNumberId = accAccountNumberId;
	}

	public String getAccountNumber() {
		return this.accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public BigDecimal getAccountSuffix() {
		return this.accountSuffix;
	}

	public void setAccountSuffix(BigDecimal accountSuffix) {
		this.accountSuffix = accountSuffix;
	}

	public String getAreaCode() {
		return this.areaCode;
	}

	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getProductNumber() {
		return this.productNumber;
	}

	public void setProductNumber(BigDecimal productNumber) {
		this.productNumber = productNumber;
	}

	public TSohAccount getTSohAccount() {
		return this.TSohAccount;
	}

	public void setTSohAccount(TSohAccount TSohAccount) {
		this.TSohAccount = TSohAccount;
	}

}