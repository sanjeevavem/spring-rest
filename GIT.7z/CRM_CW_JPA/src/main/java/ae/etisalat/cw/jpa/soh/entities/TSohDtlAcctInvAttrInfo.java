package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the T_SOH_DTL_ACCT_INV_ATTR_INFO database table.
 * 
 */
@Entity
@Table(name="T_SOH_DTL_ACCT_INV_ATTR_INFO")
@NamedQuery(name="TSohDtlAcctInvAttrInfo.findAll", query="SELECT t FROM TSohDtlAcctInvAttrInfo t")
public class TSohDtlAcctInvAttrInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_SOH_DTL_ACCT_INV_ATTR_INFO_ACCINVOICEATTRIBUTEID_GENERATOR", sequenceName="SQ_T_SOH_DTL_ACCT_INV_ATTR",allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_SOH_DTL_ACCT_INV_ATTR_INFO_ACCINVOICEATTRIBUTEID_GENERATOR")
	@Column(name="ACC_INVOICE_ATTRIBUTE_ID")
	private long accInvoiceAttributeId;

	@Column(name="BILLING_ADDRESS_ID")
	private BigDecimal billingAddressId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="DELIVERY_ADDRESS_ID")
	private BigDecimal deliveryAddressId;

	@Column(name="DETAILS_INVOICE_FLAG")
	private String detailsInvoiceFlag;

	@Temporal(TemporalType.DATE)
	@Column(name="EFF_FROM")
	private Date effFrom;

	@Temporal(TemporalType.DATE)
	@Column(name="EFF_TILL")
	private Date effTill;

	@Column(name="HIDE_NAME_FLAG")
	private String hideNameFlag;

	@Column(name="INVOICE_MEDIA_ID")
	private BigDecimal invoiceMediaId;

	@Column(name="INVOICE_TEMPLATE_ID")
	private BigDecimal invoiceTemplateId;

	@Column(name="LANGUAGE_ID")
	private BigDecimal languageId;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	private String pobox;

	//bi-directional many-to-one association to TSohMstAccountInvoiceInfo
	@ManyToOne
	@JoinColumn(name="ACC_INVOICE_ID")
	private TSohMstAccountInvoiceInfo TSohMstAccountInvoiceInfo;

	public TSohDtlAcctInvAttrInfo() {
	}

	public long getAccInvoiceAttributeId() {
		return this.accInvoiceAttributeId;
	}

	public void setAccInvoiceAttributeId(long accInvoiceAttributeId) {
		this.accInvoiceAttributeId = accInvoiceAttributeId;
	}

	public BigDecimal getBillingAddressId() {
		return this.billingAddressId;
	}

	public void setBillingAddressId(BigDecimal billingAddressId) {
		this.billingAddressId = billingAddressId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public BigDecimal getDeliveryAddressId() {
		return this.deliveryAddressId;
	}

	public void setDeliveryAddressId(BigDecimal deliveryAddressId) {
		this.deliveryAddressId = deliveryAddressId;
	}

	public String getDetailsInvoiceFlag() {
		return this.detailsInvoiceFlag;
	}

	public void setDetailsInvoiceFlag(String detailsInvoiceFlag) {
		this.detailsInvoiceFlag = detailsInvoiceFlag;
	}

	public Date getEffFrom() {
		return this.effFrom;
	}

	public void setEffFrom(Date effFrom) {
		this.effFrom = effFrom;
	}

	public Date getEffTill() {
		return this.effTill;
	}

	public void setEffTill(Date effTill) {
		this.effTill = effTill;
	}

	public String getHideNameFlag() {
		return this.hideNameFlag;
	}

	public void setHideNameFlag(String hideNameFlag) {
		this.hideNameFlag = hideNameFlag;
	}

	public BigDecimal getInvoiceMediaId() {
		return this.invoiceMediaId;
	}

	public void setInvoiceMediaId(BigDecimal invoiceMediaId) {
		this.invoiceMediaId = invoiceMediaId;
	}

	public BigDecimal getInvoiceTemplateId() {
		return this.invoiceTemplateId;
	}

	public void setInvoiceTemplateId(BigDecimal invoiceTemplateId) {
		this.invoiceTemplateId = invoiceTemplateId;
	}

	public BigDecimal getLanguageId() {
		return this.languageId;
	}

	public void setLanguageId(BigDecimal languageId) {
		this.languageId = languageId;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getPobox() {
		return this.pobox;
	}

	public void setPobox(String pobox) {
		this.pobox = pobox;
	}

	public TSohMstAccountInvoiceInfo getTSohMstAccountInvoiceInfo() {
		return this.TSohMstAccountInvoiceInfo;
	}

	public void setTSohMstAccountInvoiceInfo(TSohMstAccountInvoiceInfo TSohMstAccountInvoiceInfo) {
		this.TSohMstAccountInvoiceInfo = TSohMstAccountInvoiceInfo;
	}

}