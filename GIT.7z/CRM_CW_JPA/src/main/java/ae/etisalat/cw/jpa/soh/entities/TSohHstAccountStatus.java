package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the T_SOH_HST_ACCOUNT_STATUS database table.
 * 
 */
@Entity
@Table(name="T_SOH_HST_ACCOUNT_STATUS")
@NamedQuery(name="TSohHstAccountStatus.findAll", query="SELECT t FROM TSohHstAccountStatus t")
public class TSohHstAccountStatus implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_SOH_HST_ACCOUNT_STATUS_ACCSTSID_GENERATOR", sequenceName="SQ_T_SOH_HST_ACCOUNT_STATUS",allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_SOH_HST_ACCOUNT_STATUS_ACCSTSID_GENERATOR")
	@Column(name="ACC_STS_ID")
	private long accStsId;

	@Column(name="ACCOUNT_STATUS_ID")
	private BigDecimal accountStatusId;

	@Column(name="CRDT_REASON_ID")
	private BigDecimal crdtReasonId;

	@Column(name="CRDT_STATUS_ID")
	private BigDecimal crdtStatusId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="EFF_FROM")
	private Timestamp effFrom;

	@Column(name="EFF_TILL")
	private Timestamp effTill;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="OLD_ACCOUNT_STATUS_ID")
	private BigDecimal oldAccountStatusId;

	@Column(name="OLD_CRDT_STATUS_ID")
	private BigDecimal oldCrdtStatusId;

	@Column(name="REASON_ID")
	private BigDecimal reasonId;

	//bi-directional many-to-one association to TSohAccount
	@ManyToOne
	@JoinColumn(name="ACCOUNT_ID")
	private TSohAccount TSohAccount;

	public TSohHstAccountStatus() {
	}

	public long getAccStsId() {
		return this.accStsId;
	}

	public void setAccStsId(long accStsId) {
		this.accStsId = accStsId;
	}

	public BigDecimal getAccountStatusId() {
		return this.accountStatusId;
	}

	public void setAccountStatusId(BigDecimal accountStatusId) {
		this.accountStatusId = accountStatusId;
	}

	public BigDecimal getCrdtReasonId() {
		return this.crdtReasonId;
	}

	public void setCrdtReasonId(BigDecimal crdtReasonId) {
		this.crdtReasonId = crdtReasonId;
	}

	public BigDecimal getCrdtStatusId() {
		return this.crdtStatusId;
	}

	public void setCrdtStatusId(BigDecimal crdtStatusId) {
		this.crdtStatusId = crdtStatusId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getEffFrom() {
		return this.effFrom;
	}

	public void setEffFrom(Timestamp effFrom) {
		this.effFrom = effFrom;
	}

	public Timestamp getEffTill() {
		return this.effTill;
	}

	public void setEffTill(Timestamp effTill) {
		this.effTill = effTill;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getOldAccountStatusId() {
		return this.oldAccountStatusId;
	}

	public void setOldAccountStatusId(BigDecimal oldAccountStatusId) {
		this.oldAccountStatusId = oldAccountStatusId;
	}

	public BigDecimal getOldCrdtStatusId() {
		return this.oldCrdtStatusId;
	}

	public void setOldCrdtStatusId(BigDecimal oldCrdtStatusId) {
		this.oldCrdtStatusId = oldCrdtStatusId;
	}

	public BigDecimal getReasonId() {
		return this.reasonId;
	}

	public void setReasonId(BigDecimal reasonId) {
		this.reasonId = reasonId;
	}

	public TSohAccount getTSohAccount() {
		return this.TSohAccount;
	}

	public void setTSohAccount(TSohAccount TSohAccount) {
		this.TSohAccount = TSohAccount;
	}

}