package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import ae.etisalat.cw.jpa.adm.entities.TAdmMstRegion;
import ae.etisalat.cw.jpa.cms.entities.TCmsMstPartySubtype;

@Entity
@Table(name="T_SOH_SUBREQUEST")
@NamedQuery(name="TSohSubrequest.findAll", query="SELECT t FROM TSohSubrequest t")
@NamedNativeQueries({
	@NamedNativeQuery(name="TSohSubrequest.findById",query="SELECT * FROM T_SOH_SUBREQUEST WHERE SUBREQUEST_ID=:SUBREQUEST_ID AND DELETION_STATUS='N'",resultClass=TSohSubrequest.class),
	@NamedNativeQuery(name="TSohSubrequest.findByRequestId",query="SELECT * FROM T_SOH_SUBREQUEST WHERE REQUEST_ID=:REQUEST_ID AND DELETION_STATUS='N'",resultClass=TSohSubrequest.class),
	@NamedNativeQuery(name="TSohSubrequest.findByRequestIdAndNotInStatus",query="SELECT * FROM T_SOH_SUBREQUEST WHERE REQUEST_ID=:REQUEST_ID AND DELETION_STATUS='N' AND STATUS NOT IN :SUBREQSTATUSES ",resultClass=TSohSubrequest.class),
	@NamedNativeQuery(name="TSohSubrequest.findBySubRequestIdAndNotInStatus",query="SELECT * FROM T_SOH_SUBREQUEST WHERE SUBREQUEST_ID=:SUBREQUEST_ID AND DELETION_STATUS='N' AND STATUS NOT IN :SUBREQSTATUSES ",resultClass=TSohSubrequest.class)
})
public class TSohSubrequest implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="SQ_SOH_SUBREQUEST", sequenceName="SQ_SOH_SUBREQUEST", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SQ_SOH_SUBREQUEST")
	@Column(name="SUBREQUEST_ID")
	private long subrequestId;

	@Column(name="ACCOUNT_NUMBER")
	private String accountNumber;

	@Column(name="ACCOUNT_SUFFIX")
	private BigDecimal accountSuffix;

	@Column(name="ADD_DELETE_STATUS")
	private BigDecimal addDeleteStatus;

	@Column(name="AMEND_CANCEL_AG")
	private BigDecimal amendCancelAg;

	@Column(name="AMENDCANCEL_ACTION_TAKEN")
	private BigDecimal amendcancelActionTaken;

	@Column(name="AMENDMENT_COUNT")
	private BigDecimal amendmentCount;

	@Column(name="AREA_CODE")
	private String areaCode;

	@Column(name="ASSOC_UPDOWN_SR_ID")
	private BigDecimal assocUpdownSrId;

	@Column(name="BS_REQUEST_FLAG")
	private String bsRequestFlag;

	@Column(name="BYPASS_ACCOUNT_ID")
	private BigDecimal bypassAccountId;

	@Temporal(TemporalType.DATE)
	@Column(name="CANCELLATION_DATE")
	private Date cancellationDate;

	@Column(name="CANCELLATION_FLAG")
	private BigDecimal cancellationFlag;

	@Column(name="CDMS_REF_NO")
	private String cdmsRefNo;

	@Column(name="CESSATION_REASON_ID")
	private BigDecimal cessationReasonId;

	@Temporal(TemporalType.DATE)
	@Column(name="CESSATION_REQUIRED_DATE")
	private Date cessationRequiredDate;

	@Column(name="CIRCUIT_POINT")
	private String circuitPoint;

	@Temporal(TemporalType.DATE)
	@Column(name="CLOSED_DATE")
	private Date closedDate;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="DEPOSIT_AMT")
	private BigDecimal depositAmt;

	@Column(name="DEPOSIT_PAID")
	private BigDecimal depositPaid;

	@Column(name="DISTRIBUTION_INDX")
	private BigDecimal distributionIndx;

	@Column(name="DP_CHANGED")
	private String dpChanged;

	@Column(name="EMIRATE_ID")
	private BigDecimal emirateId;

	@Column(name="FAX_FLAG")
	private String faxFlag;

	@Column(name="IN_PREVIOUS_BALANCE")
	private BigDecimal inPreviousBalance;

	@Column(name="INSTALLATION_DATE")
	private Timestamp installationDate;

	@Column(name="MDF_CHANGED")
	private String mdfChanged;

	@Column(name="MISC_CHARGE_TYPE")
	private BigDecimal miscChargeType;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="MSG_REQ")
	private String msgReq;

	@Column(name="MSO_FLAG")
	private String msoFlag;

	@Column(name="NEW_ACCOUNT_CATEGORY")
	private BigDecimal newAccountCategory;

	@Column(name="NOTES")
	private String notes;

	@Column(name="NUM_CHG_REQD_FLAG")
	private String numChgReqdFlag;

	@Temporal(TemporalType.DATE)
	@Column(name="OLD_SRVC_REQD_DATE")
	private Date oldSrvcReqdDate;

	@Column(name="OTH_ROUTE_POINT")
	private String othRoutePoint;

	@Column(name="PREPAYMENT_AMT")
	private BigDecimal prepaymentAmt;

	@Column(name="PREPAYMENT_PAID")
	private BigDecimal prepaymentPaid;

	@Column(name="PRIORITY")
	private BigDecimal priority;

	@Column(name="PRIORITY_CODE")
	private String priorityCode;

	@Column(name="PRIORITY_ID")
	private BigDecimal priorityId;

	@Column(name="PRODUCT_GROUP_ID")
	private BigDecimal productGroupId;

	@Column(name="PRODUCT_ID")
	private BigDecimal productId;

	@Column(name="PRODUCT_NUMBER")
	private BigDecimal productNumber;

	@Column(name="SEND_TOS")
	private String sendTos;

	@Temporal(TemporalType.DATE)
	@Column(name="SERVC_REQUIRED_TILL_DATE")
	private Date servcRequiredTillDate;

	@Temporal(TemporalType.DATE)
	@Column(name="SERVICE_REQUIRED_DATE")
	private Date serviceRequiredDate;

	@Column(name="SPONSOR_FLAG")
	private String sponsorFlag;

	@Column(name="SRT_MISC_CHARGE_ID")
	private BigDecimal srtMiscChargeId;

	@Column(name="TOSS_ACTION")
	private String tossAction;

	@Column(name="TRANSFER_FLAG")
	private String transferFlag;

	@Column(name="TRB_FLAG")
	private String trbFlag;

	@Column(name="WF_ADD_DELETE_STATUS")
	private BigDecimal wfAddDeleteStatus;

	@Column(name="WORK_ORDER_REQUIRED")
	private String workOrderRequired;


	//bi-directional many-to-one association to TAdmMstRegion
	@ManyToOne
	@JoinColumn(name="REGION_ID")
	private TAdmMstRegion TAdmMstRegion;

	//bi-directional many-to-one association to TCmsMstPartySubtype
	@ManyToOne
	@JoinColumn(name="ACCOUNT_CATEGORY")
	private TCmsMstPartySubtype TCmsMstPartySubtype;

	//bi-directional many-to-one association to TSohAccount
	@ManyToOne
	@JoinColumn(name="ACCOUNT_ID")
	private TSohAccount TSohAccount1;

	//bi-directional many-to-one association to TSohAccount
	@ManyToOne
	@JoinColumn(name="NEW_ACCOUNT_ID")
	private TSohAccount TSohAccount2;

	//bi-directional many-to-one association to TSohAccount
	@ManyToOne
	@JoinColumn(name="OWNER_ACCOUNT_ID")
	private TSohAccount TSohAccount3;

	//bi-directional many-to-one association to TSohAccount
	@ManyToOne
	@JoinColumn(name="DEFAULTED_ACCOUNT")
	private TSohAccount TSohAccount4;

	//bi-directional many-to-one association to TSohAccount
	@ManyToOne
	@JoinColumn(name="LINKED_ACCOUNT_ID")
	private TSohAccount TSohAccount5;

	//bi-directional many-to-one association to TSohAccount
	@ManyToOne
	@JoinColumn(name="TRANSFER_ACCOUNT_ID")
	private TSohAccount TSohAccount6;

	//bi-directional many-to-one association to TSohDtlSystemCodeValue
	@ManyToOne
	@JoinColumn(name="STATUS")
	private TSohDtlSystemCodeValue TSohDtlSystemCodeValue1;

	//bi-directional many-to-one association to TSohDtlSystemCodeValue
	@ManyToOne
	@JoinColumn(name="AMEND_CANCEL_REASON")
	private TSohDtlSystemCodeValue TSohDtlSystemCodeValue2;

	//bi-directional many-to-one association to TSohDtlSystemCodeValue
	@ManyToOne
	@JoinColumn(name="REASON_ID")
	private TSohDtlSystemCodeValue TSohDtlSystemCodeValue3;

	//bi-directional many-to-one association to TSohMstSubRequestType
	@ManyToOne
	@JoinColumn(name="SUB_REQUEST_TYPE_ID")
	private TSohMstSubRequestType TSohMstSubRequestType;

	//bi-directional many-to-one association to TSohRequest
	@ManyToOne(cascade = {CascadeType.MERGE, CascadeType.PERSIST})
	@JoinColumn(name="REQUEST_ID")
	private TSohRequest TSohRequest;

	//bi-directional many-to-one association to TSohRequirement
	@ManyToOne
	@JoinColumn(name="REQUIREMENT_ID")
	private TSohRequirement TSohRequirement;

	//bi-directional many-to-one association to TSohSubrequest
	@ManyToOne
	@JoinColumn(name="DEFAULTED_SUBREQUEST")
	private TSohSubrequest TSohSubrequest1;

	//bi-directional many-to-one association to TSohSubrequest
	@OneToMany(mappedBy="TSohSubrequest1")
	private List<TSohSubrequest> TSohSubrequests1;

	//bi-directional many-to-one association to TSohSubrequest
	@ManyToOne
	@JoinColumn(name="DEPENDENT_SUBREQUEST")
	private TSohSubrequest TSohSubrequest2;

	//bi-directional many-to-one association to TSohSubrequest
	@OneToMany(mappedBy="TSohSubrequest2")
	private List<TSohSubrequest> TSohSubrequests2;

	//bi-directional many-to-one association to TSohSubrequest
	@ManyToOne
	@JoinColumn(name="LINKED_SUBREQUEST_ID")
	private TSohSubrequest TSohSubrequest3;

	//bi-directional many-to-one association to TSohSubrequest
	@OneToMany(mappedBy="TSohSubrequest3")
	private List<TSohSubrequest> TSohSubrequests3;

	//bi-directional many-to-one association to TSohSubreqServiceDetail
	@OneToMany(mappedBy="TSohSubrequest", cascade = {CascadeType.MERGE, CascadeType.PERSIST})
	private List<TSohSubreqServiceDetail> TSohSubreqServiceDetails;
	
	@OneToMany(mappedBy="TSohSubrequest", cascade = {CascadeType.MERGE, CascadeType.PERSIST})
	private List<TSohSubreqLinkedInstAddr> TSohSubreqLinkedInstAddrs;
	
	
	@Column(name = "PREQUALIF_WO_REQUIRED")
	private String prequalifWoRequired;

	public TSohSubrequest() {
	}

	public long getSubrequestId() {
		return this.subrequestId;
	}

	public void setSubrequestId(long subrequestId) {
		this.subrequestId = subrequestId;
	}

	public String getAccountNumber() {
		return this.accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public BigDecimal getAccountSuffix() {
		return this.accountSuffix;
	}

	public void setAccountSuffix(BigDecimal accountSuffix) {
		this.accountSuffix = accountSuffix;
	}

	public BigDecimal getAddDeleteStatus() {
		return this.addDeleteStatus;
	}

	public void setAddDeleteStatus(BigDecimal addDeleteStatus) {
		this.addDeleteStatus = addDeleteStatus;
	}

	public BigDecimal getAmendCancelAg() {
		return this.amendCancelAg;
	}

	public void setAmendCancelAg(BigDecimal amendCancelAg) {
		this.amendCancelAg = amendCancelAg;
	}

	public BigDecimal getAmendcancelActionTaken() {
		return this.amendcancelActionTaken;
	}

	public void setAmendcancelActionTaken(BigDecimal amendcancelActionTaken) {
		this.amendcancelActionTaken = amendcancelActionTaken;
	}

	public BigDecimal getAmendmentCount() {
		return this.amendmentCount;
	}

	public void setAmendmentCount(BigDecimal amendmentCount) {
		this.amendmentCount = amendmentCount;
	}

	public String getAreaCode() {
		return this.areaCode;
	}

	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

	public BigDecimal getAssocUpdownSrId() {
		return this.assocUpdownSrId;
	}

	public void setAssocUpdownSrId(BigDecimal assocUpdownSrId) {
		this.assocUpdownSrId = assocUpdownSrId;
	}

	public String getBsRequestFlag() {
		return this.bsRequestFlag;
	}

	public void setBsRequestFlag(String bsRequestFlag) {
		this.bsRequestFlag = bsRequestFlag;
	}

	public BigDecimal getBypassAccountId() {
		return this.bypassAccountId;
	}

	public void setBypassAccountId(BigDecimal bypassAccountId) {
		this.bypassAccountId = bypassAccountId;
	}

	public Date getCancellationDate() {
		return this.cancellationDate;
	}

	public void setCancellationDate(Date cancellationDate) {
		this.cancellationDate = cancellationDate;
	}

	public BigDecimal getCancellationFlag() {
		return this.cancellationFlag;
	}

	public void setCancellationFlag(BigDecimal cancellationFlag) {
		this.cancellationFlag = cancellationFlag;
	}

	public String getCdmsRefNo() {
		return this.cdmsRefNo;
	}

	public void setCdmsRefNo(String cdmsRefNo) {
		this.cdmsRefNo = cdmsRefNo;
	}

	public BigDecimal getCessationReasonId() {
		return this.cessationReasonId;
	}

	public void setCessationReasonId(BigDecimal cessationReasonId) {
		this.cessationReasonId = cessationReasonId;
	}

	public Date getCessationRequiredDate() {
		return this.cessationRequiredDate;
	}

	public void setCessationRequiredDate(Date cessationRequiredDate) {
		this.cessationRequiredDate = cessationRequiredDate;
	}

	public String getCircuitPoint() {
		return this.circuitPoint;
	}

	public void setCircuitPoint(String circuitPoint) {
		this.circuitPoint = circuitPoint;
	}

	public Date getClosedDate() {
		return this.closedDate;
	}

	public void setClosedDate(Date closedDate) {
		this.closedDate = closedDate;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public BigDecimal getDepositAmt() {
		return this.depositAmt;
	}

	public void setDepositAmt(BigDecimal depositAmt) {
		this.depositAmt = depositAmt;
	}

	public BigDecimal getDepositPaid() {
		return this.depositPaid;
	}

	public void setDepositPaid(BigDecimal depositPaid) {
		this.depositPaid = depositPaid;
	}

	public BigDecimal getDistributionIndx() {
		return this.distributionIndx;
	}

	public void setDistributionIndx(BigDecimal distributionIndx) {
		this.distributionIndx = distributionIndx;
	}

	public String getDpChanged() {
		return this.dpChanged;
	}

	public void setDpChanged(String dpChanged) {
		this.dpChanged = dpChanged;
	}

	public BigDecimal getEmirateId() {
		return this.emirateId;
	}

	public void setEmirateId(BigDecimal emirateId) {
		this.emirateId = emirateId;
	}

	public String getFaxFlag() {
		return this.faxFlag;
	}

	public void setFaxFlag(String faxFlag) {
		this.faxFlag = faxFlag;
	}

	public BigDecimal getInPreviousBalance() {
		return this.inPreviousBalance;
	}

	public void setInPreviousBalance(BigDecimal inPreviousBalance) {
		this.inPreviousBalance = inPreviousBalance;
	}

	public Timestamp getInstallationDate() {
		return this.installationDate;
	}

	public void setInstallationDate(Timestamp installationDate) {
		this.installationDate = installationDate;
	}

	public String getMdfChanged() {
		return this.mdfChanged;
	}

	public void setMdfChanged(String mdfChanged) {
		this.mdfChanged = mdfChanged;
	}

	public BigDecimal getMiscChargeType() {
		return this.miscChargeType;
	}

	public void setMiscChargeType(BigDecimal miscChargeType) {
		this.miscChargeType = miscChargeType;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getMsgReq() {
		return this.msgReq;
	}

	public void setMsgReq(String msgReq) {
		this.msgReq = msgReq;
	}

	public String getMsoFlag() {
		return this.msoFlag;
	}

	public void setMsoFlag(String msoFlag) {
		this.msoFlag = msoFlag;
	}

	public BigDecimal getNewAccountCategory() {
		return this.newAccountCategory;
	}

	public void setNewAccountCategory(BigDecimal newAccountCategory) {
		this.newAccountCategory = newAccountCategory;
	}

	public String getNotes() {
		return this.notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getNumChgReqdFlag() {
		return this.numChgReqdFlag;
	}

	public void setNumChgReqdFlag(String numChgReqdFlag) {
		this.numChgReqdFlag = numChgReqdFlag;
	}

	public Date getOldSrvcReqdDate() {
		return this.oldSrvcReqdDate;
	}

	public void setOldSrvcReqdDate(Date oldSrvcReqdDate) {
		this.oldSrvcReqdDate = oldSrvcReqdDate;
	}

	public String getOthRoutePoint() {
		return this.othRoutePoint;
	}

	public void setOthRoutePoint(String othRoutePoint) {
		this.othRoutePoint = othRoutePoint;
	}

	public BigDecimal getPrepaymentAmt() {
		return this.prepaymentAmt;
	}

	public void setPrepaymentAmt(BigDecimal prepaymentAmt) {
		this.prepaymentAmt = prepaymentAmt;
	}

	public BigDecimal getPrepaymentPaid() {
		return this.prepaymentPaid;
	}

	public void setPrepaymentPaid(BigDecimal prepaymentPaid) {
		this.prepaymentPaid = prepaymentPaid;
	}

	public BigDecimal getPriority() {
		return this.priority;
	}

	public void setPriority(BigDecimal priority) {
		this.priority = priority;
	}

	public String getPriorityCode() {
		return this.priorityCode;
	}

	public void setPriorityCode(String priorityCode) {
		this.priorityCode = priorityCode;
	}

	public BigDecimal getPriorityId() {
		return this.priorityId;
	}

	public void setPriorityId(BigDecimal priorityId) {
		this.priorityId = priorityId;
	}

	public BigDecimal getProductGroupId() {
		return this.productGroupId;
	}

	public void setProductGroupId(BigDecimal productGroupId) {
		this.productGroupId = productGroupId;
	}

	public BigDecimal getProductId() {
		return this.productId;
	}

	public void setProductId(BigDecimal productId) {
		this.productId = productId;
	}

	public BigDecimal getProductNumber() {
		return this.productNumber;
	}

	public void setProductNumber(BigDecimal productNumber) {
		this.productNumber = productNumber;
	}

	public String getSendTos() {
		return this.sendTos;
	}

	public void setSendTos(String sendTos) {
		this.sendTos = sendTos;
	}

	public Date getServcRequiredTillDate() {
		return this.servcRequiredTillDate;
	}

	public void setServcRequiredTillDate(Date servcRequiredTillDate) {
		this.servcRequiredTillDate = servcRequiredTillDate;
	}

	public Date getServiceRequiredDate() {
		return this.serviceRequiredDate;
	}

	public void setServiceRequiredDate(Date serviceRequiredDate) {
		this.serviceRequiredDate = serviceRequiredDate;
	}

	public String getSponsorFlag() {
		return this.sponsorFlag;
	}

	public void setSponsorFlag(String sponsorFlag) {
		this.sponsorFlag = sponsorFlag;
	}

	public BigDecimal getSrtMiscChargeId() {
		return this.srtMiscChargeId;
	}

	public void setSrtMiscChargeId(BigDecimal srtMiscChargeId) {
		this.srtMiscChargeId = srtMiscChargeId;
	}

	public String getTossAction() {
		return this.tossAction;
	}

	public void setTossAction(String tossAction) {
		this.tossAction = tossAction;
	}

	public String getTransferFlag() {
		return this.transferFlag;
	}

	public void setTransferFlag(String transferFlag) {
		this.transferFlag = transferFlag;
	}

	public String getTrbFlag() {
		return this.trbFlag;
	}

	public void setTrbFlag(String trbFlag) {
		this.trbFlag = trbFlag;
	}

	public BigDecimal getWfAddDeleteStatus() {
		return this.wfAddDeleteStatus;
	}

	public void setWfAddDeleteStatus(BigDecimal wfAddDeleteStatus) {
		this.wfAddDeleteStatus = wfAddDeleteStatus;
	}

	public String getWorkOrderRequired() {
		return this.workOrderRequired;
	}

	public void setWorkOrderRequired(String workOrderRequired) {
		this.workOrderRequired = workOrderRequired;
	}

	public TAdmMstRegion getTAdmMstRegion() {
		return this.TAdmMstRegion;
	}

	public void setTAdmMstRegion(TAdmMstRegion TAdmMstRegion) {
		this.TAdmMstRegion = TAdmMstRegion;
	}

	public TCmsMstPartySubtype getTCmsMstPartySubtype() {
		return this.TCmsMstPartySubtype;
	}

	public void setTCmsMstPartySubtype(TCmsMstPartySubtype TCmsMstPartySubtype) {
		this.TCmsMstPartySubtype = TCmsMstPartySubtype;
	}

	public TSohAccount getTSohAccount1() {
		return this.TSohAccount1;
	}

	public void setTSohAccount1(TSohAccount TSohAccount1) {
		this.TSohAccount1 = TSohAccount1;
	}

	public TSohAccount getTSohAccount2() {
		return this.TSohAccount2;
	}

	public void setTSohAccount2(TSohAccount TSohAccount2) {
		this.TSohAccount2 = TSohAccount2;
	}

	public TSohAccount getTSohAccount3() {
		return this.TSohAccount3;
	}

	public void setTSohAccount3(TSohAccount TSohAccount3) {
		this.TSohAccount3 = TSohAccount3;
	}

	public TSohAccount getTSohAccount4() {
		return this.TSohAccount4;
	}

	public void setTSohAccount4(TSohAccount TSohAccount4) {
		this.TSohAccount4 = TSohAccount4;
	}

	public TSohAccount getTSohAccount5() {
		return this.TSohAccount5;
	}

	public void setTSohAccount5(TSohAccount TSohAccount5) {
		this.TSohAccount5 = TSohAccount5;
	}

	public TSohAccount getTSohAccount6() {
		return this.TSohAccount6;
	}

	public void setTSohAccount6(TSohAccount TSohAccount6) {
		this.TSohAccount6 = TSohAccount6;
	}

	public TSohDtlSystemCodeValue getTSohDtlSystemCodeValue1() {
		return this.TSohDtlSystemCodeValue1;
	}

	public void setTSohDtlSystemCodeValue1(TSohDtlSystemCodeValue TSohDtlSystemCodeValue1) {
		this.TSohDtlSystemCodeValue1 = TSohDtlSystemCodeValue1;
	}

	public TSohDtlSystemCodeValue getTSohDtlSystemCodeValue2() {
		return this.TSohDtlSystemCodeValue2;
	}

	public void setTSohDtlSystemCodeValue2(TSohDtlSystemCodeValue TSohDtlSystemCodeValue2) {
		this.TSohDtlSystemCodeValue2 = TSohDtlSystemCodeValue2;
	}

	public TSohDtlSystemCodeValue getTSohDtlSystemCodeValue3() {
		return this.TSohDtlSystemCodeValue3;
	}

	public void setTSohDtlSystemCodeValue3(TSohDtlSystemCodeValue TSohDtlSystemCodeValue3) {
		this.TSohDtlSystemCodeValue3 = TSohDtlSystemCodeValue3;
	}

	public TSohMstSubRequestType getTSohMstSubRequestType() {
		return this.TSohMstSubRequestType;
	}

	public void setTSohMstSubRequestType(TSohMstSubRequestType TSohMstSubRequestType) {
		this.TSohMstSubRequestType = TSohMstSubRequestType;
	}

	public TSohRequest getTSohRequest() {
		return this.TSohRequest;
	}

	public void setTSohRequest(TSohRequest TSohRequest) {
		this.TSohRequest = TSohRequest;
	}

	public TSohRequirement getTSohRequirement() {
		return this.TSohRequirement;
	}

	public void setTSohRequirement(TSohRequirement TSohRequirement) {
		this.TSohRequirement = TSohRequirement;
	}

	public TSohSubrequest getTSohSubrequest1() {
		return this.TSohSubrequest1;
	}

	public void setTSohSubrequest1(TSohSubrequest TSohSubrequest1) {
		this.TSohSubrequest1 = TSohSubrequest1;
	}

	public List<TSohSubrequest> getTSohSubrequests1() {
		return this.TSohSubrequests1;
	}

	public void setTSohSubrequests1(List<TSohSubrequest> TSohSubrequests1) {
		this.TSohSubrequests1 = TSohSubrequests1;
	}

	public TSohSubrequest addTSohSubrequests1(TSohSubrequest TSohSubrequests1) {
		getTSohSubrequests1().add(TSohSubrequests1);
		TSohSubrequests1.setTSohSubrequest1(this);

		return TSohSubrequests1;
	}

	public TSohSubrequest removeTSohSubrequests1(TSohSubrequest TSohSubrequests1) {
		getTSohSubrequests1().remove(TSohSubrequests1);
		TSohSubrequests1.setTSohSubrequest1(null);

		return TSohSubrequests1;
	}

	public TSohSubrequest getTSohSubrequest2() {
		return this.TSohSubrequest2;
	}

	public void setTSohSubrequest2(TSohSubrequest TSohSubrequest2) {
		this.TSohSubrequest2 = TSohSubrequest2;
	}

	public List<TSohSubrequest> getTSohSubrequests2() {
		return this.TSohSubrequests2;
	}

	public void setTSohSubrequests2(List<TSohSubrequest> TSohSubrequests2) {
		this.TSohSubrequests2 = TSohSubrequests2;
	}

	public TSohSubrequest addTSohSubrequests2(TSohSubrequest TSohSubrequests2) {
		getTSohSubrequests2().add(TSohSubrequests2);
		TSohSubrequests2.setTSohSubrequest2(this);

		return TSohSubrequests2;
	}

	public TSohSubrequest removeTSohSubrequests2(TSohSubrequest TSohSubrequests2) {
		getTSohSubrequests2().remove(TSohSubrequests2);
		TSohSubrequests2.setTSohSubrequest2(null);

		return TSohSubrequests2;
	}

	public TSohSubrequest getTSohSubrequest3() {
		return this.TSohSubrequest3;
	}

	public void setTSohSubrequest3(TSohSubrequest TSohSubrequest3) {
		this.TSohSubrequest3 = TSohSubrequest3;
	}

	public List<TSohSubrequest> getTSohSubrequests3() {
		return this.TSohSubrequests3;
	}

	public void setTSohSubrequests3(List<TSohSubrequest> TSohSubrequests3) {
		this.TSohSubrequests3 = TSohSubrequests3;
	}

	public TSohSubrequest addTSohSubrequests3(TSohSubrequest TSohSubrequests3) {
		getTSohSubrequests3().add(TSohSubrequests3);
		TSohSubrequests3.setTSohSubrequest3(this);

		return TSohSubrequests3;
	}

	public TSohSubrequest removeTSohSubrequests3(TSohSubrequest TSohSubrequests3) {
		getTSohSubrequests3().remove(TSohSubrequests3);
		TSohSubrequests3.setTSohSubrequest3(null);

		return TSohSubrequests3;
	}

	public List<TSohSubreqServiceDetail> getTSohSubreqServiceDetails() {
		return this.TSohSubreqServiceDetails;
	}

	public void setTSohSubreqServiceDetails(List<TSohSubreqServiceDetail> TSohSubreqServiceDetails) {
		this.TSohSubreqServiceDetails = TSohSubreqServiceDetails;
	}

	public TSohSubreqServiceDetail addTSohSubreqServiceDetail(TSohSubreqServiceDetail TSohSubreqServiceDetail) {
		getTSohSubreqServiceDetails().add(TSohSubreqServiceDetail);
		TSohSubreqServiceDetail.setTSohSubrequest(this);

		return TSohSubreqServiceDetail;
	}

	public TSohSubreqServiceDetail removeTSohSubreqServiceDetail(TSohSubreqServiceDetail TSohSubreqServiceDetail) {
		getTSohSubreqServiceDetails().remove(TSohSubreqServiceDetail);
		TSohSubreqServiceDetail.setTSohSubrequest(null);

		return TSohSubreqServiceDetail;
	}
	
	public String getPrequalifWoRequired() {
		return prequalifWoRequired;
	}

	public void setPrequalifWoRequired(String prequalifWoRequired) {
		this.prequalifWoRequired = prequalifWoRequired;
	}
	
	public List<TSohSubreqLinkedInstAddr> getTSohSubreqLinkedInstAddrs() {
		return this.TSohSubreqLinkedInstAddrs;
	}

	public void setTSohSubreqLinkedInstAddrs(List<TSohSubreqLinkedInstAddr> TSohSubreqLinkedInstAddrs) {
		this.TSohSubreqLinkedInstAddrs = TSohSubreqLinkedInstAddrs;
	}
	
	public String toString(){
		return String.format("[SubRequestID:%s]",subrequestId);
	}
}