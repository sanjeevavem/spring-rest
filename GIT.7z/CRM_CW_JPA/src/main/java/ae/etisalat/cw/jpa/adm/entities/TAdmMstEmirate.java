package ae.etisalat.cw.jpa.adm.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the T_ADM_MST_EMIRATE database table.
 * 
 */
@Entity
@Table(name="T_ADM_MST_EMIRATE")
@NamedQuery(name="TAdmMstEmirate.findAll", query="SELECT t FROM TAdmMstEmirate t")
public class TAdmMstEmirate implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_ADM_MST_EMIRATE_EMIRATEID_GENERATOR", sequenceName="SQ_T_ADM_MST_EMIRATE")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_ADM_MST_EMIRATE_EMIRATEID_GENERATOR")
	@Column(name="EMIRATE_ID")
	private long emirateId;

	@Column(name="ARABIC_NAME")
	private String arabicName;

	private String code;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	private String description;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	private String name;

	@Column(name="REGION_ID")
	private java.math.BigDecimal regionId;

	public TAdmMstEmirate() {
	}

	public long getEmirateId() {
		return this.emirateId;
	}

	public void setEmirateId(long emirateId) {
		this.emirateId = emirateId;
	}

	public String getArabicName() {
		return this.arabicName;
	}

	public void setArabicName(String arabicName) {
		this.arabicName = arabicName;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public java.math.BigDecimal getRegionId() {
		return this.regionId;
	}

	public void setRegionId(java.math.BigDecimal regionId) {
		this.regionId = regionId;
	}

}