package ae.etisalat.cw.jpa.adm.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;


/**
 * The persistent class for the T_ADM_MST_CURRENCY database table.
 * 
 */
@Entity
@Table(name="T_ADM_MST_CURRENCY")
@NamedQuery(name="TAdmMstCurrency.findAll", query="SELECT t FROM TAdmMstCurrency t")
public class TAdmMstCurrency implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="CURRENCY_ID")
	private long currencyId;

	private String code;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="CURRENCY_SYMBOL")
	private String currencySymbol;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="DIGIT_GROUPING")
	private String digitGrouping;

	@Column(name="IS_SYSTEM_CURRENCY")
	private BigDecimal isSystemCurrency;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	private String name;

	@Column(name="NO_OFDIG_AFTER_DECIMAL")
	private BigDecimal noOfdigAfterDecimal;

	public TAdmMstCurrency() {
	}

	public long getCurrencyId() {
		return this.currencyId;
	}

	public void setCurrencyId(long currencyId) {
		this.currencyId = currencyId;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getCurrencySymbol() {
		return this.currencySymbol;
	}

	public void setCurrencySymbol(String currencySymbol) {
		this.currencySymbol = currencySymbol;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public String getDigitGrouping() {
		return this.digitGrouping;
	}

	public void setDigitGrouping(String digitGrouping) {
		this.digitGrouping = digitGrouping;
	}

	public BigDecimal getIsSystemCurrency() {
		return this.isSystemCurrency;
	}

	public void setIsSystemCurrency(BigDecimal isSystemCurrency) {
		this.isSystemCurrency = isSystemCurrency;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigDecimal getNoOfdigAfterDecimal() {
		return this.noOfdigAfterDecimal;
	}

	public void setNoOfdigAfterDecimal(BigDecimal noOfdigAfterDecimal) {
		this.noOfdigAfterDecimal = noOfdigAfterDecimal;
	}

}