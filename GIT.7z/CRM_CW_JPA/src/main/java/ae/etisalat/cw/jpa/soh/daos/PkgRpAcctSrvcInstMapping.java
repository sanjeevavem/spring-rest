package ae.etisalat.cw.jpa.soh.daos;

import java.io.Serializable;
import java.util.List;

public class PkgRpAcctSrvcInstMapping  implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String packageCode;
	private String ratePlanCode;
	private Long ratePlanId;
	private Long packageId;
	private Long srvcId;
	private Long srvcCategoryId;
	private Long acctSrvcId;
	private List<Long> acctSrvcInstanceId;
	private String quantity;
	private Long subReqSrvcId;
	private List<Long> subReqSrvcInstanceId;
	
	PkgRpAcctSrvcInstMapping(){
		
	}

	public PkgRpAcctSrvcInstMapping(String packageCode, String ratePlanCode, Long ratePlanId, Long packageId,
			Long srvcId, Long srvcCategoryId, Long acctSrvcId, List<Long> acctSrvcInstanceId, String quantity,
			Long subReqSrvcId, List<Long> subReqSrvcInstanceId) {
		super();
		this.packageCode = packageCode;
		this.ratePlanCode = ratePlanCode;
		this.ratePlanId = ratePlanId;
		this.packageId = packageId;
		this.srvcId = srvcId;
		this.srvcCategoryId = srvcCategoryId;
		this.acctSrvcId = acctSrvcId;
		this.acctSrvcInstanceId = acctSrvcInstanceId;
		this.quantity = quantity;
		this.subReqSrvcId = subReqSrvcId;
		this.subReqSrvcInstanceId = subReqSrvcInstanceId;
	}

	public String getPackageCode() {
		return packageCode;
	}
	public void setPackageCode(String packageCode) {
		this.packageCode = packageCode;
	}
	public String getRatePlanCode() {
		return ratePlanCode;
	}
	public void setRatePlanCode(String ratePlanCode) {
		this.ratePlanCode = ratePlanCode;
	}
	public Long getRatePlanId() {
		return ratePlanId;
	}
	public void setRatePlanId(Long ratePlanId) {
		this.ratePlanId = ratePlanId;
	}
	public Long getPackageId() {
		return packageId;
	}
	public void setPackageId(Long packageId) {
		this.packageId = packageId;
	}
	public Long getSrvcId() {
		return srvcId;
	}
	public void setSrvcId(Long srvcId) {
		this.srvcId = srvcId;
	}
	public Long getSrvcCategoryId() {
		return srvcCategoryId;
	}
	public void setSrvcCategoryId(Long srvcCategoryId) {
		this.srvcCategoryId = srvcCategoryId;
	}
	public Long getAcctSrvcId() {
		return acctSrvcId;
	}
	public void setAcctSrvcId(Long acctSrvcId) {
		this.acctSrvcId = acctSrvcId;
	}	
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public List<Long> getAcctSrvcInstanceId() {
		return acctSrvcInstanceId;
	}

	public void setAcctSrvcInstanceId(List<Long> acctSrvcInstanceId) {
		this.acctSrvcInstanceId = acctSrvcInstanceId;
	}

	public Long getSubReqSrvcId() {
		return subReqSrvcId;
	}

	public void setSubReqSrvcId(Long subReqSrvcId) {
		this.subReqSrvcId = subReqSrvcId;
	}

	public List<Long> getSubReqSrvcInstanceId() {
		return subReqSrvcInstanceId;
	}

	public void setSubReqSrvcInstanceId(List<Long> subReqSrvcInstanceId) {
		this.subReqSrvcInstanceId = subReqSrvcInstanceId;
	}
	
}
