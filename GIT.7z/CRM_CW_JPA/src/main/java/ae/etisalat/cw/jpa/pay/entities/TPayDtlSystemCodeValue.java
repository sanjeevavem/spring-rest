package ae.etisalat.cw.jpa.pay.entities;

import java.io.Serializable;

import javax.persistence.*;

import java.sql.Timestamp;
import java.math.BigDecimal;


/**
 * The persistent class for the T_PAY_DTL_SYSTEM_CODE_VALUES database table.
 * 
 */
@Entity
@Table(name="T_PAY_DTL_SYSTEM_CODE_VALUES")
@NamedQuery(name="TPayDtlSystemCodeValue.findAll", query="SELECT t FROM TPayDtlSystemCodeValue t")
public class TPayDtlSystemCodeValue implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="SYSTEM_CODE_VALUE_ID")
	private BigDecimal systemCodeValueId;
	
	
	private String code;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="SYSTEM_CODE_ID")
	private BigDecimal systemCodeId;

	//@Column(name="SYSTEM_CODE_VALUE_ID")
	//private BigDecimal systemCodeValueId;

	@Column(name="\"VALUE\"")
	private String value;

	public TPayDtlSystemCodeValue() {
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getSystemCodeId() {
		return this.systemCodeId;
	}

	public void setSystemCodeId(BigDecimal systemCodeId) {
		this.systemCodeId = systemCodeId;
	}

	public BigDecimal getSystemCodeValueId() {
		return this.systemCodeValueId;
	}

	public void setSystemCodeValueId(BigDecimal systemCodeValueId) {
		this.systemCodeValueId = systemCodeValueId;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}