package ae.etisalat.cw.jpa.psm.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;


/**
 * The persistent class for the T_PSM_DTL_PACKAGE database table.
 * 
 */
@Entity
@Table(name="T_PSM_DTL_PACKAGE")
@NamedQuery(name="TPsmDtlPackage.findAll", query="SELECT t FROM TPsmDtlPackage t")
public class TPsmDtlPackage implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="RATE_PLAN_DETAILS_ID")
	private long ratePlanDetailsId;

	@Column(name="ACCOUNT_CATEGORY_FLAG")
	private BigDecimal accountCategoryFlag;

	@Column(name="ACCOUNT_REGION_FLAG")
	private BigDecimal accountRegionFlag;

	@Column(name="COMPANY_TYPE_FLAG")
	private BigDecimal companyTypeFlag;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="EFFECTIVE_FROM_DATE")
	private Timestamp effectiveFromDate;

	@Column(name="EMIRATE_FLAG")
	private BigDecimal emirateFlag;

	@Column(name="INDUSTRY_TYPE_FLAG")
	private BigDecimal industryTypeFlag;

	@Column(name="MARKET_SEGMENT_FLAG")
	private BigDecimal marketSegmentFlag;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="NATIONALITY_FLAG")
	private BigDecimal nationalityFlag;

	@Column(name="PARTY_AGE_FLAG")
	private BigDecimal partyAgeFlag;

	@Column(name="PARTY_NAME_FLAG")
	private BigDecimal partyNameFlag;

	@Column(name="PARTY_SUBTYPE_FLAG")
	private BigDecimal partySubtypeFlag;

	@Column(name="PARTY_TYPE_FLAG")
	private BigDecimal partyTypeFlag;

	@Column(name="PREPAYMENT_AMOUNT")
	private BigDecimal prepaymentAmount;

	@Column(name="PROFESSION_FLAG")
	private BigDecimal professionFlag;

	@Column(name="RATE_PLAN_ID")
	private BigDecimal ratePlanId;

	//bi-directional many-to-one association to TPsmMstPackage
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="PACKAGE_ID", referencedColumnName="PACKAGE_ID"),
		@JoinColumn(name="RP_EFFECTIVE_FROM_DATE", referencedColumnName="EFFECTIVE_FROM_DATE")
		})
	private TPsmMstPackage TPsmMstPackage;

	public TPsmDtlPackage() {
	}

	public long getRatePlanDetailsId() {
		return this.ratePlanDetailsId;
	}

	public void setRatePlanDetailsId(long ratePlanDetailsId) {
		this.ratePlanDetailsId = ratePlanDetailsId;
	}

	public BigDecimal getAccountCategoryFlag() {
		return this.accountCategoryFlag;
	}

	public void setAccountCategoryFlag(BigDecimal accountCategoryFlag) {
		this.accountCategoryFlag = accountCategoryFlag;
	}

	public BigDecimal getAccountRegionFlag() {
		return this.accountRegionFlag;
	}

	public void setAccountRegionFlag(BigDecimal accountRegionFlag) {
		this.accountRegionFlag = accountRegionFlag;
	}

	public BigDecimal getCompanyTypeFlag() {
		return this.companyTypeFlag;
	}

	public void setCompanyTypeFlag(BigDecimal companyTypeFlag) {
		this.companyTypeFlag = companyTypeFlag;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getEffectiveFromDate() {
		return this.effectiveFromDate;
	}

	public void setEffectiveFromDate(Timestamp effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}

	public BigDecimal getEmirateFlag() {
		return this.emirateFlag;
	}

	public void setEmirateFlag(BigDecimal emirateFlag) {
		this.emirateFlag = emirateFlag;
	}

	public BigDecimal getIndustryTypeFlag() {
		return this.industryTypeFlag;
	}

	public void setIndustryTypeFlag(BigDecimal industryTypeFlag) {
		this.industryTypeFlag = industryTypeFlag;
	}

	public BigDecimal getMarketSegmentFlag() {
		return this.marketSegmentFlag;
	}

	public void setMarketSegmentFlag(BigDecimal marketSegmentFlag) {
		this.marketSegmentFlag = marketSegmentFlag;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getNationalityFlag() {
		return this.nationalityFlag;
	}

	public void setNationalityFlag(BigDecimal nationalityFlag) {
		this.nationalityFlag = nationalityFlag;
	}

	public BigDecimal getPartyAgeFlag() {
		return this.partyAgeFlag;
	}

	public void setPartyAgeFlag(BigDecimal partyAgeFlag) {
		this.partyAgeFlag = partyAgeFlag;
	}

	public BigDecimal getPartyNameFlag() {
		return this.partyNameFlag;
	}

	public void setPartyNameFlag(BigDecimal partyNameFlag) {
		this.partyNameFlag = partyNameFlag;
	}

	public BigDecimal getPartySubtypeFlag() {
		return this.partySubtypeFlag;
	}

	public void setPartySubtypeFlag(BigDecimal partySubtypeFlag) {
		this.partySubtypeFlag = partySubtypeFlag;
	}

	public BigDecimal getPartyTypeFlag() {
		return this.partyTypeFlag;
	}

	public void setPartyTypeFlag(BigDecimal partyTypeFlag) {
		this.partyTypeFlag = partyTypeFlag;
	}

	public BigDecimal getPrepaymentAmount() {
		return this.prepaymentAmount;
	}

	public void setPrepaymentAmount(BigDecimal prepaymentAmount) {
		this.prepaymentAmount = prepaymentAmount;
	}

	public BigDecimal getProfessionFlag() {
		return this.professionFlag;
	}

	public void setProfessionFlag(BigDecimal professionFlag) {
		this.professionFlag = professionFlag;
	}

	public BigDecimal getRatePlanId() {
		return this.ratePlanId;
	}

	public void setRatePlanId(BigDecimal ratePlanId) {
		this.ratePlanId = ratePlanId;
	}

	@Override
	public String toString() {
		return "TPsmDtlPackage [ratePlanDetailsId=" + ratePlanDetailsId + ", effectiveFromDate=" + effectiveFromDate
				+ ", prepaymentAmount=" + prepaymentAmount + ", ratePlanId=" + ratePlanId + ", TPsmMstPackage=" + TPsmMstPackage + "]";
	}

	public TPsmMstPackage getTPsmMstPackage() {
		return this.TPsmMstPackage;
	}

	public void setTPsmMstPackage(TPsmMstPackage TPsmMstPackage) {
		this.TPsmMstPackage = TPsmMstPackage;
	}

}