package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the T_SOH_MST_SUB_REQUEST_TYPE database table.
 * 
 */
@Entity
@Table(name="T_SOH_MST_SUB_REQUEST_TYPE")
@NamedQueries(value = { @NamedQuery(name="TSohMstSubRequestType.findAll", query="SELECT t FROM TSohMstSubRequestType t"),
@NamedQuery(name = "TSohMstSubRequestType.findbytypeCode", query = "SELECT p FROM TSohMstSubRequestType p where p.subRequestTypeCode = :subRequestTypeCode and p.deletionStatus='N'")})
public class TSohMstSubRequestType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_SOH_MST_SUB_REQUEST_TYPE_SUBREQUESTTYPEID_GENERATOR", sequenceName="SQ_T_SOH_MST_SUB_REQUEST_TYPE",allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_SOH_MST_SUB_REQUEST_TYPE_SUBREQUESTTYPEID_GENERATOR")
	@Column(name="SUB_REQUEST_TYPE_ID")
	private long subRequestTypeId;

	@Column(name="AMENDMENT_ALLOWED_FLAG")
	private BigDecimal amendmentAllowedFlag;

	@Column(name="CANCEL_MISC_SERVC")
	private BigDecimal cancelMiscServc;

	@Column(name="CATEGORY")
	private String category;

	@Column(name="COLLECT_ADVANCE")
	private String collectAdvance;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="DESCRIPTION")
	private String description;

	@Column(name="ECD_REQ_TYPE_ID")
	private BigDecimal ecdReqTypeId;

	@Temporal(TemporalType.DATE)
	@Column(name="EFF_FROM_DATE")
	private Date effFromDate;

	@Temporal(TemporalType.DATE)
	@Column(name="EFF_TILL_DATE")
	private Date effTillDate;

	@Column(name="IS_SERVC_SPECIFIC")
	private String isServcSpecific;

	@Column(name="LEVEL_FLAG")
	private String levelFlag;

	@Column(name="LIMITED_ACCESS_FLAG")
	private String limitedAccessFlag;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="REGN_MISC_SERVC")
	private BigDecimal regnMiscServc;

	@Column(name="REQUEST_TYPE_ID")
	private BigDecimal requestTypeId;

	@Column(name="REQUIRMENT_INDICATOR")
	private String requirmentIndicator;

	@Column(name="SERVICE_ADD_INDICATOR")
	private BigDecimal serviceAddIndicator;

	@Column(name="SHOW_FLAG")
	private BigDecimal showFlag;

	@Column(name="STATUS")
	private String status;

	@Column(name="SUB_REQUEST_TYPE_CODE")
	private String subRequestTypeCode;

	@Column(name="SUBREQUEST_TYPE_MAP")
	private BigDecimal subrequestTypeMap;

	@Column(name="VALIDATION_API")
	private BigDecimal validationApi;

	public TSohMstSubRequestType() {
	}

	public long getSubRequestTypeId() {
		return this.subRequestTypeId;
	}

	public void setSubRequestTypeId(long subRequestTypeId) {
		this.subRequestTypeId = subRequestTypeId;
	}

	public BigDecimal getAmendmentAllowedFlag() {
		return this.amendmentAllowedFlag;
	}

	public void setAmendmentAllowedFlag(BigDecimal amendmentAllowedFlag) {
		this.amendmentAllowedFlag = amendmentAllowedFlag;
	}

	public BigDecimal getCancelMiscServc() {
		return this.cancelMiscServc;
	}

	public void setCancelMiscServc(BigDecimal cancelMiscServc) {
		this.cancelMiscServc = cancelMiscServc;
	}

	public String getCategory() {
		return this.category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getCollectAdvance() {
		return this.collectAdvance;
	}

	public void setCollectAdvance(String collectAdvance) {
		this.collectAdvance = collectAdvance;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getEcdReqTypeId() {
		return this.ecdReqTypeId;
	}

	public void setEcdReqTypeId(BigDecimal ecdReqTypeId) {
		this.ecdReqTypeId = ecdReqTypeId;
	}

	public Date getEffFromDate() {
		return this.effFromDate;
	}

	public void setEffFromDate(Date effFromDate) {
		this.effFromDate = effFromDate;
	}

	public Date getEffTillDate() {
		return this.effTillDate;
	}

	public void setEffTillDate(Date effTillDate) {
		this.effTillDate = effTillDate;
	}

	public String getIsServcSpecific() {
		return this.isServcSpecific;
	}

	public void setIsServcSpecific(String isServcSpecific) {
		this.isServcSpecific = isServcSpecific;
	}

	public String getLevelFlag() {
		return this.levelFlag;
	}

	public void setLevelFlag(String levelFlag) {
		this.levelFlag = levelFlag;
	}

	public String getLimitedAccessFlag() {
		return this.limitedAccessFlag;
	}

	public void setLimitedAccessFlag(String limitedAccessFlag) {
		this.limitedAccessFlag = limitedAccessFlag;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getRegnMiscServc() {
		return this.regnMiscServc;
	}

	public void setRegnMiscServc(BigDecimal regnMiscServc) {
		this.regnMiscServc = regnMiscServc;
	}

	public BigDecimal getRequestTypeId() {
		return this.requestTypeId;
	}

	public void setRequestTypeId(BigDecimal requestTypeId) {
		this.requestTypeId = requestTypeId;
	}

	public String getRequirmentIndicator() {
		return this.requirmentIndicator;
	}

	public void setRequirmentIndicator(String requirmentIndicator) {
		this.requirmentIndicator = requirmentIndicator;
	}

	public BigDecimal getServiceAddIndicator() {
		return this.serviceAddIndicator;
	}

	public void setServiceAddIndicator(BigDecimal serviceAddIndicator) {
		this.serviceAddIndicator = serviceAddIndicator;
	}

	public BigDecimal getShowFlag() {
		return this.showFlag;
	}

	public void setShowFlag(BigDecimal showFlag) {
		this.showFlag = showFlag;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSubRequestTypeCode() {
		return this.subRequestTypeCode;
	}

	public void setSubRequestTypeCode(String subRequestTypeCode) {
		this.subRequestTypeCode = subRequestTypeCode;
	}

	public BigDecimal getSubrequestTypeMap() {
		return this.subrequestTypeMap;
	}

	public void setSubrequestTypeMap(BigDecimal subrequestTypeMap) {
		this.subrequestTypeMap = subrequestTypeMap;
	}

	public BigDecimal getValidationApi() {
		return this.validationApi;
	}

	public void setValidationApi(BigDecimal validationApi) {
		this.validationApi = validationApi;
	}

}