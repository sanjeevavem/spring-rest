package ae.etisalat.cw.jpa.soh.daos;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import ae.etisalat.cw.jpa.soh.entities.TSohAccount;
import ae.etisalat.cw.jpa.soh.entities.TSohDtlAccountInvoiceInfo;
import ae.etisalat.cw.jpa.soh.entities.TSohDtlAcctInvAttrInfo;
import ae.etisalat.cw.jpa.soh.entities.TSohMstAccountInvoiceInfo;
import ae.etisalat.cw.restws.clients.InvoiceDetails;

@Repository
@Transactional
public class AccountInvoiceInfoDao {
	
	private static final Logger logger = LogManager.getLogger(AccountInvoiceInfoDao.class);
	
	@PersistenceContext
    private EntityManager em;
	
	public boolean processInvoiceInfo(TSohAccount account, long subrequestId,InvoiceDetails invoiceDetails) {
		TSohMstAccountInvoiceInfo TSohMstAccountInvoiceInfo = null;
		try {			
			TSohMstAccountInvoiceInfo = createMstInvoice(invoiceDetails,account);
			if (TSohMstAccountInvoiceInfo.getAccInvoiceId() > 0) {
				createDtlInvoice(TSohMstAccountInvoiceInfo, account, subrequestId);
				createDtlAttrInvoice(TSohMstAccountInvoiceInfo, account,invoiceDetails);
			}
		} catch (Exception e) {
			logger.error("Exception", e);
			return false;
		} finally {
		}
		return true;
	}
	
	public TSohMstAccountInvoiceInfo createMstInvoice(InvoiceDetails invoiceDetails,TSohAccount account) {

		TSohMstAccountInvoiceInfo accountInvoiceReq = new TSohMstAccountInvoiceInfo();
		long start = System.currentTimeMillis();
		try {
			accountInvoiceReq.setDeletionStatus("N");
			accountInvoiceReq.setCreatedDate(new Timestamp(new Date().getTime()));
			accountInvoiceReq.setCreatedUserId(account.getCreatedUserId());
			accountInvoiceReq.setModifiedDate(new Timestamp(new Date().getTime()));
			accountInvoiceReq.setModifiedUserId(account.getModifiedUserId());
			accountInvoiceReq.setEmailId(invoiceDetails.getEmailId());
			accountInvoiceReq.setInvoiceNameArabic(invoiceDetails.getInvoiceNameArabic());
			accountInvoiceReq.setInvoiceNameEng(invoiceDetails.getInvoiceNameEng());
			accountInvoiceReq.setInvoiceRequiredFlag(invoiceDetails.getInvoiceRequiredFlag());
			accountInvoiceReq.setInvoiceTypeId(invoiceDetails.getInvoiceType());
			accountInvoiceReq.setMobile(invoiceDetails.getMobile());
			accountInvoiceReq.setPreferedDeliveryMode(new BigDecimal(invoiceDetails.getPreferedDeliveryMode()));
			accountInvoiceReq.setUsageClassification(null); //discuss
			em.persist(accountInvoiceReq);
			logger.info(" Mst Invoice has been inserted within " + (System.currentTimeMillis() - start) + " milliseconds");
			return accountInvoiceReq;
		}
		catch (Exception e) {
			throw e;
		}finally {
		}
	}
	
	public TSohDtlAccountInvoiceInfo createDtlInvoice(TSohMstAccountInvoiceInfo tSohMstAccountInvoiceInfo, TSohAccount account, long subReqId) {

		TSohDtlAccountInvoiceInfo accountInvoiceReq = new TSohDtlAccountInvoiceInfo();
		long start = System.currentTimeMillis();
		try {
			accountInvoiceReq.setAccountId(new BigDecimal(account.getAccountId()));
			accountInvoiceReq.setCreatedDate(new Timestamp(new Date().getTime()));
			accountInvoiceReq.setCreatedUserId(account.getCreatedUserId());
			accountInvoiceReq.setModifiedDate(new Timestamp(new Date().getTime()));
			accountInvoiceReq.setModifiedUserId(account.getModifiedUserId());
			if(subReqId!=0)
				accountInvoiceReq.setSubrequestId(new BigDecimal(subReqId));
			accountInvoiceReq.setTSohMstAccountInvoiceInfo(tSohMstAccountInvoiceInfo);
			accountInvoiceReq.setDeletionStatus("N");
			em.persist(accountInvoiceReq);
			logger.info("Dtl Invoice has been inserted within " + (System.currentTimeMillis() - start) + " milliseconds");
			return accountInvoiceReq;
		} finally {
		}
	}
	
	public TSohDtlAcctInvAttrInfo createDtlAttrInvoice(TSohMstAccountInvoiceInfo tSohMstAccountInvoiceInfo,  TSohAccount account,InvoiceDetails invoiceDetails) {

		TSohDtlAcctInvAttrInfo accountInvoiceReq = new TSohDtlAcctInvAttrInfo();
		long start = System.currentTimeMillis();
		try {			
			accountInvoiceReq.setCreatedDate(new Timestamp(new Date().getTime()));
			accountInvoiceReq.setCreatedUserId(account.getCreatedUserId());
			accountInvoiceReq.setModifiedDate(new Timestamp(new Date().getTime()));
			accountInvoiceReq.setModifiedUserId(account.getModifiedUserId());
			accountInvoiceReq.setTSohMstAccountInvoiceInfo(tSohMstAccountInvoiceInfo);
			accountInvoiceReq.setBillingAddressId(new BigDecimal(invoiceDetails.getBillingAddressId()));
			accountInvoiceReq.setDeliveryAddressId(new BigDecimal(invoiceDetails.getDeliveryAddressId()));
			accountInvoiceReq.setDetailsInvoiceFlag(invoiceDetails.getDetailsInvoiceFlag());
			accountInvoiceReq.setHideNameFlag(invoiceDetails.getHideNameFlag());
			accountInvoiceReq.setInvoiceMediaId(new BigDecimal(invoiceDetails.getInvoiceMedia()));
			accountInvoiceReq.setInvoiceTemplateId(new BigDecimal(invoiceDetails.getInvoiceTemplate()));
			accountInvoiceReq.setLanguageId(new BigDecimal(invoiceDetails.getLanguageId()));			
			accountInvoiceReq.setDeletionStatus("N");
			accountInvoiceReq.setEffFrom(new Date());
			em.persist(accountInvoiceReq);
			logger.info("Dtl Attr Invoice has been inserted within " + (System.currentTimeMillis() - start) + " milliseconds");
			return accountInvoiceReq;
		} finally {
		}
	}

}
