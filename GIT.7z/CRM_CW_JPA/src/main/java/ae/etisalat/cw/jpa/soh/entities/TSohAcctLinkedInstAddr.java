package ae.etisalat.cw.jpa.soh.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the T_SOH_ACCT_LINKED_INST_ADDR database table.
 * 
 */
@Entity
@Table(name="T_SOH_ACCT_LINKED_INST_ADDR")
@NamedQuery(name="TSohAcctLinkedInstAddr.findAll", query="SELECT t FROM TSohAcctLinkedInstAddr t")
public class TSohAcctLinkedInstAddr implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TSohAcctLinkedInstAddrPK id;

	@Column(name="CIRCUIT_POINT")
	private BigDecimal circuitPoint;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	private String point;

	//bi-directional many-to-one association to TSohAcctInstallationAddr
	@ManyToOne
	@JoinColumn(name="ACCOUNT_ADDRESS_ID",insertable = false,updatable = false)
	private TSohAcctInstallationAddr TSohAcctInstallationAddr;

	public TSohAcctLinkedInstAddr() {
	}

	public TSohAcctLinkedInstAddrPK getId() {
		return this.id;
	}

	public void setId(TSohAcctLinkedInstAddrPK id) {
		this.id = id;
	}

	public BigDecimal getCircuitPoint() {
		return this.circuitPoint;
	}

	public void setCircuitPoint(BigDecimal circuitPoint) {
		this.circuitPoint = circuitPoint;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public String getPoint() {
		return this.point;
	}

	public void setPoint(String point) {
		this.point = point;
	}

	public TSohAcctInstallationAddr getTSohAcctInstallationAddr() {
		return this.TSohAcctInstallationAddr;
	}

	public void setTSohAcctInstallationAddr(TSohAcctInstallationAddr TSohAcctInstallationAddr) {
		this.TSohAcctInstallationAddr = TSohAcctInstallationAddr;
	}

}