package ae.etisalat.cw.jpa.cms.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;


/**
 * The persistent class for the T_CMS_DTL_PARTY_SPOC_CONTACT database table.
 * 
 */
@Entity
@Table(name="T_CMS_DTL_PARTY_SPOC_CONTACT")
@NamedQuery(name="TCmsDtlPartySpocContact.findAll", query="SELECT t FROM TCmsDtlPartySpocContact t")
public class TCmsDtlPartySpocContact implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="T_CMS_DTL_PARTY_SPOC_CONTACT_PARTYSPOCID_GENERATOR", sequenceName="SQ_CMS_PARTY_SPOC_CONTACT")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_CMS_DTL_PARTY_SPOC_CONTACT_PARTYSPOCID_GENERATOR")
	@Column(name="PARTY_SPOC_ID")
	private long partySpocId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="CREATED_USER_ID")
	private String createdUserId;

	@Column(name="DELETION_STATUS")
	private String deletionStatus;

	private String email;

	@Column(name="ESCALATION_LEVEL")
	private String escalationLevel;

	private String fax;

	private String mobile1;

	private String mobile2;

	private String mobile3;

	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;

	@Column(name="MODIFIED_USER_ID")
	private String modifiedUserId;

	@Column(name="PARTY_ID")
	private BigDecimal partyId;

	@Column(name="SPOC_NAME")
	private String spocName;
	
	@Transient
	private String action;

	public TCmsDtlPartySpocContact() {
	}

	public long getPartySpocId() {
		return this.partySpocId;
	}

	public void setPartySpocId(long partySpocId) {
		this.partySpocId = partySpocId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedUserId() {
		return this.createdUserId;
	}

	public void setCreatedUserId(String createdUserId) {
		this.createdUserId = createdUserId;
	}

	public String getDeletionStatus() {
		return this.deletionStatus;
	}

	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEscalationLevel() {
		return this.escalationLevel;
	}

	public void setEscalationLevel(String escalationLevel) {
		this.escalationLevel = escalationLevel;
	}

	public String getFax() {
		return this.fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getMobile1() {
		return this.mobile1;
	}

	public void setMobile1(String mobile1) {
		this.mobile1 = mobile1;
	}

	public String getMobile2() {
		return this.mobile2;
	}

	public void setMobile2(String mobile2) {
		this.mobile2 = mobile2;
	}

	public String getMobile3() {
		return this.mobile3;
	}

	public void setMobile3(String mobile3) {
		this.mobile3 = mobile3;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedUserId() {
		return this.modifiedUserId;
	}

	public void setModifiedUserId(String modifiedUserId) {
		this.modifiedUserId = modifiedUserId;
	}

	public BigDecimal getPartyId() {
		return this.partyId;
	}

	public void setPartyId(BigDecimal partyId) {
		this.partyId = partyId;
	}

	public String getSpocName() {
		return this.spocName;
	}

	public void setSpocName(String spocName) {
		this.spocName = spocName;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

}