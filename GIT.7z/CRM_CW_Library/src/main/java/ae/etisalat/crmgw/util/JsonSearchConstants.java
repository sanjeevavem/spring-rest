package ae.etisalat.crmgw.util;

public class JsonSearchConstants {
	
	public final static String srvRegistryQry = "serviceRegistry";
	public static final String orderInfoQry = "orderInfo";
	
	public static final String request = "$.requestDetails.requestId";
	public static final String subRequest = "$.requestDetails.subRequestId";

}
