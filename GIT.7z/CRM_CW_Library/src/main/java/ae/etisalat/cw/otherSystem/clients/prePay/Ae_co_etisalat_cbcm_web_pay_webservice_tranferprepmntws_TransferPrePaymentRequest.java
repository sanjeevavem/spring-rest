/**
 * Ae_co_etisalat_cbcm_web_pay_webservice_tranferprepmntws_TransferPrePaymentRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.cw.otherSystem.clients.prePay;

public class Ae_co_etisalat_cbcm_web_pay_webservice_tranferprepmntws_TransferPrePaymentRequest  implements java.io.Serializable {
    private long subReuestId;

    private long accountId;

    private long partyId;

    public Ae_co_etisalat_cbcm_web_pay_webservice_tranferprepmntws_TransferPrePaymentRequest() {
    }

    public Ae_co_etisalat_cbcm_web_pay_webservice_tranferprepmntws_TransferPrePaymentRequest(
           long subReuestId,
           long accountId,
           long partyId) {
           this.subReuestId = subReuestId;
           this.accountId = accountId;
           this.partyId = partyId;
    }


    /**
     * Gets the subReuestId value for this Ae_co_etisalat_cbcm_web_pay_webservice_tranferprepmntws_TransferPrePaymentRequest.
     * 
     * @return subReuestId
     */
    public long getSubReuestId() {
        return subReuestId;
    }


    /**
     * Sets the subReuestId value for this Ae_co_etisalat_cbcm_web_pay_webservice_tranferprepmntws_TransferPrePaymentRequest.
     * 
     * @param subReuestId
     */
    public void setSubReuestId(long subReuestId) {
        this.subReuestId = subReuestId;
    }


    /**
     * Gets the accountId value for this Ae_co_etisalat_cbcm_web_pay_webservice_tranferprepmntws_TransferPrePaymentRequest.
     * 
     * @return accountId
     */
    public long getAccountId() {
        return accountId;
    }


    /**
     * Sets the accountId value for this Ae_co_etisalat_cbcm_web_pay_webservice_tranferprepmntws_TransferPrePaymentRequest.
     * 
     * @param accountId
     */
    public void setAccountId(long accountId) {
        this.accountId = accountId;
    }


    /**
     * Gets the partyId value for this Ae_co_etisalat_cbcm_web_pay_webservice_tranferprepmntws_TransferPrePaymentRequest.
     * 
     * @return partyId
     */
    public long getPartyId() {
        return partyId;
    }


    /**
     * Sets the partyId value for this Ae_co_etisalat_cbcm_web_pay_webservice_tranferprepmntws_TransferPrePaymentRequest.
     * 
     * @param partyId
     */
    public void setPartyId(long partyId) {
        this.partyId = partyId;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Ae_co_etisalat_cbcm_web_pay_webservice_tranferprepmntws_TransferPrePaymentRequest)) return false;
        Ae_co_etisalat_cbcm_web_pay_webservice_tranferprepmntws_TransferPrePaymentRequest other = (Ae_co_etisalat_cbcm_web_pay_webservice_tranferprepmntws_TransferPrePaymentRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.subReuestId == other.getSubReuestId() &&
            this.accountId == other.getAccountId() &&
            this.partyId == other.getPartyId();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += new Long(getSubReuestId()).hashCode();
        _hashCode += new Long(getAccountId()).hashCode();
        _hashCode += new Long(getPartyId()).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Ae_co_etisalat_cbcm_web_pay_webservice_tranferprepmntws_TransferPrePaymentRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ae.co.etisalat.cbcm.web.pay.webservice.tranferprepmntws/ITransferPayPmntWS.xsd", "ae_co_etisalat_cbcm_web_pay_webservice_tranferprepmntws_TransferPrePaymentRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subReuestId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "subReuestId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "accountId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("partyId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "partyId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
