package ae.etisalat.cw.otherSystem.clients.crc;

public class AccountSchemeAssignControllerPortTypeProxy implements ae.etisalat.cw.otherSystem.clients.crc.AccountSchemeAssignControllerPortType {
  private String _endpoint = null;
  private ae.etisalat.cw.otherSystem.clients.crc.AccountSchemeAssignControllerPortType accountSchemeAssignControllerPortType = null;
  
  public AccountSchemeAssignControllerPortTypeProxy() {
    _initAccountSchemeAssignControllerPortTypeProxy();
  }
  
  public AccountSchemeAssignControllerPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initAccountSchemeAssignControllerPortTypeProxy();
  }
  
  private void _initAccountSchemeAssignControllerPortTypeProxy() {
    try {
      accountSchemeAssignControllerPortType = (new ae.etisalat.cw.otherSystem.clients.crc.AccountSchemeAssignWebSrvLocator()).getAccountSchemeAssignControllerPort();
      if (accountSchemeAssignControllerPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)accountSchemeAssignControllerPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)accountSchemeAssignControllerPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (accountSchemeAssignControllerPortType != null)
      ((javax.xml.rpc.Stub)accountSchemeAssignControllerPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public ae.etisalat.cw.otherSystem.clients.crc.AccountSchemeAssignControllerPortType getAccountSchemeAssignControllerPortType() {
    if (accountSchemeAssignControllerPortType == null)
      _initAccountSchemeAssignControllerPortTypeProxy();
    return accountSchemeAssignControllerPortType;
  }
  
  public ae.etisalat.cw.otherSystem.clients.crc.AccountSchemeAssignResponse performAccountSchemeAssignResponse(ae.etisalat.cw.otherSystem.clients.crc.AccountSchemeAssignRequest accountSchemeAssignRequest) throws java.rmi.RemoteException{
    if (accountSchemeAssignControllerPortType == null)
      _initAccountSchemeAssignControllerPortTypeProxy();
    return accountSchemeAssignControllerPortType.performAccountSchemeAssignResponse(accountSchemeAssignRequest);
  }
  
  
}