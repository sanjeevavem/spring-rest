
package ae.etisalat.cw.restws.clients;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AdditionalInfoList {

    @SerializedName("additonalInfoDtlList")
    @Expose
    private List<AdditonalInfoDtlList> additonalInfoDtlList = null;
    @SerializedName("type")
    @Expose
    private String type;

    public List<AdditonalInfoDtlList> getAdditonalInfoDtlList() {
        return additonalInfoDtlList;
    }

    public void setAdditonalInfoDtlList(List<AdditonalInfoDtlList> additonalInfoDtlList) {
        this.additonalInfoDtlList = additonalInfoDtlList;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

}
