
package ae.etisalat.cw.restws.clients;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ProductSpecTypeAdditionalList {

    @SerializedName("productSpecInfoList")
    @Expose
    private List<ProductSpecInfoList> productSpecInfoList = null;
    @SerializedName("type")
    @Expose
    private String type;

    public List<ProductSpecInfoList> getProductSpecInfoList() {
        return productSpecInfoList;
    }

    public void setProductSpecInfoList(List<ProductSpecInfoList> productSpecInfoList) {
        this.productSpecInfoList = productSpecInfoList;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

}
