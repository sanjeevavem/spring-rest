
package ae.etisalat.cw.restws.clients;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PaymentTypeInfo {

    @SerializedName("paymentType")
    @Expose
    private String paymentType;
    @SerializedName("paymentTypeInfoList")
    @Expose
    private List<PaymentTypeInfoList> paymentTypeInfoList = null;

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public List<PaymentTypeInfoList> getPaymentTypeInfoList() {
        return paymentTypeInfoList;
    }

    public void setPaymentTypeInfoList(List<PaymentTypeInfoList> paymentTypeInfoList) {
        this.paymentTypeInfoList = paymentTypeInfoList;
    }

}
