package ae.etisalat.cw.otherSystem.clients.prePay;

public class TransferPrePaymentControllerPortTypeProxy implements ae.etisalat.cw.otherSystem.clients.prePay.TransferPrePaymentControllerPortType {
  private String _endpoint = null;
  private ae.etisalat.cw.otherSystem.clients.prePay.TransferPrePaymentControllerPortType transferPrePaymentControllerPortType = null;
  
  public TransferPrePaymentControllerPortTypeProxy() {
    _initTransferPrePaymentControllerPortTypeProxy();
  }
  
  public TransferPrePaymentControllerPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initTransferPrePaymentControllerPortTypeProxy();
  }
  
  private void _initTransferPrePaymentControllerPortTypeProxy() {
    try {
      transferPrePaymentControllerPortType = (new ae.etisalat.cw.otherSystem.clients.prePay.TransferPayPmntWSLocator()).getTransferPrePaymentControllerPort();
      if (transferPrePaymentControllerPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)transferPrePaymentControllerPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)transferPrePaymentControllerPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (transferPrePaymentControllerPortType != null)
      ((javax.xml.rpc.Stub)transferPrePaymentControllerPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public ae.etisalat.cw.otherSystem.clients.prePay.TransferPrePaymentControllerPortType getTransferPrePaymentControllerPortType() {
    if (transferPrePaymentControllerPortType == null)
      _initTransferPrePaymentControllerPortTypeProxy();
    return transferPrePaymentControllerPortType;
  }
  
  public Ae_co_etisalat_cbcm_web_pay_webservice_tranferprepmntws_TransferPrePaymentResponse performTransferPrePaymentResponse(Ae_co_etisalat_cbcm_web_pay_webservice_tranferprepmntws_TransferPrePaymentRequest transferPrePaymentRequest) throws java.rmi.RemoteException{
    if (transferPrePaymentControllerPortType == null)
      _initTransferPrePaymentControllerPortTypeProxy();
    return transferPrePaymentControllerPortType.performTransferPrePaymentResponse(transferPrePaymentRequest);
  }
  
  
}