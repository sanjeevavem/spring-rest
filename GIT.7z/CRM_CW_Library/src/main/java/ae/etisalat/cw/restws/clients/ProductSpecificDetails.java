
package ae.etisalat.cw.restws.clients;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ProductSpecificDetails {

    @SerializedName("accountNumber")
    @Expose
    private String accountNumber;
    @SerializedName("IOTAccountDetails")
    @Expose
    private IOTAccountDetails iOTAccountDetails;
    @SerializedName("productSpecTypeAdditionalList")
    @Expose
    private List<ProductSpecTypeAdditionalList> productSpecTypeAdditionalList = null;

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public IOTAccountDetails getIOTAccountDetails() {
        return iOTAccountDetails;
    }

    public void setIOTAccountDetails(IOTAccountDetails iOTAccountDetails) {
        this.iOTAccountDetails = iOTAccountDetails;
    }

    public List<ProductSpecTypeAdditionalList> getProductSpecTypeAdditionalList() {
        return productSpecTypeAdditionalList;
    }

    public void setProductSpecTypeAdditionalList(List<ProductSpecTypeAdditionalList> productSpecTypeAdditionalList) {
        this.productSpecTypeAdditionalList = productSpecTypeAdditionalList;
    }

}
