
package ae.etisalat.cw.restws.clients;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AdditonalInfoDtlList {

    @SerializedName("infoKey")
    @Expose
    private String infoKey;
    @SerializedName("infoValue")
    @Expose
    private String infoValue;

    public String getInfoKey() {
        return infoKey;
    }

    public void setInfoKey(String infoKey) {
        this.infoKey = infoKey;
    }

    public String getInfoValue() {
        return infoValue;
    }

    public void setInfoValue(String infoValue) {
        this.infoValue = infoValue;
    }

}
