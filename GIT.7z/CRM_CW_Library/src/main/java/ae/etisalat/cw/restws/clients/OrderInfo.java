
package ae.etisalat.cw.restws.clients;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class OrderInfo {

    @SerializedName("transactionId")
    @Expose
    private String transactionId;
    @SerializedName("channel")
    @Expose
    private String channel;
    @SerializedName("subChannel")
    @Expose
    private String subChannel;
    @SerializedName("userId")
    @Expose
    private String userId;
    @SerializedName("systemName")
    @Expose
    private String systemName;
    @SerializedName("recieved_time")
    @Expose
    private String recievedTime;
    @SerializedName("sourceSystemRefNo")
    @Expose
    private String sourceSystemRefNo;
    @SerializedName("requestId")
    @Expose
    private String requestId;
    @SerializedName("subRequestId")
    @Expose
    private String subRequestId;
    @SerializedName("productGroupCode")
    @Expose
    private String productGroupCode;
    @SerializedName("productCode")
    @Expose
    private String productCode;
    @SerializedName("orderType")
    @Expose
    private String orderType;
    @SerializedName("accountNumber")
    @Expose
    private String accountNumber;
    @SerializedName("accountSuffix")
    @Expose
    private String accountSuffix;
    @SerializedName("partyId")
    @Expose
    private String partyId;
    @SerializedName("regionName")
    @Expose
    private String regionName;
    @SerializedName("Emirate")
    @Expose
    private String emirate;
    @SerializedName("bitStreamFlag")
    @Expose
    private String bitStreamFlag;
    @SerializedName("additionalInfoList")
    @Expose
    private Object additionalInfoList;

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getSubChannel() {
        return subChannel;
    }

    public void setSubChannel(String subChannel) {
        this.subChannel = subChannel;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getSystemName() {
        return systemName;
    }

    public void setSystemName(String systemName) {
        this.systemName = systemName;
    }

    public String getRecievedTime() {
        return recievedTime;
    }

    public void setRecievedTime(String recievedTime) {
        this.recievedTime = recievedTime;
    }

    public String getSourceSystemRefNo() {
        return sourceSystemRefNo;
    }

    public void setSourceSystemRefNo(String sourceSystemRefNo) {
        this.sourceSystemRefNo = sourceSystemRefNo;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getSubRequestId() {
        return subRequestId;
    }

    public void setSubRequestId(String subRequestId) {
        this.subRequestId = subRequestId;
    }

    public String getProductGroupCode() {
        return productGroupCode;
    }

    public void setProductGroupCode(String productGroupCode) {
        this.productGroupCode = productGroupCode;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountSuffix() {
        return accountSuffix;
    }

    public void setAccountSuffix(String accountSuffix) {
        this.accountSuffix = accountSuffix;
    }

    public String getPartyId() {
        return partyId;
    }

    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }

    public String getRegionName() {
        return regionName;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }

    public String getEmirate() {
        return emirate;
    }

    public void setEmirate(String emirate) {
        this.emirate = emirate;
    }

    public String getBitStreamFlag() {
        return bitStreamFlag;
    }

    public void setBitStreamFlag(String bitStreamFlag) {
        this.bitStreamFlag = bitStreamFlag;
    }

    public Object getAdditionalInfoList() {
        return additionalInfoList;
    }

    public void setAdditionalInfoList(Object additionalInfoList) {
        this.additionalInfoList = additionalInfoList;
    }

}
