
package ae.etisalat.cw.restws.clients;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AccountInfo {

    @SerializedName("accountNumber")
    @Expose
    private String accountNumber;
    @SerializedName("accountSuffix")
    @Expose
    private String accountSuffix;
    @SerializedName("areaCode")
    @Expose
    private String areaCode;
    @SerializedName("productNumber")
    @Expose
    private String productNumber;
    @SerializedName("partyId")
    @Expose
    private String partyId;
    @SerializedName("partyProfileId")
    @Expose
    private String partyProfileId;
    @SerializedName("subTypeId")
    @Expose
    private String subTypeId;
    @SerializedName("ACCOUNT_FULL_NAME_ENG")
    @Expose
    private String aCCOUNTFULLNAMEENG;
    @SerializedName("ACCOUNT_FULL_NAME_ARABIC")
    @Expose
    private String aCCOUNTFULLNAMEARABIC;
    @SerializedName("ACCOUNT_CURRENCY_ID")
    @Expose
    private String aCCOUNTCURRENCYID;
    @SerializedName("BILL_CYCLE_ID")
    @Expose
    private String bILLCYCLEID;
    @SerializedName("SPONSOR_FLAG")
    @Expose
    private String sPONSORFLAG;
    @SerializedName("MAINTAINANCE_PRIORITY")
    @Expose
    private Integer mAINTAINANCEPRIORITY;
    @SerializedName("PAYMENT_PRIORITY")
    @Expose
    private Integer pAYMENTPRIORITY;
    @SerializedName("DOMAIN_NAME")
    @Expose
    private String dOMAINNAME;
    @SerializedName("GUIDING_ID")
    @Expose
    private String gUIDINGID;
    @SerializedName("PHY_ORG_UNIT_ID")
    @Expose
    private Integer pHYORGUNITID;
    @SerializedName("FAX_FLAG")
    @Expose
    private String fAXFLAG;
    @SerializedName("UPGRADE_COUNT")
    @Expose
    private String uPGRADECOUNT;
    @SerializedName("AUTH_PERSON_ID")
    @Expose
    private String aUTHPERSONID;
    @SerializedName("AUTH_PERSON_NAME")
    @Expose
    private String aUTHPERSONNAME;
    @SerializedName("CBCM_CATEGORY_ID")
    @Expose
    private String cBCMCATEGORYID;
    @SerializedName("BS_REQUEST_FLAG")
    @Expose
    private String bSREQUESTFLAG;
    @SerializedName("ACCESS_FLAG")
    @Expose
    private String aCCESSFLAG;
    @SerializedName("MIGRATED_FLAG")
    @Expose
    private String mIGRATEDFLAG;
    @SerializedName("MIGRATION_STATUS")
    @Expose
    private String mIGRATIONSTATUS;
    @SerializedName("VB_FLAG")
    @Expose
    private String vBFLAG;

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountSuffix() {
        return accountSuffix;
    }

    public void setAccountSuffix(String accountSuffix) {
        this.accountSuffix = accountSuffix;
    }

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }

    public String getProductNumber() {
        return productNumber;
    }

    public void setProductNumber(String productNumber) {
        this.productNumber = productNumber;
    }

    public String getPartyId() {
        return partyId;
    }

    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }

    public String getPartyProfileId() {
        return partyProfileId;
    }

    public void setPartyProfileId(String partyProfileId) {
        this.partyProfileId = partyProfileId;
    }

    public String getSubTypeId() {
        return subTypeId;
    }

    public void setSubTypeId(String subTypeId) {
        this.subTypeId = subTypeId;
    }

    public String getACCOUNTFULLNAMEENG() {
        return aCCOUNTFULLNAMEENG;
    }

    public void setACCOUNTFULLNAMEENG(String aCCOUNTFULLNAMEENG) {
        this.aCCOUNTFULLNAMEENG = aCCOUNTFULLNAMEENG;
    }

    public String getACCOUNTFULLNAMEARABIC() {
        return aCCOUNTFULLNAMEARABIC;
    }

    public void setACCOUNTFULLNAMEARABIC(String aCCOUNTFULLNAMEARABIC) {
        this.aCCOUNTFULLNAMEARABIC = aCCOUNTFULLNAMEARABIC;
    }

    public String getACCOUNTCURRENCYID() {
        return aCCOUNTCURRENCYID;
    }

    public void setACCOUNTCURRENCYID(String aCCOUNTCURRENCYID) {
        this.aCCOUNTCURRENCYID = aCCOUNTCURRENCYID;
    }

    public String getBILLCYCLEID() {
        return bILLCYCLEID;
    }

    public void setBILLCYCLEID(String bILLCYCLEID) {
        this.bILLCYCLEID = bILLCYCLEID;
    }

    public String getSPONSORFLAG() {
        return sPONSORFLAG;
    }

    public void setSPONSORFLAG(String sPONSORFLAG) {
        this.sPONSORFLAG = sPONSORFLAG;
    }

    public Integer getMAINTAINANCEPRIORITY() {
        return mAINTAINANCEPRIORITY;
    }

    public void setMAINTAINANCEPRIORITY(Integer mAINTAINANCEPRIORITY) {
        this.mAINTAINANCEPRIORITY = mAINTAINANCEPRIORITY;
    }

    public Integer getPAYMENTPRIORITY() {
        return pAYMENTPRIORITY;
    }

    public void setPAYMENTPRIORITY(Integer pAYMENTPRIORITY) {
        this.pAYMENTPRIORITY = pAYMENTPRIORITY;
    }

    public String getDOMAINNAME() {
        return dOMAINNAME;
    }

    public void setDOMAINNAME(String dOMAINNAME) {
        this.dOMAINNAME = dOMAINNAME;
    }

    public String getGUIDINGID() {
        return gUIDINGID;
    }

    public void setGUIDINGID(String gUIDINGID) {
        this.gUIDINGID = gUIDINGID;
    }

    public Integer getPHYORGUNITID() {
        return pHYORGUNITID;
    }

    public void setPHYORGUNITID(Integer pHYORGUNITID) {
        this.pHYORGUNITID = pHYORGUNITID;
    }

    public String getFAXFLAG() {
        return fAXFLAG;
    }

    public void setFAXFLAG(String fAXFLAG) {
        this.fAXFLAG = fAXFLAG;
    }

    public String getUPGRADECOUNT() {
        return uPGRADECOUNT;
    }

    public void setUPGRADECOUNT(String uPGRADECOUNT) {
        this.uPGRADECOUNT = uPGRADECOUNT;
    }

    public String getAUTHPERSONID() {
        return aUTHPERSONID;
    }

    public void setAUTHPERSONID(String aUTHPERSONID) {
        this.aUTHPERSONID = aUTHPERSONID;
    }

    public String getAUTHPERSONNAME() {
        return aUTHPERSONNAME;
    }

    public void setAUTHPERSONNAME(String aUTHPERSONNAME) {
        this.aUTHPERSONNAME = aUTHPERSONNAME;
    }

    public String getCBCMCATEGORYID() {
        return cBCMCATEGORYID;
    }

    public void setCBCMCATEGORYID(String cBCMCATEGORYID) {
        this.cBCMCATEGORYID = cBCMCATEGORYID;
    }

    public String getBSREQUESTFLAG() {
        return bSREQUESTFLAG;
    }

    public void setBSREQUESTFLAG(String bSREQUESTFLAG) {
        this.bSREQUESTFLAG = bSREQUESTFLAG;
    }

    public String getACCESSFLAG() {
        return aCCESSFLAG;
    }

    public void setACCESSFLAG(String aCCESSFLAG) {
        this.aCCESSFLAG = aCCESSFLAG;
    }

    public String getMIGRATEDFLAG() {
        return mIGRATEDFLAG;
    }

    public void setMIGRATEDFLAG(String mIGRATEDFLAG) {
        this.mIGRATEDFLAG = mIGRATEDFLAG;
    }

    public String getMIGRATIONSTATUS() {
        return mIGRATIONSTATUS;
    }

    public void setMIGRATIONSTATUS(String mIGRATIONSTATUS) {
        this.mIGRATIONSTATUS = mIGRATIONSTATUS;
    }

    public String getVBFLAG() {
        return vBFLAG;
    }

    public void setVBFLAG(String vBFLAG) {
        this.vBFLAG = vBFLAG;
    }

}
