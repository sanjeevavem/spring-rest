
package ae.etisalat.cw.restws.clients;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class InvoiceDetails {

    @SerializedName("invoiceRequiredFlag")
    @Expose
    private String invoiceRequiredFlag;
    @SerializedName("invoiceNameEng")
    @Expose
    private String invoiceNameEng;
    @SerializedName("invoiceNameArabic")
    @Expose
    private String invoiceNameArabic;
    @SerializedName("usageLimit")
    @Expose
    private String usageLimit;
    @SerializedName("emailId")
    @Expose
    private String emailId;
    @SerializedName("mobile")
    @Expose
    private String mobile;
    @SerializedName("billFlag")
    @Expose
    private String billFlag;
    @SerializedName("emailVerifyStatus")
    @Expose
    private String emailVerifyStatus;
    @SerializedName("noBillRequiredFlag")
    @Expose
    private String noBillRequiredFlag;
    @SerializedName("preferedDeliveryMode")
    @Expose
    private String preferedDeliveryMode;
    @SerializedName("preferedDeliveryModeValue")
    @Expose
    private Object preferedDeliveryModeValue;
    @SerializedName("invoiceType")
    @Expose
    private String invoiceType;
    @SerializedName("billingAddressId")
    @Expose
    private String billingAddressId;
    @SerializedName("deliveryAddressId")
    @Expose
    private String deliveryAddressId;
    @SerializedName("invoiceTemplate")
    @Expose
    private String invoiceTemplate;
    @SerializedName("hideNameFlag")
    @Expose
    private String hideNameFlag;
    @SerializedName("POBOX")
    @Expose
    private String pOBOX;
    @SerializedName("languageId")
    @Expose
    private String languageId;
    @SerializedName("invoiceMedia")
    @Expose
    private String invoiceMedia;
    @SerializedName("detailsInvoiceFlag")
    @Expose
    private String detailsInvoiceFlag;
    @SerializedName("additionalInfoList")
    @Expose
    private Object additionalInfoList;

    public String getInvoiceRequiredFlag() {
        return invoiceRequiredFlag;
    }

    public void setInvoiceRequiredFlag(String invoiceRequiredFlag) {
        this.invoiceRequiredFlag = invoiceRequiredFlag;
    }

    public String getInvoiceNameEng() {
        return invoiceNameEng;
    }

    public void setInvoiceNameEng(String invoiceNameEng) {
        this.invoiceNameEng = invoiceNameEng;
    }

    public String getInvoiceNameArabic() {
        return invoiceNameArabic;
    }

    public void setInvoiceNameArabic(String invoiceNameArabic) {
        this.invoiceNameArabic = invoiceNameArabic;
    }

    public String getUsageLimit() {
        return usageLimit;
    }

    public void setUsageLimit(String usageLimit) {
        this.usageLimit = usageLimit;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getBillFlag() {
        return billFlag;
    }

    public void setBillFlag(String billFlag) {
        this.billFlag = billFlag;
    }

    public String getEmailVerifyStatus() {
        return emailVerifyStatus;
    }

    public void setEmailVerifyStatus(String emailVerifyStatus) {
        this.emailVerifyStatus = emailVerifyStatus;
    }

    public String getNoBillRequiredFlag() {
        return noBillRequiredFlag;
    }

    public void setNoBillRequiredFlag(String noBillRequiredFlag) {
        this.noBillRequiredFlag = noBillRequiredFlag;
    }

    public String getPreferedDeliveryMode() {
        return preferedDeliveryMode;
    }

    public void setPreferedDeliveryMode(String preferedDeliveryMode) {
        this.preferedDeliveryMode = preferedDeliveryMode;
    }

    public Object getPreferedDeliveryModeValue() {
        return preferedDeliveryModeValue;
    }

    public void setPreferedDeliveryModeValue(Object preferedDeliveryModeValue) {
        this.preferedDeliveryModeValue = preferedDeliveryModeValue;
    }

    public String getInvoiceType() {
        return invoiceType;
    }

    public void setInvoiceType(String invoiceType) {
        this.invoiceType = invoiceType;
    }

    public String getBillingAddressId() {
        return billingAddressId;
    }

    public void setBillingAddressId(String billingAddressId) {
        this.billingAddressId = billingAddressId;
    }

    public String getDeliveryAddressId() {
        return deliveryAddressId;
    }

    public void setDeliveryAddressId(String deliveryAddressId) {
        this.deliveryAddressId = deliveryAddressId;
    }

    public String getInvoiceTemplate() {
        return invoiceTemplate;
    }

    public void setInvoiceTemplate(String invoiceTemplate) {
        this.invoiceTemplate = invoiceTemplate;
    }

    public String getHideNameFlag() {
        return hideNameFlag;
    }

    public void setHideNameFlag(String hideNameFlag) {
        this.hideNameFlag = hideNameFlag;
    }

    public String getPOBOX() {
        return pOBOX;
    }

    public void setPOBOX(String pOBOX) {
        this.pOBOX = pOBOX;
    }

    public String getLanguageId() {
        return languageId;
    }

    public void setLanguageId(String languageId) {
        this.languageId = languageId;
    }

    public String getInvoiceMedia() {
        return invoiceMedia;
    }

    public void setInvoiceMedia(String invoiceMedia) {
        this.invoiceMedia = invoiceMedia;
    }

    public String getDetailsInvoiceFlag() {
        return detailsInvoiceFlag;
    }

    public void setDetailsInvoiceFlag(String detailsInvoiceFlag) {
        this.detailsInvoiceFlag = detailsInvoiceFlag;
    }

    public Object getAdditionalInfoList() {
        return additionalInfoList;
    }

    public void setAdditionalInfoList(Object additionalInfoList) {
        this.additionalInfoList = additionalInfoList;
    }

}
