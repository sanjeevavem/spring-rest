/**
 * AccountSchemeAssignControllerPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.cw.otherSystem.clients.crc;

public interface AccountSchemeAssignControllerPortType extends java.rmi.Remote {
    public ae.etisalat.cw.otherSystem.clients.crc.AccountSchemeAssignResponse performAccountSchemeAssignResponse(ae.etisalat.cw.otherSystem.clients.crc.AccountSchemeAssignRequest accountSchemeAssignRequest) throws java.rmi.RemoteException;
}
