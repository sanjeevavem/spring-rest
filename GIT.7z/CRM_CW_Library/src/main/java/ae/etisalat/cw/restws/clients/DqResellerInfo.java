package ae.etisalat.cw.restws.clients;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DqResellerInfo {

	@SerializedName("directoryCode")
    @Expose
    private String directoryCode;

	public String getDirectoryCode() {
		return directoryCode;
	}

	public void setDirectoryCode(String directoryCode) {
		this.directoryCode = directoryCode;
	}
	
	
}
