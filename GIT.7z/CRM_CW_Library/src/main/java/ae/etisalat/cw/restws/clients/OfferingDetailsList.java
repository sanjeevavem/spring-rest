
package ae.etisalat.cw.restws.clients;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class OfferingDetailsList {

    @SerializedName("actionChargeTypeCode")
    @Expose
    private Object actionChargeTypeCode;
    @SerializedName("PO_CODE")
    @Expose
    private String pOCODE;
    @SerializedName("CPOP_CODE")
    @Expose
    private String cPOPCODE;
    @SerializedName("OLD_PO_CODE")
    @Expose
    private Object oLDPOCODE;
    @SerializedName("OLD_CPOP_CODE")
    @Expose
    private Object oLDCPOPCODE;
    @SerializedName("offerAction")
    @Expose
    private String offerAction;
    @SerializedName("numberOfInstances")
    @Expose
    private String numberOfInstances;
    @SerializedName("quantity")
    @Expose
    private String quantity;
    @SerializedName("deleteAccInsID")
    @Expose
    private Object deleteAccInsID;
    @SerializedName("additionalInfoList")
    @Expose
    private List<AdditionalInfoList> additionalInfoList = null;
    private boolean mainOffer;
    
    public boolean isMainOffer() {
		return mainOffer;
	}

	public void setMainOffer(boolean mainOffer) {
		this.mainOffer = mainOffer;
	}

    public Object getActionChargeTypeCode() {
        return actionChargeTypeCode;
    }

    public void setActionChargeTypeCode(Object actionChargeTypeCode) {
        this.actionChargeTypeCode = actionChargeTypeCode;
    }

    public String getPOCODE() {
        return pOCODE;
    }

    public void setPOCODE(String pOCODE) {
        this.pOCODE = pOCODE;
    }

    public String getCPOPCODE() {
        return cPOPCODE;
    }

    public void setCPOPCODE(String cPOPCODE) {
        this.cPOPCODE = cPOPCODE;
    }

    public Object getOLDPOCODE() {
        return oLDPOCODE;
    }

    public void setOLDPOCODE(Object oLDPOCODE) {
        this.oLDPOCODE = oLDPOCODE;
    }

    public Object getOLDCPOPCODE() {
        return oLDCPOPCODE;
    }

    public void setOLDCPOPCODE(Object oLDCPOPCODE) {
        this.oLDCPOPCODE = oLDCPOPCODE;
    }

    public String getOfferAction() {
        return offerAction;
    }

    public void setOfferAction(String offerAction) {
        this.offerAction = offerAction;
    }

    public String getNumberOfInstances() {
        return numberOfInstances;
    }

    public void setNumberOfInstances(String numberOfInstances) {
        this.numberOfInstances = numberOfInstances;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public Object getDeleteAccInsID() {
        return deleteAccInsID;
    }

    public void setDeleteAccInsID(Object deleteAccInsID) {
        this.deleteAccInsID = deleteAccInsID;
    }

    public List<AdditionalInfoList> getAdditionalInfoList() {
        return additionalInfoList;
    }

    public void setAdditionalInfoList(List<AdditionalInfoList> additionalInfoList) {
        this.additionalInfoList = additionalInfoList;
    }

}
