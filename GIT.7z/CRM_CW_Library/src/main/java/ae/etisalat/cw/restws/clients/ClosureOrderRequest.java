
package ae.etisalat.cw.restws.clients;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ClosureOrderRequest {

    @SerializedName("orderInfo")
    @Expose
    private OrderInfo orderInfo;
    @SerializedName("serviceRegistry ")
    @Expose
    private ServiceRegistry serviceRegistry;
    @SerializedName("additionalInfoList")
    @Expose
    private Object additionalInfoList;

    public OrderInfo getOrderInfo() {
        return orderInfo;
    }

    public void setOrderInfo(OrderInfo orderInfo) {
        this.orderInfo = orderInfo;
    }

    public ServiceRegistry getServiceRegistry() {
        return serviceRegistry;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry) {
        this.serviceRegistry = serviceRegistry;
    }

    public Object getAdditionalInfoList() {
        return additionalInfoList;
    }

    public void setAdditionalInfoList(Object additionalInfoList) {
        this.additionalInfoList = additionalInfoList;
    }

}
