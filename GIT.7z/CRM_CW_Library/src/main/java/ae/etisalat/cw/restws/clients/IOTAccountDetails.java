
package ae.etisalat.cw.restws.clients;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class IOTAccountDetails {

    @SerializedName("AccountType")
    @Expose
    private String accountType;
    @SerializedName("AdminName")
    @Expose
    private String adminName;
    @SerializedName("AdminUserName")
    @Expose
    private String adminUserName;
    @SerializedName("AdminContact")
    @Expose
    private String adminContact;
    @SerializedName("AdminEmail")
    @Expose
    private String adminEmail;
    @SerializedName("IOTInstance")
    @Expose
    private String iOTInstance;
    @SerializedName("IOTApplication")
    @Expose
    private String iOTApplication;
    @SerializedName("SIName")
    @Expose
    private String sIName;

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getAdminName() {
        return adminName;
    }

    public void setAdminName(String adminName) {
        this.adminName = adminName;
    }

    public String getAdminUserName() {
        return adminUserName;
    }

    public void setAdminUserName(String adminUserName) {
        this.adminUserName = adminUserName;
    }

    public String getAdminContact() {
        return adminContact;
    }

    public void setAdminContact(String adminContact) {
        this.adminContact = adminContact;
    }

    public String getAdminEmail() {
        return adminEmail;
    }

    public void setAdminEmail(String adminEmail) {
        this.adminEmail = adminEmail;
    }

    public String getIOTInstance() {
        return iOTInstance;
    }

    public void setIOTInstance(String iOTInstance) {
        this.iOTInstance = iOTInstance;
    }

    public String getIOTApplication() {
        return iOTApplication;
    }

    public void setIOTApplication(String iOTApplication) {
        this.iOTApplication = iOTApplication;
    }

    public String getSIName() {
        return sIName;
    }

    public void setSIName(String sIName) {
        this.sIName = sIName;
    }

}
