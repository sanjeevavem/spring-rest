/**
 * AccountSchemeAssignList.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.cw.otherSystem.clients.crc;

public class AccountSchemeAssignList  implements java.io.Serializable {
    private long schemeId;

    private long schemeCategoryId;

    public AccountSchemeAssignList() {
    }

    public AccountSchemeAssignList(
           long schemeId,
           long schemeCategoryId) {
           this.schemeId = schemeId;
           this.schemeCategoryId = schemeCategoryId;
    }


    /**
     * Gets the schemeId value for this AccountSchemeAssignList.
     * 
     * @return schemeId
     */
    public long getSchemeId() {
        return schemeId;
    }


    /**
     * Sets the schemeId value for this AccountSchemeAssignList.
     * 
     * @param schemeId
     */
    public void setSchemeId(long schemeId) {
        this.schemeId = schemeId;
    }


    /**
     * Gets the schemeCategoryId value for this AccountSchemeAssignList.
     * 
     * @return schemeCategoryId
     */
    public long getSchemeCategoryId() {
        return schemeCategoryId;
    }


    /**
     * Sets the schemeCategoryId value for this AccountSchemeAssignList.
     * 
     * @param schemeCategoryId
     */
    public void setSchemeCategoryId(long schemeCategoryId) {
        this.schemeCategoryId = schemeCategoryId;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AccountSchemeAssignList)) return false;
        AccountSchemeAssignList other = (AccountSchemeAssignList) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.schemeId == other.getSchemeId() &&
            this.schemeCategoryId == other.getSchemeCategoryId();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += new Long(getSchemeId()).hashCode();
        _hashCode += new Long(getSchemeCategoryId()).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AccountSchemeAssignList.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ae.co.etisalat.cbcm.web.crc.webservices.accountschemeassignwebsrv/IAccountSchemeAssignWebSrv.xsd", "ae_co_etisalat_cbcm_web_crc_webservices_accountschemeassignwebsrv_AccountSchemeAssignList"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("schemeId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "schemeId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("schemeCategoryId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "schemeCategoryId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
