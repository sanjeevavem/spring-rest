
package ae.etisalat.cw.restws.clients;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
 
public class ServiceRegistry {
	
    @SerializedName("accountInfo")
    @Expose
    private AccountInfo accountInfo;
    @SerializedName("invoiceDetails")
    @Expose
    private InvoiceDetails invoiceDetails;
    @SerializedName("dqResellerInfo")
    @Expose
    private DqResellerInfo dqResellerInfo;
    @SerializedName("paymentTypeInfo")
    @Expose
    private PaymentTypeInfo paymentTypeInfo;
    @SerializedName("productSpecificDetails")
    @Expose
    private ProductSpecificDetails productSpecificDetails;
    @SerializedName("offeringDetailsList")
    @Expose
    private List<OfferingDetailsList> offeringDetailsList = null;
    @SerializedName("additionalInfoList")
    @Expose
    private Object additionalInfoList;

    public AccountInfo getAccountInfo() {
        return accountInfo;
    }

    public void setAccountInfo(AccountInfo accountInfo) {
        this.accountInfo = accountInfo;
    }

    public InvoiceDetails getInvoiceDetails() {
        return invoiceDetails;
    }

    public void setInvoiceDetails(InvoiceDetails invoiceDetails) {
        this.invoiceDetails = invoiceDetails;
    }

    public PaymentTypeInfo getPaymentTypeInfo() {
        return paymentTypeInfo;
    }

    public void setPaymentTypeInfo(PaymentTypeInfo paymentTypeInfo) {
        this.paymentTypeInfo = paymentTypeInfo;
    }

    public ProductSpecificDetails getProductSpecificDetails() {
        return productSpecificDetails;
    }

    public void setProductSpecificDetails(ProductSpecificDetails productSpecificDetails) {
        this.productSpecificDetails = productSpecificDetails;
    }

    public List<OfferingDetailsList> getOfferingDetailsList() {
        return offeringDetailsList;
    }

    public void setOfferingDetailsList(List<OfferingDetailsList> offeringDetailsList) {
        this.offeringDetailsList = offeringDetailsList;
    }

    public Object getAdditionalInfoList() {
        return additionalInfoList;
    }

    public void setAdditionalInfoList(Object additionalInfoList) {
        this.additionalInfoList = additionalInfoList;
    }

	public DqResellerInfo getDqResellerInfo() {
		return dqResellerInfo;
	}

	public void setDqResellerInfo(DqResellerInfo dqResellerInfo) {
		this.dqResellerInfo = dqResellerInfo;
	}

}
