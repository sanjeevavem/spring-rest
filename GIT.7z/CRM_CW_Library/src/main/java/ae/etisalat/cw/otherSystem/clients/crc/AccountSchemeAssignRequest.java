/**
 * AccountSchemeAssignRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.cw.otherSystem.clients.crc;

public class AccountSchemeAssignRequest  implements java.io.Serializable {
    private boolean isPrimaryService;

    private long partyTypeId;

    private long partySubTypeId;

    private long ratePlanId;

    private long serviceId;

    private long regionId;

    private long orgUnitId;

    private long billingCycleFrequencyId;

    private long packageId;

    private java.lang.String stdaloneFlag;

    public AccountSchemeAssignRequest() {
    }

    public AccountSchemeAssignRequest(
           boolean isPrimaryService,
           long partyTypeId,
           long partySubTypeId,
           long ratePlanId,
           long serviceId,
           long regionId,
           long orgUnitId,
           long billingCycleFrequencyId,
           long packageId,
           java.lang.String stdaloneFlag) {
           this.isPrimaryService = isPrimaryService;
           this.partyTypeId = partyTypeId;
           this.partySubTypeId = partySubTypeId;
           this.ratePlanId = ratePlanId;
           this.serviceId = serviceId;
           this.regionId = regionId;
           this.orgUnitId = orgUnitId;
           this.billingCycleFrequencyId = billingCycleFrequencyId;
           this.packageId = packageId;
           this.stdaloneFlag = stdaloneFlag;
    }


    /**
     * Gets the isPrimaryService value for this AccountSchemeAssignRequest.
     * 
     * @return isPrimaryService
     */
    public boolean isIsPrimaryService() {
        return isPrimaryService;
    }


    /**
     * Sets the isPrimaryService value for this AccountSchemeAssignRequest.
     * 
     * @param isPrimaryService
     */
    public void setIsPrimaryService(boolean isPrimaryService) {
        this.isPrimaryService = isPrimaryService;
    }


    /**
     * Gets the partyTypeId value for this AccountSchemeAssignRequest.
     * 
     * @return partyTypeId
     */
    public long getPartyTypeId() {
        return partyTypeId;
    }


    /**
     * Sets the partyTypeId value for this AccountSchemeAssignRequest.
     * 
     * @param partyTypeId
     */
    public void setPartyTypeId(long partyTypeId) {
        this.partyTypeId = partyTypeId;
    }


    /**
     * Gets the partySubTypeId value for this AccountSchemeAssignRequest.
     * 
     * @return partySubTypeId
     */
    public long getPartySubTypeId() {
        return partySubTypeId;
    }


    /**
     * Sets the partySubTypeId value for this AccountSchemeAssignRequest.
     * 
     * @param partySubTypeId
     */
    public void setPartySubTypeId(long partySubTypeId) {
        this.partySubTypeId = partySubTypeId;
    }


    /**
     * Gets the ratePlanId value for this AccountSchemeAssignRequest.
     * 
     * @return ratePlanId
     */
    public long getRatePlanId() {
        return ratePlanId;
    }


    /**
     * Sets the ratePlanId value for this AccountSchemeAssignRequest.
     * 
     * @param ratePlanId
     */
    public void setRatePlanId(long ratePlanId) {
        this.ratePlanId = ratePlanId;
    }


    /**
     * Gets the serviceId value for this AccountSchemeAssignRequest.
     * 
     * @return serviceId
     */
    public long getServiceId() {
        return serviceId;
    }


    /**
     * Sets the serviceId value for this AccountSchemeAssignRequest.
     * 
     * @param serviceId
     */
    public void setServiceId(long serviceId) {
        this.serviceId = serviceId;
    }


    /**
     * Gets the regionId value for this AccountSchemeAssignRequest.
     * 
     * @return regionId
     */
    public long getRegionId() {
        return regionId;
    }


    /**
     * Sets the regionId value for this AccountSchemeAssignRequest.
     * 
     * @param regionId
     */
    public void setRegionId(long regionId) {
        this.regionId = regionId;
    }


    /**
     * Gets the orgUnitId value for this AccountSchemeAssignRequest.
     * 
     * @return orgUnitId
     */
    public long getOrgUnitId() {
        return orgUnitId;
    }


    /**
     * Sets the orgUnitId value for this AccountSchemeAssignRequest.
     * 
     * @param orgUnitId
     */
    public void setOrgUnitId(long orgUnitId) {
        this.orgUnitId = orgUnitId;
    }


    /**
     * Gets the billingCycleFrequencyId value for this AccountSchemeAssignRequest.
     * 
     * @return billingCycleFrequencyId
     */
    public long getBillingCycleFrequencyId() {
        return billingCycleFrequencyId;
    }


    /**
     * Sets the billingCycleFrequencyId value for this AccountSchemeAssignRequest.
     * 
     * @param billingCycleFrequencyId
     */
    public void setBillingCycleFrequencyId(long billingCycleFrequencyId) {
        this.billingCycleFrequencyId = billingCycleFrequencyId;
    }


    /**
     * Gets the packageId value for this AccountSchemeAssignRequest.
     * 
     * @return packageId
     */
    public long getPackageId() {
        return packageId;
    }


    /**
     * Sets the packageId value for this AccountSchemeAssignRequest.
     * 
     * @param packageId
     */
    public void setPackageId(long packageId) {
        this.packageId = packageId;
    }


    /**
     * Gets the stdaloneFlag value for this AccountSchemeAssignRequest.
     * 
     * @return stdaloneFlag
     */
    public java.lang.String getStdaloneFlag() {
        return stdaloneFlag;
    }


    /**
     * Sets the stdaloneFlag value for this AccountSchemeAssignRequest.
     * 
     * @param stdaloneFlag
     */
    public void setStdaloneFlag(java.lang.String stdaloneFlag) {
        this.stdaloneFlag = stdaloneFlag;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AccountSchemeAssignRequest)) return false;
        AccountSchemeAssignRequest other = (AccountSchemeAssignRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.isPrimaryService == other.isIsPrimaryService() &&
            this.partyTypeId == other.getPartyTypeId() &&
            this.partySubTypeId == other.getPartySubTypeId() &&
            this.ratePlanId == other.getRatePlanId() &&
            this.serviceId == other.getServiceId() &&
            this.regionId == other.getRegionId() &&
            this.orgUnitId == other.getOrgUnitId() &&
            this.billingCycleFrequencyId == other.getBillingCycleFrequencyId() &&
            this.packageId == other.getPackageId() &&
            ((this.stdaloneFlag==null && other.getStdaloneFlag()==null) || 
             (this.stdaloneFlag!=null &&
              this.stdaloneFlag.equals(other.getStdaloneFlag())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += (isIsPrimaryService() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += new Long(getPartyTypeId()).hashCode();
        _hashCode += new Long(getPartySubTypeId()).hashCode();
        _hashCode += new Long(getRatePlanId()).hashCode();
        _hashCode += new Long(getServiceId()).hashCode();
        _hashCode += new Long(getRegionId()).hashCode();
        _hashCode += new Long(getOrgUnitId()).hashCode();
        _hashCode += new Long(getBillingCycleFrequencyId()).hashCode();
        _hashCode += new Long(getPackageId()).hashCode();
        if (getStdaloneFlag() != null) {
            _hashCode += getStdaloneFlag().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AccountSchemeAssignRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ae.co.etisalat.cbcm.web.crc.webservices.accountschemeassignwebsrv/IAccountSchemeAssignWebSrv.xsd", "ae_co_etisalat_cbcm_web_crc_webservices_accountschemeassignwebsrv_AccountSchemeAssignRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isPrimaryService");
        elemField.setXmlName(new javax.xml.namespace.QName("", "isPrimaryService"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("partyTypeId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "partyTypeId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("partySubTypeId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "partySubTypeId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ratePlanId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ratePlanId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serviceId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "serviceId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("regionId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "regionId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orgUnitId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "orgUnitId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billingCycleFrequencyId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "billingCycleFrequencyId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("packageId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "packageId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("stdaloneFlag");
        elemField.setXmlName(new javax.xml.namespace.QName("", "stdaloneFlag"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
