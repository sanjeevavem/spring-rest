package ae.etisalat.cbcm.cw.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ae.etisalat.cbcm.cw.exception.DataAccessException;

@Repository
public class GenericDAOImpl implements GenericDAO {
	
    @Autowired
   private SessionFactory sessionFactory;
	
	@Override
	public <T> T findByPrimaryKey(Class<T> entityClass, Serializable id) throws DataAccessException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean save(Object entity) throws DataAccessException {
		// TODO Auto-generated method stub
        try {
            Session session = sessionFactory.openSession();
            session.beginTransaction();
			session.save(entity);
			session.getTransaction().commit();
            return true;
        }
        catch (HibernateException e) {
        	e.printStackTrace();
          //  throw new DataAccessException("Error in persisting entity.", e);
        }
		return false;
	}

	@Override
	public <T> List<T> findAll(Class<T> entityClass) throws DataAccessException {
		// TODO Auto-generated method stub
		return null;
	}

}
