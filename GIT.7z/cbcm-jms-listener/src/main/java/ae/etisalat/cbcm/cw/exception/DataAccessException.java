package ae.etisalat.cbcm.cw.exception;

public class DataAccessException extends Exception {

	private static final long serialVersionUID = 9192620926488954393L;

	public DataAccessException() {
        super();
    }

    public DataAccessException(String message, Throwable cause) {
        super(message, cause);
    }

    public DataAccessException(String message) {
        super(message);
    }

    public DataAccessException(Throwable cause) {
        super(cause);
}
}
