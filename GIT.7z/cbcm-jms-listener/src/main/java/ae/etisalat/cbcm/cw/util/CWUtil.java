package ae.etisalat.cbcm.cw.util;

import java.sql.Timestamp;
import java.util.Date;

public class CWUtil {
 
	public static Timestamp getSQLTimestamp() {
		return new Timestamp(new Date().getTime());
	}
}
